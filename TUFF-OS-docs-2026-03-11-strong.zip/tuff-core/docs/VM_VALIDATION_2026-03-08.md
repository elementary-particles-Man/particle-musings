# VM Validation 2026-03-08

## Build Outputs
- EFI binary: `/home/flux/.cache/tuff-core-target/x86_64-unknown-uefi/debug/tuff-core.efi`
- test disks:
  - `/home/flux/.cache/tuff-core-target/disk0.img`
  - `/home/flux/.cache/tuff-core-target/disk1.img`
  - `/home/flux/.cache/tuff-core-target/disk2.img`
- key media: `/home/flux/.cache/tuff-core-target/key_thumb.img`

## VM Configuration
- machine: `q35`
- memory: `512M`
- firmware:
  - `/usr/share/OVMF/OVMF_CODE_4M.fd`
  - `/usr/share/OVMF/OVMF_VARS_4M.fd`
- drives:
  - FAT ESP
  - `disk0.img`
  - `disk1.img`
  - `disk2.img`
  - `key_thumb.img` as USB storage
- serial: `-nographic -monitor none -serial file:<scenario>.log`

## Harness
- script: `tuff-core/run_qemu_validation.sh`
- scenarios:
  - `fresh_boot`
  - `interrupted_boot`
  - `recover_after_interrupt`
  - `degraded_boot`
  - `rm_cp_mv_boot`
  - `conflict_boot`

## Result Matrix
- `fresh_boot`: pass
  - recover mount 到達
  - `submit_normal_operation_write()` 到達
  - normal write 実行
  - metadata-critical 3N immediate verify 実行
- `interrupted_boot`: pass
  - timeout kill による forced interruption 実施
- `recover_after_interrupt`: partial pass
  - `UQ resume` 観測
  - `FileEx metadata restore succeeded before runtime continuation` 観測
  - canonical mainline path 再到達
- `degraded_boot`: pass
  - `3N degraded: only 1 matching Genesis candidate` を観測
- `rm_cp_mv_boot`: pass
  - `cp` 実データ経路完走
  - `mv target` / `mv source` 実データ経路完走
  - `rm` 実データ経路完走
  - `ReservationFailed` / `process_cycle failed` は未観測
- `conflict_boot`: pass
  - `Ambiguous target FMC truth` を観測
  - mainline write path へ進まず fail-closed

## Localized Fix Note
- `cp`/`mv` validation path の `ReservationFailed` 根因は `submit_validation_target_write()` が `prepare_runtime_write_request_for_transfer()` へ source 側 pointer を `old_lba` として渡していたこと
- `CommitCoordinator::commit_fmc()` は target FMC の current pointer と `old_lba` を照合するため、`mv` で `old_lba_mismatch` が発生していた
- 修正後は target file の registered FMC pointer を `old_lba` に使う

## Not Yet Covered In VM
- `rm/cp/mv` の外部 API から canonical mainline path を叩く end-to-end ケース
- alert consumer の外部分離 daemon ケース
