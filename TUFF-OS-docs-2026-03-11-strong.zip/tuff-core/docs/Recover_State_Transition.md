# Recover State Transition

## 前提

Layer 2 の鍵階層は以下で固定する。

- `MK`: 人間が保管する唯一の回復起点
- `OK`: `MK` から導出される所有者検証鍵
- `TKW`: `MK` から導出される `TK` 用 wrap key
- `PKW`: `MK` から導出される `PK` 用 wrap key
- `wrapped_tk`: `Enc_TKW(TK)`
- `wrapped_pk`: `Enc_PKW(PK)`

KEC は `fs_uuid`, `genesis_salt`, `kdf_params`, `mk_verifier`, `wrapped_tk`, `wrapped_pk`, `key_bundle_hash`, `policy_root_hash` を持つ。

## Recover

1. Genesis / KEC を読む
2. `key_bundle_hash` を検証
3. ユーザー入力の `MK` から `OK/TKW/PKW` を導出
4. `mk_verifier` と照合
5. `wrapped_tk`, `wrapped_pk` を復元
6. 復元した `TK/PK` を Layer 1 CSE に渡す
7. `FIC -> FMC -> Data` を走査

### Recover 成功条件

- `key_bundle_hash` 一致
- `mk_verifier` 一致
- `wrapped_tk` 復号成功
- `wrapped_pk` 復号成功
- その後の CSE 整合性検証成功

### Recover 失敗時の挙動

- `key_bundle_hash` 不一致: KEC 改ざんとみなし停止
- `mk_verifier` 不一致: 誤った `MK` とみなし沈黙
- `wrapped_tk/pk` 復号失敗: 鍵束破損または誤鍵として沈黙
- CSE 整合性失敗: 復号拒否

## Rekey

1. 現行 `MK` で `OK/TKW/PKW` を導出
2. `wrapped_tk`, `wrapped_pk` を開く
3. 新しい `MK` を入力
4. 新 `MK` から新 `OK/TKW/PKW` を導出
5. 同一の `TK/PK` を新 wrap key で再ラップ
6. `mk_verifier`, `key_bundle_hash` を更新

### Rekey の性質

- `TK/PK` 自体は変えない
- データチャンクの再暗号化は不要
- 変更対象は KEC のみ

## ForceInstall

1. 既存の Genesis / KEC を無視して新規初期化
2. 新しい `MK` と新しい `TK/PK` を生成
3. 新しい KEC を書く

### ForceInstall の結果

- 旧 `wrapped_tk/pk` とは無関係な新環境になる
- 旧データは復号不能
- Recover ではなく破壊的再初期化として扱う

## 沈黙の定義

Recover / Rekey / ForceInstall のどの経路でも、以下は明示拒否ではなく停止または上位非公開とする。

- 誤 `MK`
- 破損した `wrapped_tk/pk`
- `key_bundle_hash` 不一致
- CSE `integrity_tag` 不一致

Layer 2/Layer 1 のどこで失敗したかを攻撃者に露出しないことを優先する。
