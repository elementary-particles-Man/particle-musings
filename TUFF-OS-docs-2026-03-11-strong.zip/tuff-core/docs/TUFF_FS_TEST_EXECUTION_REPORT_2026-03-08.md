# TUFF-FS freeze-gate テスト実行結果レポート (2026-03-08)

## 1. 正本
- `tuff-core/docs/TUFF_FS_DETAILED_TEST_PLAN_2026-03-08.md`
- `tuff-core/docs/TUFF_FS_DETAILED_TEST_CASES_2026-03-08.md`
- `tuff-core/docs/TUFF_FS_TEST_EXECUTION_MATRIX_2026-03-08.md`

## 2. 実施環境
- 実施日: 2026-03-09 (JST)
- ブランチ: `feat/tuff-fs-mainline-completion-batch`
- 実行環境: ローカル Linux + QEMU + OVMF
- VMログ出力先: `/home/flux/.cache/tuff-core-target/vm-validation/`

## 3. 実施コマンド
- `cd tuff-core && cargo test --lib`
- `cd tuff-core && cargo build --target x86_64-unknown-uefi`
- `cargo build --manifest-path tools/tuff-builder/Cargo.toml --release`
- `bash tuff-core/run_qemu_validation.sh`

## 4. ケース別結果
| ケース | 結果 | 根拠 |
|---|---|---|
| TC-BLD-001 | PASS | `cargo test --lib` 成功、`75 passed; 0 failed` |
| TC-BLD-002 | PASS | UEFI build 成功 (exit 0) |
| TC-BLD-003 | PASS | builder release build 成功 (exit 0) |
| TC-BOOT-001 | PASS | `fresh_boot.log` に `STATE_RECOVER_MOUNT` |
| TC-BOOT-002 | PASS | `degraded_boot.log` に `3N degraded: only 1 matching Genesis candidate(s)` |
| TC-WRT-001 | PASS | `fresh_boot.log` に `mainline_write_path` と `Runtime data write path queued and wrote` |
| TC-WRT-002 | PASS | unitログで append系 (`append_*`) テスト通過 |
| TC-WRT-003 | PASS | unitログで `append_base_generation_mismatch_fails_closed ... ok` |
| TC-POP-001..006 | PASS | unitログで `rm/cp/mv commit/reject` 系テスト通過、VM `rm_cp_mv_boot.log` で commit 成功確認 |
| TC-POP-007..010 | PARTIAL | unitで policy差分 (`cross_hw_transfer_policy_differs_for_cp_mv_paths`) は観測済み、専用 same/cross HW VM シナリオは未整備 |
| TC-RCV (covered subset) | PASS | `interrupted_boot.log` + `recover_after_interrupt.log` で再開確認 |
| FileEX restore (recover subset) | PASS | `recover_after_interrupt.log` に `FileEx metadata restore succeeded...` |
| UQ/MQ persistence (covered subset) | PASS | `recover_after_interrupt.log` に `UQ resume:`、unitで MQ resume/persist 系テスト通過 |
| reclaim (covered subset) | PARTIAL | unitで delayed reclaim 系は通過、`TC-UQ-007` の中断注入は未整備 |
| metadata-critical same-HW 3N (covered subset) | PASS | `fresh_boot.log` 等に `metadata_3n_verify_passed` |
| multi-FMC conflict fail-closed (covered subset) | PASS | `conflict_boot.log` に `Ambiguous target FMC truth` かつ `mainline_write_path` 非到達 |
| Alert/IPC basic path (covered subset) | PASS | unitで `alert_consumer_*` 系テスト通過 |
| CSE (existing covered subset) | PASS | unitで tamper reject (`secure_processing_rejects_tampered_ciphertext_before_decrypt`) 等通過 |
| CSE plaintext grep / zeroization | NOT_READY | 実行マトリクスで未整備扱い、今回ハーネス未対応 |
| Disk Full注入 (TC-RCV-010) | NOT_READY | 専用注入導線未整備 |
| HW Flush偽装 (TC-PHY-COM-002) | NOT_READY | 専用注入導線未整備 |
| Epoch/Time anomaly (TC-TIME-*) | NOT_READY | 正本詳細未記載 |
| N/J詳細 (TC-RED/GEN/MIX) | NOT_READY | 正本詳細未記載 |

## 5. 証跡一覧
- build/unit:
  - `cargo test --lib` 実行ログ (`75 passed; 0 failed`)
  - `cargo build --target x86_64-unknown-uefi` 実行ログ
  - `cargo build --manifest-path tools/tuff-builder/Cargo.toml --release` 実行ログ
- VMログ:
  - `/home/flux/.cache/tuff-core-target/vm-validation/fresh_boot.log`
  - `/home/flux/.cache/tuff-core-target/vm-validation/interrupted_boot.log`
  - `/home/flux/.cache/tuff-core-target/vm-validation/recover_after_interrupt.log`
  - `/home/flux/.cache/tuff-core-target/vm-validation/degraded_boot.log`
  - `/home/flux/.cache/tuff-core-target/vm-validation/rm_cp_mv_boot.log`
  - `/home/flux/.cache/tuff-core-target/vm-validation/conflict_boot.log`

## 6. freeze-gate 判定
- 暫定判定: `PARTIAL (freeze未確定)`
- 理由:
  - freeze-gate の実行可能サブセットは PASS。
  - ただし正本/実行マトリクスで `NOT_READY` の必須注入系 (Disk Full, HW Flush偽装, CSE zeroization導線, same/cross HW専用VM 等) が未実施。
  - よって現時点では freeze 完了を主張しない。

## 7. 未整備ケース
- `NOT_READY`:
  - `TC-RCV-010` (Disk Full注入)
  - `TC-UQ-007` (reclaim中断注入)
  - `TC-CSE-001/003/004` の forensic/zeroization 自動導線
  - `TC-PHY-COM-002` (HW Flush偽装)
  - `TC-POP-007..010` 専用 same/cross HW VMシナリオ
  - 正本詳細未記載群: `TC-RCV-001..009`, `TC-UQ-001..006`, `TC-MC-001..005`, `TC-FMC-001..003`, `TC-ALT-001..007`, `TC-RED-001`, `TC-GEN-001`, `TC-MIX-001`, `TC-TIME-001..003`, `TC-3N-001..003`
- `NOT_RUN`:
  - 本実行スコープ外で、かつ正本詳細不足により今回着手不可の項目

## 8. 次アクション
1. `NOT_READY` 注入導線の最小整備 (Disk Full, HW Flush偽装, reclaim中断, CSE zeroization)。
2. `TC-POP-007..010` を分離観測できる VM シナリオ追加。
3. 正本「変更なし」群に最低限の手順/観測点を追記し、`NOT_READY` から `NOT_RUN`/実行可能へ移行。
