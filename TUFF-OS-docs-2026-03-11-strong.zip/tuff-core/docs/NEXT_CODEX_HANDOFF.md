# NEXT CODEX HANDOFF

- Completed 確定までの実施履歴は `tuff-core/docs/COMPLETION_HANDOFF_2026-03-09.md`
- テストフェイズ移行後の最短 handoff は `tuff-core/docs/TEST_PHASE_HANDOFF_2026-03-09.md`
- FS 主系の freeze 境界は `tuff-core/docs/TUFF_FS_FREEZE_DECISION_2026-03-08.md` を正とし、次層作業はこの判定を前提に進める

## 現在の到達点
- `cargo test --lib` 通過
- `cargo build --target x86_64-unknown-uefi` 通過
- boot 時に `Genesis -> KEC -> FIC -> FMC -> DataChunk` を読める
- FMC discovery 後、`CommitCoordinator` へ FMC replica を登録できる
- `CommitCoordinator::commit_fmc()` は `PhysicalWriteback` を生成する
- UEFI runtime は `execute_physical_writebacks()` 経由で `BlockIO::write_blocks()` を叩ける
- `verify_mldsa()` は常時成功 placeholder を廃止し、ML-DSA verify（現状は ML-DSA-44 実検証）へ置換済み
- `execute_physical_writebacks()` は write 後の再読込 + checksum 再検証を実施
- `CommitCoordinator` は `BootFlow` 所有の長寿命オブジェクトへ移動済み
- `UniqueQueueRuntime` は DataChunk 書込要求 (`enqueue_data_write`) を受け、CSE encrypt 後に runtime writeback へ流せる
  - `run_recover_mount()` の非テスト runtime 経路から `submit_runtime_data_write()` 経由で最小接続済み
  - runtime scheduler 容量は `media.last_block()` + `block_size` から 4KiB 単位へ換算して投入
  - Queue state を `UqIngesting / UqStored / HwWriting / CommitPending / Rejected` で明示
  - boot/recover で `resume_from_persisted_queue()` を実行し、fail-closed で再開判断
    - `UqIngesting`: 末尾不完全レコードのみ truncate、それ以外はエラー
    - `UqStored`: 再開キューへ再投入
    - `HwWriting`: 成功前提にせず再投入
    - `CommitPending`: readback/pointer 検証済みでない場合のみ再投入
    - `Rejected`: 再投入しない
  - backend policy を `memory-backed` / `file-backed` で保持
  - `TUFF-FS.MQ`（UEFI FS上の `\TUFF-FS.MQ`）へ queue record を encode/decode して保存/復元
  - `execute_physical_writebacks()` の readback成功結果に応じて `verified_readback` を更新
  - metadata writeback完了かつ `pending_updates` 解消時に `pointer_validated` を更新
  - 通常運用 write 入口を `submit_normal_operation_write()` として明示
    - recover path / runtime loop の両方がこの canonical path を通る
  - Rejected policy を active 化（不整合レコードは `Rejected` へ遷移）
  - `Rejected` は reason code を MQ レコードへ永続化
  - MQ 永続レコードは epoch 単位で compaction（terminal record GC + key重複の最新化）
  - `FolderStatus` + `FileExState` で N/J committed/pending 分離を active code 化
  - `commit_file_ex_pending()` / `reject_file_ex_pending()` で真実化/破棄を明示
  - append-only は `read_existing_then_overlay()` で新しい完全像を生成し J pending へ stage
  - append commit は base generation 一致を検証し、不一致時は fail-closed で reject
  - rm/cp/mv/append/N更新は `PendingOperation` モデルで統一（`Remove/CreateFromSource/MoveSource/MoveTarget/AppendOnly/NRedundancyUpdate`）
  - `InitialChunk` / `IndexChunk` は metadata-critical path として same-HW 3N direct write（queue bypass）
  - metadata-critical producer は実イベント駆動化済み
    - `InitialChunk`: `stage_n_redundancy_candidate()` 後の `FileExState`
    - `IndexChunk`: `stage_append_only_generation()` が作る `full_image`
  - metadata-critical placement は named policy `MetadataCriticalPlacementPolicy` へ昇格
    - `initial_zone_base_lba=0x2000`
    - `index_zone_base_lba=0x4000`
    - `file_slot_stride_lbas=0x40`
    - `replica_stride_lbas=0x08`
    - `file_slot_mask=0x1f`
    - safety assumption: `SameHwOnly3n / DistinctZonePerChunkKind / FixedSlotMasking`
  - `METADATA_3N_VERIFY_INTERVAL_MS=15000` で定期照合し、missing/mismatch 時は queue stop + alert IPC
  - `FileExState` は `TUFF-FS.FILEEX` を廃止し、各 FMC replica の直後 1 chunk（`fmc.start_lba + FILE_EX_METADATA_FMC_EXTENSION_OFFSET_CHUNKS * lba_per_4k`）へ保存
    - boot/recover は FMC discovery/register 後、この metadata chunk を先に restore
    - commit flow は pointer validation 後、`commit_pending_operation_with_reclaim()` 済みスナップショットを metadata area へ write+readback verify してから runtime state に反映
  - daemon-facing alert は共有メモリ ring `shared-memory:tuff.alert.ipc.v1` へ fire-and-forget 通知
    - `metadata_3n_inconsistency`
    - `queue_fault`
    - `reclaim_anomaly`
  - daemon-side consumer は同 shared-memory ring を polling し、overflow を検知して各 alert class を消費
  - `run_recover_mount()` は FIC 内の active entry を走査し、複数 FMC を `CommitCoordinator` へ登録
    - target file truth は `merge_target_meta_chunk_truth()` で明示選択
    - target として複数の異なる `meta_id` が見えた場合は fail-closed
  - `cp/mv` cross-HW policy を追加
    - same-HW: `PreserveLocalClone`
    - cross-HW: `RequireFullReplicaCopy`
    - `cp` は source 保持、`mv` は target commit 後のみ source 削除
    - active write path では cross-HW 時に source HW を exclude し、full-image payload を target HW へ流す
  - MQ 長期運用は named retention policy へ昇格
    - `keep_recent_epochs=8`
    - `retain_rejected_epochs=8`
    - `retain_verified_commit_epochs=2`
  - Rejected reason は severity を持つ
    - `IncompleteNonIngesting -> HardReject`
    - `MissingWritebackLocation -> CriticalFault`
    - `TargetDiskMismatch -> CriticalFault`
  - `freed_pending_chunk` は `reclaim_pending_list` へ遅延投入し、active reader を主信号に free-list へ handoff
    - reader tracking が無い chunk のみ `+2 epoch` fallback を使う
  - metadata-critical write 直後は immediate readback verify を 1 回実施し、その後は `METADATA_3N_VERIFY_INTERVAL_MS=15000` の periodic verify へ移行

## 今の制約
- `PqSignatureBlob` が 2420 bytes 固定のため、現状の実検証は ML-DSA-44 のみ（65/87 は `BufferTooSmall` / `InvalidFormat`）
- metadata writeback は再検証まで接続済みだが、通常運用 write/read 本流への完全統合は未了
- `CseScheduler` は `SequentialScaffold`（worker=1）であり、実並列は未実装
- TUFF-FS.MQ は recover path に加えて `run_operational_loop()` からも処理。常駐ループ全体の実運用化は継続実装が必要
- FileEX metadata は本メタ領域へ移行済み。旧 `TUFF-FS.FILEEX` への fallback は残していない
- alert consumer は同一 runtime 内の daemon-side polling まで。別プロセス daemon との外部分離は未実装
- `cp/mv` cross-HW policy は mainline write path の target/exclude/payload 構成へ反映済みだが、専用 cp/mv API からの全面起動は未了
- VM validation の `cp`/`mv` `ReservationFailed` は修正済み。根因は validation path が source 側 pointer を `old_lba` として `commit_fmc()` に渡していたこと

## VM 検証（2026-03-08）
- ハーネス: `tuff-core/run_qemu_validation.sh`
- firmware:
  - `OVMF_CODE=/usr/share/OVMF/OVMF_CODE_4M.fd`
  - `OVMF_VARS_TEMPLATE=/usr/share/OVMF/OVMF_VARS_4M.fd`
- VM 構成:
  - `q35`
  - `512M RAM`
  - FAT ESP + `disk0.img/disk1.img/disk2.img`
  - `key_thumb.img` を USB storage として接続
- pass:
  - fresh boot/recover mount
  - canonical mainline write path 到達
  - normal write 実行
  - metadata-critical 3N immediate verify
  - forced interruption 後の再 boot で `UQ resume` と `FileEx metadata restore`、mainline path 再到達
  - degraded genesis quorum 観測
  - `rm/cp/mv` の VM 実データ経路シナリオ完走
  - multi-FMC conflicting truth の VM fail-closed 観測
- 実装メモ:
  - `run_qemu_validation.sh` は `-serial file:<scenario>.log` へ変更。`mon:stdio` のリダイレクトで空ログになる回避策
  - `submit_validation_target_write()` は target FMC の registered pointer を `old_lba` に使用する
  - `rm_cp_mv_boot.log` では `commit_fmc reservation_failed` / `process_cycle failed` は未観測

## 次にやるべきこと
1. `PqSignatureBlob` 拡張（65/87長へ対応）と ML-DSA-65/87 の実検証拡張
2. `UniqueQueueRuntime` の commit/checkpoint を実 write path と接続し、Data write API を上位導線から呼び出す
3. alert consumer を外部分離 daemon へ昇格し、shared-memory ring を IPC 境界として固定する
4. `Evacuating` ディスクからの自動退避を実データ経路へ接続する
5. `CseScheduler` の実並列実装（worker 実体 + queue 分配）を行う

## TUFF-DB 前の安定化ゲート
- `cargo test --lib` と `cargo build --target x86_64-unknown-uefi` を継続通過していること
- `run_recover_mount()` が複数 FMC を登録し、target truth を曖昧性なく fail-closed で選別できること
- `FileExState` metadata restore と `PendingOperation` recover が同時に壊れず、commit truth が FMC pointer 切替にのみ依存していること
- metadata-critical `InitialChunk / IndexChunk` の same-HW 3N write と定期検証、alert IPC producer/consumer が通ること
- `cp/mv` の same-HW / cross-HW policy と MQ retention / Rejected severity が active policy として固定されていること
- 上記が満たされるまで TUFF-DB は接続しない

## FIC / File ID 移行境界
- 現時点の FS truth 境界は引き続き `FIC -> FMC pointer switch` であり、TUFF-DB を truth source にしてはならない
- File ID 軸は「FIC entry が指す file identity」を主キー候補として整理し、DB 側の別 ID 体系を先行導入しない
- `PendingOperation` / `FileExState` / metadata-critical placement は File ID を前提に読める形を維持し、TUFF-DB 接続時も commit 境界は変えない
- TUFF-DB 接続は、この境界を壊さずに FIC 改訂後の lookup/index 補助を追加する段階で初めて着手する

## 重要ルール
- CSE は I/O 境界でのみ実行
  - write: `UNIQUE Queue` 投下直前
  - read: リードプロセスでの並列復号
- 真実の確定点は **FMC pointer 切替**
- 物理 staging は commit 前は真実ではない
- `Evacuating` では新規通常 write を禁止
- `Faulted` では書込禁止

## 関連ファイル
- `src/main.rs`
- `src/engine.rs`
- `src/scheduler.rs`
- `src/evacuation.rs`
- `../docs/uq_state_machine.md`
- `docs/TUFF-Core_実装進捗_2026-03-08.md`
- `docs/TUFF-Core_PQC導入設計書.md`

## 直近コミット
- `887e43e` bridge coordinator writebacks to UEFI BlockIO
- `2dfa3f9` bridge FMC discovery into coordinator registration
- `915be05` connect FMC writeback and runtime checkpoint hooks
- `a0d39a1` persist FMC writeback through scheduler and trigger UQ checkpoints
- `0a16bf6` 4-stage CommitCoordinator and autonomous evacuation agent

## 2026-03-08 追加ハンドオフ（PC移動用）
- push 済み: `8ccf92f` (`feat/tuff-fs-mainline-completion-batch`)
- 今回変更ファイル:
  - `src/engine.rs`
  - `src/fs_structs.rs`
  - `src/main.rs`

### 今回の実装内容（事実）
- FileEX encode/decode を `FILE_EX_META_VERSION=2` に更新
  - `magic + version + length + checksum(SHA-256) + payload` 構成
  - `version=1` 互換 decode を維持
  - checksum 不一致/length 不正は fail-closed
- reader-safe reclaim の最小追跡を追加
  - `ActiveChunkRead { chunk_id, last_seen_epoch, in_flight_read_count }`
  - `ReaderTrackingState { active_readers_by_chunk }`
  - `drain_reclaim_pending_to_free_list_reader_safe()` 追加
- metadata-critical producer の空返しを解消
  - その後の実装で `pending_requests` は廃止済み
  - 現在は active write から Initial/Index request を即時生成して same-HW 3N direct write する

### いま未完（明示）
- reader-safe reclaim は最小追跡のみ（reader 実参照モデルの完全版は未実装）
- alert consumer は同一 runtime 内 polling であり、外部分離 daemon ではない
- metadata-critical placement policy は named policy 化済みだが、通常運用仕様への最終固定は継続

### 直近の検証結果
- `cd tuff-core && cargo test --lib` : pass (71 tests)
- `cd tuff-core && cargo build --target x86_64-unknown-uefi` : pass

### 次の最優先3件（固定）
1. alert consumer を外部分離 daemon へ昇格し、shared-memory ring を正式 IPC 境界にする
2. reclaim を reader 実参照ベースへ拡張（in-flight reader を含む安全判定）
3. TUFF-DB 前の安定化ゲートを満たしたうえで、FIC 改訂と File ID 軸の移行面を確定する
