# TUFF-FS 実行マトリクス (2026-03-08)

## 正本
- `docs/テスト計画書.md`
- `docs/テストケース設計書.md`

| 領域 | freeze gate | 対応TC | 実行レイヤ | 既存ハーネス/コマンド | 証跡 | 状態 |
|---|---|---|---|---|---|---|
| build/unit | 必須 | TC-BLD-001 | local | `cd tuff-core && cargo test --lib` | テストログ | 実行可 |
| UEFI build | 必須 | TC-BLD-002 | local | `cd tuff-core && cargo build --target x86_64-unknown-uefi` | ビルドログ | 実行可 |
| builder build | 必須 | TC-BLD-003 | local | `cargo build --manifest-path tools/tuff-builder/Cargo.toml --release` | ビルドログ | 実行可 |
| boot/install | 必須 | TC-BOOT-001 | VM | `tuff-core/run_qemu_validation.sh` (fresh_boot) | `fresh_boot.log` | 実行可 |
| degraded quorum | 必須 | TC-BOOT-002 | VM | `run_qemu_validation.sh` (degraded_boot) | `degraded_boot.log` | 実行可 |
| normal write | 必須 | TC-WRT-001 | VM | `run_qemu_validation.sh` (fresh_boot) | `fresh_boot.log` | 実行可 |
| append-only | 必須 | TC-WRT-002 | unit/VM | 単体ケース + VM補助 | appendログ | 一部未整備 |
| append-only mismatch | 必須 | TC-WRT-003 | unit | 既存ユニットテスト群 | unitログ | 実行可 |
| rm/cp/mv | 必須 | TC-POP-001〜006 | unit/VM | `run_qemu_validation.sh` (rm_cp_mv_boot) | `rm_cp_mv_boot.log` | 実行可 |
| rm/cp/mv same/cross HW policy | 必須 | TC-POP-007〜010 | VM | 専用シナリオ未実装 | policyログ | 未整備 |
| recover after interruption | 必須 | TC-RCV-001〜009 | VM | `run_qemu_validation.sh` (interrupted/recover) | `interrupted_boot.log`, `recover_after_interrupt.log` | 一部未整備 |
| Disk Full | 必須 | TC-RCV-010 | VM | 専用full-disk注入未実装 | 失敗/Rejectログ | 未整備 |
| FileEX restore | 必須 | (recover系) | VM | `run_qemu_validation.sh` (recover_after_interrupt) | `FileEx metadata restore succeeded...` | 実行可 |
| UQ/MQ persistence | 必須 | TC-UQ-001〜006 | VM/unit | `run_qemu_validation.sh` (recover) + unit | UQ/MQ resume/persistログ | 一部未整備 |
| reclaim | 必須 | TC-UQ-007 | VM/unit | 専用中断注入未実装 | reclaim復旧ログ | 未整備 |
| metadata-critical 3N | 必須 | TC-MC-001〜005 | VM/unit | fresh bootでverify観測、詳細ケース別途 | `metadata_3n_verify_passed` | 一部未整備 |
| multi-FMC conflict | 必須 | TC-FMC-001〜003 | VM | `run_qemu_validation.sh` (conflict_boot) | `conflict_boot.log` | 実行可(競合検知) |
| Alert/IPC | 必須 | TC-ALT-001〜007 | unit/VM | unit中心、VMでdegraded通知 | alertログ | 一部未整備 |
| CSE plaintext absence | 必須 | TC-CSE-001 | VM/forensic | disk image grep | grep結果 | 未整備(手順化要) |
| CSE tamper/fail-closed | 必須 | TC-CSE-002 | VM/unit | 改ざん注入手順未実装 | MAC失敗ログ | 未整備 |
| CSE metadata no-plaintext | 必須 | TC-CSE-003 | VM/forensic | metadata領域grep | grep結果 | 未整備 |
| CSE zeroization | 必須 | TC-CSE-004 | VM | core dump導線未実装 | dump解析ログ | 未整備 |
| N/J | 必須 | TC-RED-001, TC-GEN-001, TC-MIX-001 | VM/unit | 正本詳細未記載 | 実行ログ | 未整備 |
| Commit/Reject | 必須 | TC-PHY-REJ-001/002, TC-PHY-COM-001/002 | VM/unit | 専用障害注入は追加要 | commit/rejectログ | 一部未整備 |
| HW Flush偽装 | 必須 | TC-PHY-COM-002 | VM | 注入ドライバ未整備 | MAC/checksum失敗ログ | 未整備 |
| Epoch/Time | 必須 | TC-TIME-001〜003 | VM/unit | 正本詳細未記載 | 時刻検証ログ | 未整備 |
| 3N placement/quorum | 必須 | TC-3N-001〜003 | VM/unit | 正本詳細未記載 | 投票/配置ログ | 未整備 |

## VM scenario mapping
| VMシナリオ | 主要対応項目 |
|---|---|
| `fresh_boot` | boot/install, normal write, metadata-critical 3N |
| `interrupted_boot` | recover前提の中断位相 |
| `recover_after_interrupt` | recover, FileEX restore, UQ/MQ resume |
| `degraded_boot` | degraded quorum |
| `rm_cp_mv_boot` | rm/cp/mv commit path |
| `conflict_boot` | multi-FMC conflict fail-closed |

## freeze最小セット
- 実行可のみで freeze 判定を出さない。`未整備` または `一部未整備` 行は、専用シナリオ/注入導線の整備完了後に再実施してゲートを閉じる。
