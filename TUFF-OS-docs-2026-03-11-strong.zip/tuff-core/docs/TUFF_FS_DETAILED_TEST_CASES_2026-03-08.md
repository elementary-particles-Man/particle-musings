# TUFF-FS 詳細テスト項目一覧 (2026-03-08)

## 正本
- `docs/テスト計画書.md`
- `docs/テストケース設計書.md`

## 凡例
- 優先度: `P0`=freeze必須, `P1`=freeze準必須(正本明示だがハーネス補助が要る), `P2`=正本詳細未記載バックログ
- 期待結果は `pass / fail-closed / degraded` を明記

## freeze実施ケース
### TC-BLD-001
- テストID: TC-BLD-001
- 分類: Build/Static
- 優先度: P0
- 目的: unit test 全通
- 前提条件: Rust toolchain 利用可能
- 準備手順: `cd tuff-core`
- 入力/故障注入: `cargo test --lib`
- 実行手順: コマンド実行
- 観測ポイント: 終了コード、`test result`
- 期待結果: `pass` (0 failed)
- ログ/証跡: 実行ログ保存
- 失敗時の切り分け: 失敗テストID単位で再実行

### TC-BLD-002
- テストID: TC-BLD-002
- 分類: Build/Static
- 優先度: P0
- 目的: UEFI build 成功
- 前提条件: `x86_64-unknown-uefi` target 利用可能
- 準備手順: `cd tuff-core`
- 入力/故障注入: `cargo build --target x86_64-unknown-uefi`
- 実行手順: コマンド実行
- 観測ポイント: 終了コード
- 期待結果: `pass`
- ログ/証跡: ビルドログ
- 失敗時の切り分け: target/toolchain/linker 依存確認

### TC-BLD-003
- テストID: TC-BLD-003
- 分類: Build/Static
- 優先度: P0
- 目的: builder build 成功
- 前提条件: `tools/tuff-builder` が参照可能
- 準備手順: リポジトリルートへ移動
- 入力/故障注入: `cargo build --manifest-path tools/tuff-builder/Cargo.toml --release`
- 実行手順: コマンド実行
- 観測ポイント: 終了コード
- 期待結果: `pass`
- ログ/証跡: ビルドログ
- 失敗時の切り分け: builder依存crate、lock不整合

### TC-BOOT-001
- テストID: TC-BOOT-001
- 分類: Boot/Install
- 優先度: P0
- 目的: fresh boot 成功
- 前提条件: `tuff-core/run_qemu_validation.sh` 実行可能
- 準備手順: ハーネスで image 生成
- 入力/故障注入: fresh boot シナリオ起動
- 実行手順: `tuff-core/run_qemu_validation.sh`
- 観測ポイント: `fresh_boot.log` の `STATE_RECOVER_MOUNT`, `mainline_write_path`
- 期待結果: `pass` (runtime 到達)
- ログ/証跡: `vm-validation/fresh_boot.log`
- 失敗時の切り分け: OVMF/QEMU起動、EFI配置、builder出力

### TC-BOOT-002
- テストID: TC-BOOT-002
- 分類: Boot/Install
- 優先度: P0
- 目的: degraded quorum 観測
- 前提条件: disk corruption オプション利用可能
- 準備手順: `prepare_images --corrupt-disk 1 --corrupt-disk 2`
- 入力/故障注入: quorum 部分破壊 image で boot
- 実行手順: ハーネス degraded シナリオ実行
- 観測ポイント: `degraded_boot.log` の `3N degraded`
- 期待結果: `degraded` を観測し `silent success` なし
- ログ/証跡: `vm-validation/degraded_boot.log`
- 失敗時の切り分け: 破壊注入の適用漏れ、判定ログ有無

### TC-WRT-001
- テストID: TC-WRT-001
- 分類: canonical mainline write
- 優先度: P0
- 目的: normal write 成功
- 前提条件: fresh boot 可能
- 準備手順: boot後 write シーケンス開始
- 入力/故障注入: mainline write 実行
- 実行手順: fresh boot シナリオ内で確認
- 観測ポイント: `mainline_write_path`, `Runtime data write path queued and wrote`
- 期待結果: `pass` (`submit_normal_operation_write()` 経由 commit)
- ログ/証跡: `fresh_boot.log`
- 失敗時の切り分け: UQ投入、commit経路、FMC更新ログ

### TC-WRT-002
- テストID: TC-WRT-002
- 分類: canonical mainline write
- 優先度: P0
- 目的: append-only 成功
- 前提条件: 既存ファイル存在
- 準備手順: read→overlay 状態を作る
- 入力/故障注入: append-only 書込
- 実行手順: 対応ユニット/VMケース実行
- 観測ポイント: pending generation 生成と commit 昇格
- 期待結果: `pass`
- ログ/証跡: テストログ（append commit）
- 失敗時の切り分け: base generation、pending/current遷移

### TC-WRT-003
- テストID: TC-WRT-003
- 分類: canonical mainline write
- 優先度: P0
- 目的: append-only base mismatch fail-closed
- 前提条件: base generation 改変可能
- 準備手順: base generation を意図的にずらす
- 入力/故障注入: mismatch 状態で commit
- 実行手順: append mismatch ケース実行
- 観測ポイント: `BaseGenerationMismatch`
- 期待結果: `fail-closed` (reject、silent overwriteなし)
- ログ/証跡: エラーログ
- 失敗時の切り分け: 例外種別、overwrite痕跡有無

### TC-POP-001
- テストID: TC-POP-001
- 分類: PendingOperation
- 優先度: P0
- 目的: rm commit
- 前提条件: 対象エントリ存在
- 準備手順: remove stage
- 入力/故障注入: commit
- 実行手順: rm commit ケース実行
- 観測ポイント: ID群クリア、entry削除
- 期待結果: `pass`
- ログ/証跡: rm commit ログ
- 失敗時の切り分け: reclaim遷移、真実残存確認

### TC-POP-002
- テストID: TC-POP-002
- 分類: PendingOperation
- 優先度: P0
- 目的: rm reject
- 前提条件: remove stage済み
- 準備手順: rejectトリガ可能
- 入力/故障注入: reject
- 実行手順: rm reject ケース実行
- 観測ポイント: committed truth 維持
- 期待結果: `fail-closed` 側で `truth維持`
- ログ/証跡: rejectログ
- 失敗時の切り分け: truth消失有無

### TC-POP-003
- テストID: TC-POP-003
- 分類: PendingOperation
- 優先度: P0
- 目的: cp commit
- 前提条件: source 存在
- 準備手順: source→target 作成
- 入力/故障注入: commit
- 実行手順: cp commit ケース実行
- 観測ポイント: target committed、source保持
- 期待結果: `pass`
- ログ/証跡: cp commit ログ
- 失敗時の切り分け: source消失/target不整合

### TC-POP-004
- テストID: TC-POP-004
- 分類: PendingOperation
- 優先度: P0
- 目的: cp reject
- 前提条件: cp pending 作成済み
- 準備手順: rejectトリガ
- 入力/故障注入: reject
- 実行手順: cp reject ケース実行
- 観測ポイント: target pending破棄、source不変
- 期待結果: `fail-closed`
- ログ/証跡: cp reject ログ
- 失敗時の切り分け: pending残骸、source改変有無

### TC-POP-005
- テストID: TC-POP-005
- 分類: PendingOperation
- 優先度: P0
- 目的: mv commit
- 前提条件: source 存在
- 準備手順: MoveSource/MoveTarget stage
- 入力/故障注入: commit
- 実行手順: mv commit ケース実行
- 観測ポイント: target committed、source削除
- 期待結果: `pass`
- ログ/証跡: mv commit ログ
- 失敗時の切り分け: source残存/target不在

### TC-POP-006
- テストID: TC-POP-006
- 分類: PendingOperation
- 優先度: P0
- 目的: mv reject
- 前提条件: mv pending 作成済み
- 準備手順: rejectトリガ
- 入力/故障注入: reject
- 実行手順: mv reject ケース実行
- 観測ポイント: source維持、target破棄
- 期待結果: `fail-closed`
- ログ/証跡: mv reject ログ
- 失敗時の切り分け: source改変/target残骸

### TC-POP-007
- テストID: TC-POP-007
- 分類: PendingOperation
- 優先度: P1
- 目的: cp same-HW policy
- 前提条件: 同一HW判定条件を満たす配置
- 準備手順: same-HW cp シナリオ作成
- 入力/故障注入: cp 実行
- 実行手順: policy判定ログを有効化して実行
- 観測ポイント: local clone / pointer migration 相当の最短経路
- 期待結果: `pass`
- ログ/証跡: policy分岐ログ
- 失敗時の切り分け: cross-HW経路誤選択

### TC-POP-008
- テストID: TC-POP-008
- 分類: PendingOperation
- 優先度: P1
- 目的: cp cross-HW policy
- 前提条件: 異HW配置
- 準備手順: cross-HW cp シナリオ作成
- 入力/故障注入: cp 実行
- 実行手順: policy判定ログを有効化して実行
- 観測ポイント: transfer/write 経路選択
- 期待結果: `pass`
- ログ/証跡: policy分岐ログ
- 失敗時の切り分け: same-HW経路誤選択

### TC-POP-009
- テストID: TC-POP-009
- 分類: PendingOperation
- 優先度: P1
- 目的: mv same-HW policy
- 前提条件: 同一HW配置
- 準備手順: same-HW mv シナリオ作成
- 入力/故障注入: mv 実行
- 実行手順: policy判定ログを有効化して実行
- 観測ポイント: local clone / pointer migration 相当経路
- 期待結果: `pass`
- ログ/証跡: policy分岐ログ
- 失敗時の切り分け: cross-HW経路誤選択

### TC-POP-010
- テストID: TC-POP-010
- 分類: PendingOperation
- 優先度: P1
- 目的: mv cross-HW policy
- 前提条件: 異HW配置
- 準備手順: cross-HW mv シナリオ作成
- 入力/故障注入: mv 実行
- 実行手順: policy判定ログを有効化して実行
- 観測ポイント: transfer/write 経路選択
- 期待結果: `pass`
- ログ/証跡: policy分岐ログ
- 失敗時の切り分け: same-HW経路誤選択

### TC-RCV-010
- テストID: TC-RCV-010
- 分類: Recover/Restart
- 優先度: P0
- 目的: Disk Full時 LFS限界 fail-closed
- 前提条件: ディスク容量100%枯渇を再現可能
- 準備手順: full image 準備
- 入力/故障注入: append/new write 試行
- 実行手順: write 実行後 commit
- 観測ポイント: allocate failure、Reject、既存truth不変
- 期待結果: `fail-closed`
- ログ/証跡: エラー/Rejectログ、FMC比較
- 失敗時の切り分け: truth破壊有無、pointer更新有無

### TC-UQ-007
- テストID: TC-UQ-007
- 分類: UQ/MQ/Reclaim
- 優先度: P0
- 目的: reclaim中断復旧
- 前提条件: reclaim_pending_list 経由の解放処理中断を注入可能
- 準備手順: reclaim 実行中状態を作る
- 入力/故障注入: 電断/強制終了
- 実行手順: 再起動して復旧処理観測
- 観測ポイント: Double Free/Leak 不在、alloc map整合
- 期待結果: `pass` もしくは `fail-closed` で安全停止
- ログ/証跡: reclaim前後ログ、再起動ログ
- 失敗時の切り分け: chunk状態二重化/消失

### TC-CSE-001
- テストID: TC-CSE-001
- 分類: CSE
- 優先度: P0
- 目的: 平文不在確認
- 前提条件: 特徴的平文を書き込める
- 準備手順: 平文パターン選定
- 入力/故障注入: write後 `disk*.img` 検索
- 実行手順: grep検索
- 観測ポイント: 一致件数
- 期待結果: `pass` (0件)
- ログ/証跡: grep実行ログ
- 失敗時の切り分け: 誤検知/実漏洩切り分け

### TC-CSE-002
- テストID: TC-CSE-002
- 分類: CSE
- 優先度: P0
- 目的: 改ざん時 fail-closed
- 前提条件: chunkビット反転が可能
- 準備手順: 対象チャンク特定
- 入力/故障注入: 1bit反転後 read
- 実行手順: read要求
- 観測ポイント: MAC検証失敗、復号拒否
- 期待結果: `fail-closed`
- ログ/証跡: 改ざん操作ログ、readエラーログ
- 失敗時の切り分け: silent corruption 発生有無

### TC-CSE-003
- テストID: TC-CSE-003
- 分類: CSE
- 優先度: P0
- 目的: FileEX/metadata 平文不在
- 前提条件: メタデータ書込可能
- 準備手順: ファイル名・タグ設定
- 入力/故障注入: メタ領域検索
- 実行手順: disk image grep
- 観測ポイント: 平文一致件数
- 期待結果: `pass` (0件)
- ログ/証跡: grepログ
- 失敗時の切り分け: index領域/メタ領域の漏洩箇所特定

### TC-CSE-004
- テストID: TC-CSE-004
- 分類: CSE
- 優先度: P0
- 目的: In-memory key zeroization
- 前提条件: panic/fault誘発、core dump取得可能
- 準備手順: dump取得設定
- 入力/故障注入: I/O中にクラッシュ注入
- 実行手順: core dump 検索
- 観測ポイント: 鍵/復号平文パターン有無
- 期待結果: `pass` (残存なし)
- ログ/証跡: core dump解析ログ
- 失敗時の切り分け: zeroize漏れ領域特定

### TC-PHY-REJ-001
- テストID: TC-PHY-REJ-001
- 分類: 物理 Commit/Reject
- 優先度: P0
- 目的: 曖昧窓の即時 Reject
- 前提条件: 物理I/Oエラー注入可能
- 準備手順: write中断点設定
- 入力/故障注入: I/O error
- 実行手順: 該当操作実行
- 観測ポイント: 即時Reject、真実候補除外
- 期待結果: `fail-closed`
- ログ/証跡: I/O障害ログ、Rejectログ
- 失敗時の切り分け: 窓残留/truth昇格有無

### TC-PHY-REJ-002
- テストID: TC-PHY-REJ-002
- 分類: 物理 Commit/Reject
- 優先度: P0
- 目的: 旧窓再利用禁止
- 前提条件: Reject履歴追跡可能
- 準備手順: Reject発生させる
- 入力/故障注入: 再試行
- 実行手順: LBA割当トレース
- 観測ポイント: 新規窓割当、旧窓不使用
- 期待結果: `pass`
- ログ/証跡: 割当ログ
- 失敗時の切り分け: LBA再利用原因調査

### TC-PHY-COM-001
- テストID: TC-PHY-COM-001
- 分類: 物理 Commit/Reject
- 優先度: P0
- 目的: Commit境界原子性
- 前提条件: readback成功後の遅延/クラッシュ注入可能
- 準備手順: 注入点設定
- 入力/故障注入: readback後クラッシュ
- 実行手順: 再起動して状態確認
- 観測ポイント: FMC更新前は `CommitPending` 維持
- 期待結果: `fail-closed` (フライング真実化なし)
- ログ/証跡: commitログ、再起動ログ
- 失敗時の切り分け: pointer更新タイミング

### TC-PHY-COM-002
- テストID: TC-PHY-COM-002
- 分類: 物理 Commit/Reject
- 優先度: P0
- 目的: HW Flush偽装耐性
- 前提条件: Flush完了偽装を注入可能
- 準備手順: QEMU/ドライバ側注入設定
- 入力/故障注入: flush成功応答だが実データ未反映、直後再起動
- 実行手順: 読み込み検証
- 観測ポイント: MAC/checksum失敗、truth採用拒否
- 期待結果: `fail-closed`
- ログ/証跡: 注入ログ、再起動ログ、検証失敗ログ
- 失敗時の切り分け: silent success 有無

## 正本詳細未記載ケース (拡張QAバックログ)
- テストID: TC-RCV-001〜009 / TC-UQ-001〜006 / TC-MC-001〜005 / TC-FMC-001〜003 / TC-ALT-001〜007 / TC-RED-001 / TC-GEN-001 / TC-MIX-001 / TC-TIME-001〜003 / TC-3N-001〜003
- 分類: 各章対応
- 優先度: P2
- 目的: 正本記載の各観点検証
- 前提条件: 正本に手順・期待結果の詳細追記が必要
- 準備手順: 未定義
- 入力/故障注入: 未定義
- 実行手順: 未定義
- 観測ポイント: 未定義
- 期待結果: 未定義
- ログ/証跡: 未定義
- 失敗時の切り分け: 未定義
