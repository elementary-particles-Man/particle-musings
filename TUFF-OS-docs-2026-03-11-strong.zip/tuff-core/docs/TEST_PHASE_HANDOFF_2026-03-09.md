# TUFF-FS Test Phase Handoff 2026-03-09

## 目的
- この文書は、TUFF-FS 主系の実装完了後に後続 CODEX がテストフェイズへ入るための最短 handoff
- 実装の大工事を再開するためではなく、freeze 済み主系を前提に検証を進めるための座標を固定する

## 正本
- mainline は `tuff-core/**` と `tools/tuff-builder/**`
- freeze 境界は `tuff-core/docs/TUFF_FS_FREEZE_DECISION_2026-03-08.md` を正とする
- 現行の包括 handoff は `tuff-core/docs/NEXT_CODEX_HANDOFF.md`
- VM 検証結果は `tuff-core/docs/VM_VALIDATION_2026-03-08.md`

## 現在地
- TUFF-FS 主系は一通り完成
- freeze 判定は「ほぼ freeze 可」で固定済み
- stabilization gate は実質通過済み
- ここからは実装主導ではなく、テスト主導で進める

## 既に通っているもの
- `cargo test --lib`
- `cargo build --target x86_64-unknown-uefi`
- canonical mainline write path
- append-only
- `rm/cp/mv`
- recover
- degraded quorum
- metadata-critical same-HW 3N
- multi-FMC conflict fail-closed
- full VM validation

## 直近で潰した重要不具合
- VM validation の `cp`/`mv` `ReservationFailed`
- 根因は validation path の `old_lba` 誤導出
- `CommitCoordinator::commit_fmc()` 自体ではなく、target FMC ではなく source 側 pointer を `old_lba` に使っていたのが原因
- 修正後、`rm/cp/mv` VM シナリオは完走し、次 boot 汚染も実質解消

## テストフェイズで守ること
- freeze 境界を崩さない
- truth model を変えない
- commit 境界を変えない
- fail-closed を弱めない
- 不具合回避のための silent cleanup を入れない

## 不変条件
- Pending is candidate, not truth
- Truth changes only on explicit commit
- CommitPending requires real validation
- `InitialChunk` / `IndexChunk` remain metadata-critical same-HW 3N
- ambiguity is fail-closed

## テストフェイズの主眼
- 既存 VM シナリオの再現性確認
- recover / interruption / degraded / conflict の再確認
- 検証ログの整理
- freeze 判定を崩す regression の早期検出

## 残件の扱い
- `cp/mv` 専用 API から canonical path への全面統合
- alert consumer の外部分離 daemon 化
- これらは残件だが、FS 本体未完成を意味しない
- テストフェイズ中に触る場合も、freeze 境界を壊さない範囲に限定する

## 次層へ進む前提
- TUFF-DB / FIC 改訂は、この固定済み FS 主系を前提に行う
- FS を再設計するのではなく、固定済み truth model の上へ次層を積む

## 最初に読む順番
1. `tuff-core/docs/TUFF_FS_FREEZE_DECISION_2026-03-08.md`
2. `tuff-core/docs/NEXT_CODEX_HANDOFF.md`
3. `tuff-core/docs/VM_VALIDATION_2026-03-08.md`
4. `docs/uq_state_machine.md`
