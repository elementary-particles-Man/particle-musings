# TUFF-FS Freeze Decision 2026-03-08

## 現行 mainline
- `tuff-core/**`
- `tools/tuff-builder/**`

## 判定
- TUFF-FS 主系は **ほぼ freeze 可**
- ただし、運用完成度を上げる残件は残る
- 次層の作業は、この freeze 判定時点の FS 主系を固定前提に進める

## 通過済み stabilization gate
- canonical mainline write path が active
- append-only path が active
- `rm/cp/mv` が `PendingOperation` モデルで active
- recover path が active
- degraded quorum が観測済み
- metadata-critical `InitialChunk/IndexChunk` same-HW 3N write と verify が active
- multi-FMC conflict fail-closed が active
- VM validation が pass

## VM validation で通過した項目
- write
- append-only
- `rm/cp/mv`
- recover
- degraded quorum
- metadata-critical 3N
- multi-FMC conflict fail-closed

## 未完だが freeze を妨げない残件
- `cp/mv` 専用 API から canonical path を全面起動する統合
- alert consumer の外部分離 daemon 化

## 次層へ進む条件
- FS 主系はこの時点の mainline を固定版として扱う
- TUFF-DB 統合は、この固定版の truth model と commit 境界を変更しない
- FIC 改訂と File ID 軸の整理は、この固定版の FS 振る舞いを前提に進める

## 不変条件
- Pending is candidate, not truth
- Truth changes only on explicit commit
- CommitPending requires real validation
- `InitialChunk` / `IndexChunk` remain metadata-critical same-HW 3N
- ambiguity is fail-closed

## 補足
- 残件は FS 本体の成立条件というより、運用完成度と導線整理の項目
- 大規模な FS 主系改修を再開する段階ではない
- 以後は freeze 境界を崩さない形で上位層へ進める
