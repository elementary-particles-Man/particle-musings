# CSE Freeze Criteria

## 目的

CSE は TUFF-Core の Layer 1 として固定し、以後は量子耐性を CSE 自体へ過剰に盛り込まない。
役割は以下に限定する。

- 4KiB チャンク単位の高速秘匿
- `chunk_id` と `epoch` による位相拘束
- 再配置・ロールバック検知
- 改ざん検知
- 解析コスト増大

## Freeze 条件

以下を満たした時点で CSE の at-rest 形式を freeze candidate とみなす。

1. `cargo test --lib` が通ること
2. `cargo build --target x86_64-unknown-uefi` が通ること
3. `Genesis -> FIC -> FMC -> Data` の QEMU 成功経路が維持されること
4. `algorithm_chain` が `2/2/2/2` の family 分布を維持すること
5. 非線形層が最低 2 層含まれること
6. `integrity_tag` が phase 差分で変化し、bit flip で avalanche を示すこと
7. fixed padding が deterministic-random 化されていること
8. Encrypt-then-MAC (EtM) へ移行済みであり、暗号文 MAC の pre-verify に成功した場合のみ復号すること

## 古典耐性

Layer 1 の freeze 判定は、量子耐性ではなく古典攻撃に対する十分な耐性を基準に行う。
現行 CSE は以下を満たしている。

- `algorithm_chain` の family 分布固定
- 最低 2 層の非線形層保証
- deterministic-random padding による既知平文足場の削減
- ciphertext-based `integrity_tag`
- constant-time 比較
- tampered ciphertext を復号前に拒否する EtM

これにより、Decrypt-then-MAC に起因する「暗号の破滅原則」は解消済みである。

## 整合性検証

`integrity_tag` は平文ではなく、protected 領域の ciphertext を対象に計算する。
復号フローは以下で固定する。

1. ciphertext MAC を計算
2. `integrity_tag` と constant-time 比較
3. 一致時のみ復号
4. 不一致時は `IntegrityCheckFailed`

この条件を満たしたため、Layer 1 (CSE) は物理的な沈黙と整合性を保証する freeze 確定フェーズに到達したものとみなす。

## Freeze 後に CSE へ入れないもの

- PQ KEM の直接実装
- PQ 署名の直接実装
- 鍵配送ロジックの複雑化
- 監査署名の責務

これらは Layer 2 / Layer 3 へ分離する。

## Layer 分離

- Layer 1: CSE
- Layer 2: PQ key envelope (`ML-KEM`)
- Layer 3: PQ trust plane (`ML-DSA` / `SPHINCS+`)
