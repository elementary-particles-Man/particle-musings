# TUFF-FS 詳細テスト実施計画書 (2026-03-08)

## 1. 文書の目的
`docs/テスト計画書.md` と `docs/テストケース設計書.md` を唯一の正本として、TUFF-FS freeze 判定に使う実行可能なテスト計画へ分解する。

## 2. 正本
- `docs/テスト計画書.md`
- `docs/テストケース設計書.md`

運用ルール:
- 上記2文書のみを要求定義として扱う。
- 正本に記載のない要件は追加しない。
- 正本で「変更なし」とされ詳細が欠けるケースは、本計画では未整備として扱う。

## 3. テスト対象範囲
- `tuff-core/**`
- `tools/tuff-builder/**`
- Build/Static、Boot/Install、canonical write、PendingOperation、Recover、UQ/MQ/Reclaim、metadata-critical 3N、multi-FMC、Alert/IPC、CSE、N/J、物理 Commit/Reject、時刻/Epoch、3N Placement/Quorum

## 4. 除外範囲
- `tuffutl`
- TUFF-DB
- KAIRO-P
- 旧 TUFF-FS 系 (`retire/**`)

## 5. 環境/前提条件
- OS: Linux (QEMU 実行可能)
- 必須コマンド: `cargo`, `qemu-system-x86_64`, `timeout`, `rg`
- UEFI firmware:
  - `OVMF_CODE` (default: `/usr/share/OVMF/OVMF_CODE_4M.fd`)
  - `OVMF_VARS_TEMPLATE` (default: `/usr/share/OVMF/OVMF_VARS_4M.fd`)
- ビルド条件:
  - `cd tuff-core && cargo test --lib`
  - `cd tuff-core && cargo build --target x86_64-unknown-uefi`
  - `cargo build --manifest-path tools/tuff-builder/Cargo.toml --release`
- VMハーネス:
  - `tuff-core/run_qemu_validation.sh`
- ログ出力先:
  - `/home/flux/.cache/tuff-core-target/vm-validation/*.log`

## 6. 実施フェーズ
1. Build/Static フェーズ
2. VM 基本起動フェーズ (fresh/degraded/conflict)
3. Write/Operation フェーズ (normal/append/rm/cp/mv)
4. Recover/UQ/MQ/Reclaim フェーズ
5. Security/Integrity フェーズ (CSE、physical Commit/Reject、Epoch/Time)
6. metadata-critical 3N / multi-FMC / Alert-IPC フェーズ
7. freeze 判定フェーズ

## 7. 実施順序
正本「実施順 最終版」に合わせ、実行単位へ分解:
1. Build/unit (`TC-BLD-001/002/003`)
2. fresh boot (`TC-BOOT-001`)
3. CSE verification (`TC-CSE-001/002/003/004`)
4. normal write / append-only (`TC-WRT-001/002/003`)
5. N/J (`TC-RED-001, TC-GEN-001, TC-MIX-001`: 正本詳細未記載)
6. rm/cp/mv (`TC-POP-001` 〜 `010`)
7. 物理 Commit/Reject (`TC-PHY-REJ-001/002`, `TC-PHY-COM-001/002`)
8. 時刻/Epoch (`TC-TIME-001` 〜 `003`: 正本詳細未記載)
9. recover/電断位相差 (`TC-RCV-010` + `TC-RCV-001` 〜 `009`: 正本詳細未記載)
10. UQ/MQ/Reclaim (`TC-UQ-007` + `TC-UQ-001` 〜 `006`: 正本詳細未記載)
11. metadata-critical 3N (`TC-MC-001` 〜 `005`: 正本詳細未記載)
12. multi-FMC (`TC-FMC-001` 〜 `003`: 正本詳細未記載)
13. Alert/IPC (`TC-ALT-001` 〜 `007`: 正本詳細未記載)

## 8. 証跡採取方針
- Build/Unit 証跡:
  - 実行コマンド、終了コード、標準出力ログを `artifacts/test-logs/build/` に保存。
- VM 証跡:
  - `run_qemu_validation.sh` が生成するシナリオ別ログを保存。
  - 主要シナリオ: `fresh_boot.log`, `interrupted_boot.log`, `recover_after_interrupt.log`, `degraded_boot.log`, `rm_cp_mv_boot.log`, `conflict_boot.log`
- CSE/改ざん/平文不在:
  - ディスクイメージ (`disk*.img`) の grep 結果、改ざん前後の read 結果ログを保存。
- 失敗時:
  - 失敗ケースID、再現コマンド、直近ログ 200 行、該当イメージのハッシュを保存。

## 9. freeze判定条件
必須ゲート (正本 + freeze gate 指定):
- build/unit pass
- UEFI build pass
- builder build pass
- fresh boot/install
- normal write
- append-only
- rm/cp/mv
- recover after interruption
- FileEX restore
- UQ/MQ persistence
- delayed reclaim
- metadata-critical same-HW 3N
- multi-FMC conflict fail-closed
- CSE tamper/fail-closed
- Epoch/Time anomaly
- Alert/IPC basic path
- DR追加: HW Flush偽装 fail-closed、Disk Full fail-closed、In-memory key zeroization

禁止条件 (1件でも該当で freeze 不可):
- 曖昧状態で silent success
- 明示 commit 前の truth promotion
- 正本未定義の self-heal 前提で pass 扱い

## 10. 拡張QAバックログ
正本にIDのみあり詳細が欠けるため、freeze最小セットから分離して管理:
- `TC-RCV-001` 〜 `009`
- `TC-UQ-001` 〜 `006`
- `TC-MC-001` 〜 `005`
- `TC-FMC-001` 〜 `003`
- `TC-ALT-001` 〜 `007`
- `TC-RED-001`, `TC-GEN-001`, `TC-MIX-001`
- `TC-TIME-001` 〜 `003`
- `TC-3N-001` 〜 `003`

これらは「正本詳細が追記され次第」本計画へ同一形式で昇格する。
