# TUFF-FS インデックスチェーン + メモリキャッシュ設計

最終更新: 2026-01-30

## 目的
- フォルダ単位のインデックスチェーンで大規模ファイル数に対応する
- DICTは使わず、メモリキャッシュで検索高速化
- 起動時キャッシュとオンデマンドキャッシュを両立
- 4096B固定I/O制約を守る

## 前提
- インデックスはフォルダ単位
- サブフォルダは親フォルダのインデックスチェーンに含める
- 圧縮は速度重視（LZ4をデフォルト）
- 暗号化は AES-GCM（HW-AESがあれば優先）
- 生成物の鍵はUSB内に保存された暗号化MKから復号してRAM常駐

## JSON（USB内）
例:
```json
{
  "zip_level": 1,
  "compressor": "lz4",
  "cipher": "aes-gcm",
  "kdf": "hkdf-sha256",

  "chunk_size": 4096,
  "index_chunk_size": 4096,

  "oncachedir": [
    "/var/log",
    "/home/user"
  ],

  "cache": {
    "max_entries": 5000000,
    "evict": "round_robin"
  },

  "queue": {
    "per_hwid_depth": 1024
  }
}
```

## インデックスチェーン構造
- 1チャンク = 4096B
- フォルダ単位でチェーンを持つ
- 追記型（ログ構造）

### チャンクヘッダ（例）
- magic (4)
- version (2)
- flags (2)
- next_chunk (8)
- record_count (4)
- reserved (44)

### レコード（例）
固定長または短い可変長。
最低限:
- file_id (16 or 32)
- inode (8)
- birth_time (8)
- file_size (8)
- rand64 (8)
- data_ptr (8)  // 実データの先頭チャンク
- flags (4)

合計サイズは設計に応じて調整。

## file_id 生成
A方式（推奨）:
```
file_id = H(fs_uuid || inode || birth_time || file_size || rand64)
```
- rand64は作成時に生成しメタに保存
- 追加時にチェーン内で重複チェック
- 重複時はrand64再生成

## メモリキャッシュ
- key: file_id
- value: {chunk_id, offset, meta}
- 上限: JSONのmax_entries
- 追い出し: Round Robin
- 4096B制約は無し

### 起動時キャッシュ構築
- JSONの`oncachedir`配下フォルダのみをスキャン
- そのフォルダのチェーンからキャッシュ構築
- サブフォルダがあれば順次追従

### オンラインキャッシュ構築
- 未キャッシュのフォルダアクセス時に、そのフォルダのチェーンを読み込みキャッシュ構築

## 書き込みフロー
1) 書き込み要求を HW-ID 対応のキューに投入
2) キュー処理でインデックスに追記
3) インデックス書き込み完了後にメモリキャッシュ更新

## キュー設計
- HW-ID と 1:1 のキュー
- 深さは JSON で設定
- 深すぎるとメモリを食うため保守的な値を推奨

## 未決事項
- recordの固定長 or 可変長の確定
- チャンク再構築の最適化（スキャン高速化など）
- キャッシュ再構築時のメモリ消費見積もり

