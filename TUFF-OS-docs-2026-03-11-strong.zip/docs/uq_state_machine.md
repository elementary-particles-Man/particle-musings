# UQ/MQ State Machine (Normative)

この文書は `tuff-core` の UQ/MQ 実装に対する正規状態遷移仕様である。  
対象状態は `UqIngesting / UqStored / HwWriting / CommitPending / Rejected`。

## 状態定義
- `UqIngesting`: レコード投入中。末尾不完全レコードが発生しうる。
- `UqStored`: レコードが UQ/MQ に格納済み。HW 書込前。
- `HwWriting`: 物理書込を実行中、または結果不確定。
- `CommitPending`: 物理書込は完了済み。commit 完了待ち。
- `Rejected`: 復旧不能またはポリシー違反で拒否済み。再開対象外。

## 不変条件
- `HwWriting` の曖昧状態を成功扱いしてはならない。
- 破損レコードは fail-closed。例外は「末尾の `UqIngesting` 不完全レコード」のみで、truncate/破棄を許可。
- `CommitPending` は `verified_readback=true` かつ `pointer_validated=true` を満たすまで完了扱い不可。
- 旧 write window の再利用は禁止。
- queue が存在する間、commit 前の pending truth は queue 側を正とする。

## 復帰規則（boot/recover）
- `UqIngesting`:
  - 末尾の不完全レコードのみ truncate。
  - それ以外の不完全レコードは fail-closed。
  - 完全レコードは再投入。
- `UqStored`: 再投入。
- `HwWriting`: 成功前提にせず再投入。
- `CommitPending`:
  - `verified_readback && pointer_validated` を満たすなら完了扱いで再投入不要。
  - 満たさない場合は再投入。
- `Rejected`: 再投入しない。

## Rejected 判定（active policy）
- `complete_record=false` かつ `state != UqIngesting`
- `state in {HwWriting, CommitPending}` かつ writeback 位置（disk/lba）が未設定
- `target_disk` と `writeback_disk_id` が矛盾
- `Rejected` へ遷移したレコードは reason code を MQ レコードへ保持する
- severity は active code で分類する
  - `IncompleteNonIngesting`: `HardReject`
  - `MissingWritebackLocation`: `CriticalFault`
  - `TargetDiskMismatch`: `CriticalFault`

## MQ Retention / GC（active）
- MQ compaction は named retention policy で動く。
- 現行 default:
  - recent epoch keep: `8`
  - rejected retention: `8`
  - verified commit terminal retention: `2`
- fail-closed でない terminal record だけを対象に GC する。曖昧 record の寿命は短縮しない。

## 実装座標（現状）
- 状態型: `tuff-core/src/fs_structs.rs` (`QueueWriteState`)
- Folder/FileEX 状態型: `tuff-core/src/fs_structs.rs` (`FolderStatus`, `FileExState`)
- レコード型・復帰処理: `tuff-core/src/engine.rs`
- MQ ファイル永続（recover path）: `tuff-core/src/main.rs` (`\\TUFF-FS.MQ`)
- 常駐運用ループ入口: `tuff-core/src/main.rs` (`run_operational_loop`)
- canonical mainline write path: `tuff-core/src/main.rs` (`submit_normal_operation_write`)

## FileEX committed/pending 分離（active）
- N冗長:
  - committed: `committed_hw_id`, `committed_chunk_id`
  - pending: `pending_hw_id`, `pending_chunk_id`
- J世代:
  - current(committed): `current_epoch`, `current_chunk_id`
  - pending: `pending_epoch`, `pending_chunk_id`
- 真実化は `commit_file_ex_pending()` のみ。`reject_file_ex_pending()` は pending を破棄し committed view を維持する。

## Append-only（active）
- 既存ファイル: committed current image を読み出し、要求 payload を overlay して新しい完全像を生成。
- 新規ファイル: 空イメージから overlay して完全像を生成。
- 生成結果は in-place 書換ではなく J pending generation として stage。
- pending J には base generation（epoch/chunk）を保持し、commit 時に base 不一致なら fail-closed で reject。

## Canonical PendingOperation（active）
- `Remove`: Pending remove。commit でエントリ真実を消去、reject で committed view 維持。
- `CreateFromSource` (`cp`): target を Pending 生成。commit 後も source は保持。
- `MoveSource` + `MoveTarget` (`mv`): source pending remove と target pending create を対で扱う。commit で target確定後に source削除。
- `AppendOnly`: append-only 生成を Pending operation として扱い、J pending/current 規則へ統合。
- `NRedundancyUpdate`: 1N + 冗長更新候補を pending として扱い、commit/reject で確定/破棄。
- cross-HW policy:
  - same-HW `cp/mv`: `PreserveLocalClone`
  - cross-HW `cp/mv`: `RequireFullReplicaCopy`
  - `cp` は source を保持
  - `mv` は target commit 後に source を削除
  - active mainline path では cross-HW 時に source HW を `exclude_disks` へ入れ、full-image payload を target HW へ送る

## Metadata-Critical 3N（InitialChunk / IndexChunk）
- `InitialChunk` と `IndexChunk` は通常 UQ/MQ write path を使わず、same-HW 3N で direct write。
- event source は active flow から生成される。
  - `InitialChunk`: `stage_n_redundancy_candidate()` 後の `FileExState`
  - `IndexChunk`: `stage_append_only_generation()` が返す `full_image`
- 1回の論理 write は同一HW上 3つの replica LBA へ展開される。
- placement は hard-coded fixed policy。
  - active code では named policy `MetadataCriticalPlacementPolicy`
  - `InitialChunk`: `initial_zone_base_lba + (file_id & file_slot_mask) * file_slot_stride_lbas`
  - `IndexChunk`: `index_zone_base_lba + (file_id & file_slot_mask) * file_slot_stride_lbas`
  - replica stride: `replica_stride_lbas`
- 定期検証（hard-coded interval）で 3N 整合性を確認。
- missing replica / mismatch 検出時は HW write queue を停止し、shared-memory alert IPC へ通知して fail-closed。

## FileEX persistence / delayed reclaim（active）
- `FileExState` は `TUFF-FS.FILEEX` を使わない。
- 保存先は各 FMC replica の直後 1 chunk（`fmc.start_lba + FILE_EX_METADATA_FMC_EXTENSION_OFFSET_CHUNKS * lba_per_4k`）。
- commit flow は pointer validation 後、`commit_pending_operation_with_reclaim()` 済みスナップショットを metadata area へ write + readback verify してから runtime へ反映。
- boot/recover では FMC discovery/register 後、この metadata area から restore を試行し、破損時は fail-closed。
- `freed_pending_chunk` は即 free-list へ戻さず `reclaim_pending_list` へ投入。
- reclaim は active reader tracking を主信号に使う。
  - tracked reader があれば `in_flight_read_count==0` かつ recent guard 経過後だけ reclaim する
  - tracking が無い chunk にだけ `queued_epoch+2` fallback を使う
- reclaim anomaly（duplicate chunk / stale epoch）は alert IPC へ fire-and-forget 通知。

## FIC / File ID migration boundary（pre-TUFF-DB）
- 現行 FS の truth は `FIC -> FMC pointer switch` に固定する。TUFF-DB はこの段階では truth source ではない。
- File ID 軸は `FIC` entry が指す identity を主境界として整理し、DB 導入のために commit 境界や pointer truth を変えない。
- `PendingOperation`、`FileExState`、metadata-critical placement は File ID 前提で読める状態を維持する。
- TUFF-DB 統合は、次の安定化ゲート通過後にだけ着手する。
  - 複数 FMC recover と target truth の fail-closed 選別が安定している
  - metadata-critical 3N write / verify / alert IPC が運用導線として成立している
  - MQ retention / Rejected severity / cross-HW policy が active policy として固定されている

## 非目標（この仕様の範囲外）
- 常駐 always-on 運用ループの完全実装
- 上位統合（KAIRO-P / TUFF-DB）
