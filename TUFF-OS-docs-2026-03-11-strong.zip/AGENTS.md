# AGENTS

## 現行前提
- 旧 `TUFF-FS/tuffd/tuffctl/Buildroot/Linux` 系は参照用。主作業対象は `tuff-core/`。
- 現在の主系統は `TUFF-Core` ベアメタル Rust OS。
- 以後の実装・レビュー・引き継ぎは **TUFF-Core を正** とする。
- **応答言語は日本語**。

## 進捗まとめ（2026-03-08時点）
- `TUFF-Core` の UEFI 起動骨格を作成。
- `Genesis -> KEC -> FIC -> FMC -> DataChunk` の実読込チェーンを実装。
- `CSE` は Layer 1 として実装済み。
  - EtM（Encrypt-then-MAC）へ移行済み
  - DataChunk まで CSE 対象化済み
  - `cargo test --lib` と `cargo build --target x86_64-unknown-uefi` は通過
- `PQC` は Layer 2/3 の雛形と接続面を実装済み。
  - `KEC`
  - `KeyEnvelopeManager`
  - `BootPolicy / UpdateManifest / AuditLogEntry`
  - `ML-DSA verify` placeholder
- `MK -> WrapKey -> Wrapped TK/PK` の鍵階層へ移行済み。
- `3N` 検証、`ForceInstall / Recover / Rekey` の scaffold 実装済み。
- `HwScheduler` / `CommitCoordinator` / `UniqueQueueRuntime` / `Evacuation` を追加。
- `CommitCoordinator` は FMC pointer rewrite と metadata writeback descriptor 生成まで実装。
- UEFI runtime 側で `PhysicalWriteback -> BlockIO::write_blocks()` の橋を実装済み。

## 直近の主要コミット
- `887e43e` feat(fs): bridge coordinator writebacks to UEFI BlockIO
- `2dfa3f9` feat(fs): bridge FMC discovery into coordinator registration
- `915be05` feat(fs): connect FMC writeback and runtime checkpoint hooks
- `a0d39a1` feat(fs): persist FMC writeback through scheduler and trigger UQ checkpoints
- `0a16bf6` feat(fs): implement 4-stage CommitCoordinator and autonomous evacuation agent with 80/65 hysteresis
- `1f3c78f` feat(boot): add 3N corruption tests and lockout/silence verification
- `a72b102` feat(boot): add 3N disk simulation and implement force-install KEC rebuild
- `ad19498` feat(boot): load TUFFkey metadata and add 3N genesis verification scaffold
- `1221f49` feat(core): scaffold boot state machine and formalize UQ write path hooks
- `0b468c3` feat(cse): encrypt DataChunk and integrate parallel read path for pointer_matrix

## 現在の重要ファイル
- 実装
  - `tuff-core/src/main.rs`
  - `tuff-core/src/engine.rs`
  - `tuff-core/src/scheduler.rs`
  - `tuff-core/src/evacuation.rs`
  - `tuff-core/src/fs_structs.rs`
  - `tuff-core/src/pq/mod.rs`
  - `tuff-core/src/pq/signatures.rs`
- 設計・引き継ぎ
  - `docs/TUFF-Core_実装進捗_2026-03-08.md`
  - `tuff-core/docs/NEXT_CODEX_HANDOFF.md`
  - `docs/TUFF-Core_PQC導入設計書.md`
  - `docs/CSE基本設計書.md`
  - `docs/量子耐性向上と残存脆弱性.md`
  - `tuff-core/docs/cse_freeze_criteria.md`
  - `tuff-core/docs/Recover_State_Transition.md`

## 今の到達点
- boot 時の FMC discovery から `CommitCoordinator` への FMC replica 登録は接続済み。
- `CommitCoordinator::commit_fmc()` は
  - FMC buffer 更新
  - checksum 再計算
  - metadata writeback descriptor 生成
  - UEFI `BlockIO::write_blocks()` 橋渡し
 まで通る。
- ただし「通常運用の epoch commit が常時走る本流」に fully 統合した段階ではない。

## 次の自然タスク
1. `registered_fmcs` を target file 1 本から複数 FMC に拡張
2. `CommitCoordinator` を boot ローカル変数ではなく runtime 長寿命オブジェクトへ昇格
3. metadata writeback 後の再読込・checksum 再検証
4. `UniqueQueueRuntime` を実際の write/read 本流へ正式接続
5. `Evacuating` ディスクの自動退避を実データ経路に接続

## ビルド確認
- `cd tuff-core && cargo test --lib`
- `cd tuff-core && cargo build --target x86_64-unknown-uefi`

## 作業ルール
- 旧 Linux ユーザー空間実装へ巻き戻さない。
- `CSE` は I/O 境界でだけ使う。
  - write: `UNIQUE Queue` 投下直前
  - read: リードプロセスでの並列復号
- 真実の確定点は **FMC pointer 切替**。物理 staging は commit 前は未確定。
