use std::collections::{HashMap, VecDeque};
use log::{debug, info};
use crate::fs::config::CacheConfig;
use crate::fs::record::IndexRecord;

/// Memory Cache for Index Records (FIFO eviction)
pub struct IndexCache {
    map: HashMap<[u8; 16], IndexRecord>,
    queue: VecDeque<[u8; 16]>,
    config: CacheConfig,
}

impl IndexCache {
    pub fn new(config: CacheConfig) -> Self {
        let cap = config.max_entries.max(1);
        info!("IndexCache init: max_entries={}, evict={}", config.max_entries, config.evict);
        Self {
            map: HashMap::with_capacity(cap),
            queue: VecDeque::with_capacity(cap),
            config,
        }
    }

    pub fn get(&self, file_id: &[u8; 16]) -> Option<IndexRecord> {
        self.map.get(file_id).copied()
    }

    pub fn insert(&mut self, record: IndexRecord) {
        if self.config.max_entries == 0 {
            return;
        }

        if self.map.contains_key(&record.file_id) {
            // FIFO: update data only, do not change queue order.
            self.map.insert(record.file_id, record);
            return;
        }

        if self.queue.len() >= self.config.max_entries {
            if let Some(evicted_id) = self.queue.pop_front() {
                self.map.remove(&evicted_id);
                debug!("Cache eviction (FIFO): {:?}", evicted_id);
            }
        }

        self.queue.push_back(record.file_id);
        self.map.insert(record.file_id, record);
    }

    pub fn len(&self) -> usize {
        self.map.len()
    }
}
