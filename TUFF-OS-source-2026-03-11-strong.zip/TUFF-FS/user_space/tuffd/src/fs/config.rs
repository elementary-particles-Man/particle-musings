use serde::{Deserialize, Serialize};
use std::fs::File;
use std::io::{self, Read};
use std::path::Path;

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct TuffConfig {
    #[serde(default = "default_zip_level")]
    pub zip_level: u8,
    #[serde(default = "default_compressor")]
    pub compressor: String,
    #[serde(default = "default_cipher")]
    pub cipher: String,
    #[serde(default = "default_kdf")]
    pub kdf: String,

    #[serde(default = "default_chunk_size")]
    pub chunk_size: u64,
    #[serde(default = "default_chunk_size")]
    pub index_chunk_size: u64,

    #[serde(default)]
    pub oncachedir: Vec<String>,

    #[serde(default)]
    pub cache: CacheConfig,
    #[serde(default)]
    pub queue: QueueConfig,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct CacheConfig {
    #[serde(default = "default_max_entries")]
    pub max_entries: usize,
    #[serde(default = "default_evict_policy")]
    pub evict: String, // "fifo" or "round_robin"
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct QueueConfig {
    #[serde(default = "default_queue_depth")]
    pub per_hwid_depth: usize,
}

impl Default for CacheConfig {
    fn default() -> Self {
        Self {
            max_entries: default_max_entries(),
            evict: default_evict_policy(),
        }
    }
}

impl Default for QueueConfig {
    fn default() -> Self {
        Self {
            per_hwid_depth: default_queue_depth(),
        }
    }
}

impl Default for TuffConfig {
    fn default() -> Self {
        Self {
            zip_level: default_zip_level(),
            compressor: default_compressor(),
            cipher: default_cipher(),
            kdf: default_kdf(),
            chunk_size: default_chunk_size(),
            index_chunk_size: default_chunk_size(),
            oncachedir: Vec::new(),
            cache: CacheConfig::default(),
            queue: QueueConfig::default(),
        }
    }
}

impl TuffConfig {
    pub fn load_from_file<P: AsRef<Path>>(path: P) -> io::Result<Self> {
        let mut file = File::open(path)?;
        let mut buf = String::new();
        file.read_to_string(&mut buf)?;
        let cfg: TuffConfig = serde_json::from_str(&buf)
            .map_err(|e| io::Error::new(io::ErrorKind::InvalidData, e))?;
        Ok(cfg)
    }
}

// Defaults
fn default_zip_level() -> u8 { 1 }
fn default_compressor() -> String { "lz4".to_string() }
fn default_cipher() -> String { "aes-gcm".to_string() }
fn default_kdf() -> String { "hkdf-sha256".to_string() }
fn default_chunk_size() -> u64 { 4096 }
fn default_max_entries() -> usize { 1_000_000 }
fn default_evict_policy() -> String { "fifo".to_string() }
fn default_queue_depth() -> usize { 1024 }
