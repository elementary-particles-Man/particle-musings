use serde::{Deserialize, Serialize};

pub const FILE_ID_LEN: usize = 16;
pub const INDEX_RECORD_LEN: usize = 72;

/// Fixed-length index record (disk/in-memory compatible).
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
pub struct IndexRecord {
    pub file_id: [u8; FILE_ID_LEN],
    pub inode: u64,
    pub birth_time: u64,
    pub size: u64,
    pub rand64: u64,
    pub start_chunk_id: u64,
    pub mtime: i64,
    pub mode: u32,
    pub flags: u32,
}

impl IndexRecord {
    pub fn new(
        file_id: [u8; FILE_ID_LEN],
        inode: u64,
        birth_time: u64,
        size: u64,
        rand64: u64,
        start_chunk_id: u64,
        mtime: i64,
        mode: u32,
        flags: u32,
    ) -> Self {
        Self {
            file_id,
            inode,
            birth_time,
            size,
            rand64,
            start_chunk_id,
            mtime,
            mode,
            flags,
        }
    }

    pub fn to_bytes(self) -> [u8; INDEX_RECORD_LEN] {
        let mut out = [0u8; INDEX_RECORD_LEN];
        let mut off = 0usize;

        out[off..off + FILE_ID_LEN].copy_from_slice(&self.file_id);
        off += FILE_ID_LEN;

        out[off..off + 8].copy_from_slice(&self.inode.to_le_bytes());
        off += 8;
        out[off..off + 8].copy_from_slice(&self.birth_time.to_le_bytes());
        off += 8;
        out[off..off + 8].copy_from_slice(&self.size.to_le_bytes());
        off += 8;
        out[off..off + 8].copy_from_slice(&self.rand64.to_le_bytes());
        off += 8;
        out[off..off + 8].copy_from_slice(&self.start_chunk_id.to_le_bytes());
        off += 8;
        out[off..off + 8].copy_from_slice(&self.mtime.to_le_bytes());
        off += 8;
        out[off..off + 4].copy_from_slice(&self.mode.to_le_bytes());
        off += 4;
        out[off..off + 4].copy_from_slice(&self.flags.to_le_bytes());

        out
    }

    pub fn from_bytes(buf: &[u8; INDEX_RECORD_LEN]) -> Self {
        let mut off = 0usize;
        let mut file_id = [0u8; FILE_ID_LEN];
        file_id.copy_from_slice(&buf[off..off + FILE_ID_LEN]);
        off += FILE_ID_LEN;

        let inode = u64::from_le_bytes(buf[off..off + 8].try_into().unwrap());
        off += 8;
        let birth_time = u64::from_le_bytes(buf[off..off + 8].try_into().unwrap());
        off += 8;
        let size = u64::from_le_bytes(buf[off..off + 8].try_into().unwrap());
        off += 8;
        let rand64 = u64::from_le_bytes(buf[off..off + 8].try_into().unwrap());
        off += 8;
        let start_chunk_id = u64::from_le_bytes(buf[off..off + 8].try_into().unwrap());
        off += 8;
        let mtime = i64::from_le_bytes(buf[off..off + 8].try_into().unwrap());
        off += 8;
        let mode = u32::from_le_bytes(buf[off..off + 4].try_into().unwrap());
        off += 4;
        let flags = u32::from_le_bytes(buf[off..off + 4].try_into().unwrap());

        Self {
            file_id,
            inode,
            birth_time,
            size,
            rand64,
            start_chunk_id,
            mtime,
            mode,
            flags,
        }
    }
}
