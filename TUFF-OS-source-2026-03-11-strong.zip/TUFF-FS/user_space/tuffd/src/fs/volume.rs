use std::fs::{self, File};
use std::io::{Read, Seek, SeekFrom};
use std::path::Path;

use anyhow::{Context, Result};
use log::{debug, info, warn};

use crate::crypto::{derive_mk, try_decrypt};
use flatbuffers::root;
use tuff_schemas::tuff::tuff_os;

// Layout constants
const SECTOR_SIZE: u64 = 4096;
const INITIAL_CHUNK_OFFSET: u64 = 0;
const ROOT_INDEX_START: u64 = SECTOR_SIZE; // LBA 1
const ROOT_INDEX_SLOTS: u64 = 256; // 8-bit generation ring

#[derive(Debug)]
pub struct TuffVolume {
    pub device_path: String,
    pub volume_uuid: String,
    pub hw_id: u64,
}

/// Scans /dev/disk/by-id for devices with a valid InitialChunk.
pub fn scan_volumes(raw_key: &[u8]) -> Result<Vec<TuffVolume>> {
    let mk = derive_mk(raw_key);
    let mut volumes = Vec::new();
    let disk_dir = Path::new("/dev/disk/by-id");

    if !disk_dir.exists() {
        warn!("Disk directory not found: {:?}", disk_dir);
        return Ok(Vec::new());
    }

    for entry in fs::read_dir(disk_dir)? {
        let entry = entry?;
        let path = entry.path();
        let name = entry.file_name().to_string_lossy().to_string();

        // Skip partitions for now; adjust if TUFF-FS lives on partitions.
        if name.contains("-part") {
            continue;
        }

        debug!("Probing device: {:?}", path);
        if let Ok(Some(vol)) = probe_device(&path, &mk) {
            info!("Found TUFF-FS volume: {} (HW-ID: {})", vol.volume_uuid, vol.hw_id);
            volumes.push(vol);
        }
    }

    Ok(volumes)
}

fn probe_device(path: &Path, mk: &[u8; 32]) -> Result<Option<TuffVolume>> {
    let mut file = File::open(path).with_context(|| "Failed to open device")?;
    let mut buf = vec![0u8; SECTOR_SIZE as usize];

    file.seek(SeekFrom::Start(INITIAL_CHUNK_OFFSET))?;
    if file.read_exact(&mut buf).is_err() {
        return Ok(None);
    }

    match try_decrypt(mk, &buf) {
        Some(plaintext) => match root::<tuff_os::InitialChunk>(&plaintext) {
            Ok(chunk) => Ok(Some(TuffVolume {
                device_path: path.to_string_lossy().to_string(),
                volume_uuid: chunk.volume_uuid().unwrap_or("unknown").to_string(),
                hw_id: chunk.hw_id(),
            })),
            Err(_) => Ok(None),
        },
        None => Ok(None),
    }
}

/// Finds the latest committed IndexChunk from the root ring buffer.
pub fn mount_root_index(vol: &TuffVolume, raw_key: &[u8]) -> Result<Option<Vec<u8>>> {
    let mk = derive_mk(raw_key);
    let mut file = File::open(&vol.device_path)?;

    let mut best_gen: Option<u8> = None;
    let mut best_chunk: Option<Vec<u8>> = None;

    debug!("Scanning root index ring on {}", vol.device_path);

    for i in 0..ROOT_INDEX_SLOTS {
        let offset = ROOT_INDEX_START + (i * SECTOR_SIZE);
        let mut buf = vec![0u8; SECTOR_SIZE as usize];

        file.seek(SeekFrom::Start(offset))?;
        if file.read_exact(&mut buf).is_err() {
            continue;
        }

        if let Some(plaintext) = try_decrypt(&mk, &buf) {
            if let Ok(index) = root::<tuff_os::IndexChunk>(&plaintext) {
                let header = index.header();
                if header.wrote_flag() {
                    let gen = header.generation();
                    let take = match best_gen {
                        None => true,
                        Some(bg) => gen > bg,
                    };
                    if take {
                        best_gen = Some(gen);
                        best_chunk = Some(plaintext);
                    }
                }
            }
        }
    }

    if let Some(gen) = best_gen {
        info!("Mounted root index (gen={})", gen);
    } else {
        warn!("No valid root index found on {}", vol.device_path);
    }

    Ok(best_chunk)
}
