use aes_gcm::{aead::{Aead, KeyInit}, Aes256Gcm, Nonce};
use sha2::{Digest, Sha256};

/// Derives a fixed-size key from raw MK material.
/// TODO: Replace with HKDF/Argon2 once the key schedule is finalized.
pub fn derive_mk(raw_key: &[u8]) -> [u8; 32] {
    let mut hasher = Sha256::new();
    hasher.update(raw_key);
    hasher.finalize().into()
}

/// Decrypts data using AES-256-GCM.
/// Expects [nonce(12B)] + [ciphertext||tag].
pub fn try_decrypt(key: &[u8; 32], ciphertext: &[u8]) -> Option<Vec<u8>> {
    if ciphertext.len() < 12 + 16 {
        return None;
    }

    let cipher = Aes256Gcm::new(key.into());
    let nonce = Nonce::from_slice(&ciphertext[..12]);
    cipher.decrypt(nonce, &ciphertext[12..]).ok()
}
