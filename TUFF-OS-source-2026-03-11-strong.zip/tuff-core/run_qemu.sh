#!/bin/bash
set -euo pipefail

TARGET_DIR="/home/flux/.cache/tuff-core-target"
EFI_FILE="$TARGET_DIR/x86_64-unknown-uefi/debug/tuff-core.efi"
ESP_DIR="$TARGET_DIR/esp"
DISK0_IMG="$TARGET_DIR/disk0.img"
DISK1_IMG="$TARGET_DIR/disk1.img"
DISK2_IMG="$TARGET_DIR/disk2.img"
KEY_THUMB_DIR="$TARGET_DIR/key_thumb.img"
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OVMF_CODE="${OVMF_CODE:-/usr/share/OVMF/OVMF_CODE_4M.fd}"
OVMF_VARS_TEMPLATE="${OVMF_VARS_TEMPLATE:-/usr/share/OVMF/OVMF_VARS_4M.fd}"
OVMF_VARS="$TARGET_DIR/OVMF_VARS_4M.fd"

if [[ ! -f "$EFI_FILE" ]]; then
    echo "EFI binary not found: $EFI_FILE" >&2
    echo "Run: cargo build --target x86_64-unknown-uefi" >&2
    exit 1
fi

if [[ ! -f "$OVMF_CODE" || ! -f "$OVMF_VARS_TEMPLATE" ]]; then
    echo "OVMF firmware files not found under /usr/share/OVMF" >&2
    exit 1
fi

mkdir -p "$ESP_DIR/EFI/BOOT"
cp "$EFI_FILE" "$ESP_DIR/EFI/BOOT/BOOTX64.EFI"
cp "$OVMF_VARS_TEMPLATE" "$OVMF_VARS"

. "$HOME/.cargo/env"
CARGO_TARGET_DIR="/home/flux/.cache/tuff-builder-target" \
    cargo run --manifest-path "$REPO_ROOT/tools/tuff-builder/Cargo.toml" --release >/tmp/tuff-builder.log
cat /tmp/tuff-builder.log

QEMU_ACCEL=()
if [[ -e /dev/kvm && -r /dev/kvm && -w /dev/kvm ]]; then
    QEMU_ACCEL=(-enable-kvm -cpu host)
fi

exec qemu-system-x86_64 \
    "${QEMU_ACCEL[@]}" \
    -machine q35 \
    -m 512M \
    -drive if=pflash,format=raw,readonly=on,file="$OVMF_CODE" \
    -drive if=pflash,format=raw,file="$OVMF_VARS" \
    -drive format=raw,file=fat:rw:"$ESP_DIR" \
    -drive file="$DISK0_IMG",format=raw,if=virtio \
    -drive file="$DISK1_IMG",format=raw,if=virtio \
    -drive file="$DISK2_IMG",format=raw,if=virtio \
    -drive file=fat:rw:"$KEY_THUMB_DIR",if=none,id=key_drive,format=raw \
    -device qemu-xhci \
    -device usb-storage,drive=key_drive \
    -net none \
    -nographic \
    -serial mon:stdio
