#!/bin/bash
set -euo pipefail

TARGET_DIR="/home/flux/.cache/tuff-core-target"
DISK_IMG="$TARGET_DIR/tuff_test_disk.img"

mkdir -p "$TARGET_DIR"

if [[ ! -f "$DISK_IMG" ]]; then
    truncate -s 64M "$DISK_IMG"
fi

# Clear the first 4KiB so stale test data does not leak into the probe.
dd if=/dev/zero of="$DISK_IMG" bs=4096 count=1 conv=notrunc status=none

# magic @ 0x00
printf 'TUFFGEN ' | dd of="$DISK_IMG" bs=1 seek=0 conv=notrunc status=none

# timestamp(u64 LE) @ 0x08
printf '\x00\x00\x00\x00\x00\x00\x00\x00' | dd of="$DISK_IMG" bs=1 seek=8 conv=notrunc status=none

# version(u32 LE = 1) @ 0x10
printf '\x01\x00\x00\x00' | dd of="$DISK_IMG" bs=1 seek=16 conv=notrunc status=none

# hardware_id @ 0x14
printf 'TUFF-UQ-001\0\0\0\0\0' | dd of="$DISK_IMG" bs=1 seek=20 conv=notrunc status=none

echo "Genesis header written to $DISK_IMG"
