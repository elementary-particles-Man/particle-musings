#!/bin/bash
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TARGET_DIR="/home/flux/.cache/tuff-core-target"
EFI_FILE="$TARGET_DIR/x86_64-unknown-uefi/debug/tuff-core.efi"
ESP_DIR="$TARGET_DIR/esp"
DISK0_IMG="$TARGET_DIR/disk0.img"
DISK1_IMG="$TARGET_DIR/disk1.img"
DISK2_IMG="$TARGET_DIR/disk2.img"
KEY_THUMB_DIR="$TARGET_DIR/key_thumb.img"
OVMF_CODE="${OVMF_CODE:-/usr/share/OVMF/OVMF_CODE_4M.fd}"
OVMF_VARS_TEMPLATE="${OVMF_VARS_TEMPLATE:-/usr/share/OVMF/OVMF_VARS_4M.fd}"
LOG_DIR="$TARGET_DIR/vm-validation"
DEMO_PLAN_SRC="$KEY_THUMB_DIR/TUFFdemo.json"
DEMO_PLAN_DST="$ESP_DIR/TUFFdemo.json"
DEMO_PLAN_BOOT_DST="$ESP_DIR/EFI/BOOT/TUFFdemo.json"

mkdir -p "$LOG_DIR" "$ESP_DIR/EFI/BOOT"

build_artifacts() {
    (
        cd "$REPO_ROOT/tuff-core"
        cargo build --target x86_64-unknown-uefi
    )
    cargo build --manifest-path "$REPO_ROOT/tools/tuff-builder/Cargo.toml" --release
    cp "$EFI_FILE" "$ESP_DIR/EFI/BOOT/BOOTX64.EFI"
}

prepare_images() {
    cargo run --manifest-path "$REPO_ROOT/tools/tuff-builder/Cargo.toml" --release -- "$@"
}

sync_demo_plan() {
    rm -f "$DEMO_PLAN_DST"
    rm -f "$DEMO_PLAN_BOOT_DST"
    if [[ -f "$DEMO_PLAN_SRC" ]]; then
        cp "$DEMO_PLAN_SRC" "$DEMO_PLAN_DST"
        cp "$DEMO_PLAN_SRC" "$DEMO_PLAN_BOOT_DST"
    fi
}

run_vm() {
    local name="$1"
    local timeout_secs="$2"
    shift 2
    local vars_file="$LOG_DIR/${name}_OVMF_VARS.fd"
    local log_file="$LOG_DIR/${name}.log"

    cp "$OVMF_VARS_TEMPLATE" "$vars_file"
    rm -f "$log_file"

    set +e
    timeout -k 3s "${timeout_secs}s" qemu-system-x86_64 \
        -machine q35 \
        -m 512M \
        -drive if=pflash,format=raw,readonly=on,file="$OVMF_CODE" \
        -drive if=pflash,format=raw,file="$vars_file" \
        -drive format=raw,file=fat:rw:"$ESP_DIR" \
        -drive file="$DISK0_IMG",format=raw,if=virtio \
        -drive file="$DISK1_IMG",format=raw,if=virtio \
        -drive file="$DISK2_IMG",format=raw,if=virtio \
        -drive file=fat:rw:"$KEY_THUMB_DIR",if=none,id=key_drive,format=raw \
        -device qemu-xhci \
        -device usb-storage,drive=key_drive \
        -net none \
        -nographic \
        -monitor none \
        -serial "file:$log_file" \
        "$@"
    local status=$?
    set -e

    if [[ $status -ne 0 && $status -ne 124 && $status -ne 143 ]]; then
        echo "QEMU scenario '$name' failed with status $status" >&2
        cat "$log_file" >&2
        exit $status
    fi

    echo "$log_file"
}

assert_log_contains() {
    local log_file="$1"
    local pattern="$2"
    local label="$3"
    if rg -n "$pattern" "$log_file" >/dev/null; then
        echo "[pass] $label"
    else
        echo "[fail] $label" >&2
        echo "  pattern: $pattern" >&2
        echo "  log: $log_file" >&2
        exit 1
    fi
}

assert_log_not_contains() {
    local log_file="$1"
    local pattern="$2"
    local label="$3"
    if rg -n "$pattern" "$log_file" >/dev/null; then
        echo "[fail] $label" >&2
        echo "  unexpected pattern: $pattern" >&2
        echo "  log: $log_file" >&2
        exit 1
    else
        echo "[pass] $label"
    fi
}

assert_disk_not_contains() {
    local disk_file="$1"
    local pattern="$2"
    local label="$3"
    if rg -a -n "$pattern" "$disk_file" >/dev/null; then
        echo "[fail] $label" >&2
        echo "  unexpected plaintext pattern: $pattern" >&2
        echo "  disk: $disk_file" >&2
        exit 1
    else
        echo "[pass] $label"
    fi
}

build_artifacts
sync_demo_plan

prepare_images >/tmp/tuff-builder-validation.log
sync_demo_plan
fresh_log="$(run_vm fresh_boot 20)"
assert_log_contains "$fresh_log" "STATE_RECOVER_MOUNT" "fresh boot reached recover mount"
assert_log_contains "$fresh_log" "mainline_write_path" "fresh boot reached canonical mainline write path"
assert_log_contains "$fresh_log" "Runtime data write path queued and wrote" "fresh boot executed normal write"
assert_log_contains "$fresh_log" "metadata_3n_verify_passed" "fresh boot verified metadata-critical 3N replicas"
assert_disk_not_contains "$DISK0_IMG" "TUFFDATA-CHUNK-A" "disk0 has no plaintext data chunk marker"
assert_disk_not_contains "$DISK1_IMG" "TUFFDATA-CHUNK-A" "disk1 has no plaintext data chunk marker"
assert_disk_not_contains "$DISK2_IMG" "TUFFDATA-CHUNK-A" "disk2 has no plaintext data chunk marker"
assert_disk_not_contains "$DISK0_IMG" "target_file.txt" "disk0 has no plaintext file metadata marker"
assert_disk_not_contains "$DISK1_IMG" "target_file.txt" "disk1 has no plaintext file metadata marker"
assert_disk_not_contains "$DISK2_IMG" "target_file.txt" "disk2 has no plaintext file metadata marker"

prepare_images >/tmp/tuff-builder-validation.log
sync_demo_plan
interrupted_log="$(run_vm interrupted_boot 20)"
recover_log="$(run_vm recover_after_interrupt 20)"
assert_log_contains "$interrupted_log" "Runtime data write path queued and wrote" "interrupted boot reached post-commit write before forced stop"
assert_log_contains "$recover_log" "UQ resume:" "recover boot resumed UQ/MQ state"
assert_log_contains "$recover_log" "FileEx metadata restore succeeded before runtime continuation" "recover boot restored FileEx metadata"
assert_log_contains "$recover_log" "mainline_write_path" "recover boot returned to mainline write path"

prepare_images --corrupt-disk 1 --corrupt-disk 2 >/tmp/tuff-builder-validation.log
sync_demo_plan
degraded_log="$(run_vm degraded_boot 20)"
assert_log_contains "$degraded_log" "3N degraded: only 1 matching Genesis candidate" "degraded genesis quorum is observable"

prepare_images --enable-vm-ops >/tmp/tuff-builder-validation.log
sync_demo_plan
ops_log="$(run_vm rm_cp_mv_boot 25)"
assert_log_contains "$ops_log" "vm_validation cp commit succeeded" "vm boot executed cp path"
assert_log_contains "$ops_log" "vm_validation mv target commit succeeded" "vm boot executed mv target path"
assert_log_contains "$ops_log" "vm_validation mv source commit succeeded" "vm boot executed mv source path"
assert_log_contains "$ops_log" "vm_validation rm commit succeeded" "vm boot executed rm path"
assert_log_contains "$ops_log" "vm_validation cp same-hw commit succeeded" "vm boot executed cp same-hw path"
assert_log_contains "$ops_log" "vm_validation mv same-hw target commit succeeded" "vm boot executed mv same-hw target path"
assert_log_contains "$ops_log" "vm_validation mv same-hw source commit succeeded" "vm boot executed mv same-hw source path"

prepare_images --conflict-target-meta-disk 2 >/tmp/tuff-builder-validation.log
sync_demo_plan
conflict_log="$(run_vm conflict_boot 15)"
assert_log_contains "$conflict_log" "Ambiguous target FMC truth" "multi-FMC conflict is detected fail-closed"
assert_log_not_contains "$conflict_log" "mainline_write_path" "multi-FMC conflict never reaches mainline write path"

prepare_images --validation-profile "disk_full" >/tmp/tuff-builder-validation.log
sync_demo_plan
disk_full_log="$(run_vm disk_full_boot 15)"
assert_log_contains "$disk_full_log" "vm_validation disk_full injected fail_closed" "disk full injection rejected fail-closed"

prepare_images --validation-profile "flush_spoof" >/tmp/tuff-builder-validation.log
sync_demo_plan
flush_spoof_log="$(run_vm flush_spoof_boot 15)"
assert_log_contains "$flush_spoof_log" "vm_validation flush_spoof injected fail_closed" "flush spoof injection rejected fail-closed"

prepare_images --validation-profile "reclaim_interrupt" >/tmp/tuff-builder-validation.log
sync_demo_plan
reclaim_interrupt_log="$(run_vm reclaim_interrupt_boot 15)"
assert_log_contains "$reclaim_interrupt_log" "vm_validation reclaim_interrupt injected fail_closed" "reclaim interruption injected and aborted safely"
rm -f "$DEMO_PLAN_DST" "$DEMO_PLAN_BOOT_DST"
reclaim_recover_log="$(run_vm reclaim_recover_boot 20)"
assert_log_contains "$reclaim_recover_log" "mainline_write_path" "reclaim interruption recovery reached mainline path"

prepare_images --validation-profile "rm_cp_mv+cse_probe" >/tmp/tuff-builder-validation.log
sync_demo_plan
cse_probe_log="$(run_vm cse_probe_boot 25)"
assert_log_contains "$cse_probe_log" "vm_validation cse_zeroization_probe_passed" "cse zeroization probe passed"

cat <<EOF
VM validation completed.
Logs:
  fresh_boot: $fresh_log
  interrupted_boot: $interrupted_log
  recover_after_interrupt: $recover_log
  degraded_boot: $degraded_log
  rm_cp_mv_boot: $ops_log
  conflict_boot: $conflict_log
  disk_full_boot: $disk_full_log
  flush_spoof_boot: $flush_spoof_log
  reclaim_interrupt_boot: $reclaim_interrupt_log
  reclaim_recover_boot: $reclaim_recover_log
  cse_probe_boot: $cse_probe_log
EOF
