use crate::engine::{UniqueQueueEntry, UniqueQueueRuntime};
use crate::scheduler::{CommitCoordinator, DispatchRequest, HwScheduler, IoPriority, TuffError};

pub const UQ_PAUSE_PERCENT: u8 = 80;
pub const UQ_RESUME_PERCENT: u8 = 65;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EvacuationChunkKind {
    Metadata,
    Data,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct EvacuationCandidate {
    pub epoch: u64,
    pub timestamp: u64,
    pub lba: u64,
    pub sectors: u64,
    pub source_disk_id: u64,
    pub file_id: u64,
    pub entry_index: usize,
    pub kind: EvacuationChunkKind,
}

impl EvacuationCandidate {
    pub fn priority(&self) -> IoPriority {
        match self.kind {
            EvacuationChunkKind::Metadata => IoPriority::HighMetadata,
            EvacuationChunkKind::Data => IoPriority::LowRestore,
        }
    }
}

pub fn sort_evacuation_candidates(candidates: &mut [EvacuationCandidate]) {
    candidates.sort_by(|left, right| {
        right
            .epoch
            .cmp(&left.epoch)
            .then_with(|| right.timestamp.cmp(&left.timestamp))
            .then_with(|| left.lba.cmp(&right.lba))
    });
}

pub fn should_pause_restore(uq_usage_percent: u8, paused: bool) -> bool {
    if paused {
        uq_usage_percent >= UQ_RESUME_PERCENT
    } else {
        uq_usage_percent >= UQ_PAUSE_PERCENT
    }
}

pub fn submit_evacuation_batch(
    scheduler: &mut HwScheduler,
    candidates: &[EvacuationCandidate],
    uq_usage_percent: u8,
    now_ms: u64,
) -> Result<usize, TuffError> {
    if should_pause_restore(uq_usage_percent, false) {
        return Ok(0);
    }

    let mut submitted = 0usize;
    for candidate in candidates.iter() {
        if should_pause_restore(uq_usage_percent, false) {
            break;
        }

        let request = DispatchRequest {
            epoch: candidate.epoch,
            priority: candidate.priority(),
            sectors: candidate.sectors,
            target_disk: None,
            exclude_disks: [candidate.source_disk_id, 0, 0],
            exclude_len: 1,
        };

        if scheduler.dispatch(request, now_ms).is_ok() {
            submitted += 1;
        }
    }

    Ok(submitted)
}

pub fn enqueue_evacuation_candidates(
    uq: &mut UniqueQueueRuntime,
    candidates: &[EvacuationCandidate],
    paused: bool,
) -> usize {
    if should_pause_restore(uq.usage_percent, paused) {
        return 0;
    }

    let mut queued = 0usize;
    for candidate in candidates.iter() {
        if should_pause_restore(uq.usage_percent, paused) {
            break;
        }

        uq.enqueue(UniqueQueueEntry {
            file_id: candidate.file_id,
            epoch: candidate.epoch,
            priority: candidate.priority(),
            sectors: candidate.sectors,
            old_lba: candidate.lba,
            entry_index: candidate.entry_index,
            exclude_disks: [candidate.source_disk_id, 0, 0],
            exclude_len: 1,
        });
        queued += 1;
    }

    queued
}

pub fn run_evacuation_cycle(
    scheduler: &mut HwScheduler,
    coordinator: &mut CommitCoordinator,
    uq: &mut UniqueQueueRuntime,
    candidates: &mut [EvacuationCandidate],
    now_ms: u64,
) -> Result<usize, TuffError> {
    sort_evacuation_candidates(candidates);
    let queued = enqueue_evacuation_candidates(uq, candidates, uq.paused);
    if queued == 0 {
        return Ok(0);
    }

    let committed = uq.process_cycle(scheduler, coordinator, now_ms)?;
    Ok(committed.len())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::scheduler::{CommitCoordinator, HwScheduler};

    #[test]
    fn evacuation_order_prefers_epoch_then_timestamp_then_lba() {
        let mut candidates = [
            EvacuationCandidate {
                epoch: 1,
                timestamp: 10,
                lba: 400,
                sectors: 8,
                source_disk_id: 0,
                file_id: 1,
                entry_index: 0,
                kind: EvacuationChunkKind::Data,
            },
            EvacuationCandidate {
                epoch: 2,
                timestamp: 5,
                lba: 500,
                sectors: 8,
                source_disk_id: 0,
                file_id: 1,
                entry_index: 1,
                kind: EvacuationChunkKind::Metadata,
            },
            EvacuationCandidate {
                epoch: 2,
                timestamp: 5,
                lba: 100,
                sectors: 8,
                source_disk_id: 0,
                file_id: 1,
                entry_index: 2,
                kind: EvacuationChunkKind::Data,
            },
        ];

        sort_evacuation_candidates(&mut candidates);
        assert_eq!(candidates[0].lba, 100);
        assert_eq!(candidates[1].lba, 500);
        assert_eq!(candidates[2].epoch, 1);
    }

    #[test]
    fn hysteresis_pauses_and_resumes_at_expected_thresholds() {
        assert!(should_pause_restore(80, false));
        assert!(!should_pause_restore(79, false));
        assert!(should_pause_restore(70, true));
        assert!(!should_pause_restore(64, true));
    }

    #[test]
    fn evacuation_cycle_enqueues_and_dispatches() {
        let mut scheduler = HwScheduler::new(&[(1, 32_768), (2, 32_768)]);
        let mut coordinator = CommitCoordinator::new();
        let mut uq = UniqueQueueRuntime::new();
        let mut candidates = [EvacuationCandidate {
            epoch: 10,
            timestamp: 99,
            lba: 2048,
            sectors: 8,
            source_disk_id: 1,
            file_id: 7,
            entry_index: 0,
            kind: EvacuationChunkKind::Metadata,
        }];

        let committed = run_evacuation_cycle(
            &mut scheduler,
            &mut coordinator,
            &mut uq,
            &mut candidates,
            123,
        )
        .unwrap();

        assert_eq!(committed, 1);
        assert_eq!(coordinator.pending_updates.len(), 1);
    }
}
