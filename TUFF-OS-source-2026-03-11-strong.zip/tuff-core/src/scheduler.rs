use alloc::vec::Vec;
use sha2::{Digest, Sha256};

use crate::fs_structs::FmcChunk;
use log::warn;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TuffError {
    DiskNotFound,
    ReservationFailed,
    StorageFull,
    DeviceFault,
    InvalidStateTransition,
    InternalReadHandled,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum IoPriority {
    CriticalRead,
    HighMetadata,
    NormalData,
    LowRestore,
    BackgroundDefrag,
    Maintenance,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HwQueueState {
    Active,
    Idle,
    Diagnosing,
    Evacuating,
    Restoring,
    Suspended,
    Faulted,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct WindowGrant {
    pub disk_id: u64,
    pub epoch: u64,
    pub start_lba: u64,
    pub len_sectors: u64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PendingWrite {
    pub epoch: u64,
    pub priority: IoPriority,
    pub start_lba: u64,
    pub written_sectors: u64,
    pub total_sectors: u64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SmartSnapshot {
    pub temperature_c: i8,
    pub reallocated_sectors: u32,
    pub pending_sectors: u32,
    pub read_error_rate: u32,
    pub spin_retry_count: u32,
    pub power_on_hours: u32,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum SmartHealth {
    Healthy,
    Warning,
    Critical,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SmartThresholds {
    pub temp_warning: i8,
    pub temp_critical: i8,
    pub reallocated_critical: u32,
    pub pending_warning: u32,
}

impl Default for SmartThresholds {
    fn default() -> Self {
        Self {
            temp_warning: 50,
            temp_critical: 60,
            reallocated_critical: 100,
            pending_warning: 1,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct DispatchRequest {
    pub epoch: u64,
    pub priority: IoPriority,
    pub sectors: u64,
    pub target_disk: Option<u64>,
    pub exclude_disks: [u64; 3],
    pub exclude_len: usize,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct DispatchDecision {
    pub disk_id: u64,
    pub start_lba: u64,
    pub sectors: u64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PerDiskState {
    pub disk_id: u64,
    pub state: HwQueueState,
    pub capacity_sectors: u64,
    pub write_frontier: u64,
    pub gc_watermark: u64,
    pub is_wrapped: bool,
    pub current_window: Option<WindowGrant>,
    pub window_used_sectors: u64,
    pub queue_load_bytes: u64,
    pub last_epoch_written: u64,
    pub pending_write: Option<PendingWrite>,
    pub last_io_at: u64,
    pub last_smart_check_at: u64,
    pub smart_jitter_ms: u32,
}

impl PerDiskState {
    pub const fn new(disk_id: u64, capacity_sectors: u64, smart_jitter_ms: u32) -> Self {
        Self {
            disk_id,
            state: HwQueueState::Idle,
            capacity_sectors,
            write_frontier: 0,
            gc_watermark: 0,
            is_wrapped: false,
            current_window: None,
            window_used_sectors: 0,
            queue_load_bytes: 0,
            last_epoch_written: 0,
            pending_write: None,
            last_io_at: 0,
            last_smart_check_at: 0,
            smart_jitter_ms,
        }
    }
}

pub struct HwScheduler {
    pub disks: Vec<PerDiskState>,
    pub default_window_sectors: u64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PointerUpdate {
    pub file_id: u64,
    pub entry_index: usize,
    pub old_lba: u64,
    pub new_lba: u64,
}

pub struct CommitCoordinator {
    pub pending_updates: Vec<PointerUpdate>,
    pub registered_fmcs: Vec<FmcReplica>,
    pub pending_writebacks: Vec<PhysicalWriteback>,
}

pub struct FmcReplica {
    pub file_id: u64,
    pub disk_id: u64,
    pub discovered_start_lba: u64,
    pub start_lba: u64,
    pub buffer: [u8; 4096],
    pub checksum: [u8; 32],
}

pub struct PhysicalWriteback {
    pub disk_id: u64,
    pub start_lba: u64,
    pub priority: IoPriority,
    pub buffer: [u8; 4096],
    pub expected_checksum: [u8; 32],
}

impl CommitCoordinator {
    pub fn new() -> Self {
        Self {
            pending_updates: Vec::new(),
            registered_fmcs: Vec::new(),
            pending_writebacks: Vec::new(),
        }
    }

    pub fn push_update(&mut self, update: PointerUpdate) {
        self.pending_updates.push(update);
    }

    pub fn register_fmc_replica(
        &mut self,
        file_id: u64,
        disk_id: u64,
        start_lba: u64,
        buffer: [u8; 4096],
    ) {
        let checksum = compute_fmc_checksum(&buffer);
        self.registered_fmcs.push(FmcReplica {
            file_id,
            disk_id,
            discovered_start_lba: start_lba,
            start_lba,
            buffer,
            checksum,
        });
    }

    pub fn register_fmc(
        &mut self,
        file_id: u64,
        disk_id: u64,
        start_lba: u64,
        buffer: [u8; 4096],
    ) {
        self.register_fmc_replica(file_id, disk_id, start_lba, buffer);
    }

    pub fn prepare_epoch_commit(&self, epoch: u64) -> Result<(), TuffError> {
        if epoch == 0 {
            return Err(TuffError::ReservationFailed);
        }

        for (index, left) in self.pending_updates.iter().enumerate() {
            for right in self.pending_updates.iter().skip(index + 1) {
                if left.file_id == right.file_id
                    && left.entry_index == right.entry_index
                    && left.new_lba != right.new_lba
                {
                    return Err(TuffError::ReservationFailed);
                }
            }
        }
        Ok(())
    }

    pub fn flush_epoch(&mut self, epoch: u64, scheduler: &mut HwScheduler) -> Result<(), TuffError> {
        let disk_ids = scheduler.disks.iter().map(|disk| disk.disk_id).collect::<Vec<_>>();
        for disk_id in disk_ids {
            scheduler.flush_epoch_on_disk(disk_id, epoch)?;
        }
        Ok(())
    }

    pub fn commit_fmc(
        &mut self,
        epoch: u64,
        scheduler: &mut HwScheduler,
        now_ms: u64,
    ) -> Result<(), TuffError> {
        if epoch == 0 {
            return Err(TuffError::ReservationFailed);
        }
        let mut touched_any = false;
        let mut writeback_targets = Vec::new();
        for update in self.pending_updates.iter() {
            let mut replica_count = 0usize;
            for (replica_index, replica) in self
                .registered_fmcs
                .iter_mut()
                .enumerate()
                .filter(|(_, replica)| replica.file_id == update.file_id)
            {
                let mut fmc: FmcChunk =
                    unsafe { core::ptr::read_unaligned(replica.buffer.as_ptr() as *const FmcChunk) };
                if update.entry_index >= fmc.pointer_matrix.len() {
                    warn!(
                        "commit_fmc reservation_failed: file_id={} entry_index={} reason=entry_oob len={}",
                        update.file_id,
                        update.entry_index,
                        fmc.pointer_matrix.len()
                    );
                    return Err(TuffError::ReservationFailed);
                }
                if fmc.pointer_matrix[update.entry_index] != update.old_lba {
                    warn!(
                        "commit_fmc reservation_failed: file_id={} disk_id={} entry_index={} reason=old_lba_mismatch expected_current={} update_old={} update_new={}",
                        update.file_id,
                        replica.disk_id,
                        update.entry_index,
                        fmc.pointer_matrix[update.entry_index],
                        update.old_lba,
                        update.new_lba
                    );
                    return Err(TuffError::ReservationFailed);
                }
                fmc.pointer_matrix[update.entry_index] = update.new_lba;
                unsafe {
                    core::ptr::write_unaligned(
                        replica.buffer.as_mut_ptr() as *mut FmcChunk,
                        fmc,
                    );
                }
                replica.checksum = compute_fmc_checksum(&replica.buffer);
                writeback_targets.push((replica_index, replica.disk_id));
                replica_count += 1;
                touched_any = true;
            }
            if replica_count < 3 {
                warn!(
                    "commit_fmc reservation_failed: file_id={} reason=replica_quorum replica_count={}",
                    update.file_id,
                    replica_count
                );
                return Err(TuffError::ReservationFailed);
            }
        }
        if !touched_any {
            warn!("commit_fmc reservation_failed: reason=no_pending_updates_touched");
            return Err(TuffError::ReservationFailed);
        }

        for (replica_index, disk_id) in writeback_targets.iter().copied() {
            let decision = scheduler.enqueue_write(
                epoch,
                IoPriority::HighMetadata,
                1,
                Some(disk_id),
                [0; 3],
                0,
                now_ms,
            )?;
            if let Some(replica) = self.registered_fmcs.get_mut(replica_index) {
                replica.start_lba = decision.start_lba;
                self.pending_writebacks.push(PhysicalWriteback {
                    disk_id: replica.disk_id,
                    start_lba: replica.start_lba,
                    priority: IoPriority::HighMetadata,
                    buffer: replica.buffer,
                    expected_checksum: replica.checksum,
                });
            }
        }

        for (_, disk_id) in writeback_targets {
            scheduler.flush_epoch_on_disk(disk_id, epoch)?;
        }
        Ok(())
    }

    pub fn finalize_epoch(
        &mut self,
        epoch: u64,
        scheduler: &mut HwScheduler,
        now_ms: u64,
    ) -> Result<(), TuffError> {
        self.prepare_epoch_commit(epoch)?;
        if let Err(err) = self.flush_epoch(epoch, scheduler) {
            scheduler.reject_epoch(epoch);
            return Err(err);
        }
        if let Err(err) = self.commit_fmc(epoch, scheduler, now_ms) {
            scheduler.reject_epoch(epoch);
            return Err(err);
        }
        self.pending_updates.clear();
        Ok(())
    }

    pub fn take_physical_writebacks(&mut self) -> Vec<PhysicalWriteback> {
        core::mem::take(&mut self.pending_writebacks)
    }

    pub fn enqueue_runtime_writeback(
        &mut self,
        disk_id: u64,
        start_lba: u64,
        priority: IoPriority,
        buffer: [u8; 4096],
    ) {
        self.pending_writebacks.push(PhysicalWriteback {
            disk_id,
            start_lba,
            priority,
            expected_checksum: compute_block_checksum(&buffer),
            buffer,
        });
    }
}

impl HwScheduler {
    pub fn new(disk_configs: &[(u64, u64)]) -> Self {
        let mut disks = Vec::with_capacity(disk_configs.len());
        for (index, (disk_id, capacity_sectors)) in disk_configs.iter().enumerate() {
            disks.push(PerDiskState::new(
                *disk_id,
                *capacity_sectors,
                (index as u32 * 37_000) % 600_000,
            ));
        }

        Self {
            disks,
            default_window_sectors: 2048,
        }
    }

    pub fn reserve_window(
        &mut self,
        disk_id: u64,
        epoch: u64,
        required: u64,
    ) -> Result<(), TuffError> {
        let idx = self.find_disk_idx(disk_id)?;
        let need_new = {
            let disk = &self.disks[idx];
            if disk.state == HwQueueState::Faulted {
                return Err(TuffError::DeviceFault);
            }
            disk.current_window.as_ref().map_or(true, |window| {
                window.epoch != epoch || disk.window_used_sectors + required > window.len_sectors
            })
        };

        if need_new {
            self.advance_frontier(idx, epoch)?;
        }
        Ok(())
    }

    pub fn allocate_sectors(
        &mut self,
        disk_id: u64,
        count: u64,
        now: u64,
    ) -> Result<(u64, u64), TuffError> {
        let idx = self.find_disk_idx(disk_id)?;
        let disk = &mut self.disks[idx];

        if let Some(window) = disk.current_window {
            if disk.window_used_sectors + count <= window.len_sectors {
                let start = window.start_lba + disk.window_used_sectors;
                disk.window_used_sectors += count;
                disk.last_io_at = now;
                disk.queue_load_bytes = disk
                    .queue_load_bytes
                    .saturating_add(count.saturating_mul(4096));
                disk.last_epoch_written = window.epoch;
                return Ok((start, count));
            }
        }
        Err(TuffError::ReservationFailed)
    }

    pub fn enqueue_write(
        &mut self,
        epoch: u64,
        priority: IoPriority,
        sectors: u64,
        target_disk: Option<u64>,
        exclude_disks: [u64; 3],
        exclude_len: usize,
        now: u64,
    ) -> Result<DispatchDecision, TuffError> {
        self.dispatch(
            DispatchRequest {
                epoch,
                priority,
                sectors,
                target_disk,
                exclude_disks,
                exclude_len,
            },
            now,
        )
    }

    pub fn dispatch(
        &mut self,
        req: DispatchRequest,
        now: u64,
    ) -> Result<DispatchDecision, TuffError> {
        if req.priority == IoPriority::CriticalRead {
            let disk_id = req.target_disk.ok_or(TuffError::DiskNotFound)?;
            self.suspend_for_read(disk_id)?;
            self.resume_after_read(disk_id, now)?;
            return Err(TuffError::InternalReadHandled);
        }

        let disk_id = self
            .select_best_disk(&req)
            .ok_or(TuffError::StorageFull)?;
        self.reserve_window(disk_id, req.epoch, req.sectors)?;
        let (start_lba, sectors) = self.allocate_sectors(disk_id, req.sectors, now)?;

        let idx = self.find_disk_idx(disk_id)?;
        self.disks[idx].pending_write = Some(PendingWrite {
            epoch: req.epoch,
            priority: req.priority,
            start_lba,
            written_sectors: 0,
            total_sectors: sectors,
        });
        self.disks[idx].state = HwQueueState::Active;

        Ok(DispatchDecision {
            disk_id,
            start_lba,
            sectors,
        })
    }

    pub fn select_best_disk(&self, req: &DispatchRequest) -> Option<u64> {
        self.disks
            .iter()
            .filter(|disk| self.is_dispatch_allowed(disk, req.priority))
            .filter(|disk| {
                !req.exclude_disks[..req.exclude_len]
                    .iter()
                    .any(|exclude_id| *exclude_id == disk.disk_id)
            })
            .min_by(|left, right| {
                left.queue_load_bytes
                    .cmp(&right.queue_load_bytes)
                    .then_with(|| {
                        let left_idle = left.state == HwQueueState::Idle;
                        let right_idle = right.state == HwQueueState::Idle;
                        right_idle.cmp(&left_idle)
                    })
                    .then_with(|| left.disk_id.cmp(&right.disk_id))
            })
            .map(|disk| disk.disk_id)
    }

    pub fn evaluate_smart(
        &self,
        snapshot: &SmartSnapshot,
        thresholds: &SmartThresholds,
    ) -> SmartHealth {
        if snapshot.temperature_c >= thresholds.temp_critical
            || snapshot.reallocated_sectors > thresholds.reallocated_critical
        {
            return SmartHealth::Critical;
        }
        if snapshot.pending_sectors > thresholds.pending_warning
            || snapshot.temperature_c >= thresholds.temp_warning
        {
            return SmartHealth::Warning;
        }
        SmartHealth::Healthy
    }

    pub fn apply_health_transition(
        &mut self,
        disk_id: u64,
        health: SmartHealth,
    ) -> Result<(), TuffError> {
        let idx = self.find_disk_idx(disk_id)?;
        let disk = &mut self.disks[idx];
        disk.state = match health {
            SmartHealth::Healthy => {
                if disk.state == HwQueueState::Diagnosing {
                    HwQueueState::Active
                } else {
                    disk.state
                }
            }
            SmartHealth::Warning => HwQueueState::Evacuating,
            SmartHealth::Critical => HwQueueState::Faulted,
        };
        Ok(())
    }

    pub fn should_run_smart(
        &self,
        disk_id: u64,
        now_ms: u64,
        idle_threshold_ms: u64,
    ) -> Result<bool, TuffError> {
        let idx = self.find_disk_idx(disk_id)?;
        let disk = &self.disks[idx];
        let next_due = disk
            .last_smart_check_at
            .saturating_add(30 * 60 * 1000)
            .saturating_add(disk.smart_jitter_ms as u64);

        Ok(
            now_ms >= next_due
                && now_ms.saturating_sub(disk.last_io_at) >= idle_threshold_ms
                && matches!(disk.state, HwQueueState::Active | HwQueueState::Idle),
        )
    }

    pub fn mark_smart_checked(&mut self, disk_id: u64, now_ms: u64) -> Result<(), TuffError> {
        let idx = self.find_disk_idx(disk_id)?;
        let disk = &mut self.disks[idx];
        disk.last_smart_check_at = now_ms;
        Ok(())
    }

    pub fn suspend_for_read(&mut self, disk_id: u64) -> Result<(), TuffError> {
        let idx = self.find_disk_idx(disk_id)?;
        let disk = &mut self.disks[idx];

        match disk.state {
            HwQueueState::Active if disk.pending_write.is_some() => {
                if let Some(pending) = disk.pending_write.as_mut() {
                    pending.written_sectors = disk.window_used_sectors;
                }
                disk.state = HwQueueState::Suspended;
                Ok(())
            }
            HwQueueState::Idle | HwQueueState::Suspended => Ok(()),
            HwQueueState::Faulted => Err(TuffError::DeviceFault),
            _ => Ok(()),
        }
    }

    pub fn resume_after_read(&mut self, disk_id: u64, now: u64) -> Result<(), TuffError> {
        let idx = self.find_disk_idx(disk_id)?;
        let disk = &mut self.disks[idx];

        if disk.state != HwQueueState::Suspended {
            return Err(TuffError::InvalidStateTransition);
        }

        disk.last_io_at = now;
        disk.state = match disk.pending_write {
            Some(pending) if pending.written_sectors < pending.total_sectors => {
                HwQueueState::Active
            }
            _ => HwQueueState::Idle,
        };
        Ok(())
    }

    pub fn flush_epoch_on_disk(&mut self, disk_id: u64, epoch: u64) -> Result<(), TuffError> {
        let idx = self.find_disk_idx(disk_id)?;
        let disk = &mut self.disks[idx];
        if let Some(window) = disk.current_window {
            if window.epoch == epoch {
                disk.current_window = None;
                disk.pending_write = None;
                disk.window_used_sectors = 0;
                disk.queue_load_bytes = 0;
                disk.state = HwQueueState::Idle;
            }
        }
        Ok(())
    }

    pub fn reject_epoch(&mut self, epoch: u64) {
        for disk in &mut self.disks {
            if let Some(window) = disk.current_window {
                if window.epoch == epoch {
                    disk.current_window = None;
                    disk.pending_write = None;
                    disk.window_used_sectors = 0;
                    disk.queue_load_bytes = 0;
                    disk.state = HwQueueState::Idle;
                }
            }
        }
    }

    fn advance_frontier(&mut self, idx: usize, epoch: u64) -> Result<(), TuffError> {
        let disk = &mut self.disks[idx];
        let next_start = disk.write_frontier + self.default_window_sectors;

        if next_start + self.default_window_sectors > disk.capacity_sectors {
            if disk.gc_watermark > self.default_window_sectors {
                disk.write_frontier = 0;
                disk.is_wrapped = true;
            } else {
                return Err(TuffError::StorageFull);
            }
        } else {
            if disk.is_wrapped && next_start + self.default_window_sectors >= disk.gc_watermark {
                return Err(TuffError::StorageFull);
            }
            disk.write_frontier = next_start;
        }

        disk.current_window = Some(WindowGrant {
            disk_id: disk.disk_id,
            epoch,
            start_lba: disk.write_frontier,
            len_sectors: self.default_window_sectors,
        });
        disk.window_used_sectors = 0;
        Ok(())
    }

    fn find_disk_idx(&self, disk_id: u64) -> Result<usize, TuffError> {
        self.disks
            .iter()
            .position(|disk| disk.disk_id == disk_id)
            .ok_or(TuffError::DiskNotFound)
    }

fn is_dispatch_allowed(&self, disk: &PerDiskState, priority: IoPriority) -> bool {
        match disk.state {
            HwQueueState::Faulted | HwQueueState::Suspended => false,
            HwQueueState::Evacuating => {
                matches!(priority, IoPriority::CriticalRead | IoPriority::LowRestore)
            }
            HwQueueState::Diagnosing => matches!(priority, IoPriority::CriticalRead),
            HwQueueState::Restoring => {
                !matches!(priority, IoPriority::BackgroundDefrag | IoPriority::Maintenance)
            }
            HwQueueState::Active | HwQueueState::Idle => true,
        }
    }
}

pub fn compute_block_checksum(buffer: &[u8; 4096]) -> [u8; 32] {
    Sha256::digest(buffer).into()
}

fn compute_fmc_checksum(buffer: &[u8; 4096]) -> [u8; 32] {
    compute_block_checksum(buffer)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reserve_and_allocate_are_sequential() {
        let mut scheduler = HwScheduler::new(&[(0, 32_768)]);
        scheduler.reserve_window(0, 7, 8).unwrap();
        let (first_start, first_len) = scheduler.allocate_sectors(0, 8, 100).unwrap();
        let (second_start, second_len) = scheduler.allocate_sectors(0, 8, 200).unwrap();
        assert_eq!(first_start, 2048);
        assert_eq!(first_len, 8);
        assert_eq!(second_start, 2056);
        assert_eq!(second_len, 8);
    }

    #[test]
    fn warning_disk_is_not_selected_for_new_write() {
        let mut scheduler = HwScheduler::new(&[(0, 32_768), (1, 32_768)]);
        scheduler
            .apply_health_transition(0, SmartHealth::Warning)
            .unwrap();
        let selected = scheduler.select_best_disk(&DispatchRequest {
            epoch: 1,
            priority: IoPriority::NormalData,
            sectors: 8,
            target_disk: None,
            exclude_disks: [0; 3],
            exclude_len: 0,
        });
        assert_eq!(selected, Some(1));
    }

    #[test]
    fn suspend_and_resume_restore_active_state() {
        let mut scheduler = HwScheduler::new(&[(0, 32_768)]);
        scheduler.reserve_window(0, 1, 16).unwrap();
        let _ = scheduler.allocate_sectors(0, 16, 10).unwrap();
        scheduler.disks[0].pending_write = Some(PendingWrite {
            epoch: 1,
            priority: IoPriority::NormalData,
            start_lba: 2048,
            written_sectors: 0,
            total_sectors: 32,
        });
        scheduler.disks[0].state = HwQueueState::Active;

        scheduler.suspend_for_read(0).unwrap();
        assert_eq!(scheduler.disks[0].state, HwQueueState::Suspended);
        scheduler.resume_after_read(0, 20).unwrap();
        assert_eq!(scheduler.disks[0].state, HwQueueState::Active);
    }

    #[test]
    fn finalize_epoch_rejects_conflicting_pointer_updates() {
        let mut scheduler = HwScheduler::new(&[(0, 32_768)]);
        scheduler.reserve_window(0, 4, 8).unwrap();
        let _ = scheduler.allocate_sectors(0, 8, 10).unwrap();
        let mut coordinator = CommitCoordinator::new();
        coordinator.push_update(PointerUpdate {
            file_id: 7,
            entry_index: 0,
            old_lba: 10,
            new_lba: 100,
        });
        coordinator.push_update(PointerUpdate {
            file_id: 7,
            entry_index: 0,
            old_lba: 10,
            new_lba: 200,
        });

        let result = coordinator.finalize_epoch(4, &mut scheduler, 10);
        assert_eq!(result, Err(TuffError::ReservationFailed));
    }

    #[test]
    fn commit_fmc_rewrites_all_three_replicas() {
        let mut coordinator = CommitCoordinator::new();
        let mut buffer = [0u8; 4096];
        let mut fmc: FmcChunk =
            unsafe { core::ptr::read_unaligned(buffer.as_ptr() as *const FmcChunk) };
        fmc.pointer_matrix[0] = 111;
        unsafe {
            core::ptr::write_unaligned(buffer.as_mut_ptr() as *mut FmcChunk, fmc);
        }
        coordinator.register_fmc_replica(9, 0, 16, buffer);
        coordinator.register_fmc_replica(9, 1, 16, buffer);
        coordinator.register_fmc_replica(9, 2, 16, buffer);
        coordinator.push_update(PointerUpdate {
            file_id: 9,
            entry_index: 0,
            old_lba: 111,
            new_lba: 222,
        });

        let mut scheduler = HwScheduler::new(&[(0, 32_768), (1, 32_768), (2, 32_768)]);
        coordinator.commit_fmc(7, &mut scheduler, 100).unwrap();

        for replica in coordinator.registered_fmcs.iter().filter(|r| r.file_id == 9) {
            let fmc: FmcChunk =
                unsafe { core::ptr::read_unaligned(replica.buffer.as_ptr() as *const FmcChunk) };
            assert_eq!(fmc.pointer_matrix[0], 222);
            assert_eq!(replica.checksum, compute_fmc_checksum(&replica.buffer));
        }
    }
}
