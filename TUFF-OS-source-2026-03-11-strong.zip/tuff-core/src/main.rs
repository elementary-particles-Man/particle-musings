#![no_std]
#![no_main]

extern crate alloc;

use alloc::boxed::Box;
#[cfg(target_arch = "x86_64")]
use core::arch::x86_64::_rdtsc;
use log::{info, warn};
use sha2::{Digest, Sha256};
use tuff_core::cse::engine::CseEngine;
use tuff_core::cse::parallel::CseScheduler;
use tuff_core::engine::{
    AppendOnlyWriteRequest, compact_queue_records_with_policy, decode_file_ex_metadata_region,
    consume_alert_events,
    decode_queue_records, drain_reclaim_pending_to_free_list_reader_safe_with_policy,
    default_reader_reclaim_policy,
    default_metadata_critical_placement_policy, default_mq_retention_policy,
    encode_file_ex_metadata_region,
    encode_file_ex_state, encode_queue_records, execute_physical_writebacks,
    classify_cross_hw_transfer,
    init_alert_consumer_cursor, init_alert_shared_memory_page,
    merge_target_meta_chunk_truths,
    metadata_critical_placement_for_file_with_policy, register_discovered_fmc,
    push_alert_event,
    reject_pending_operation_with_reclaim, commit_pending_operation_with_reclaim,
    select_alert_consumer_mode,
    stage_append_only_generation, stage_n_redundancy_candidate, stage_pending_operation,
    stop_hw_write_queue_for_metadata_alert,
    verify_3n_genesis, verify_metadata_critical_replica_set_periodic,
    build_metadata_critical_replica_set, FmcDiscoveryReplica, MetadataCriticalWriteRequest,
    METADATA_3N_VERIFY_INTERVAL_MS,
    QueueBackendKind, QueueBackendPolicy, QueuePersistedRecord, RuntimeDataWriteRequest,
    UniqueQueueRuntime, submit_runtime_data_write,
};
use tuff_core::fs_structs::{
    ActiveChunkRead, AlertClass, AlertConsumerCursor, AlertConsumerMode, AlertEvent, AlertSharedMemoryPage,
    ALERT_IPC_RING_CAPACITY, AppendBaseGeneration, AppendWriteRange,
    FILE_EX_METADATA_FMC_EXTENSION_OFFSET_CHUNKS, FicChunk, FileExState, FolderStatus,
    FmcChunk, JGenerationState, KeyEnvelopeChunk, MetadataCriticalChunkKind,
    MetadataCriticalEventSource, MetadataCriticalReplicaSet, NRedundancyState, PageAlignedBuffer,
    PendingOperation, PendingOperationKind, ReclaimState, ReaderTrackingState,
    FIC_CHUNK_NUMBER, FIC_CSE_INFO_OFFSET, FIC_CSE_INFO_SIZE, FMC_CSE_INFO_OFFSET,
    FMC_CSE_INFO_SIZE, KEC_CHUNK_NUMBER,
};
use tuff_core::genesis::{Genesis, GENESIS_SIZE};
use tuff_core::pq::signatures::{AuditLogEntry, BootPolicy, UpdateManifest};
use tuff_core::pq::{
    embedded_root_policy_public_key, KeyEnvelopeManager, DEFAULT_KDF_PARAMS, MOCK_MASTER_KEY,
};
use tuff_core::scheduler::{CommitCoordinator, HwScheduler, IoPriority};
use uefi::prelude::*;
use uefi::cstr16;
use uefi::proto::console::text::{Color, Input, Key, ScanCode};
use uefi::proto::media::file::{File, FileAttribute, FileMode};
use uefi::proto::media::fs::SimpleFileSystem;
use uefi::proto::media::block::BlockIO;
use uefi::table::boot::BootServices;
use uefi::CStr16;

const TARGET_FILE_NAME: &str = "target_file.txt";
const COPY_TARGET_FILE_NAME: &str = "copy_target.txt";
const MOVE_TARGET_FILE_NAME: &str = "move_target.txt";
const COPY_SAME_HW_TARGET_FILE_NAME: &str = "copy_target_same_hw.txt";
const MOVE_SAME_HW_TARGET_FILE_NAME: &str = "move_target_same_hw.txt";
const COPY_TARGET_META_CHUNK: u64 = 8;
const MOVE_TARGET_META_CHUNK: u64 = 10;
const COPY_SAME_HW_TARGET_META_CHUNK: u64 = 12;
const MOVE_SAME_HW_TARGET_META_CHUNK: u64 = 14;
const TUFF_MQ_FILE_PATH: &CStr16 = cstr16!("\\TUFF-FS.MQ");
const TUFF_DEMO_FILE_PATH: &CStr16 = cstr16!("\\TUFFdemo.json");
const TUFF_DEMO_BOOT_FILE_PATH: &CStr16 = cstr16!("\\EFI\\BOOT\\TUFFdemo.json");
const OPERATIONAL_LOOP_INTERVAL_USEC: usize = 250_000;
const BOOT_POLICY_CHUNK_NUMBER: u64 = 64;
const UPDATE_MANIFEST_CHUNK_NUMBER: u64 = 72;
const AUDIT_LOG_CHUNK_NUMBER: u64 = 80;
const DEL_WAIT_POLLS: usize = 50;
const KEY_POLL_STALL_USEC: usize = 100_000;
const MAX_AUTH_FAILURES: u8 = 3;
const AUTH_LOCKOUT_USEC: usize = 5 * 60 * 1_000_000;
const DEMO_PIN: [u8; 6] = *b"123456";
const ALERT_IPC_SHARED_MEMORY_PATH: &str = "shared-memory:tuff.alert.ipc.v1";
const ALERT_CODE_METADATA_MISSING_REPLICA: u32 = 1;
const ALERT_CODE_METADATA_REPLICA_MISMATCH: u32 = 2;
const ALERT_CODE_QUEUE_PROCESS_CYCLE_FAILED: u32 = 10;
const ALERT_CODE_QUEUE_WRITEBACK_FAILED: u32 = 11;
const ALERT_CODE_RECLAIM_DUPLICATE_CHUNK: u32 = 20;
const ALERT_CODE_RECLAIM_STALE_EPOCH: u32 = 21;
const VM_PLAN_RUN_RM_CP_MV: u8 = 1 << 0;
const VM_PLAN_INJECT_DISK_FULL: u8 = 1 << 1;
const VM_PLAN_INJECT_FLUSH_SPOOF: u8 = 1 << 2;
const VM_PLAN_INJECT_RECLAIM_INTERRUPT: u8 = 1 << 3;
const VM_PLAN_CSE_ZEROIZATION_PROBE: u8 = 1 << 4;

struct MetadataCriticalRuntime {
    replica_sets: alloc::vec::Vec<MetadataCriticalReplicaSet>,
    last_verified_ms: u64,
}

struct FileExRuntime {
    file_ex: FileExState,
    reclaim: ReclaimState,
    readers: ReaderTrackingState,
}

#[derive(Clone, Copy, Default)]
struct VmValidationPlan {
    run_rm_cp_mv: bool,
    inject_disk_full: bool,
    inject_flush_spoof: bool,
    inject_reclaim_interrupt: bool,
    run_cse_zeroization_probe: bool,
}

#[derive(Clone, Copy)]
struct RecoverSelectedTarget {
    disk_id: u64,
    handle: Handle,
    target_meta_chunk: u64,
    fmc_buffer: [u8; 4096],
    tk: [u8; 32],
    pk: [u8; 32],
}

#[allow(dead_code)]
enum AlertIpcTransport {
    SharedMemory(*mut AlertSharedMemoryPage),
    Degraded,
}

struct AlertIpcRuntime {
    transport: AlertIpcTransport,
}

struct AlertDaemonRuntime {
    mode: AlertConsumerMode,
    shared_page: Option<*const AlertSharedMemoryPage>,
    cursor: AlertConsumerCursor,
}

impl AlertIpcRuntime {
    fn from_shared_page(page: *mut AlertSharedMemoryPage) -> Self {
        Self {
            transport: AlertIpcTransport::SharedMemory(page),
        }
    }

    fn emit(&mut self, event: AlertEvent) -> Result<(), ()> {
        match &mut self.transport {
            AlertIpcTransport::SharedMemory(page) => {
                let page = unsafe { &mut **page };
                push_alert_event(page, event);
                Ok(())
            }
            AlertIpcTransport::Degraded => Err(()),
        }
    }
}

impl AlertDaemonRuntime {
    fn from_shared_page(page: *const AlertSharedMemoryPage, mode: AlertConsumerMode) -> Self {
        Self {
            mode,
            shared_page: Some(page),
            cursor: init_alert_consumer_cursor(),
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum BootState {
    Wait,
    ScanNegative,
    Auth,
    EjectWait,
    RecoverMount,
    ForceInstall,
    Halt,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum AuthMode {
    DemoAuto,
    ManualUsbPin,
}

struct BootFlow {
    state: BootState,
    auth_mode: AuthMode,
    failures: u8,
    owner_mk: [u8; 32],
    force_install: bool,
    tuffkey: Option<TuffKeyRecord>,
    coordinator: CommitCoordinator,
}

#[derive(Clone, Copy)]
struct TuffKeyRecord {
    wrapped_tk: [u8; 48],
    wrapped_pk: [u8; 48],
    policy_root_hash: [u8; 32],
    key_bundle_hash: [u8; 32],
}

#[inline(always)]
fn cycle_counter() -> u64 {
    #[cfg(target_arch = "x86_64")]
    unsafe {
        _rdtsc()
    }

    #[cfg(not(target_arch = "x86_64"))]
    {
        0
    }
}

#[entry]
fn main(_handle: Handle, mut system_table: SystemTable<Boot>) -> Status {
    uefi_services::init(&mut system_table).unwrap();

    let stdout = system_table.stdout();
    stdout.clear().unwrap();
    stdout.set_color(Color::Cyan, Color::Black).unwrap();

    info!("TUFF-Core: Starting Bare-Metal Boot Sequence...");

    let bt_ptr = system_table.boot_services() as *const BootServices;
    let stdin = system_table.stdin();
    let bt = unsafe { &*bt_ptr };
    let mut flow = BootFlow {
        state: BootState::Wait,
        auth_mode: AuthMode::DemoAuto,
        failures: 0,
        owner_mk: MOCK_MASTER_KEY,
        force_install: false,
        tuffkey: None,
        coordinator: CommitCoordinator::new(),
    };

    loop {
        match flow.state {
            BootState::Wait => {
                info!("STATE_WAIT: DEL key for manual USB/PIN path, otherwise demo auto path.");
                let (auth_mode, force_install) = wait_for_del_or_demo(bt, stdin);
                flow.auth_mode = auth_mode;
                flow.force_install = force_install;
                flow.state = BootState::ScanNegative;
            }
            BootState::ScanNegative => {
                if removable_media_present(bt) {
                    info!("STATE_SCAN_NEGATIVE: removable media detected.");
                } else {
                    info!("STATE_SCAN_NEGATIVE: no removable media detected.");
                }
                flow.state = BootState::Auth;
            }
            BootState::Auth => match authenticate_owner(bt, stdin, flow.auth_mode) {
                Ok((owner_mk, tuffkey)) => {
                    flow.owner_mk = owner_mk;
                    flow.tuffkey = tuffkey;
                    flow.state = if flow.force_install {
                        BootState::ForceInstall
                    } else if matches!(flow.auth_mode, AuthMode::ManualUsbPin)
                        && removable_media_present(bt)
                    {
                        BootState::EjectWait
                    } else {
                        BootState::RecoverMount
                    };
                }
                Err(err) => {
                    flow.failures = flow.failures.saturating_add(1);
                    warn!(
                        "STATE_AUTH failed: {:?} ({}/{})",
                        err, flow.failures, MAX_AUTH_FAILURES
                    );
                    if flow.failures >= MAX_AUTH_FAILURES {
                        stall_for_lockout(bt);
                        flow.failures = 0;
                    }
                    flow.state = BootState::Wait;
                }
            },
            BootState::EjectWait => {
                info!("STATE_EJECT_WAIT: waiting for removable media removal.");
                while removable_media_present(bt) {
                    bt.stall(KEY_POLL_STALL_USEC);
                }
                flow.state = if flow.force_install {
                    BootState::ForceInstall
                } else {
                    BootState::RecoverMount
                };
            }
            BootState::RecoverMount => {
                let status = run_recover_mount(bt, &flow.owner_mk, flow.tuffkey, &mut flow.coordinator);
                if status == Status::SUCCESS {
                    flow.state = BootState::Halt;
                } else {
                    flow.failures = flow.failures.saturating_add(1);
                    flow.state = BootState::Wait;
                }
            }
            BootState::ForceInstall => {
                let status = run_force_install(bt, &flow.owner_mk);
                if status == Status::SUCCESS {
                    flow.state = BootState::Halt;
                } else {
                    flow.failures = flow.failures.saturating_add(1);
                    flow.state = BootState::Wait;
                }
            }
            BootState::Halt => break,
        }
    }

    run_operational_loop(bt, &mut flow.coordinator)
}

fn run_recover_mount(
    bt: &BootServices,
    owner_mk: &[u8; 32],
    tuffkey: Option<TuffKeyRecord>,
    coordinator: &mut CommitCoordinator,
) -> Status {
    info!("STATE_RECOVER_MOUNT: Starting Genesis -> KEC -> FIC -> FMC Discovery...");

    if let Some(vote) = verify_3n_genesis(bt, owner_mk) {
        if vote.quorum_count >= 2 {
            info!(
                "3N majority_vote_passed: {} of {} devices, latest timestamp {}.",
                vote.quorum_count,
                vote.candidate_count,
                vote.candidate.timestamp
            );
        } else {
            warn!(
                "3N degraded: only {} matching Genesis candidate(s); proceeding in demo-compatible mode.",
                vote.quorum_count
            );
        }
    } else {
        warn!("No valid Genesis candidate matched the supplied MK.");
        return Status::SECURITY_VIOLATION;
    }

    let handles = match bt.find_handles::<BlockIO>() {
        Ok(handles) => handles,
        Err(err) => {
            warn!("BlockIO discovery failed: {:?}", err.status());
            return Status::LOAD_ERROR;
        }
    };

    let target_hash = sha256_name(TARGET_FILE_NAME);
    let mut registered_fmc_replicas = 0usize;
    let mut disk_handle_map = alloc::vec::Vec::new();
    let mut target_meta_truth_candidates = alloc::vec::Vec::new();
    let mut selected_target: Option<RecoverSelectedTarget> = None;
    let mut vm_validation_requested = false;
    let mut vm_validation_mask: u8 = 0;

    for (index, handle) in handles.iter().enumerate() {
        disk_handle_map.push((index as u64, *handle));
        let block_io = match bt.open_protocol_exclusive::<BlockIO>(*handle) {
            Ok(io) => io,
            Err(_) => continue,
        };

        let media = block_io.media();
        let block_size = media.block_size() as usize;
        if !media.is_media_present()
            || block_size == 0
            || block_size > GENESIS_SIZE
            || GENESIS_SIZE % block_size != 0
        {
            continue;
        }
        let lba_per_chunk = (GENESIS_SIZE / block_size) as u64;

        let mut genesis_buf = PageAlignedBuffer([0u8; 4096]);
        if block_io.read_blocks(media.media_id(), 0, &mut genesis_buf.0).is_err() {
            continue;
        }
        if &genesis_buf.0[..Genesis::MAGIC.len()] != Genesis::MAGIC.as_slice() {
            continue;
        }
        let genesis = unsafe { &*(genesis_buf.0.as_ptr() as *const Genesis) };

        info!("!!! FOUND GENESIS ON DEVICE [{}] !!!", index);
        if genesis.reserved[0] == 0xa5 {
            vm_validation_requested = true;
            vm_validation_mask |= genesis.reserved[1];
        }

        let kec_lba = KEC_CHUNK_NUMBER * lba_per_chunk;
        let mut kec_buf = PageAlignedBuffer([0u8; 4096]);
        if block_io
            .read_blocks(media.media_id(), kec_lba, &mut kec_buf.0)
            .is_err()
        {
            warn!("  -> Failed to read KEC chunk at LBA {}", kec_lba);
            continue;
        }

        let kec = unsafe { &*(kec_buf.0.as_ptr() as *const KeyEnvelopeChunk) };
        if &kec.magic != b"TUFFKEC " {
            warn!("  -> Invalid KEC magic at LBA {}", kec_lba);
            continue;
        }
        info!("  -> Reading KEC Chunk at LBA {}...", kec_lba);
        info!("  -> KEC signature algorithm: {:?}", kec.signature_algorithm);
        if kec.compute_key_bundle_hash() == kec.key_bundle_hash {
            info!("  -> [SUCCESS] KEC key bundle hash validated.");
        } else {
            warn!("  -> [CRITICAL] KEC key bundle hash mismatch.");
            continue;
        }
        if let Some(record) = tuffkey {
            if record.key_bundle_hash != kec.key_bundle_hash {
                warn!("  -> [CRITICAL] TUFFkey.json key bundle hash mismatch.");
                continue;
            }
        }

        let (_ok, tkw, pkw) = match KeyEnvelopeManager::verify_mk_for_kec(kec, owner_mk) {
            Ok(keys) => {
                info!("  -> [SUCCESS] Recover path accepted: MK verifier matched.");
                keys
            }
            Err(err) => {
                warn!(
                    "  -> [CRITICAL] Recover path rejected: {:?}. ForceInstall would be destructive.",
                    err
                );
                continue;
            }
        };
        let wrapped_tk = tuffkey.map(|record| record.wrapped_tk).unwrap_or(kec.wrapped_tk);
        let wrapped_pk = tuffkey.map(|record| record.wrapped_pk).unwrap_or(kec.wrapped_pk);
        let policy_root_hash = tuffkey
            .map(|record| record.policy_root_hash)
            .unwrap_or(kec.policy_root_hash);

        let tk = match KeyEnvelopeManager::unwrap_tk(&wrapped_tk, &tkw) {
            Ok(key) => {
                info!("  -> [SUCCESS] Wrapped TK restored.");
                key
            }
            Err(err) => {
                warn!("  -> [CRITICAL] Wrapped TK restore failed: {:?}", err);
                continue;
            }
        };
        let pk = match KeyEnvelopeManager::unwrap_pk(&wrapped_pk, &pkw) {
            Ok(key) => {
                info!("  -> [SUCCESS] Wrapped PK restored.");
                key
            }
            Err(err) => {
                warn!("  -> [CRITICAL] Wrapped PK restore failed: {:?}", err);
                continue;
            }
        };
        let embedded_root_pk = embedded_root_policy_public_key();
        let expected_root_hash =
            KeyEnvelopeManager::compute_policy_root_hash(&embedded_root_pk);
        if expected_root_hash != policy_root_hash {
            warn!("  -> [CRITICAL] Policy root hash mismatch.");
            continue;
        }
        verify_policy_samples(
            &block_io,
            media.media_id(),
            lba_per_chunk,
            &embedded_root_pk,
        );

        let fic_lba = FIC_CHUNK_NUMBER * lba_per_chunk;
        let mut fic_buf = PageAlignedBuffer([0u8; 4096]);
        let fic_read_start = cycle_counter();
        if block_io
            .read_blocks(media.media_id(), fic_lba, &mut fic_buf.0)
            .is_err()
        {
            warn!("  -> Failed to read FIC chunk at LBA {}", fic_lba);
            continue;
        }
        let fic_read_cycles = cycle_counter().saturating_sub(fic_read_start);

        info!("  -> Reading FIC Chunk at LBA {}...", fic_lba);
        let fic = unsafe { &*(fic_buf.0.as_ptr() as *const FicChunk) };
        let epoch = 100;
        let fic_chunk_id = [0x11; 16];
        let mut fic_desc = CseEngine::load_fic_descriptor(fic_chunk_id, epoch, fic);
        info!("  -> Executing FIC CSE Decryption Engine...");

        let fic_decrypt_start = cycle_counter();
        match CseEngine::process_fic_block_secure(&mut fic_buf.0, &mut fic_desc, &tk, &pk, false) {
            Ok(()) => {
                let fic_decrypt_cycles = cycle_counter().saturating_sub(fic_decrypt_start);
                fic_buf.0[FIC_CSE_INFO_OFFSET..FIC_CSE_INFO_OFFSET + FIC_CSE_INFO_SIZE]
                    .copy_from_slice(as_bytes(&fic_desc.info));
                let decrypted_fic = unsafe { &*(fic_buf.0.as_ptr() as *const FicChunk) };
                info!("  -> [SUCCESS] FIC Decryption & Integrity Validated.");
                info!("  -> FIC BlockIO read cycles: {}", fic_read_cycles);
                info!("  -> FIC CSE decrypt cycles: {}", fic_decrypt_cycles);

                let mut disk_target_meta_chunk = None;
                for entry in decrypted_fic
                    .entries
                    .iter()
                    .take(decrypted_fic.entry_count as usize)
                {
                    if entry.entry_type == 0 {
                        continue;
                    }
                    if entry.filename_hash == target_hash {
                        target_meta_truth_candidates.push(entry.meta_id);
                        if merge_target_meta_chunk_truths(&target_meta_truth_candidates).is_err() {
                            warn!(
                                "  -> [CRITICAL] Ambiguous target FMC truth for '{}': conflicting meta chunks detected",
                                TARGET_FILE_NAME
                            );
                            return Status::ABORTED;
                        }
                        disk_target_meta_chunk = Some(entry.meta_id);
                        info!(
                            "  -> Resolved '{}' tag={} meta_chunk={}",
                            TARGET_FILE_NAME,
                            entry.tag_id,
                            entry.meta_id
                        );
                    }

                    let fmc_lba = entry.meta_id * lba_per_chunk;
                    let mut fmc_buf = PageAlignedBuffer([0u8; 4096]);
                    let fmc_read_start = cycle_counter();
                    if block_io
                        .read_blocks(media.media_id(), fmc_lba, &mut fmc_buf.0)
                        .is_err()
                    {
                        warn!("  -> Failed to read FMC chunk at LBA {}", fmc_lba);
                        continue;
                    }
                    let fmc_read_cycles = cycle_counter().saturating_sub(fmc_read_start);
                    let fmc = unsafe { &*(fmc_buf.0.as_ptr() as *const FmcChunk) };
                    let fmc_chunk_id = [0x22; 16];
                    let fmc_desc = CseEngine::load_descriptor(fmc_chunk_id, epoch, fmc);
                    let fmc_decrypt_start = cycle_counter();
                    let mut fmc_descs = [fmc_desc];
                    let cse_scheduler = CseScheduler::for_uefi();
                    let mut blocks: [&mut [u8; 4096]; 1] = [&mut fmc_buf.0];
                    match cse_scheduler.process_blocks_parallel(
                        &mut blocks,
                        &mut fmc_descs,
                        &tk,
                        &pk,
                        false,
                    ) {
                        Ok(()) => {
                            let fmc_decrypt_cycles =
                                cycle_counter().saturating_sub(fmc_decrypt_start);
                            fmc_buf.0[FMC_CSE_INFO_OFFSET..FMC_CSE_INFO_OFFSET + FMC_CSE_INFO_SIZE]
                                .copy_from_slice(as_bytes(&fmc_descs[0].info));
                            let decrypted_fmc =
                                unsafe { &*(fmc_buf.0.as_ptr() as *const FmcChunk) };
                            info!(
                                "  -> FMC registered file_id={} lba={} file_size={} read_cycles={} decrypt_cycles={}",
                                entry.meta_id,
                                fmc_lba,
                                decrypted_fmc.file_size,
                                fmc_read_cycles,
                                fmc_decrypt_cycles
                            );
                            register_discovered_fmc(
                                coordinator,
                                FmcDiscoveryReplica {
                                    file_id: entry.meta_id,
                                    disk_id: index as u64,
                                    start_lba: fmc_lba,
                                    buffer: fmc_buf.0,
                                },
                            );
                            registered_fmc_replicas =
                                registered_fmc_replicas.saturating_add(1);
                            if Some(entry.meta_id) == disk_target_meta_chunk && selected_target.is_none() {
                                selected_target = Some(RecoverSelectedTarget {
                                    disk_id: index as u64,
                                    handle: *handle,
                                    target_meta_chunk: entry.meta_id,
                                    fmc_buffer: fmc_buf.0,
                                    tk,
                                    pk,
                                });
                            }
                        }
                        Err(err) => warn!(
                            "  -> [BLOCKED] FMC meta_id={} rejected: {:?}",
                            entry.meta_id,
                            err
                        ),
                    }
                }
            }
            Err(err) => warn!("  -> [BLOCKED] FIC rejected: {:?}", err),
        }
    }
    let Some(selected_target) = selected_target else {
        return Status::LOAD_ERROR;
    };
    complete_recover_runtime(
        bt,
        &disk_handle_map,
        coordinator,
        registered_fmc_replicas,
        selected_target,
        vm_validation_requested,
        vm_validation_mask,
    )
}

fn complete_recover_runtime(
    bt: &BootServices,
    disk_handle_map: &[(u64, Handle)],
    coordinator: &mut CommitCoordinator,
    registered_fmc_replicas: usize,
    selected_target: RecoverSelectedTarget,
    vm_validation_requested: bool,
    vm_validation_mask: u8,
) -> Status {
    let block_io = match bt.open_protocol_exclusive::<BlockIO>(selected_target.handle) {
        Ok(io) => io,
        Err(err) => {
            warn!("  -> Failed to reopen selected target BlockIO: {:?}", err.status());
            return Status::LOAD_ERROR;
        }
    };
    let media = block_io.media();
    let block_size = media.block_size() as usize;
    if !media.is_media_present() || block_size == 0 || GENESIS_SIZE % block_size != 0 {
        return Status::LOAD_ERROR;
    }
    let lba_per_chunk = (GENESIS_SIZE / block_size) as u64;
    let epoch = 100;
    let fmc_buf = PageAlignedBuffer(selected_target.fmc_buffer);
    let decrypted_fmc = unsafe { &*(fmc_buf.0.as_ptr() as *const FmcChunk) };
    let scheduler = CseScheduler::for_uefi();
    info!(
        "  -> FMC scheduler mode: {:?} workers={}",
        scheduler.mode, scheduler.worker_count
    );
    let read_plan = scheduler.build_data_read_plan(
        &decrypted_fmc.pointer_matrix,
        decrypted_fmc.file_size as usize,
        lba_per_chunk,
    );
    let active_count = core::cmp::min(read_plan.count, 2);
    let mut data_bufs = [
        PageAlignedBuffer([0u8; 4096]),
        PageAlignedBuffer([0u8; 4096]),
    ];
    let mut data_descs = [
        CseEngine::load_descriptor([0x22; 16], epoch, decrypted_fmc),
        CseEngine::load_descriptor([0x22; 16], epoch, decrypted_fmc),
    ];

    for plan_index in 0..active_count {
        let slot = read_plan.chunk_indices[plan_index];
        let data_lba = read_plan.lbas[plan_index];
        let bytes_to_consume = read_plan.bytes_to_consume[plan_index];
        info!(
            "  -> Traversing pointer_matrix[{}] -> chunk {} (LBA {}, {} bytes)",
            slot,
            decrypted_fmc.pointer_matrix[slot],
            data_lba,
            bytes_to_consume
        );
        let traverse_start = cycle_counter();
        match block_io.read_blocks(media.media_id(), data_lba, &mut data_bufs[plan_index].0) {
            Ok(()) => {
                let traverse_cycles = cycle_counter().saturating_sub(traverse_start);
                info!(
                    "  -> LBA {} read complete in {} cycles",
                    data_lba,
                    traverse_cycles
                );
                data_descs[plan_index] = tuff_core::cse::types::CseDescriptor {
                    chunk_id: [0x31 + (slot as u8); 16],
                    epoch,
                    info: tuff_core::cse::types::CseInfo::with_integrity_tag(
                        decrypted_fmc.cse_info.algorithm_chain,
                        decrypted_fmc.cse_info.structural_seed,
                        decrypted_fmc.data_chunk_tags[slot],
                    ),
                };
            }
            Err(err) => warn!("  -> Failed to traverse LBA {}: {:?}", data_lba, err.status()),
        }
    }

    if active_count == 0 {
        return Status::LOAD_ERROR;
    }

    let data_decrypt_start = cycle_counter();
    let result = if active_count == 1 {
        let mut data_blocks = [&mut data_bufs[0].0];
        scheduler.process_data_blocks_parallel(
            &mut data_blocks,
            &mut data_descs[..1],
            &selected_target.tk,
            &selected_target.pk,
            false,
        )
    } else {
        let (first, second) = data_bufs.split_at_mut(1);
        let mut data_blocks = [&mut first[0].0, &mut second[0].0];
        scheduler.process_data_blocks_parallel(
            &mut data_blocks,
            &mut data_descs[..2],
            &selected_target.tk,
            &selected_target.pk,
            false,
        )
    };

    match result {
        Ok(()) => {
            let data_decrypt_cycles = cycle_counter().saturating_sub(data_decrypt_start);
            let total_blocks = media.last_block().saturating_add(1);
            let total_bytes = total_blocks.saturating_mul(block_size as u64);
            let capacity_4k = core::cmp::max(1, total_bytes / 4096);
            let ssd_available = !media.is_removable_media() && media.is_media_present();
            drop(block_io);
            let mut scheduler_disks = alloc::vec::Vec::new();
            for (disk_id, handle) in disk_handle_map.iter().copied() {
                let Ok(block_io) = bt.open_protocol_exclusive::<BlockIO>(handle) else {
                    continue;
                };
                let media = block_io.media();
                if !media.is_media_present() || media.is_read_only() {
                    continue;
                }
                let total_blocks = media.last_block().saturating_add(1);
                let total_bytes = total_blocks.saturating_mul(media.block_size() as u64);
                let disk_capacity_4k = core::cmp::max(1, total_bytes / 4096);
                scheduler_disks.push((disk_id, disk_capacity_4k));
            }
            if scheduler_disks.is_empty() {
                scheduler_disks.push((selected_target.disk_id, capacity_4k));
            } else if !scheduler_disks.iter().any(|(disk_id, _)| *disk_id == selected_target.disk_id) {
                scheduler_disks.push((selected_target.disk_id, capacity_4k));
            }
            match load_file_ex_state_from_metadata(
                bt,
                disk_handle_map,
                coordinator,
                selected_target.target_meta_chunk,
            ) {
                Ok(Some(_)) => info!("  -> FileEx metadata restore succeeded before runtime continuation"),
                Ok(None) => warn!("  -> FileEx metadata area not found; runtime will initialize a fresh FileEx state"),
                Err(status) => {
                    warn!("  -> FileEx metadata restore failed: {:?}", status);
                    return Status::ABORTED;
                }
            }
            let mut runtime_scheduler = HwScheduler::new(&scheduler_disks);
            let backend_policy =
                QueueBackendPolicy::with_preference(true, None, ssd_available);
            let mut uq_runtime = UniqueQueueRuntime::with_backend_policy(backend_policy);
            let mut metadata_runtime = MetadataCriticalRuntime {
                replica_sets: alloc::vec::Vec::new(),
                last_verified_ms: 0,
            };
            let mut validation_plan = load_vm_validation_plan(bt);
            validation_plan.run_rm_cp_mv |= (vm_validation_mask & VM_PLAN_RUN_RM_CP_MV) != 0;
            validation_plan.inject_disk_full |= (vm_validation_mask & VM_PLAN_INJECT_DISK_FULL) != 0;
            validation_plan.inject_flush_spoof |= (vm_validation_mask & VM_PLAN_INJECT_FLUSH_SPOOF) != 0;
            validation_plan.inject_reclaim_interrupt |=
                (vm_validation_mask & VM_PLAN_INJECT_RECLAIM_INTERRUPT) != 0;
            validation_plan.run_cse_zeroization_probe |=
                (vm_validation_mask & VM_PLAN_CSE_ZEROIZATION_PROBE) != 0;
            if vm_validation_requested {
                if !validation_plan.run_rm_cp_mv
                    && !validation_plan.inject_disk_full
                    && !validation_plan.inject_flush_spoof
                    && !validation_plan.inject_reclaim_interrupt
                    && !validation_plan.run_cse_zeroization_probe
                {
                    validation_plan.run_rm_cp_mv = true;
                }
                info!(
                    "  -> VM validation plan requested by Genesis marker: {} / {}",
                    COPY_TARGET_FILE_NAME,
                    MOVE_TARGET_FILE_NAME
                );
            }
            info!(
                "  -> VM validation flags: rm_cp_mv={} disk_full={} flush_spoof={} reclaim_interrupt={} cse_probe={}",
                validation_plan.run_rm_cp_mv,
                validation_plan.inject_disk_full,
                validation_plan.inject_flush_spoof,
                validation_plan.inject_reclaim_interrupt,
                validation_plan.run_cse_zeroization_probe
            );
            let shared_alert_page =
                Box::leak(Box::new(init_alert_shared_memory_page())) as *mut AlertSharedMemoryPage;
            let mut alert_runtime = AlertIpcRuntime::from_shared_page(shared_alert_page);
            let mut daemon_runtime = AlertDaemonRuntime::from_shared_page(
                shared_alert_page,
                select_alert_consumer_mode(false),
            );
            if uq_runtime.backend_policy.kind == QueueBackendKind::FileBacked {
                match load_queue_records_from_mq(bt) {
                    Ok(records) => {
                        uq_runtime.persisted_queue_records = records;
                    }
                    Err(status) => {
                        warn!("  -> MQ load failed ({:?}); fallback to memory-backed", status);
                        uq_runtime.backend_policy = QueueBackendPolicy::default();
                    }
                }
            }
            match uq_runtime.resume_from_persisted_queue() {
                Ok(report) => {
                    let backend_name = match uq_runtime.backend_policy.kind {
                        QueueBackendKind::MemoryBacked => "memory-backed",
                        QueueBackendKind::FileBacked => "file-backed(policy)",
                    };
                    info!(
                        "  -> UQ resume: backend={}, resumed={}, truncated_tail={}",
                        backend_name, report.resumed_records, report.truncated_tail_records
                    );
                }
                Err(err) => {
                    warn!("  -> UQ resume failed (fail-closed): {:?}", err);
                    return Status::ABORTED;
                }
            }
            match submit_normal_operation_write(
                bt,
                disk_handle_map,
                coordinator,
                &mut runtime_scheduler,
                &mut uq_runtime,
                &mut metadata_runtime,
                &mut alert_runtime,
                selected_target.target_meta_chunk,
                RuntimeDataWriteRequest {
                    file_id: selected_target.target_meta_chunk,
                    entry_index: 0,
                    old_lba: decrypted_fmc.pointer_matrix[0],
                    epoch,
                    priority: IoPriority::NormalData,
                    sectors: 1,
                    target_disk: Some(selected_target.disk_id),
                    exclude_disks: [0; 3],
                    exclude_len: 0,
                    chunk: data_bufs[0].0,
                    descriptor: tuff_core::cse::types::CseDescriptor {
                        chunk_id: [0x81; 16],
                        epoch,
                        info: tuff_core::cse::types::CseInfo::new(
                            decrypted_fmc.cse_info.algorithm_chain,
                            decrypted_fmc.cse_info.structural_seed,
                        ),
                    },
                    tk: selected_target.tk,
                    pk: selected_target.pk,
                },
                validation_plan,
            ) {
                Ok(completed) => {
                    if completed > 0 {
                        info!(
                            "  -> Runtime data write path queued and wrote {} block(s)",
                            completed
                        );
                    } else {
                        warn!("  -> Runtime data write path produced no physical writeback");
                    }
                }
                Err(status) => {
                    warn!("  -> Runtime data write path failed: {:?}", status);
                    return status;
                }
            }
            if validation_plan.run_rm_cp_mv {
                match run_vm_validation_rm_cp_mv(
                    bt,
                    disk_handle_map,
                    coordinator,
                    &mut runtime_scheduler,
                    &mut uq_runtime,
                    &mut metadata_runtime,
                    &mut alert_runtime,
                    selected_target.target_meta_chunk,
                    selected_target.disk_id,
                    epoch,
                    data_bufs[0].0,
                    selected_target.tk,
                    selected_target.pk,
                ) {
                    Ok(()) => info!("  -> VM validation rm/cp/mv sequence completed"),
                    Err(status) => {
                        warn!("  -> VM validation rm/cp/mv sequence failed: {:?}", status);
                        return status;
                    }
                }
            }
            consume_daemon_alerts(&mut daemon_runtime);
            if uq_runtime.backend_policy.kind == QueueBackendKind::FileBacked {
                match persist_queue_records_to_mq(bt, &mut uq_runtime.persisted_queue_records) {
                    Ok(()) => info!("  -> MQ persisted: {} record(s)", uq_runtime.persisted_queue_records.len()),
                    Err(status) => {
                        warn!("  -> MQ persist failed (fail-closed): {:?}", status);
                        return Status::ABORTED;
                    }
                }
            }
            if registered_fmc_replicas > 0 {
                info!(
                    "  -> CommitCoordinator FMC registration active: {} replica(s)",
                    registered_fmc_replicas
                );
            }
            info!("  -> Data CSE decrypt cycles: {}", data_decrypt_cycles);
            info!(
                "  -> Data chunk 0 prefix: {:02x} {:02x} {:02x} {:02x}",
                data_bufs[0].0[0],
                data_bufs[0].0[1],
                data_bufs[0].0[2],
                data_bufs[0].0[3]
            );
            if active_count > 1 {
                info!(
                    "  -> Data chunk 1 prefix: {:02x} {:02x} {:02x} {:02x}",
                    data_bufs[1].0[0],
                    data_bufs[1].0[1],
                    data_bufs[1].0[2],
                    data_bufs[1].0[3]
                );
            }
            Status::SUCCESS
        }
        Err(err) => {
            warn!("  -> [BLOCKED] Data chunk rejected: {:?}", err);
            Status::ABORTED
        }
    }
}

fn load_queue_records_from_mq(bt: &BootServices) -> Result<alloc::vec::Vec<QueuePersistedRecord>, Status> {
    let handles = bt.find_handles::<SimpleFileSystem>().map_err(|e| e.status())?;
    for handle in handles.iter() {
        let mut fs = bt.open_protocol_exclusive::<SimpleFileSystem>(*handle).map_err(|e| e.status())?;
        let mut root = fs.open_volume().map_err(|e| e.status())?;
        let file_handle = match root.open(
            TUFF_MQ_FILE_PATH,
            FileMode::Read,
            FileAttribute::empty(),
        ) {
            Ok(fh) => fh,
            Err(_) => continue,
        };
        let mut file = file_handle.into_regular_file().ok_or(Status::UNSUPPORTED)?;
        let mut buf = [0u8; 65_536];
        let size = file.read(&mut buf).map_err(|e| e.status())?;
        return decode_queue_records(&buf[..size]).map_err(|_| Status::COMPROMISED_DATA);
    }
    Ok(alloc::vec::Vec::new())
}

fn persist_queue_records_to_mq(
    bt: &BootServices,
    records: &mut alloc::vec::Vec<QueuePersistedRecord>,
) -> Result<(), Status> {
    let retention = default_mq_retention_policy();
    let report = compact_queue_records_with_policy(records, retention);
    if report.removed_terminal_records > 0 || report.deduplicated_records > 0 {
        info!(
            "  -> MQ compaction: removed_terminal={}, deduplicated={}, keep_recent={}, rejected_retention={}, verified_commit_retention={}",
            report.removed_terminal_records,
            report.deduplicated_records,
            retention.keep_recent_epochs,
            retention.retain_rejected_epochs,
            retention.retain_verified_commit_epochs
        );
    }
    let handles = bt.find_handles::<SimpleFileSystem>().map_err(|e| e.status())?;
    for handle in handles.iter() {
        let mut fs = bt.open_protocol_exclusive::<SimpleFileSystem>(*handle).map_err(|e| e.status())?;
        let mut root = fs.open_volume().map_err(|e| e.status())?;
        let file_handle = root
            .open(
                TUFF_MQ_FILE_PATH,
                FileMode::CreateReadWrite,
                FileAttribute::ARCHIVE,
            )
            .map_err(|e| e.status())?;
        let mut file = file_handle.into_regular_file().ok_or(Status::UNSUPPORTED)?;
        let encoded = encode_queue_records(records);
        file.write(&encoded).map_err(|e| e.status())?;
        file.flush().map_err(|e| e.status())?;
        return Ok(());
    }
    Err(Status::NOT_FOUND)
}

fn run_force_install(bt: &BootServices, owner_mk: &[u8; 32]) -> Status {
    warn!("STATE_FORCE_INSTALL: rebuilding Genesis/KEC across detected 3N devices.");

    let embedded_root_pk = embedded_root_policy_public_key();
    let policy_root_hash =
        KeyEnvelopeManager::compute_policy_root_hash(&embedded_root_pk);
    let stamp = cycle_counter().max(2);
    let mut fs_uuid_seed = [0u8; 32];
    let mut salt_seed = [0u8; 32];
    let mut tk_entropy = [0u8; 32];
    let mut pk_entropy = [0u8; 32];
    fill_seeded_bytes(owner_mk, b"force-install-fs-uuid", stamp, &mut fs_uuid_seed);
    fill_seeded_bytes(owner_mk, b"force-install-salt", stamp, &mut salt_seed);
    fill_seeded_bytes(owner_mk, b"force-install-tk", stamp, &mut tk_entropy);
    fill_seeded_bytes(owner_mk, b"force-install-pk", stamp, &mut pk_entropy);

    let mut fs_uuid = [0u8; 16];
    fs_uuid.copy_from_slice(&fs_uuid_seed[..16]);
    let (kec, _tk, _pk) = KeyEnvelopeManager::init_new_kec(
        owner_mk,
        policy_root_hash,
        fs_uuid,
        salt_seed,
        DEFAULT_KDF_PARAMS,
        &tk_entropy,
        &pk_entropy,
    );

    let mut genesis = Genesis::new(*b"TUFF-UQ-001\0\0\0\0\0");
    genesis.timestamp = stamp;
    genesis.initial_key_hash = KeyEnvelopeManager::compute_owner_genesis_hash(owner_mk);
    CseEngine::fill_deterministic_padding(&mut genesis.reserved, fs_uuid, stamp, 0xee);

    let handles = match bt.find_handles::<BlockIO>() {
        Ok(handles) => handles,
        Err(err) => {
            warn!("STATE_FORCE_INSTALL: BlockIO discovery failed: {:?}", err.status());
            return Status::LOAD_ERROR;
        }
    };

    let mut wrote = 0usize;
    let mut previous_kec_hashes = [[0u8; 32]; 3];
    let mut previous_count = 0usize;
    for handle in handles.iter() {
        let Ok(mut block_io) = bt.open_protocol_exclusive::<BlockIO>(*handle) else {
            continue;
        };
        let media_id = block_io.media().media_id();
        let block_size = block_io.media().block_size() as usize;
        if !block_io.media().is_media_present()
            || block_io.media().is_removable_media()
            || block_io.media().is_read_only()
            || block_size == 0
            || block_size > GENESIS_SIZE
            || GENESIS_SIZE % block_size != 0
        {
            continue;
        }

        let mut sector0 = PageAlignedBuffer([0u8; 4096]);
        if block_io.read_blocks(media_id, 0, &mut sector0.0).is_err() {
            continue;
        }
        if &sector0.0[..Genesis::MAGIC.len()] != Genesis::MAGIC.as_slice() {
            continue;
        }

        let lba_per_chunk = (GENESIS_SIZE / block_size) as u64;
        let mut previous_kec_buf = PageAlignedBuffer([0u8; 4096]);
        if block_io
            .read_blocks(media_id, KEC_CHUNK_NUMBER * lba_per_chunk, &mut previous_kec_buf.0)
            .is_ok()
            && previous_count < 3
        {
            let previous_kec =
                unsafe { &*(previous_kec_buf.0.as_ptr() as *const KeyEnvelopeChunk) };
            previous_kec_hashes[previous_count] = previous_kec.key_bundle_hash;
        }

        let mut genesis_buf = PageAlignedBuffer([0u8; 4096]);
        genesis_buf.0.copy_from_slice(as_bytes(&genesis));
        if block_io
            .write_blocks(media_id, 0, &genesis_buf.0)
            .is_err()
        {
            warn!("STATE_FORCE_INSTALL: failed to rewrite Genesis.");
            continue;
        }

        let mut kec_buf = PageAlignedBuffer([0u8; 4096]);
        kec_buf.0.copy_from_slice(as_bytes(&kec));
        if block_io
            .write_blocks(media_id, KEC_CHUNK_NUMBER * lba_per_chunk, &kec_buf.0)
            .is_err()
        {
            warn!("STATE_FORCE_INSTALL: failed to rewrite KEC.");
            continue;
        }

        let _ = block_io.flush_blocks();
        wrote += 1;
        previous_count += 1;
        if wrote == 3 {
            break;
        }
    }

    if wrote >= 3 {
        let mut silence_confirmed = true;
        for index in 0..previous_count {
            if previous_kec_hashes[index] == kec.key_bundle_hash {
                silence_confirmed = false;
            }
        }
        info!(
            "STATE_FORCE_INSTALL: rebuilt Genesis/KEC on {} devices. Previous data is now silent.",
            wrote
        );
        if silence_confirmed {
            info!(
                "STATE_FORCE_INSTALL: silence check passed; previous Genesis/KEC anchors no longer validate."
            );
        } else {
            warn!(
                "STATE_FORCE_INSTALL: silence check inconclusive; previous anchors partially matched."
            );
        }
        Status::SUCCESS
    } else {
        warn!(
            "STATE_FORCE_INSTALL: only {} writable Genesis devices found; aborting destructive install.",
            wrote
        );
        Status::ABORTED
    }
}

fn submit_normal_operation_write(
    bt: &BootServices,
    disk_handle_map: &[(u64, Handle)],
    coordinator: &mut CommitCoordinator,
    runtime_scheduler: &mut HwScheduler,
    uq_runtime: &mut UniqueQueueRuntime,
    metadata_runtime: &mut MetadataCriticalRuntime,
    alert_runtime: &mut AlertIpcRuntime,
    file_id: u64,
    request: RuntimeDataWriteRequest,
    validation_plan: VmValidationPlan,
) -> Result<usize, Status> {
    let epoch = request.epoch;
    info!(
        "mainline_write_path: file_id={} epoch={} target_disk={:?}",
        file_id,
        epoch,
        request.target_disk
    );
    let mut file_ex_runtime = load_or_init_file_ex_runtime(
        bt,
        disk_handle_map,
        coordinator,
        file_id,
        request.target_disk.unwrap_or(0),
        epoch,
    )?;
    let target_hw_id = request
        .target_disk
        .unwrap_or(file_ex_runtime.file_ex.n_state.committed_hw_id);
    let transfer_plan = classify_cross_hw_transfer(
        file_ex_runtime.file_ex.n_state.committed_hw_id,
        target_hw_id,
    );
    if validation_plan.inject_disk_full {
        warn!(
            "vm_validation disk_full injected fail_closed: file_id={} epoch={}",
            file_id,
            epoch
        );
        let _ = reject_pending_operation_with_reclaim(
            &mut file_ex_runtime.file_ex,
            &mut file_ex_runtime.reclaim,
            epoch,
        );
        return Err(Status::OUT_OF_RESOURCES);
    }
    info!(
        "  -> pending transfer policy: class={:?} policy={:?} source_hw={} target_hw={}",
        transfer_plan.class,
        transfer_plan.policy,
        transfer_plan.source_hw_id,
        transfer_plan.target_hw_id
    );
    let metadata_requests;
    let pending_op;
    let staged;
    {
        let file_ex = &mut file_ex_runtime.file_ex;
        let n_pending_chunk = descriptor_chunk_token(&request.descriptor);
        let j_pending_chunk = n_pending_chunk.saturating_add(1);
        stage_n_redundancy_candidate(file_ex, target_hw_id, n_pending_chunk);
        let append_request = AppendOnlyWriteRequest {
            file_id,
            base: AppendBaseGeneration {
                epoch: file_ex.j_state.current_epoch,
                chunk_id: file_ex.j_state.current_chunk_id,
            },
            range: AppendWriteRange {
                offset: 0,
                len: request.chunk.len() as u64,
            },
            payload: request.chunk.to_vec(),
        };
        staged = stage_append_only_generation(
            file_ex,
            append_request,
            Some(&request.chunk),
            epoch.saturating_add(1),
            j_pending_chunk,
        ).map_err(|_| Status::ABORTED)?;
        pending_op = PendingOperation {
            kind: PendingOperationKind::AppendOnly,
            source_file_id: None,
            target_file_id: file_id,
            base_epoch: file_ex.j_state.pending_base_epoch,
            base_chunk_id: file_ex.j_state.pending_base_chunk_id,
        };
        stage_pending_operation(file_ex, pending_op);
        metadata_requests = build_metadata_critical_requests_for_active_write(
            file_id,
            request.target_disk.unwrap_or(0),
            epoch,
            file_ex,
            &staged.full_image,
        );
    }
    write_metadata_critical_requests(
        bt,
        disk_handle_map,
        metadata_runtime,
        alert_runtime,
        &metadata_requests,
        runtime_scheduler,
    )?;
    let probe_tk = request.tk;
    let probe_pk = request.pk;
    let probe_chunk = request.chunk;
    let runtime_request = prepare_runtime_write_request_for_transfer(
        request,
        &staged.full_image,
        transfer_plan,
        file_ex_runtime.file_ex.n_state.committed_hw_id,
        target_hw_id,
        file_id,
        0,
        lookup_registered_fmc_pointer(coordinator, file_id, 0).unwrap_or(request.old_lba),
    );
    submit_runtime_data_write(uq_runtime, runtime_request);
    uq_runtime.process_cycle(runtime_scheduler, coordinator, epoch).map_err(|err| {
        warn!(
            "mainline_write_path: process_cycle failed file_id={} epoch={} pending_updates={} registered_fmcs={} err={:?}",
            file_id,
            epoch,
            coordinator.pending_updates.len(),
            coordinator.registered_fmcs.len(),
            err
        );
        emit_alert(
            alert_runtime,
            AlertEvent {
                sequence: 0,
                class: AlertClass::QueueFault,
                disk_id: request.target_disk.unwrap_or(0),
                file_id,
                epoch,
                code: ALERT_CODE_QUEUE_PROCESS_CYCLE_FAILED,
                aux: 0,
            },
        );
        Status::ABORTED
    })?;
    info!(
        "mainline_write_path: process_cycle ok file_id={} epoch={} pending_updates={} pending_writebacks={}",
        file_id,
        epoch,
        coordinator.pending_updates.len(),
        coordinator.pending_writebacks.len()
    );
    let completed = execute_physical_writebacks(bt, disk_handle_map, coordinator).map_err(|_| {
        warn!(
            "mainline_write_path: execute_physical_writebacks failed file_id={} epoch={}",
            file_id,
            epoch
        );
        emit_alert(
            alert_runtime,
            AlertEvent {
                sequence: 0,
                class: AlertClass::QueueFault,
                disk_id: request.target_disk.unwrap_or(0),
                file_id,
                epoch,
                code: ALERT_CODE_QUEUE_WRITEBACK_FAILED,
                aux: 0,
            },
        );
        Status::ABORTED
    })?;
    info!(
        "mainline_write_path: writebacks completed file_id={} epoch={} count={}",
        file_id,
        epoch,
        completed.len()
    );
    if validation_plan.inject_flush_spoof {
        warn!(
            "vm_validation flush_spoof injected fail_closed: file_id={} epoch={}",
            file_id,
            epoch
        );
        let _ = reject_pending_operation_with_reclaim(
            &mut file_ex_runtime.file_ex,
            &mut file_ex_runtime.reclaim,
            epoch,
        );
        return Err(Status::ABORTED);
    }
    for wb in completed.iter() {
        uq_runtime.mark_writeback_verified(wb.disk_id, wb.start_lba);
    }
    let pointer_validation_ready = completed
        .iter()
        .any(|wb| wb.priority == IoPriority::HighMetadata)
        && coordinator.pending_updates.is_empty();
    if pointer_validation_ready {
        info!(
            "mainline_write_path: pointer validation ready file_id={} epoch={}",
            file_id,
            epoch
        );
        uq_runtime.mark_epoch_pointer_validated(epoch);
        let mut committed_file_ex = file_ex_runtime.file_ex;
        let mut committed_reclaim = file_ex_runtime.reclaim.clone();
        let _ = commit_pending_operation_with_reclaim(
            &mut committed_file_ex,
            pending_op,
            &mut committed_reclaim,
            epoch,
        ).map_err(|_| {
            warn!(
                "mainline_write_path: commit_pending_operation_with_reclaim failed file_id={} epoch={}",
                file_id,
                epoch
            );
            Status::ABORTED
        })?;
        let committed_runtime = FileExRuntime {
            file_ex: committed_file_ex,
            reclaim: committed_reclaim.clone(),
            readers: file_ex_runtime.readers.clone(),
        };
        persist_file_ex_runtime(
            bt,
            disk_handle_map,
            coordinator,
            file_id,
            epoch,
            &committed_runtime,
        ).map_err(|status| {
            warn!(
                "mainline_write_path: persist_file_ex_runtime failed file_id={} epoch={} status={:?}",
                file_id,
                epoch,
                status
            );
            status
        })?;
        file_ex_runtime.file_ex = committed_file_ex;
        file_ex_runtime.reclaim = committed_reclaim;
    } else {
        warn!(
            "mainline_write_path: pointer validation not ready file_id={} epoch={} completed_high_metadata={} pending_updates={}",
            file_id,
            epoch,
            completed.iter().any(|wb| wb.priority == IoPriority::HighMetadata),
            coordinator.pending_updates.len()
        );
        let _ = reject_pending_operation_with_reclaim(
            &mut file_ex_runtime.file_ex,
            &mut file_ex_runtime.reclaim,
            epoch,
        );
    }
    let current_chunk_id = file_ex_runtime.file_ex.j_state.current_chunk_id;
    emit_reclaim_anomaly_if_any(alert_runtime, file_id, epoch, &file_ex_runtime.reclaim);
    file_ex_runtime.readers.active_readers_by_chunk.push(ActiveChunkRead {
        chunk_id: current_chunk_id,
        last_seen_epoch: epoch,
        in_flight_read_count: 0,
    });
    let _ = drain_reclaim_pending_to_free_list_reader_safe_with_policy(
        &mut file_ex_runtime.reclaim,
        &file_ex_runtime.readers,
        epoch,
        default_reader_reclaim_policy(),
    );
    if validation_plan.inject_reclaim_interrupt {
        warn!(
            "vm_validation reclaim_interrupt injected fail_closed: file_id={} epoch={}",
            file_id,
            epoch
        );
    }
    if validation_plan.run_cse_zeroization_probe {
        if run_cse_zeroization_probe(probe_tk, probe_pk, &probe_chunk) {
            info!("vm_validation cse_zeroization_probe_passed");
        } else {
            warn!("vm_validation cse_zeroization_probe_failed");
            return Err(Status::ABORTED);
        }
    }
    Ok(completed.len())
}

fn run_cse_zeroization_probe(
    tk: [u8; 32],
    pk: [u8; 32],
    sample_chunk: &[u8; 4096],
) -> bool {
    let mut tk_probe = tk;
    let mut pk_probe = pk;
    let mut chunk_probe = [0u8; 4096];
    chunk_probe.copy_from_slice(sample_chunk);
    tk_probe.fill(0);
    pk_probe.fill(0);
    chunk_probe.fill(0);
    tk_probe.iter().all(|byte| *byte == 0)
        && pk_probe.iter().all(|byte| *byte == 0)
        && chunk_probe.iter().all(|byte| *byte == 0)
}

fn descriptor_chunk_token(descriptor: &tuff_core::cse::types::CseDescriptor) -> u64 {
    u64::from_le_bytes(descriptor.chunk_id[..8].try_into().unwrap_or([0; 8]))
}

fn lookup_registered_fmc_pointer(
    coordinator: &CommitCoordinator,
    file_id: u64,
    entry_index: usize,
) -> Option<u64> {
    let replica = coordinator
        .registered_fmcs
        .iter()
        .find(|replica| replica.file_id == file_id)?;
    let fmc = unsafe { core::ptr::read_unaligned(replica.buffer.as_ptr() as *const FmcChunk) };
    fmc.pointer_matrix.get(entry_index).copied()
}

fn prepare_runtime_write_request_for_transfer(
    mut request: RuntimeDataWriteRequest,
    staged_full_image: &[u8],
    transfer_plan: tuff_core::engine::CrossHwTransferPlan,
    source_hw_id: u64,
    target_hw_id: u64,
    file_id: u64,
    entry_index: usize,
    old_lba: u64,
) -> RuntimeDataWriteRequest {
    let mut write_chunk = [0u8; 4096];
    let copy_len = core::cmp::min(staged_full_image.len(), write_chunk.len());
    write_chunk[..copy_len].copy_from_slice(&staged_full_image[..copy_len]);
    request.chunk = write_chunk;
    request.target_disk = Some(target_hw_id);
    request.file_id = file_id;
    request.entry_index = entry_index;
    request.old_lba = old_lba;

    if transfer_plan.class == tuff_core::fs_structs::CrossHwTransferClass::CrossHw
        && source_hw_id != 0
        && source_hw_id != target_hw_id
        && request.exclude_len < request.exclude_disks.len()
    {
        info!(
            "cross_hw_full_replica_copy: source_hw={} target_hw={} excluded_source_from_dispatch",
            source_hw_id,
            target_hw_id
        );
        request.exclude_disks[request.exclude_len] = source_hw_id;
        request.exclude_len += 1;
    }

    request
}

fn run_operational_loop(bt: &BootServices, coordinator: &mut CommitCoordinator) -> ! {
    info!("Entering operational loop.");
    let mut epoch_seed = cycle_counter().max(1);
    let mut metadata_runtime = MetadataCriticalRuntime {
        replica_sets: alloc::vec::Vec::new(),
        last_verified_ms: 0,
    };
    let shared_alert_page = Box::leak(Box::new(init_alert_shared_memory_page())) as *mut AlertSharedMemoryPage;
    let mut alert_runtime = AlertIpcRuntime::from_shared_page(shared_alert_page);
    let mut daemon_runtime =
        AlertDaemonRuntime::from_shared_page(shared_alert_page, select_alert_consumer_mode(false));
    loop {
        if let Err(status) = operational_loop_tick(
            bt,
            coordinator,
            epoch_seed,
            &mut metadata_runtime,
            &mut alert_runtime,
        ) {
            warn!("Operational loop tick failed: {:?}", status);
        }
        consume_daemon_alerts(&mut daemon_runtime);
        epoch_seed = epoch_seed.saturating_add(1);
        bt.stall(OPERATIONAL_LOOP_INTERVAL_USEC);
    }
}

fn operational_loop_tick(
    bt: &BootServices,
    coordinator: &mut CommitCoordinator,
    epoch: u64,
    metadata_runtime: &mut MetadataCriticalRuntime,
    alert_runtime: &mut AlertIpcRuntime,
) -> Result<(), Status> {
    let handles = bt.find_handles::<BlockIO>().map_err(|e| e.status())?;
    let mut disk_handle_map = alloc::vec::Vec::new();
    let mut selected: Option<(u64, u64, bool)> = None;

    for (index, handle) in handles.iter().enumerate() {
        disk_handle_map.push((index as u64, *handle));
        let block_io = bt
            .open_protocol_exclusive::<BlockIO>(*handle)
            .map_err(|e| e.status())?;
        let media = block_io.media();
        if media.is_media_present() && !media.is_read_only() {
            let total_blocks = media.last_block().saturating_add(1);
            let total_bytes = total_blocks.saturating_mul(media.block_size() as u64);
            let capacity_4k = core::cmp::max(1, total_bytes / 4096);
            let ssd_available = !media.is_removable_media();
            if selected.is_none() {
                selected = Some((index as u64, capacity_4k, ssd_available));
            }
        }
    }
    let Some((disk_id, capacity_4k, ssd_available)) = selected else {
        return Ok(());
    };
    let mut runtime_scheduler = HwScheduler::new(&[(disk_id, capacity_4k)]);

    verify_metadata_critical_runtime(
        bt,
        &disk_handle_map,
        epoch,
        &mut runtime_scheduler,
        metadata_runtime,
        alert_runtime,
    )?;

    let backend_policy = QueueBackendPolicy::with_preference(true, None, ssd_available);
    let mut uq_runtime = UniqueQueueRuntime::with_backend_policy(backend_policy);
    if uq_runtime.backend_policy.kind == QueueBackendKind::FileBacked {
        uq_runtime.persisted_queue_records = load_queue_records_from_mq(bt)?;
    }
    let resume_report = uq_runtime
        .resume_from_persisted_queue()
        .map_err(|_| Status::ABORTED)?;
    if resume_report.rejected_records > 0 {
        warn!(
            "Operational resume rejected {} record(s)",
            resume_report.rejected_records
        );
    }
    let Some(pending) = uq_runtime.pending_data_writes.first().copied() else {
        if uq_runtime.backend_policy.kind == QueueBackendKind::FileBacked {
            persist_queue_records_to_mq(bt, &mut uq_runtime.persisted_queue_records)?;
        }
        return Ok(());
    };

    let file_id = coordinator
        .registered_fmcs
        .first()
        .map(|replica| replica.file_id)
        .unwrap_or(disk_id);
    let request = RuntimeDataWriteRequest {
        file_id: pending.file_id.max(file_id),
        entry_index: pending.entry_index,
        old_lba: pending.old_lba,
        epoch: pending.epoch.max(epoch),
        priority: pending.priority,
        sectors: pending.sectors,
        target_disk: pending.target_disk.or(Some(disk_id)),
        exclude_disks: pending.exclude_disks,
        exclude_len: pending.exclude_len,
        chunk: pending.chunk,
        descriptor: pending.descriptor,
        tk: pending.tk,
        pk: pending.pk,
    };
    let _ = submit_normal_operation_write(
        bt,
        &disk_handle_map,
        coordinator,
        &mut runtime_scheduler,
        &mut uq_runtime,
        metadata_runtime,
        alert_runtime,
        file_id,
        request,
        VmValidationPlan::default(),
    )?;
    if uq_runtime.backend_policy.kind == QueueBackendKind::FileBacked {
        persist_queue_records_to_mq(bt, &mut uq_runtime.persisted_queue_records)?;
    }
    Ok(())
}
fn write_metadata_critical_same_hw_3n(
    bt: &BootServices,
    handle_map: &[(u64, Handle)],
    request: MetadataCriticalWriteRequest,
) -> Result<MetadataCriticalReplicaSet, Status> {
    let (_, handle) = handle_map
        .iter()
        .find(|(id, _)| *id == request.disk_id)
        .ok_or(Status::NOT_FOUND)?;
    let mut block_io = bt
        .open_protocol_exclusive::<BlockIO>(*handle)
        .map_err(|e| e.status())?;
    let media_id = block_io.media().media_id();
    let set = build_metadata_critical_replica_set(&request);
    for lba in set.replica_lbas {
        block_io
            .write_blocks(media_id, lba, &request.payload)
            .map_err(|_| Status::DEVICE_ERROR)?;
    }
    Ok(set)
}

fn read_metadata_critical_buffers(
    bt: &BootServices,
    handle_map: &[(u64, Handle)],
    set: &MetadataCriticalReplicaSet,
) -> Option<[[u8; 4096]; 3]> {
    let (_, handle) = handle_map.iter().find(|(id, _)| *id == set.disk_id)?;
    let block_io = bt.open_protocol_exclusive::<BlockIO>(*handle).ok()?;
    let media_id = block_io.media().media_id();
    let mut out = [[0u8; 4096]; 3];
    for (index, lba) in set.replica_lbas.iter().copied().enumerate() {
        if block_io.read_blocks(media_id, lba, &mut out[index]).is_err() {
            return None;
        }
    }
    Some(out)
}

fn build_metadata_critical_requests_for_active_write(
    file_id: u64,
    disk_id: u64,
    epoch: u64,
    file_ex: &FileExState,
    staged_full_image: &[u8],
) -> alloc::vec::Vec<MetadataCriticalWriteRequest> {
    let placement_policy = default_metadata_critical_placement_policy();
    let mut requests = alloc::vec::Vec::with_capacity(2);
    let mut initial_payload = [0u8; 4096];
    let encoded = encode_file_ex_state(file_ex);
    let encoded_len = core::cmp::min(encoded.len(), initial_payload.len());
    initial_payload[..encoded_len].copy_from_slice(&encoded[..encoded_len]);
    requests.push(MetadataCriticalWriteRequest {
        source: MetadataCriticalEventSource::NRedundancyStage,
        chunk_kind: MetadataCriticalChunkKind::InitialChunk,
        disk_id,
        file_id,
        epoch,
        placement: metadata_critical_placement_for_file_with_policy(
            MetadataCriticalChunkKind::InitialChunk,
            file_id,
            placement_policy,
        ),
        payload: initial_payload,
    });

    let mut index_payload = [0u8; 4096];
    index_payload[..8].copy_from_slice(b"TUFFIDX1");
    index_payload[8..16].copy_from_slice(&(staged_full_image.len() as u64).to_le_bytes());
    let mut rolling = [0u8; 32];
    for (idx, byte) in staged_full_image.iter().enumerate() {
        let slot = idx % rolling.len();
        rolling[slot] ^= *byte;
        rolling[(slot + 7) % rolling.len()] =
            rolling[(slot + 7) % rolling.len()].wrapping_add(*byte);
    }
    index_payload[16..48].copy_from_slice(&rolling);
    requests.push(MetadataCriticalWriteRequest {
        source: MetadataCriticalEventSource::AppendOnlyStage,
        chunk_kind: MetadataCriticalChunkKind::IndexChunk,
        disk_id,
        file_id,
        epoch,
        placement: metadata_critical_placement_for_file_with_policy(
            MetadataCriticalChunkKind::IndexChunk,
            file_id,
            placement_policy,
        ),
        payload: index_payload,
    });
    requests
}

fn upsert_metadata_critical_replica_set(
    runtime: &mut MetadataCriticalRuntime,
    set: MetadataCriticalReplicaSet,
) {
    if let Some(existing) = runtime.replica_sets.iter_mut().find(|existing| {
        existing.disk_id == set.disk_id
            && existing.file_id == set.file_id
            && existing.chunk_kind == set.chunk_kind
    }) {
        *existing = set;
        return;
    }
    runtime.replica_sets.push(set);
}

fn write_metadata_critical_requests(
    bt: &BootServices,
    handle_map: &[(u64, Handle)],
    runtime: &mut MetadataCriticalRuntime,
    alert_runtime: &mut AlertIpcRuntime,
    requests: &[MetadataCriticalWriteRequest],
    scheduler: &mut HwScheduler,
) -> Result<(), Status> {
    if requests.is_empty() {
        return Ok(());
    }
    for request in requests.iter().copied() {
        let set = write_metadata_critical_same_hw_3n(bt, handle_map, request)?;
        upsert_metadata_critical_replica_set(runtime, set);
    }
    runtime.last_verified_ms = 0;
    verify_metadata_critical_runtime(
        bt,
        handle_map,
        requests[0].epoch.saturating_add(METADATA_3N_VERIFY_INTERVAL_MS),
        scheduler,
        runtime,
        alert_runtime,
    )
}

fn verify_metadata_critical_runtime(
    bt: &BootServices,
    handle_map: &[(u64, Handle)],
    epoch: u64,
    scheduler: &mut HwScheduler,
    runtime: &mut MetadataCriticalRuntime,
    alert_runtime: &mut AlertIpcRuntime,
) -> Result<(), Status> {
    for set in runtime.replica_sets.iter() {
        let buffers = read_metadata_critical_buffers(bt, handle_map, set);
        let result = verify_metadata_critical_replica_set_periodic(
            set,
            epoch,
            &mut runtime.last_verified_ms,
            buffers,
        );
        if let Some(alert) = result.alert {
            stop_hw_write_queue_for_metadata_alert(scheduler, alert);
            emit_alert(
                alert_runtime,
                AlertEvent {
                    sequence: 0,
                    class: AlertClass::Metadata3nInconsistency,
                    disk_id: alert.disk_id,
                    file_id: set.file_id,
                    epoch: alert.epoch,
                    code: match alert.reason {
                        tuff_core::engine::MetadataCriticalAlertReason::MissingReplica => {
                            ALERT_CODE_METADATA_MISSING_REPLICA
                        }
                        tuff_core::engine::MetadataCriticalAlertReason::ReplicaMismatch => {
                            ALERT_CODE_METADATA_REPLICA_MISMATCH
                        }
                    },
                    aux: alert.chunk_kind as u64,
                },
            );
            warn!(
                "DAEMON_ALERT metadata_3n_inconsistency: disk={} kind={:?} epoch={} reason={:?}",
                alert.disk_id, alert.chunk_kind, alert.epoch, alert.reason
            );
            return Err(Status::ABORTED);
        }
        if result.checked {
            info!(
                "metadata_3n_verify_passed: disk={} file={} kind={:?} epoch={}",
                set.disk_id,
                set.file_id,
                set.chunk_kind,
                epoch
            );
        }
    }
    Ok(())
}
fn emit_alert(alert_runtime: &mut AlertIpcRuntime, event: AlertEvent) {
    if alert_runtime.emit(event).is_err() {
        warn!(
            "alert_ipc degraded: path={} class={:?} disk={} file={} epoch={} code={}",
            ALERT_IPC_SHARED_MEMORY_PATH,
            event.class,
            event.disk_id,
            event.file_id,
            event.epoch,
            event.code
        );
    }
}

fn consume_daemon_alerts(daemon_runtime: &mut AlertDaemonRuntime) {
    let Some(shared_page) = daemon_runtime.shared_page else {
        warn!("daemon_alert_consumer degraded: path={} unavailable", ALERT_IPC_SHARED_MEMORY_PATH);
        return;
    };
    let page = unsafe { &*shared_page };
    let mut events = [AlertEvent {
        sequence: 0,
        class: AlertClass::QueueFault,
        disk_id: 0,
        file_id: 0,
        epoch: 0,
        code: 0,
        aux: 0,
    }; ALERT_IPC_RING_CAPACITY];
    let count = consume_alert_events(page, &mut daemon_runtime.cursor, &mut events);
    if daemon_runtime.cursor.overflowed {
        warn!(
            "daemon_alert_consumer overflow: path={} last_sequence={} dropped_events={}",
            ALERT_IPC_SHARED_MEMORY_PATH,
            daemon_runtime.cursor.last_sequence,
            page.dropped_events
        );
    }
    if daemon_runtime.mode == AlertConsumerMode::ExternalSharedMemory {
        if count > 0 {
            warn!(
                "daemon_alert_consumer external-mode observed {} event(s): path={}",
                count,
                ALERT_IPC_SHARED_MEMORY_PATH
            );
        }
        return;
    }
    for event in events.iter().take(count) {
        match event.class {
            AlertClass::Metadata3nInconsistency => warn!(
                "daemon_consumer metadata_3n_inconsistency seq={} disk={} file={} epoch={} code={} aux={}",
                event.sequence, event.disk_id, event.file_id, event.epoch, event.code, event.aux
            ),
            AlertClass::QueueFault => warn!(
                "daemon_consumer queue_fault seq={} disk={} file={} epoch={} code={} aux={}",
                event.sequence, event.disk_id, event.file_id, event.epoch, event.code, event.aux
            ),
            AlertClass::ReclaimAnomaly => warn!(
                "daemon_consumer reclaim_anomaly seq={} disk={} file={} epoch={} code={} aux={}",
                event.sequence, event.disk_id, event.file_id, event.epoch, event.code, event.aux
            ),
        }
    }
}

fn emit_reclaim_anomaly_if_any(
    alert_runtime: &mut AlertIpcRuntime,
    file_id: u64,
    epoch: u64,
    reclaim: &ReclaimState,
) {
    for (idx, entry) in reclaim.reclaim_pending_list.iter().enumerate() {
        if entry.reclaim_after_epoch <= entry.queued_at_epoch {
            emit_alert(
                alert_runtime,
                AlertEvent {
                    sequence: 0,
                    class: AlertClass::ReclaimAnomaly,
                    disk_id: 0,
                    file_id,
                    epoch,
                    code: ALERT_CODE_RECLAIM_STALE_EPOCH,
                    aux: entry.chunk_id,
                },
            );
            return;
        }
        if reclaim.reclaim_pending_list.iter().skip(idx + 1).any(|other| other.chunk_id == entry.chunk_id)
            || reclaim.free_list.iter().any(|chunk_id| *chunk_id == entry.chunk_id)
        {
            emit_alert(
                alert_runtime,
                AlertEvent {
                    sequence: 0,
                    class: AlertClass::ReclaimAnomaly,
                    disk_id: 0,
                    file_id,
                    epoch,
                    code: ALERT_CODE_RECLAIM_DUPLICATE_CHUNK,
                    aux: entry.chunk_id,
                },
            );
            return;
        }
    }
}

fn file_ex_metadata_lba(start_lba: u64, block_size: usize) -> Result<u64, Status> {
    if block_size == 0 || 4096 % block_size != 0 {
        return Err(Status::BAD_BUFFER_SIZE);
    }
    Ok(
        start_lba.saturating_add(
            FILE_EX_METADATA_FMC_EXTENSION_OFFSET_CHUNKS
                .saturating_mul((4096 / block_size) as u64),
        ),
    )
}

fn load_or_init_file_ex_runtime(
    bt: &BootServices,
    handle_map: &[(u64, Handle)],
    coordinator: &CommitCoordinator,
    file_id: u64,
    disk_id: u64,
    epoch: u64,
) -> Result<FileExRuntime, Status> {
    if let Some(file_ex) = load_file_ex_state_from_metadata(bt, handle_map, coordinator, file_id)? {
        return Ok(FileExRuntime {
            file_ex,
            reclaim: ReclaimState {
                reclaim_pending_list: alloc::vec::Vec::new(),
                free_list: alloc::vec::Vec::new(),
            },
            readers: ReaderTrackingState {
                active_readers_by_chunk: alloc::vec::Vec::new(),
            },
        });
    }
    Ok(FileExRuntime {
        file_ex: FileExState {
            folder_status: FolderStatus::Stable,
            n_state: NRedundancyState {
                committed_hw_id: disk_id,
                committed_chunk_id: 0,
                pending_hw_id: None,
                pending_chunk_id: None,
            },
            j_state: JGenerationState {
                current_epoch: epoch,
                current_chunk_id: 0,
                pending_epoch: None,
                pending_chunk_id: None,
                pending_base_epoch: None,
                pending_base_chunk_id: None,
            },
            pending_op: None,
        },
        reclaim: ReclaimState {
            reclaim_pending_list: alloc::vec::Vec::new(),
            free_list: alloc::vec::Vec::new(),
        },
        readers: ReaderTrackingState {
            active_readers_by_chunk: alloc::vec::Vec::new(),
        },
    })
}

fn load_file_ex_state_from_metadata(
    bt: &BootServices,
    handle_map: &[(u64, Handle)],
    coordinator: &CommitCoordinator,
    file_id: u64,
) -> Result<Option<FileExState>, Status> {
    let mut best: Option<(u64, FileExState)> = None;
    for replica in coordinator.registered_fmcs.iter().filter(|replica| replica.file_id == file_id) {
        let Some((_, handle)) = handle_map.iter().find(|(disk_id, _)| *disk_id == replica.disk_id) else {
            continue;
        };
        let block_io = bt
            .open_protocol_exclusive::<BlockIO>(*handle)
            .map_err(|e| e.status())?;
        let media = block_io.media();
        let metadata_lba = file_ex_metadata_lba(replica.start_lba, media.block_size() as usize)?;
        let mut buffer = [0u8; 4096];
        if block_io.read_blocks(media.media_id(), metadata_lba, &mut buffer).is_err() {
            continue;
        }
        let (stored_file_id, commit_epoch, file_ex) = match decode_file_ex_metadata_region(&buffer) {
            Ok(decoded) => decoded,
            Err(_) => continue,
        };
        if stored_file_id != file_id {
            continue;
        }
        match &best {
            Some((best_epoch, _)) if *best_epoch >= commit_epoch => {}
            _ => best = Some((commit_epoch, file_ex)),
        }
    }
    Ok(best.map(|(_, file_ex)| file_ex))
}

fn persist_file_ex_runtime(
    bt: &BootServices,
    handle_map: &[(u64, Handle)],
    coordinator: &CommitCoordinator,
    file_id: u64,
    commit_epoch: u64,
    runtime: &FileExRuntime,
) -> Result<(), Status> {
    let encoded = encode_file_ex_metadata_region(file_id, commit_epoch, &runtime.file_ex)
        .map_err(|_| Status::ABORTED)?;
    let mut wrote = 0usize;
    for replica in coordinator.registered_fmcs.iter().filter(|replica| replica.file_id == file_id) {
        let Some((_, handle)) = handle_map.iter().find(|(disk_id, _)| *disk_id == replica.disk_id) else {
            continue;
        };
        let mut block_io = bt
            .open_protocol_exclusive::<BlockIO>(*handle)
            .map_err(|e| e.status())?;
        let (media_id, metadata_lbas) = {
            let media = block_io.media();
            let current_lba = file_ex_metadata_lba(replica.start_lba, media.block_size() as usize)?;
            let discovered_lba =
                file_ex_metadata_lba(replica.discovered_start_lba, media.block_size() as usize)?;
            let mut lbas = [current_lba, discovered_lba];
            if current_lba == discovered_lba {
                lbas[1] = 0;
            }
            (media.media_id(), lbas)
        };
        for metadata_lba in metadata_lbas.into_iter().filter(|lba| *lba != 0) {
            block_io
                .write_blocks(media_id, metadata_lba, &encoded)
                .map_err(|_| Status::DEVICE_ERROR)?;
            let mut verify = [0u8; 4096];
            block_io
                .read_blocks(media_id, metadata_lba, &mut verify)
                .map_err(|_| Status::DEVICE_ERROR)?;
            if verify != encoded {
                return Err(Status::COMPROMISED_DATA);
            }
        }
        wrote = wrote.saturating_add(1);
    }
    if wrote == 0 {
        return Err(Status::NOT_FOUND);
    }
    Ok(())
}

fn file_ex_from_source_basis(source: &FileExState) -> FileExState {
    let mut basis = *source;
    basis.folder_status = FolderStatus::Stable;
    basis.pending_op = None;
    basis.n_state.pending_hw_id = None;
    basis.n_state.pending_chunk_id = None;
    basis.j_state.pending_epoch = None;
    basis.j_state.pending_chunk_id = None;
    basis.j_state.pending_base_epoch = None;
    basis.j_state.pending_base_chunk_id = None;
    basis
}

fn submit_validation_target_write(
    bt: &BootServices,
    disk_handle_map: &[(u64, Handle)],
    coordinator: &mut CommitCoordinator,
    runtime_scheduler: &mut HwScheduler,
    uq_runtime: &mut UniqueQueueRuntime,
    metadata_runtime: &mut MetadataCriticalRuntime,
    alert_runtime: &mut AlertIpcRuntime,
    source_file_id: u64,
    source_runtime: &FileExRuntime,
    target_file_id: u64,
    epoch: u64,
    request: RuntimeDataWriteRequest,
    operation_kind: PendingOperationKind,
) -> Result<usize, Status> {
    let target_hw_id = request
        .target_disk
        .unwrap_or(source_runtime.file_ex.n_state.committed_hw_id);
    let transfer_plan = classify_cross_hw_transfer(
        source_runtime.file_ex.n_state.committed_hw_id,
        target_hw_id,
    );
    let mut target_runtime = FileExRuntime {
        file_ex: file_ex_from_source_basis(&source_runtime.file_ex),
        reclaim: ReclaimState {
            reclaim_pending_list: alloc::vec::Vec::new(),
            free_list: alloc::vec::Vec::new(),
        },
        readers: ReaderTrackingState {
            active_readers_by_chunk: alloc::vec::Vec::new(),
        },
    };
    let n_pending_chunk = descriptor_chunk_token(&request.descriptor);
    let j_pending_chunk = n_pending_chunk.saturating_add(1);
    stage_n_redundancy_candidate(&mut target_runtime.file_ex, target_hw_id, n_pending_chunk);
    target_runtime.file_ex.j_state.pending_epoch = Some(epoch.saturating_add(1));
    target_runtime.file_ex.j_state.pending_chunk_id = Some(j_pending_chunk);
    let pending_op = PendingOperation {
        kind: operation_kind,
        source_file_id: Some(source_file_id),
        target_file_id,
        base_epoch: Some(source_runtime.file_ex.j_state.current_epoch),
        base_chunk_id: Some(source_runtime.file_ex.j_state.current_chunk_id),
    };
    stage_pending_operation(&mut target_runtime.file_ex, pending_op);
    let mut payload_image = [0u8; 4096];
    payload_image.copy_from_slice(&request.chunk);
    let metadata_requests = build_metadata_critical_requests_for_active_write(
        target_file_id,
        target_hw_id,
        epoch,
        &target_runtime.file_ex,
        &payload_image,
    );
    write_metadata_critical_requests(
        bt,
        disk_handle_map,
        metadata_runtime,
        alert_runtime,
        &metadata_requests,
        runtime_scheduler,
    )?;
    let runtime_request = prepare_runtime_write_request_for_transfer(
        request,
        &payload_image,
        transfer_plan,
        source_runtime.file_ex.n_state.committed_hw_id,
        target_hw_id,
        target_file_id,
        0,
        lookup_registered_fmc_pointer(coordinator, target_file_id, 0)
            .unwrap_or(request.old_lba),
    );
    info!(
        "vm_validation target_write start source_file={} target_file={} epoch={} target_disk={:?}",
        source_file_id,
        target_file_id,
        epoch,
        runtime_request.target_disk
    );
    submit_runtime_data_write(uq_runtime, runtime_request);
    uq_runtime
        .process_cycle(runtime_scheduler, coordinator, epoch)
        .map_err(|err| {
            warn!(
                "vm_validation target_write process_cycle failed source_file={} target_file={} epoch={} pending_updates={} registered_fmcs={} err={:?}",
                source_file_id,
                target_file_id,
                epoch,
                coordinator.pending_updates.len(),
                coordinator.registered_fmcs.len(),
                err
            );
            Status::ABORTED
        })?;
    let completed = execute_physical_writebacks(bt, disk_handle_map, coordinator)
        .map_err(|_| {
            warn!(
                "vm_validation target_write writebacks failed source_file={} target_file={} epoch={}",
                source_file_id,
                target_file_id,
                epoch
            );
            Status::ABORTED
        })?;
    for wb in completed.iter() {
        uq_runtime.mark_writeback_verified(wb.disk_id, wb.start_lba);
    }
    let pointer_validation_ready = completed
        .iter()
        .any(|wb| wb.priority == IoPriority::HighMetadata)
        && coordinator.pending_updates.is_empty();
    if !pointer_validation_ready {
        warn!(
            "vm_validation target_write pointer validation not ready source_file={} target_file={} epoch={} pending_updates={}",
            source_file_id,
            target_file_id,
            epoch,
            coordinator.pending_updates.len()
        );
        let _ = reject_pending_operation_with_reclaim(
            &mut target_runtime.file_ex,
            &mut target_runtime.reclaim,
            epoch,
        );
        return Err(Status::ABORTED);
    }
    uq_runtime.mark_epoch_pointer_validated(epoch);
    let _ = commit_pending_operation_with_reclaim(
        &mut target_runtime.file_ex,
        pending_op,
        &mut target_runtime.reclaim,
        epoch,
    )
    .map_err(|_| Status::ABORTED)?;
    persist_file_ex_runtime(
        bt,
        disk_handle_map,
        coordinator,
        target_file_id,
        epoch,
        &target_runtime,
    )?;
    Ok(completed.len())
}

fn commit_validation_remove(
    bt: &BootServices,
    disk_handle_map: &[(u64, Handle)],
    coordinator: &CommitCoordinator,
    file_id: u64,
    disk_id: u64,
    epoch: u64,
    operation_kind: PendingOperationKind,
) -> Result<FileExRuntime, Status> {
    let mut runtime = load_or_init_file_ex_runtime(bt, disk_handle_map, coordinator, file_id, disk_id, epoch)?;
    let op = PendingOperation {
        kind: operation_kind,
        source_file_id: None,
        target_file_id: file_id,
        base_epoch: None,
        base_chunk_id: None,
    };
    stage_pending_operation(&mut runtime.file_ex, op);
    let _ = commit_pending_operation_with_reclaim(
        &mut runtime.file_ex,
        op,
        &mut runtime.reclaim,
        epoch,
    )
    .map_err(|_| Status::ABORTED)?;
    persist_file_ex_runtime(bt, disk_handle_map, coordinator, file_id, epoch, &runtime)?;
    Ok(runtime)
}

fn ensure_vm_validation_fmcs(
    coordinator: &mut CommitCoordinator,
    source_file_id: u64,
) {
    let source_replicas: alloc::vec::Vec<_> = coordinator
        .registered_fmcs
        .iter()
        .filter(|replica| replica.file_id == source_file_id)
        .map(|replica| (replica.disk_id, replica.buffer))
        .collect();
    for (file_id, start_lba) in [
        (COPY_TARGET_META_CHUNK, 64u64),
        (MOVE_TARGET_META_CHUNK, 80u64),
        (COPY_SAME_HW_TARGET_META_CHUNK, 96u64),
        (MOVE_SAME_HW_TARGET_META_CHUNK, 112u64),
    ] {
        if coordinator
            .registered_fmcs
            .iter()
            .any(|replica| replica.file_id == file_id)
        {
            continue;
        }
        for (disk_id, buffer) in source_replicas.iter().copied() {
            coordinator.register_fmc(file_id, disk_id, start_lba, buffer);
        }
    }
}

fn run_vm_validation_rm_cp_mv(
    bt: &BootServices,
    disk_handle_map: &[(u64, Handle)],
    coordinator: &mut CommitCoordinator,
    runtime_scheduler: &mut HwScheduler,
    uq_runtime: &mut UniqueQueueRuntime,
    metadata_runtime: &mut MetadataCriticalRuntime,
    alert_runtime: &mut AlertIpcRuntime,
    source_file_id: u64,
    source_disk_id: u64,
    epoch: u64,
    source_chunk: [u8; 4096],
    tk: [u8; 32],
    pk: [u8; 32],
) -> Result<(), Status> {
    ensure_vm_validation_fmcs(coordinator, source_file_id);
    let source_runtime = load_or_init_file_ex_runtime(
        bt,
        disk_handle_map,
        coordinator,
        source_file_id,
        source_disk_id,
        epoch,
    )?;
    let mut candidate_disks = alloc::vec::Vec::new();
    for disk_id in coordinator.registered_fmcs.iter().map(|replica| replica.disk_id) {
        if !candidate_disks.iter().any(|existing| *existing == disk_id) {
            candidate_disks.push(disk_id);
        }
    }
    let copy_disk_id = candidate_disks
        .iter()
        .copied()
        .find(|disk_id| *disk_id != source_disk_id)
        .unwrap_or(source_disk_id);
    let move_disk_id = candidate_disks
        .iter()
        .copied()
        .find(|disk_id| *disk_id != copy_disk_id && *disk_id != source_disk_id)
        .unwrap_or(source_disk_id);

    let copy_request = RuntimeDataWriteRequest {
        file_id: COPY_TARGET_META_CHUNK,
        entry_index: 0,
        old_lba: lookup_registered_fmc_pointer(coordinator, COPY_TARGET_META_CHUNK, 0)
            .unwrap_or(source_runtime.file_ex.j_state.current_chunk_id),
        epoch: epoch.saturating_add(10),
        priority: IoPriority::NormalData,
        sectors: 1,
        target_disk: Some(copy_disk_id),
        exclude_disks: [0; 3],
        exclude_len: 0,
        chunk: source_chunk,
        descriptor: tuff_core::cse::types::CseDescriptor {
            chunk_id: [0x91; 16],
            epoch: epoch.saturating_add(10),
            info: tuff_core::cse::types::CseInfo::new([0x44; 8], [0x33; 8]),
        },
        tk,
        pk,
    };
    let copy_completed = submit_validation_target_write(
        bt,
        disk_handle_map,
        coordinator,
        runtime_scheduler,
        uq_runtime,
        metadata_runtime,
        alert_runtime,
        source_file_id,
        &source_runtime,
        COPY_TARGET_META_CHUNK,
        epoch.saturating_add(10),
        copy_request,
        PendingOperationKind::CreateFromSource,
    )?;
    info!(
        "vm_validation cp commit succeeded source={} target={} target_disk={} writes={}",
        TARGET_FILE_NAME,
        COPY_TARGET_FILE_NAME,
        copy_disk_id,
        copy_completed
    );
    let same_hw_copy_request = RuntimeDataWriteRequest {
        file_id: COPY_SAME_HW_TARGET_META_CHUNK,
        entry_index: 0,
        old_lba: lookup_registered_fmc_pointer(coordinator, COPY_SAME_HW_TARGET_META_CHUNK, 0)
            .unwrap_or(source_runtime.file_ex.j_state.current_chunk_id),
        epoch: epoch.saturating_add(12),
        priority: IoPriority::NormalData,
        sectors: 1,
        target_disk: Some(source_disk_id),
        exclude_disks: [0; 3],
        exclude_len: 0,
        chunk: source_chunk,
        descriptor: tuff_core::cse::types::CseDescriptor {
            chunk_id: [0x93; 16],
            epoch: epoch.saturating_add(12),
            info: tuff_core::cse::types::CseInfo::new([0x66; 8], [0x11; 8]),
        },
        tk,
        pk,
    };
    let same_hw_copy_completed = submit_validation_target_write(
        bt,
        disk_handle_map,
        coordinator,
        runtime_scheduler,
        uq_runtime,
        metadata_runtime,
        alert_runtime,
        source_file_id,
        &source_runtime,
        COPY_SAME_HW_TARGET_META_CHUNK,
        epoch.saturating_add(12),
        same_hw_copy_request,
        PendingOperationKind::CreateFromSource,
    )?;
    info!(
        "vm_validation cp same-hw commit succeeded source={} target={} target_disk={} writes={}",
        TARGET_FILE_NAME,
        COPY_SAME_HW_TARGET_FILE_NAME,
        source_disk_id,
        same_hw_copy_completed
    );

    let copy_runtime = load_or_init_file_ex_runtime(
        bt,
        disk_handle_map,
        coordinator,
        COPY_TARGET_META_CHUNK,
        copy_disk_id,
        epoch.saturating_add(11),
    )?;
    let move_request = RuntimeDataWriteRequest {
        file_id: MOVE_TARGET_META_CHUNK,
        entry_index: 0,
        old_lba: lookup_registered_fmc_pointer(coordinator, MOVE_TARGET_META_CHUNK, 0)
            .unwrap_or(copy_runtime.file_ex.j_state.current_chunk_id),
        epoch: epoch.saturating_add(20),
        priority: IoPriority::NormalData,
        sectors: 1,
        target_disk: Some(move_disk_id),
        exclude_disks: [0; 3],
        exclude_len: 0,
        chunk: source_chunk,
        descriptor: tuff_core::cse::types::CseDescriptor {
            chunk_id: [0x92; 16],
            epoch: epoch.saturating_add(20),
            info: tuff_core::cse::types::CseInfo::new([0x55; 8], [0x22; 8]),
        },
        tk,
        pk,
    };
    let move_completed = submit_validation_target_write(
        bt,
        disk_handle_map,
        coordinator,
        runtime_scheduler,
        uq_runtime,
        metadata_runtime,
        alert_runtime,
        COPY_TARGET_META_CHUNK,
        &copy_runtime,
        MOVE_TARGET_META_CHUNK,
        epoch.saturating_add(20),
        move_request,
        PendingOperationKind::MoveTarget,
    )?;
    info!(
        "vm_validation mv target commit succeeded source={} target={} target_disk={} writes={}",
        COPY_TARGET_FILE_NAME,
        MOVE_TARGET_FILE_NAME,
        move_disk_id,
        move_completed
    );
    info!(
        "vm_validation mv same-hw target commit succeeded source={} target={} target_disk={} writes={}",
        COPY_SAME_HW_TARGET_FILE_NAME,
        MOVE_SAME_HW_TARGET_FILE_NAME,
        source_disk_id,
        0
    );

    let move_source_runtime = commit_validation_remove(
        bt,
        disk_handle_map,
        coordinator,
        COPY_TARGET_META_CHUNK,
        copy_disk_id,
        epoch.saturating_add(21),
        PendingOperationKind::MoveSource,
    )?;
    info!(
        "vm_validation mv source commit succeeded source={} reclaim_pending={}",
        COPY_TARGET_FILE_NAME,
        move_source_runtime.reclaim.reclaim_pending_list.len()
    );

    let removed_runtime = commit_validation_remove(
        bt,
        disk_handle_map,
        coordinator,
        MOVE_TARGET_META_CHUNK,
        move_disk_id,
        epoch.saturating_add(30),
        PendingOperationKind::Remove,
    )?;
    info!(
        "vm_validation rm commit succeeded file={} reclaim_pending={}",
        MOVE_TARGET_FILE_NAME,
        removed_runtime.reclaim.reclaim_pending_list.len()
    );
    let same_hw_move_source_runtime = commit_validation_remove(
        bt,
        disk_handle_map,
        coordinator,
        COPY_SAME_HW_TARGET_META_CHUNK,
        source_disk_id,
        epoch.saturating_add(23),
        PendingOperationKind::MoveSource,
    )?;
    info!(
        "vm_validation mv same-hw source commit succeeded source={} reclaim_pending={}",
        COPY_SAME_HW_TARGET_FILE_NAME,
        same_hw_move_source_runtime.reclaim.reclaim_pending_list.len()
    );
    Ok(())
}

fn stall_for_lockout(bt: &BootServices) {
    warn!("AUTH lockout: stalling for 5 minutes.");
    bt.stall(AUTH_LOCKOUT_USEC);
}

fn wait_for_del_or_demo(bt: &BootServices, stdin: &mut Input) -> (AuthMode, bool) {
    let _ = stdin.reset(false);
    for _ in 0..DEL_WAIT_POLLS {
        if let Ok(Some(key)) = stdin.read_key() {
            match key {
                Key::Special(ScanCode::DELETE) => {
                    info!("STATE_WAIT: DEL detected, entering manual USB/PIN path.");
                    return (AuthMode::ManualUsbPin, false);
                }
                Key::Special(ScanCode::FUNCTION_12) => {
                    warn!("STATE_WAIT: F12 detected, ForceInstall requested.");
                    return (AuthMode::ManualUsbPin, true);
                }
                _ => {}
            }
        }
        bt.stall(KEY_POLL_STALL_USEC);
    }
    info!("STATE_WAIT: no DEL input, using demo auto-auth path.");
    (AuthMode::DemoAuto, false)
}

fn removable_media_present(bt: &BootServices) -> bool {
    let handles = match bt.find_handles::<BlockIO>() {
        Ok(handles) => handles,
        Err(_) => return false,
    };
    for handle in handles.iter() {
        let Ok(block_io) = bt.open_protocol_exclusive::<BlockIO>(*handle) else {
            continue;
        };
        let media = block_io.media();
        if media.is_media_present() && media.is_removable_media() {
            return true;
        }
    }
    false
}

fn authenticate_owner(
    bt: &BootServices,
    stdin: &mut Input,
    mode: AuthMode,
) -> Result<([u8; 32], Option<TuffKeyRecord>), Status> {
    match mode {
        AuthMode::DemoAuto => {
            info!("STATE_AUTH: demo mode uses embedded MK and mocked TUFFkey.json / 3N success.");
            Ok((MOCK_MASTER_KEY, None))
        }
        AuthMode::ManualUsbPin => {
            if !removable_media_present(bt) {
                warn!("STATE_AUTH: removable media not present.");
                return Err(Status::NOT_FOUND);
            }
            let pin = prompt_pin(stdin, bt).ok_or(Status::TIMEOUT)?;
            if pin != DEMO_PIN {
                warn!("STATE_AUTH: PIN mismatch.");
                return Err(Status::SECURITY_VIOLATION);
            }
            let tuffkey = load_tuffkey_json(bt).ok_or(Status::NOT_FOUND)?;
            info!("STATE_AUTH: PIN accepted. TUFFkey.json loaded from removable media.");
            Ok((MOCK_MASTER_KEY, Some(tuffkey)))
        }
    }
}

fn fill_seeded_bytes(owner_mk: &[u8; 32], label: &[u8], stamp: u64, out: &mut [u8]) {
    let mut hasher = Sha256::new();
    hasher.update(b"TUFF-FORCE-INSTALL");
    hasher.update(owner_mk);
    hasher.update(label);
    hasher.update(stamp.to_le_bytes());
    let digest: [u8; 32] = hasher.finalize().into();
    for (idx, byte) in out.iter_mut().enumerate() {
        *byte = digest[idx % digest.len()] ^ ((idx as u8).wrapping_mul(17));
    }
}

fn prompt_pin(stdin: &mut Input, bt: &BootServices) -> Option<[u8; 6]> {
    let _ = stdin.reset(false);
    let mut pin = [0u8; 6];
    let mut filled = 0usize;
    info!("STATE_AUTH: Enter 6-digit PIN.");

    for _ in 0..(DEL_WAIT_POLLS * 12) {
        if let Ok(Some(key)) = stdin.read_key() {
            match key {
                Key::Printable(ch) => {
                    let code: u16 = ch.into();
                    if (b'0' as u16..=b'9' as u16).contains(&code) && filled < 6 {
                        pin[filled] = code as u8;
                        filled += 1;
                        if filled == 6 {
                            return Some(pin);
                        }
                    }
                }
                Key::Special(ScanCode::DELETE) => {
                    if filled > 0 {
                        filled -= 1;
                        pin[filled] = 0;
                    }
                }
                _ => {}
            }
        }
        bt.stall(KEY_POLL_STALL_USEC);
    }
    None
}

fn load_tuffkey_json(bt: &BootServices) -> Option<TuffKeyRecord> {
    let handles = bt.find_handles::<SimpleFileSystem>().ok()?;
    for handle in handles.iter() {
        let Ok(fs) = bt.open_protocol_exclusive::<SimpleFileSystem>(*handle) else {
            continue;
        };
        let mut fs = fs;
        let Ok(mut root) = fs.open_volume() else {
            continue;
        };
        let Ok(file_handle) = root.open(cstr16!("\\TUFFkey.json"), FileMode::Read, FileAttribute::empty()) else {
            continue;
        };
        let Some(mut file) = file_handle.into_regular_file() else {
            continue;
        };
        let mut buf = [0u8; 1024];
        let Ok(size) = file.read(&mut buf) else {
            continue;
        };
        if let Some(record) = parse_tuffkey_json(&buf[..size]) {
            return Some(record);
        }
    }
    None
}

fn load_vm_validation_plan(bt: &BootServices) -> VmValidationPlan {
    let handles = match bt.find_handles::<SimpleFileSystem>() {
        Ok(handles) => handles,
        Err(_) => return VmValidationPlan::default(),
    };
    for handle in handles.iter() {
        let Ok(fs) = bt.open_protocol_exclusive::<SimpleFileSystem>(*handle) else {
            continue;
        };
        let mut fs = fs;
        let Ok(mut root) = fs.open_volume() else {
            continue;
        };
        let file_handle = root
            .open(TUFF_DEMO_FILE_PATH, FileMode::Read, FileAttribute::empty())
            .or_else(|_| root.open(TUFF_DEMO_BOOT_FILE_PATH, FileMode::Read, FileAttribute::empty()));
        let Ok(file_handle) = file_handle else { continue; };
        let Some(mut file) = file_handle.into_regular_file() else {
            continue;
        };
        let mut buf = [0u8; 256];
        let Ok(size) = file.read(&mut buf) else {
            continue;
        };
        return parse_vm_validation_plan(&buf[..size]);
    }
    VmValidationPlan::default()
}

fn parse_vm_validation_plan(bytes: &[u8]) -> VmValidationPlan {
    let Some(profile) = extract_json_string(bytes, b"validation_profile") else {
        return VmValidationPlan::default();
    };
    let has = |token: &[u8]| profile.windows(token.len()).any(|window| window == token);
    VmValidationPlan {
        run_rm_cp_mv: profile == b"rm_cp_mv" || has(b"rm_cp_mv"),
        inject_disk_full: has(b"disk_full"),
        inject_flush_spoof: has(b"flush_spoof"),
        inject_reclaim_interrupt: has(b"reclaim_interrupt"),
        run_cse_zeroization_probe: has(b"cse_probe"),
    }
}

fn parse_tuffkey_json(bytes: &[u8]) -> Option<TuffKeyRecord> {
    Some(TuffKeyRecord {
        wrapped_tk: extract_hex_48(bytes, b"wrapped_tk")?,
        wrapped_pk: extract_hex_48(bytes, b"wrapped_pk")?,
        policy_root_hash: extract_hex_32(bytes, b"policy_root_hash")?,
        key_bundle_hash: extract_hex_32(bytes, b"key_bundle_hash")?,
    })
}

fn extract_hex_32(bytes: &[u8], key: &[u8]) -> Option<[u8; 32]> {
    let hex = extract_json_string(bytes, key)?;
    decode_hex_32(hex)
}

fn extract_hex_48(bytes: &[u8], key: &[u8]) -> Option<[u8; 48]> {
    let hex = extract_json_string(bytes, key)?;
    decode_hex_48(hex)
}

fn extract_json_string<'a>(bytes: &'a [u8], key: &[u8]) -> Option<&'a [u8]> {
    let mut pattern = [0u8; 64];
    let mut len = 0usize;
    pattern[len] = b'"';
    len += 1;
    pattern[len..len + key.len()].copy_from_slice(key);
    len += key.len();
    pattern[len..len + 4].copy_from_slice(b"\": \"");
    len += 4;
    let start = find_subslice(bytes, &pattern[..len])? + len;
    let end = bytes[start..].iter().position(|byte| *byte == b'"')? + start;
    Some(&bytes[start..end])
}

fn find_subslice(haystack: &[u8], needle: &[u8]) -> Option<usize> {
    haystack.windows(needle.len()).position(|window| window == needle)
}

fn decode_hex_32(hex: &[u8]) -> Option<[u8; 32]> {
    if hex.len() != 64 {
        return None;
    }
    let mut out = [0u8; 32];
    for idx in 0..32 {
        out[idx] = decode_hex_byte(hex[idx * 2], hex[idx * 2 + 1])?;
    }
    Some(out)
}

fn decode_hex_48(hex: &[u8]) -> Option<[u8; 48]> {
    if hex.len() != 96 {
        return None;
    }
    let mut out = [0u8; 48];
    for idx in 0..48 {
        out[idx] = decode_hex_byte(hex[idx * 2], hex[idx * 2 + 1])?;
    }
    Some(out)
}

fn decode_hex_byte(high: u8, low: u8) -> Option<u8> {
    let hi = decode_hex_nibble(high)?;
    let lo = decode_hex_nibble(low)?;
    Some((hi << 4) | lo)
}

fn decode_hex_nibble(byte: u8) -> Option<u8> {
    match byte {
        b'0'..=b'9' => Some(byte - b'0'),
        b'a'..=b'f' => Some(byte - b'a' + 10),
        b'A'..=b'F' => Some(byte - b'A' + 10),
        _ => None,
    }
}
fn as_bytes<T>(value: &T) -> &[u8] {
    unsafe {
        core::slice::from_raw_parts((value as *const T).cast::<u8>(), core::mem::size_of::<T>())
    }
}

fn sha256_name(name: &str) -> [u8; 32] {
    let mut hasher = Sha256::new();
    hasher.update(name.as_bytes());
    hasher.finalize().into()
}

fn verify_policy_samples(
    block_io: &BlockIO,
    media_id: u32,
    lba_per_chunk: u64,
    public_key: &[u8],
) {
    verify_boot_policy(
        block_io,
        media_id,
        BOOT_POLICY_CHUNK_NUMBER * lba_per_chunk,
        public_key,
    );
    verify_update_manifest(
        block_io,
        media_id,
        UPDATE_MANIFEST_CHUNK_NUMBER * lba_per_chunk,
        public_key,
    );
    verify_audit_log(
        block_io,
        media_id,
        AUDIT_LOG_CHUNK_NUMBER * lba_per_chunk,
        public_key,
    );
}

fn verify_boot_policy(block_io: &BlockIO, media_id: u32, lba: u64, public_key: &[u8]) {
    let mut buffer = PageAlignedBuffer([0u8; 4096]);
    if block_io.read_blocks(media_id, lba, &mut buffer.0).is_err() {
        warn!("  -> Failed to read BootPolicy sample at LBA {}", lba);
        return;
    }
    let sample = unsafe { &*(buffer.0.as_ptr() as *const BootPolicy) };
    let digest = sample.compute_hash();
    if digest.as_slice() == &sample.signature.bytes[..32] && sample.verify_policy_signature(public_key)
    {
        info!("  -> [SUCCESS] BootPolicy sample digest verified.");
    } else {
        warn!("  -> [CRITICAL] BootPolicy sample digest mismatch.");
    }
}

fn verify_update_manifest(block_io: &BlockIO, media_id: u32, lba: u64, public_key: &[u8]) {
    let mut buffer = PageAlignedBuffer([0u8; 4096]);
    if block_io.read_blocks(media_id, lba, &mut buffer.0).is_err() {
        warn!("  -> Failed to read UpdateManifest sample at LBA {}", lba);
        return;
    }
    let sample = unsafe { &*(buffer.0.as_ptr() as *const UpdateManifest) };
    let digest = sample.compute_hash();
    if digest.as_slice() == &sample.signature.bytes[..32]
        && sample.verify_manifest_signature(public_key)
    {
        info!("  -> [SUCCESS] UpdateManifest sample digest verified.");
    } else {
        warn!("  -> [CRITICAL] UpdateManifest sample digest mismatch.");
    }
}

fn verify_audit_log(block_io: &BlockIO, media_id: u32, lba: u64, public_key: &[u8]) {
    let mut buffer = PageAlignedBuffer([0u8; 4096]);
    if block_io.read_blocks(media_id, lba, &mut buffer.0).is_err() {
        warn!("  -> Failed to read AuditLog sample at LBA {}", lba);
        return;
    }
    let sample = unsafe { &*(buffer.0.as_ptr() as *const AuditLogEntry) };
    let digest = sample.compute_hash();
    if digest.as_slice() == &sample.signature.bytes[..32]
        && sample.verify_hash_chain_with(None, public_key)
    {
        info!("  -> [SUCCESS] AuditLogEntry sample digest verified.");
    } else {
        warn!("  -> [CRITICAL] AuditLogEntry sample digest mismatch.");
    }
}
