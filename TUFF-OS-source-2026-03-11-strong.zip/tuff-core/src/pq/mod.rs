#![allow(dead_code)]

pub mod signatures;

use crate::cse::types::CseError;
use crate::fs_structs::KeyEnvelopeChunk;
use fips204::traits::{KeyGen, SerDes, Verifier};
use sha2::{Digest, Sha256};

pub const PQ_PUBLIC_KEY_MAX: usize = 4096;
pub const PQ_SECRET_KEY_MAX: usize = 8192;
pub const PQ_CIPHERTEXT_MAX: usize = 4096;
pub const PQ_SIGNATURE_MAX: usize = 8192;
pub type OwnerKey = [u8; 32];
pub type TransientKey = [u8; 32];
pub type PermanentKey = [u8; 32];
pub type WrapKey = [u8; 32];
pub const MOCK_MASTER_KEY: OwnerKey = [0x91; 32];
pub const EMBEDDED_ROOT_POLICY_SEED: [u8; 32] = [0x52; 32];
pub const DEFAULT_KDF_PARAMS: u32 = 0x0001_0001;

#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PqKemAlgorithm {
    MlKem512 = 0,
    MlKem768 = 1,
    MlKem1024 = 2,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MlKemVariant {
    MlKem768,
    MlKem1024,
}

impl MlKemVariant {
    pub fn algorithm(self) -> PqKemAlgorithm {
        match self {
            Self::MlKem768 => PqKemAlgorithm::MlKem768,
            Self::MlKem1024 => PqKemAlgorithm::MlKem1024,
        }
    }

    pub fn recipient_public_key_len(self) -> u16 {
        match self {
            Self::MlKem768 => 1184,
            Self::MlKem1024 => 1568,
        }
    }

    pub fn ciphertext_len(self) -> u16 {
        match self {
            Self::MlKem768 => 1088,
            Self::MlKem1024 => 1568,
        }
    }

    pub fn shared_secret_len(self) -> u16 {
        32
    }
}

#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PqSignatureAlgorithm {
    MlDsa44 = 0,
    MlDsa65 = 1,
    MlDsa87 = 2,
    SphincsSha2128s = 3,
}

#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PqDomain {
    KeyEnvelope = 0,
    BootPolicy = 1,
    UpdateManifest = 2,
    AuditLog = 3,
    KairoPolicy = 4,
}

#[repr(C)]
#[derive(Debug, Clone, Copy)]
pub struct PqKemEnvelopeHeader {
    pub version: u16,
    pub algorithm: PqKemAlgorithm,
    pub domain: PqDomain,
    pub public_key_len: u16,
    pub ciphertext_len: u16,
    pub shared_secret_len: u16,
    pub reserved: u16,
}

#[repr(C)]
#[derive(Debug, Clone, Copy)]
pub struct PqSignatureHeader {
    pub version: u16,
    pub algorithm: PqSignatureAlgorithm,
    pub domain: PqDomain,
    pub public_key_len: u16,
    pub signature_len: u16,
    pub payload_len: u32,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PqError {
    UnsupportedAlgorithm,
    InvalidFormat,
    VerificationFailed,
    BufferTooSmall,
}

pub struct KeyEnvelopeManager;

pub fn embedded_root_policy_public_key() -> [u8; fips204::ml_dsa_44::PK_LEN] {
    let (public_key, _private_key) = fips204::ml_dsa_44::KG::keygen_from_seed(&EMBEDDED_ROOT_POLICY_SEED);
    public_key.into_bytes()
}

impl KeyEnvelopeManager {
    pub fn derive_wrap_keys(
        mk: &OwnerKey,
        genesis_salt: &[u8; 32],
        fs_uuid: &[u8; 16],
        kdf_params: u32,
    ) -> (WrapKey, WrapKey, WrapKey) {
        (
            derive_labeled_key(mk, genesis_salt, fs_uuid, kdf_params, b"owner"),
            derive_labeled_key(mk, genesis_salt, fs_uuid, kdf_params, b"transient"),
            derive_labeled_key(mk, genesis_salt, fs_uuid, kdf_params, b"permanent"),
        )
    }

    pub fn compute_mk_verifier(ok: &WrapKey) -> [u8; 32] {
        let mut hasher = Sha256::new();
        hasher.update(b"TUFF-MK-VERIFIER");
        hasher.update(ok);
        hasher.finalize().into()
    }

    pub fn wrap_tk(tk: &TransientKey, tkw: &WrapKey) -> [u8; 48] {
        wrap_key_material(tk, tkw, b"wrapped-tk")
    }

    pub fn wrap_pk(pk: &PermanentKey, pkw: &WrapKey) -> [u8; 48] {
        wrap_key_material(pk, pkw, b"wrapped-pk")
    }

    pub fn unwrap_tk(wrapped_tk: &[u8; 48], tkw: &WrapKey) -> Result<TransientKey, CseError> {
        unwrap_key_material(wrapped_tk, tkw, b"wrapped-tk")
    }

    pub fn unwrap_pk(wrapped_pk: &[u8; 48], pkw: &WrapKey) -> Result<PermanentKey, CseError> {
        unwrap_key_material(wrapped_pk, pkw, b"wrapped-pk")
    }

    pub fn derive_cse_keys(shared_secret: &[u8; 32]) -> (TransientKey, PermanentKey) {
        let mut tk_hasher = Sha256::new();
        tk_hasher.update(b"TUFF-TK");
        tk_hasher.update(shared_secret);
        let tk: [u8; 32] = tk_hasher.finalize().into();

        let mut pk_hasher = Sha256::new();
        pk_hasher.update(b"TUFF-PK");
        pk_hasher.update(shared_secret);
        let pk: [u8; 32] = pk_hasher.finalize().into();

        (tk, pk)
    }

    pub fn compute_policy_root_hash(public_key: &[u8]) -> [u8; 32] {
        Sha256::digest(public_key).into()
    }

    pub fn compute_owner_genesis_hash(mk: &OwnerKey) -> [u8; 32] {
        let mut hasher = Sha256::new();
        hasher.update(b"TUFF-GENESIS-OWNER");
        hasher.update(mk);
        hasher.finalize().into()
    }

    pub fn verify_mk_for_kec(kec: &KeyEnvelopeChunk, mk: &OwnerKey) -> Result<(WrapKey, WrapKey, WrapKey), CseError> {
        if kec.compute_key_bundle_hash() != kec.key_bundle_hash {
            return Err(CseError::IntegrityCheckFailed);
        }
        let (ok, tkw, pkw) = Self::derive_wrap_keys(mk, &kec.genesis_salt, &kec.fs_uuid, kec.kdf_params);
        let verifier = Self::compute_mk_verifier(&ok);
        if verifier != kec.mk_verifier {
            return Err(CseError::KeyMismatch);
        }
        Ok((ok, tkw, pkw))
    }

    pub fn init_new_kec(
        mk: &OwnerKey,
        policy_root_hash: [u8; 32],
        fs_uuid: [u8; 16],
        genesis_salt: [u8; 32],
        kdf_params: u32,
        tk_entropy: &[u8; 32],
        pk_entropy: &[u8; 32],
    ) -> (KeyEnvelopeChunk, TransientKey, PermanentKey) {
        let (ok, tkw, pkw) = Self::derive_wrap_keys(mk, &genesis_salt, &fs_uuid, kdf_params);
        let mk_verifier = Self::compute_mk_verifier(&ok);
        let tk = derive_operational_key(tk_entropy, b"tuff-force-install-tk");
        let pk = derive_operational_key(pk_entropy, b"tuff-force-install-pk");

        let mut kec = KeyEnvelopeChunk {
            magic: *b"TUFFKEC ",
            version: 1,
            envelope_version: 1,
            kdf_params,
            flags: 0,
            signature_algorithm: PqSignatureAlgorithm::MlDsa65,
            reserved0: 0,
            fs_uuid,
            genesis_salt,
            mk_verifier,
            wrapped_tk: Self::wrap_tk(&tk, &tkw),
            wrapped_pk: Self::wrap_pk(&pk, &pkw),
            key_bundle_hash: [0u8; 32],
            policy_root_hash,
            reserved1: [0u8; 32],
            reserved: [0u8; 3800],
        };
        kec.key_bundle_hash = kec.compute_key_bundle_hash();
        (kec, tk, pk)
    }
}

pub fn verify_mldsa(
    data_hash: &[u8; 32],
    signature: &signatures::PqSignatureBlob,
    public_key: &[u8],
) -> Result<bool, PqError> {
    let message = mldsa_signing_message(data_hash, signature.domain);

    match signature.algorithm {
        PqSignatureAlgorithm::MlDsa44 => verify_mldsa44(&message, signature, public_key),
        PqSignatureAlgorithm::MlDsa65 => verify_mldsa65(&message, signature, public_key),
        PqSignatureAlgorithm::MlDsa87 => verify_mldsa87(&message, signature, public_key),
        _ => Err(PqError::UnsupportedAlgorithm),
    }
}

pub fn pq_layer_summary() -> &'static str {
    "Layer 2 unwraps MK-derived wrap keys from KEC metadata; Layer 3 verifies ML-DSA/SPHINCS+ signatures. CSE remains Layer 1."
}

fn derive_labeled_key(
    mk: &OwnerKey,
    genesis_salt: &[u8; 32],
    fs_uuid: &[u8; 16],
    kdf_params: u32,
    label: &[u8],
) -> WrapKey {
    let mut hasher = Sha256::new();
    hasher.update(b"TUFF-KDF");
    hasher.update(mk);
    hasher.update(fs_uuid);
    hasher.update(genesis_salt);
    hasher.update(kdf_params.to_le_bytes());
    hasher.update(label);
    hasher.finalize().into()
}

fn wrap_key_material(material: &[u8; 32], wrap_key: &WrapKey, label: &[u8]) -> [u8; 48] {
    let stream = derive_stream_block(wrap_key, label);
    let mut wrapped = [0u8; 48];
    for idx in 0..32 {
        wrapped[idx] = material[idx] ^ stream[idx];
    }
    let tag = derive_wrap_tag(&wrapped[..32], wrap_key, label);
    wrapped[32..48].copy_from_slice(&tag);
    wrapped
}

fn unwrap_key_material(wrapped: &[u8; 48], wrap_key: &WrapKey, label: &[u8]) -> Result<[u8; 32], CseError> {
    let expected = derive_wrap_tag(&wrapped[..32], wrap_key, label);
    if !constant_time_eq_16(&expected, wrapped[32..48].try_into().unwrap()) {
        return Err(CseError::IntegrityCheckFailed);
    }
    let stream = derive_stream_block(wrap_key, label);
    let mut out = [0u8; 32];
    for idx in 0..32 {
        out[idx] = wrapped[idx] ^ stream[idx];
    }
    Ok(out)
}

fn derive_stream_block(wrap_key: &WrapKey, label: &[u8]) -> [u8; 32] {
    let mut hasher = Sha256::new();
    hasher.update(b"TUFF-WRAP-STREAM");
    hasher.update(wrap_key);
    hasher.update(label);
    hasher.finalize().into()
}

fn derive_wrap_tag(ciphertext: &[u8], wrap_key: &WrapKey, label: &[u8]) -> [u8; 16] {
    let mut hasher = Sha256::new();
    hasher.update(b"TUFF-WRAP-TAG");
    hasher.update(wrap_key);
    hasher.update(label);
    hasher.update(ciphertext);
    let digest: [u8; 32] = hasher.finalize().into();
    digest[..16].try_into().unwrap()
}

fn derive_operational_key(seed: &[u8; 32], label: &[u8]) -> [u8; 32] {
    let mut hasher = Sha256::new();
    hasher.update(b"TUFF-OP-KEY");
    hasher.update(seed);
    hasher.update(label);
    hasher.finalize().into()
}

fn constant_time_eq_16(left: &[u8; 16], right: &[u8; 16]) -> bool {
    let mut diff = 0u8;
    for idx in 0..16 {
        diff |= left[idx] ^ right[idx];
    }
    diff == 0
}

fn verify_mldsa44(
    message: &[u8; 34],
    signature: &signatures::PqSignatureBlob,
    public_key: &[u8],
) -> Result<bool, PqError> {
    if signature.length as usize != fips204::ml_dsa_44::SIG_LEN {
        return Err(PqError::InvalidFormat);
    }
    if public_key.len() != fips204::ml_dsa_44::PK_LEN {
        return Err(PqError::InvalidFormat);
    }

    let mut pk_bytes = [0u8; fips204::ml_dsa_44::PK_LEN];
    pk_bytes.copy_from_slice(public_key);
    let mut sig_bytes = [0u8; fips204::ml_dsa_44::SIG_LEN];
    sig_bytes.copy_from_slice(&signature.bytes[..fips204::ml_dsa_44::SIG_LEN]);
    let pk = fips204::ml_dsa_44::PublicKey::try_from_bytes(pk_bytes)
        .map_err(|_| PqError::VerificationFailed)?;
    Ok(pk.verify(message, &sig_bytes, &[]))
}

fn verify_mldsa65(
    _message: &[u8; 34],
    signature: &signatures::PqSignatureBlob,
    _public_key: &[u8],
) -> Result<bool, PqError> {
    // Current PqSignatureBlob storage (2420 bytes) cannot carry ML-DSA-65 signatures (3309 bytes).
    if signature.length as usize > signatures::PQ_SIGNATURE_PLACEHOLDER_LEN {
        return Err(PqError::BufferTooSmall);
    }
    Err(PqError::InvalidFormat)
}

fn verify_mldsa87(
    _message: &[u8; 34],
    signature: &signatures::PqSignatureBlob,
    _public_key: &[u8],
) -> Result<bool, PqError> {
    // Current PqSignatureBlob storage (2420 bytes) cannot carry ML-DSA-87 signatures (4627 bytes).
    if signature.length as usize > signatures::PQ_SIGNATURE_PLACEHOLDER_LEN {
        return Err(PqError::BufferTooSmall);
    }
    Err(PqError::InvalidFormat)
}

pub fn mldsa_signing_message(data_hash: &[u8; 32], domain: PqDomain) -> [u8; 34] {
    let mut message = [0u8; 34];
    message[0] = b'T';
    message[1] = domain as u8;
    message[2..].copy_from_slice(data_hash);
    message
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::pq::signatures::PqSignatureBlob;
    use fips204::traits::{SerDes, Signer};

    fn hash_sample() -> [u8; 32] {
        let mut out = [0u8; 32];
        for (idx, byte) in out.iter_mut().enumerate() {
            *byte = (idx as u8).wrapping_mul(3);
        }
        out
    }

    fn make_sig(
        hash: &[u8; 32],
        domain: PqDomain,
        seed: [u8; 32],
    ) -> ([u8; fips204::ml_dsa_44::PK_LEN], PqSignatureBlob) {
        let (pk, sk) = fips204::ml_dsa_44::KG::keygen_from_seed(&seed);
        let mut sig = PqSignatureBlob {
            algorithm: PqSignatureAlgorithm::MlDsa44,
            domain,
            length: fips204::ml_dsa_44::SIG_LEN as u16,
            bytes: [0u8; signatures::PQ_SIGNATURE_PLACEHOLDER_LEN],
        };
        let message = mldsa_signing_message(hash, domain);
        let raw = sk.try_sign_with_seed(&seed, &message, &[]).unwrap();
        sig.bytes[..raw.len()].copy_from_slice(&raw);
        (pk.into_bytes(), sig)
    }

    #[test]
    fn verify_mldsa_accepts_valid_signature() {
        let hash = hash_sample();
        let (pk, sig) = make_sig(&hash, PqDomain::BootPolicy, [0x11; 32]);
        assert!(verify_mldsa(&hash, &sig, &pk).unwrap());
    }

    #[test]
    fn verify_mldsa_rejects_invalid_signature() {
        let hash = hash_sample();
        let (pk, mut sig) = make_sig(&hash, PqDomain::BootPolicy, [0x22; 32]);
        sig.bytes[10] ^= 0xff;
        assert!(!verify_mldsa(&hash, &sig, &pk).unwrap());
    }

    #[test]
    fn verify_mldsa_rejects_wrong_domain_public_key_or_hash() {
        let hash = hash_sample();
        let (pk, sig) = make_sig(&hash, PqDomain::BootPolicy, [0x33; 32]);
        let mut wrong_domain_sig = sig;
        wrong_domain_sig.domain = PqDomain::AuditLog;
        let (wrong_pk, _) = make_sig(&hash, PqDomain::BootPolicy, [0x44; 32]);
        let mut wrong_hash = hash;
        wrong_hash[0] ^= 0x7f;

        assert!(!verify_mldsa(&hash, &wrong_domain_sig, &pk).unwrap());
        assert!(!verify_mldsa(&hash, &sig, &wrong_pk).unwrap());
        assert!(!verify_mldsa(&wrong_hash, &sig, &pk).unwrap());
    }
}
