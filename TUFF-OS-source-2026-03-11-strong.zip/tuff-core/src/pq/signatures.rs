#![allow(dead_code)]

use crate::pq::{PqDomain, PqSignatureAlgorithm};
use sha2::{Digest, Sha256};

pub const PQ_SIGNATURE_PLACEHOLDER_LEN: usize = 2420;

#[repr(C)]
#[derive(Debug, Clone, Copy)]
pub struct PqSignatureBlob {
    pub algorithm: PqSignatureAlgorithm,
    pub domain: PqDomain,
    pub length: u16,
    pub bytes: [u8; PQ_SIGNATURE_PLACEHOLDER_LEN],
}

#[repr(C)]
#[derive(Debug, Clone, Copy)]
pub struct BootPolicy {
    pub policy_version: u32,
    pub policy_epoch: u64,
    pub allowed_genesis_version: u32,
    pub minimum_kec_version: u32,
    pub allowed_root_hashes: [[u8; 32]; 4],
    pub allowed_update_signers: [[u8; 32]; 2],
    pub required_pq_algorithm: PqSignatureAlgorithm,
    pub reserved: [u8; 19],
    pub signature: PqSignatureBlob,
}

impl BootPolicy {
    pub fn compute_hash(&self) -> [u8; 32] {
        let mut hasher = Sha256::new();
        hasher.update(self.policy_version.to_le_bytes());
        hasher.update(self.policy_epoch.to_le_bytes());
        hasher.update(self.allowed_genesis_version.to_le_bytes());
        hasher.update(self.minimum_kec_version.to_le_bytes());
        for hash in self.allowed_root_hashes {
            hasher.update(hash);
        }
        for signer in self.allowed_update_signers {
            hasher.update(signer);
        }
        hasher.update([self.required_pq_algorithm as u8]);
        hasher.update(self.reserved);
        hasher.finalize().into()
    }

    pub fn verify_policy_signature(&self, public_key: &[u8]) -> bool {
        let digest = self.compute_hash();
        crate::pq::verify_mldsa(&digest, &self.signature, public_key).unwrap_or(false)
    }
}

#[repr(C)]
#[derive(Debug, Clone, Copy)]
pub struct UpdateManifest {
    pub manifest_version: u32,
    pub manifest_epoch: u64,
    pub build_timestamp: u64,
    pub image_hash: [u8; 32],
    pub previous_image_hash: [u8; 32],
    pub allowed_boot_hash: [u8; 32],
    pub action_type: u16,
    pub next_bank: u8,
    pub reserved: [u8; 21],
    pub signature: PqSignatureBlob,
}

impl UpdateManifest {
    pub fn compute_hash(&self) -> [u8; 32] {
        let mut hasher = Sha256::new();
        hasher.update(self.manifest_version.to_le_bytes());
        hasher.update(self.manifest_epoch.to_le_bytes());
        hasher.update(self.build_timestamp.to_le_bytes());
        hasher.update(self.image_hash);
        hasher.update(self.previous_image_hash);
        hasher.update(self.allowed_boot_hash);
        hasher.update(self.action_type.to_le_bytes());
        hasher.update([self.next_bank]);
        hasher.update(self.reserved);
        hasher.finalize().into()
    }

    pub fn verify_manifest_signature(&self, public_key: &[u8]) -> bool {
        let digest = self.compute_hash();
        crate::pq::verify_mldsa(&digest, &self.signature, public_key).unwrap_or(false)
    }
}

#[repr(C)]
#[derive(Debug, Clone, Copy)]
pub struct AuditLogEntry {
    pub entry_version: u32,
    pub event_epoch: u64,
    pub timestamp_unix_ms: u64,
    pub event_type: u16,
    pub actor_class: u16,
    pub action_type: u16,
    pub result_code: u16,
    pub subject_hash: [u8; 32],
    pub payload_hash: [u8; 32],
    pub previous_entry_hash: [u8; 32],
    pub reserved: [u8; 8],
    pub signature: PqSignatureBlob,
}

impl AuditLogEntry {
    pub fn compute_hash(&self) -> [u8; 32] {
        let mut hasher = Sha256::new();
        hasher.update(self.entry_version.to_le_bytes());
        hasher.update(self.event_epoch.to_le_bytes());
        hasher.update(self.timestamp_unix_ms.to_le_bytes());
        hasher.update(self.event_type.to_le_bytes());
        hasher.update(self.actor_class.to_le_bytes());
        hasher.update(self.action_type.to_le_bytes());
        hasher.update(self.result_code.to_le_bytes());
        hasher.update(self.subject_hash);
        hasher.update(self.payload_hash);
        hasher.update(self.previous_entry_hash);
        hasher.update(self.reserved);
        hasher.finalize().into()
    }

    pub fn verify_entry_signature(&self, public_key: &[u8]) -> bool {
        let digest = self.compute_hash();
        crate::pq::verify_mldsa(&digest, &self.signature, public_key).unwrap_or(false)
    }

    pub fn verify_hash_chain_with(
        &self,
        previous: Option<&AuditLogEntry>,
        public_key: &[u8],
    ) -> bool {
        let chain_ok = match previous {
            Some(prev) => self.previous_entry_hash == prev.compute_hash(),
            None => self.previous_entry_hash == [0u8; 32],
        };
        chain_ok && self.verify_entry_signature(public_key)
    }
}
