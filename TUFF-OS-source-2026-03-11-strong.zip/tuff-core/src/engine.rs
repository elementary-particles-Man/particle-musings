use crate::genesis::Genesis;
use crate::pq::{KeyEnvelopeManager, OwnerKey};
use alloc::vec::Vec;
use crate::cse::engine::CseEngine;
use crate::cse::types::{CseDescriptor, CSE_BLOCK_SIZE};
use crate::fs_structs::{
    AlertConsumerCursor, AlertConsumerMode, AlertEvent, AlertSharedMemoryPage, ALERT_IPC_RING_CAPACITY,
    AppendBaseGeneration, AppendWriteRange, CrossHwTransferClass, CrossHwTransferPolicy,
    FileExState, FolderStatus, MetadataCriticalChunkKind, MetadataCriticalEventSource,
    MetadataCriticalPlacement, MetadataCriticalPlacementPolicy, MetadataCriticalReplicaSet,
    MetadataPlacementSafetyAssumption, MqRetentionPolicy, PendingOperation,
    PendingOperationKind, QueueRejectSeverity, QueueWriteState, ReaderReclaimPolicy,
    ReaderTrackingState,
    ReclaimPendingEntry, ReclaimState,
};

use crate::evacuation::{enqueue_evacuation_candidates, sort_evacuation_candidates, EvacuationCandidate};
use crate::scheduler::{
    CommitCoordinator, DispatchDecision, DispatchRequest, HwQueueState, HwScheduler, IoPriority,
    PhysicalWriteback, PointerUpdate, SmartSnapshot, TuffError, compute_block_checksum,
};
use sha2::{Digest, Sha256};
use uefi::proto::media::block::BlockIO;
use uefi::table::boot::BootServices;
use uefi::Handle;

const MAX_GENESIS_CANDIDATES: usize = 16;

#[derive(Clone, Copy)]
pub struct GenesisCandidate {
    pub handle_index: usize,
    pub timestamp: u64,
    pub hash: [u8; 32],
}

#[derive(Clone, Copy)]
pub struct GenesisVoteResult {
    pub candidate: GenesisCandidate,
    pub quorum_count: usize,
    pub candidate_count: usize,
}

pub const UQ_PAUSE_PERCENT: u8 = 80;
pub const UQ_RESUME_PERCENT: u8 = 65;
pub const DEFAULT_MEMORY_BACKED_UQ_BYTES: usize = 512 * 1024 * 1024;
pub const TUFF_MQ_MAGIC: [u8; 8] = *b"TUFFMQ01";
pub const TUFF_MQ_VERSION: u32 = 2;
pub const READER_RECLAIM_RECENT_EPOCH_GUARD: u64 = 1;
pub const READER_RECLAIM_FALLBACK_EPOCH_GUARD: u64 = 2;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct UqFlowControl {
    pub paused: bool,
    pub usage_percent: u8,
}

impl UqFlowControl {
    pub const fn new(usage_percent: u8) -> Self {
        Self {
            paused: usage_percent >= UQ_PAUSE_PERCENT,
            usage_percent,
        }
    }
}

pub fn verify_3n_genesis(
    bt: &BootServices,
    owner_mk: &OwnerKey,
) -> Option<GenesisVoteResult> {
    let handles = bt.find_handles::<BlockIO>().ok()?;
    let expected_hash = KeyEnvelopeManager::compute_owner_genesis_hash(owner_mk);
    let mut candidates = [GenesisCandidate {
        handle_index: 0,
        timestamp: 0,
        hash: [0u8; 32],
    }; MAX_GENESIS_CANDIDATES];
    let mut candidate_count = 0usize;

    for (index, handle) in handles.iter().enumerate() {
        if candidate_count >= MAX_GENESIS_CANDIDATES {
            break;
        }
        let Ok(block_io) = bt.open_protocol_exclusive::<BlockIO>(*handle) else {
            continue;
        };
        let media = block_io.media();
        let block_size = media.block_size() as usize;
        if !media.is_media_present() || block_size == 0 || block_size > crate::genesis::GENESIS_SIZE {
            continue;
        }

        let mut sector0 = [0u8; crate::genesis::GENESIS_SIZE];
        if block_io.read_blocks(media.media_id(), 0, &mut sector0).is_err() {
            continue;
        }
        if &sector0[..Genesis::MAGIC.len()] != Genesis::MAGIC.as_slice() {
            continue;
        }

        let genesis = unsafe { &*(sector0.as_ptr() as *const Genesis) };
        if genesis.initial_key_hash != expected_hash {
            continue;
        }

        candidates[candidate_count] = GenesisCandidate {
            handle_index: index,
            timestamp: genesis.timestamp,
            hash: genesis.initial_key_hash,
        };
        candidate_count += 1;
    }

    if candidate_count == 0 {
        return None;
    }

    let mut best = candidates[0];
    let mut best_quorum = 1usize;
    for i in 0..candidate_count {
        let mut quorum = 1usize;
        for j in 0..candidate_count {
            if i != j && candidates[i].hash == candidates[j].hash {
                quorum += 1;
            }
        }
        if quorum > best_quorum || (quorum == best_quorum && candidates[i].timestamp >= best.timestamp)
        {
            best = candidates[i];
            best_quorum = quorum;
        }
    }

    Some(GenesisVoteResult {
        candidate: best,
        quorum_count: best_quorum,
        candidate_count,
    })
}

pub fn update_uq_flow_control(current: UqFlowControl, usage_percent: u8) -> UqFlowControl {
    let paused = if current.paused {
        usage_percent >= UQ_RESUME_PERCENT
    } else {
        usage_percent >= UQ_PAUSE_PERCENT
    };
    UqFlowControl {
        paused,
        usage_percent,
    }
}

pub fn dispatch_loop(
    scheduler: &mut HwScheduler,
    requests: &[DispatchRequest],
    uq_usage_percent: u8,
    now_ms: u64,
) -> Result<[Option<DispatchDecision>; 8], TuffError> {
    let mut decisions = [None; 8];
    let mut flow = UqFlowControl::new(uq_usage_percent);

    for (index, request) in requests.iter().enumerate() {
        if index >= decisions.len() {
            break;
        }

        if flow.paused && request.priority >= IoPriority::LowRestore {
            continue;
        }

        if let Some(target_disk) = request.target_disk {
            let disk_idx = scheduler
                .disks
                .iter()
                .position(|disk| disk.disk_id == target_disk)
                .ok_or(TuffError::DiskNotFound)?;
            let disk = scheduler.disks[disk_idx];
            if disk.state == HwQueueState::Evacuating
                && !matches!(request.priority, IoPriority::CriticalRead | IoPriority::LowRestore)
            {
                continue;
            }
            if disk.state == HwQueueState::Faulted {
                continue;
            }
        }

        if let Ok(decision) = scheduler.dispatch(*request, now_ms) {
            decisions[index] = Some(decision);
        }

        let synthetic_usage = flow.usage_percent.saturating_add(8);
        flow = update_uq_flow_control(flow, synthetic_usage);
    }

    Ok(decisions)
}

pub fn run_monitoring_cycle(
    scheduler: &mut HwScheduler,
    disk_id: u64,
    snapshot: crate::scheduler::SmartSnapshot,
    now_ms: u64,
) -> Result<(), TuffError> {
    if scheduler.should_run_smart(disk_id, now_ms, 30_000)? {
        let health = scheduler.evaluate_smart(&snapshot, &Default::default());
        scheduler.apply_health_transition(disk_id, health)?;
        scheduler.mark_smart_checked(disk_id, now_ms)?;
    }
    Ok(())
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct UniqueQueueEntry {
    pub file_id: u64,
    pub epoch: u64,
    pub priority: IoPriority,
    pub sectors: u64,
    pub old_lba: u64,
    pub entry_index: usize,
    pub exclude_disks: [u64; 3],
    pub exclude_len: usize,
}

pub struct UniqueQueueRuntime {
    pub entries: Vec<UniqueQueueEntry>,
    pub usage_percent: u8,
    pub paused: bool,
    pub monitoring_queue: Vec<(u64, SmartSnapshot)>,
    pub evacuation_candidates: Vec<EvacuationCandidate>,
    pub checkpoint_batch_size: usize,
    pub checkpoint_timeout_ms: u64,
    pub last_checkpoint_at: u64,
    pub pending_data_writes: Vec<PendingDataWrite>,
    pub persisted_queue_records: Vec<QueuePersistedRecord>,
    pub backend_policy: QueueBackendPolicy,
}

#[derive(Debug, Clone, Copy)]
pub struct PendingDataWrite {
    pub file_id: u64,
    pub entry_index: usize,
    pub old_lba: u64,
    pub epoch: u64,
    pub priority: IoPriority,
    pub sectors: u64,
    pub target_disk: Option<u64>,
    pub exclude_disks: [u64; 3],
    pub exclude_len: usize,
    pub chunk: [u8; CSE_BLOCK_SIZE],
    pub descriptor: CseDescriptor,
    pub tk: [u8; 32],
    pub pk: [u8; 32],
}

#[derive(Debug, Clone, Copy)]
pub struct RuntimeDataWriteRequest {
    pub file_id: u64,
    pub entry_index: usize,
    pub old_lba: u64,
    pub epoch: u64,
    pub priority: IoPriority,
    pub sectors: u64,
    pub target_disk: Option<u64>,
    pub exclude_disks: [u64; 3],
    pub exclude_len: usize,
    pub chunk: [u8; CSE_BLOCK_SIZE],
    pub descriptor: CseDescriptor,
    pub tk: [u8; 32],
    pub pk: [u8; 32],
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum QueueBackendKind {
    MemoryBacked,
    FileBacked,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct QueueBackendPolicy {
    pub kind: QueueBackendKind,
    pub memory_bytes: usize,
}

#[derive(Debug, Clone, Copy)]
pub struct QueuePersistedRecord {
    pub state: QueueWriteState,
    pub complete_record: bool,
    pub verified_readback: bool,
    pub pointer_validated: bool,
    pub writeback_disk_id: u64,
    pub writeback_start_lba: u64,
    pub reject_reason: Option<QueueRejectReason>,
    pub pending: PendingDataWrite,
}

pub type UqRecord = QueuePersistedRecord;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct QueueResumeReport {
    pub truncated_tail_records: usize,
    pub resumed_records: usize,
    pub rejected_records: usize,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct CompletedWriteback {
    pub disk_id: u64,
    pub start_lba: u64,
    pub priority: IoPriority,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum QueueRejectReason {
    IncompleteNonIngesting,
    MissingWritebackLocation,
    TargetDiskMismatch,
}

impl QueueRejectReason {
    pub const fn as_u8(self) -> u8 {
        match self {
            QueueRejectReason::IncompleteNonIngesting => 1,
            QueueRejectReason::MissingWritebackLocation => 2,
            QueueRejectReason::TargetDiskMismatch => 3,
        }
    }

    pub const fn from_u8(value: u8) -> Option<Self> {
        match value {
            1 => Some(QueueRejectReason::IncompleteNonIngesting),
            2 => Some(QueueRejectReason::MissingWritebackLocation),
            3 => Some(QueueRejectReason::TargetDiskMismatch),
            _ => None,
        }
    }
}

impl QueueRejectReason {
    pub const fn severity(self) -> QueueRejectSeverity {
        match self {
            QueueRejectReason::IncompleteNonIngesting => QueueRejectSeverity::HardReject,
            QueueRejectReason::MissingWritebackLocation => QueueRejectSeverity::CriticalFault,
            QueueRejectReason::TargetDiskMismatch => QueueRejectSeverity::CriticalFault,
        }
    }
}

pub const fn default_mq_retention_policy() -> MqRetentionPolicy {
    MqRetentionPolicy {
        keep_recent_epochs: 8,
        retain_rejected_epochs: 8,
        retain_verified_commit_epochs: 2,
    }
}

pub const fn default_reader_reclaim_policy() -> ReaderReclaimPolicy {
    ReaderReclaimPolicy {
        recent_epoch_guard: READER_RECLAIM_RECENT_EPOCH_GUARD,
        fallback_epoch_guard: READER_RECLAIM_FALLBACK_EPOCH_GUARD,
    }
}

pub const fn default_metadata_critical_placement_policy() -> MetadataCriticalPlacementPolicy {
    MetadataCriticalPlacementPolicy {
        initial_zone_base_lba: METADATA_CRITICAL_INITIAL_ZONE_BASE_LBA,
        index_zone_base_lba: METADATA_CRITICAL_INDEX_ZONE_BASE_LBA,
        file_slot_stride_lbas: METADATA_CRITICAL_FILE_SLOT_STRIDE_LBAS,
        replica_stride_lbas: METADATA_CRITICAL_REPLICA_STRIDE_LBAS,
        file_slot_mask: 0x1f,
    }
}

pub const fn metadata_critical_placement_safety_assumptions() -> [MetadataPlacementSafetyAssumption; 3] {
    [
        MetadataPlacementSafetyAssumption::SameHwOnly3n,
        MetadataPlacementSafetyAssumption::DistinctZonePerChunkKind,
        MetadataPlacementSafetyAssumption::FixedSlotMasking,
    ]
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct QueueCompactionReport {
    pub removed_terminal_records: usize,
    pub deduplicated_records: usize,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct FileExTransitionReport {
    pub became_pending: bool,
    pub committed: bool,
    pub rejected: bool,
    pub freed_pending_chunk: Option<u64>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AppendOnlyWriteRequest {
    pub file_id: u64,
    pub base: AppendBaseGeneration,
    pub range: AppendWriteRange,
    pub payload: Vec<u8>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AppendOnlyStageResult {
    pub request: AppendOnlyWriteRequest,
    pub full_image: Vec<u8>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AppendOnlyError {
    RangeOverflow,
    BaseGenerationMismatch,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PendingOperationError {
    BaseGenerationMismatch,
    MissingSource,
}

pub const METADATA_3N_VERIFY_INTERVAL_MS: u64 = 15_000;
pub const FILE_EX_META_MAGIC: [u8; 8] = *b"TUFFFX01";
pub const FILE_EX_META_VERSION: u32 = 2;
pub const FILE_EX_METADATA_REGION_MAGIC: [u8; 8] = *b"TFXMDT01";
pub const FILE_EX_METADATA_REGION_VERSION: u32 = 1;
pub const FILE_EX_METADATA_PAYLOAD_MAX: usize = 4096 - (8 + 4 + 8 + 8 + 4 + 32);
pub const METADATA_CRITICAL_INITIAL_ZONE_BASE_LBA: u64 = 0x2000;
pub const METADATA_CRITICAL_INDEX_ZONE_BASE_LBA: u64 = 0x4000;
pub const METADATA_CRITICAL_FILE_SLOT_STRIDE_LBAS: u64 = 0x40;
pub const METADATA_CRITICAL_REPLICA_STRIDE_LBAS: u64 = 0x08;
pub const EMPTY_ALERT_EVENT: AlertEvent = AlertEvent {
    sequence: 0,
    class: crate::fs_structs::AlertClass::QueueFault,
    disk_id: 0,
    file_id: 0,
    epoch: 0,
    code: 0,
    aux: 0,
};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct MetadataCriticalWriteRequest {
    pub source: MetadataCriticalEventSource,
    pub chunk_kind: MetadataCriticalChunkKind,
    pub disk_id: u64,
    pub file_id: u64,
    pub epoch: u64,
    pub placement: MetadataCriticalPlacement,
    pub payload: [u8; 4096],
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MetadataCriticalAlertReason {
    MissingReplica,
    ReplicaMismatch,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct MetadataCriticalAlert {
    pub chunk_kind: MetadataCriticalChunkKind,
    pub disk_id: u64,
    pub epoch: u64,
    pub reason: MetadataCriticalAlertReason,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Metadata3nVerificationResult {
    pub alert: Option<MetadataCriticalAlert>,
    pub checked: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct FmcDiscoveryReplica {
    pub file_id: u64,
    pub disk_id: u64,
    pub start_lba: u64,
    pub buffer: [u8; 4096],
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RecoverTargetSelectionError {
    AmbiguousTargetMetaId,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct CrossHwTransferPlan {
    pub class: CrossHwTransferClass,
    pub policy: CrossHwTransferPolicy,
    pub source_hw_id: u64,
    pub target_hw_id: u64,
}

impl UniqueQueueRuntime {
    pub fn new() -> Self {
        Self::with_backend_policy(QueueBackendPolicy::default())
    }

    pub fn with_backend_policy(backend_policy: QueueBackendPolicy) -> Self {
        Self {
            entries: Vec::new(),
            usage_percent: 0,
            paused: false,
            monitoring_queue: Vec::new(),
            evacuation_candidates: Vec::new(),
            checkpoint_batch_size: 3,
            checkpoint_timeout_ms: 5_000,
            last_checkpoint_at: 0,
            pending_data_writes: Vec::new(),
            persisted_queue_records: Vec::new(),
            backend_policy,
        }
    }

    pub fn resume_from_persisted_queue(&mut self) -> Result<QueueResumeReport, TuffError> {
        let mut report = QueueResumeReport {
            truncated_tail_records: 0,
            resumed_records: 0,
            rejected_records: 0,
        };
        let mut records = core::mem::take(&mut self.persisted_queue_records);
        let last_index = records.len().saturating_sub(1);

        for (idx, mut record) in records.drain(..).enumerate() {
            if let Some(reason) = evaluate_rejected_policy(&record) {
                if record.state != QueueWriteState::UqIngesting || record.complete_record {
                    record.state = QueueWriteState::Rejected;
                    record.reject_reason = Some(reason);
                    self.persisted_queue_records.push(record);
                    report.rejected_records += 1;
                    continue;
                }
            }
            match record.state {
                QueueWriteState::UqIngesting => {
                    if !record.complete_record {
                        if idx != last_index {
                            return Err(TuffError::InvalidStateTransition);
                        }
                        report.truncated_tail_records += 1;
                        continue;
                    }
                    self.enqueue_data_write(record.pending);
                    report.resumed_records += 1;
                }
                QueueWriteState::UqStored => {
                    if !record.complete_record {
                        return Err(TuffError::InvalidStateTransition);
                    }
                    self.enqueue_data_write(record.pending);
                    report.resumed_records += 1;
                }
                QueueWriteState::HwWriting => {
                    if !record.complete_record {
                        return Err(TuffError::InvalidStateTransition);
                    }
                    self.enqueue_data_write(record.pending);
                    report.resumed_records += 1;
                }
                QueueWriteState::CommitPending => {
                    if !record.complete_record {
                        return Err(TuffError::InvalidStateTransition);
                    }
                    if record.verified_readback && record.pointer_validated {
                        continue;
                    }
                    self.enqueue_data_write(record.pending);
                    report.resumed_records += 1;
                }
                QueueWriteState::Rejected => {}
            }
        }
        Ok(report)
    }

    pub fn enqueue(&mut self, entry: UniqueQueueEntry) {
        self.entries.push(entry);
    }

    pub fn enqueue_monitoring_snapshot(&mut self, disk_id: u64, snapshot: SmartSnapshot) {
        self.monitoring_queue.push((disk_id, snapshot));
    }

    pub fn enqueue_evacuation_candidate(&mut self, candidate: EvacuationCandidate) {
        self.evacuation_candidates.push(candidate);
    }

    pub fn enqueue_data_write(&mut self, write: PendingDataWrite) {
        self.upsert_runtime_record(
            write,
            QueueWriteState::UqStored,
            false,
            false,
            0,
            0,
        );
        self.pending_data_writes.push(write);
    }

    pub fn mark_writeback_verified(&mut self, disk_id: u64, start_lba: u64) {
        for record in self.persisted_queue_records.iter_mut() {
            if record.writeback_disk_id == disk_id
                && record.writeback_start_lba == start_lba
                && record.state == QueueWriteState::HwWriting
            {
                record.state = QueueWriteState::CommitPending;
                record.verified_readback = true;
            }
        }
    }

    pub fn mark_epoch_pointer_validated(&mut self, epoch: u64) {
        for record in self.persisted_queue_records.iter_mut() {
            if record.pending.epoch == epoch && record.state == QueueWriteState::CommitPending {
                record.pointer_validated = true;
            }
        }
    }

    fn upsert_runtime_record(
        &mut self,
        write: PendingDataWrite,
        state: QueueWriteState,
        verified_readback: bool,
        pointer_validated: bool,
        writeback_disk_id: u64,
        writeback_start_lba: u64,
    ) {
        if let Some(existing) = self.persisted_queue_records.iter_mut().find(|record| {
            record.pending.epoch == write.epoch
                && record.pending.descriptor.chunk_id == write.descriptor.chunk_id
                && record.pending.target_disk == write.target_disk
        }) {
            existing.state = state;
            existing.complete_record = true;
            existing.verified_readback = verified_readback;
            existing.pointer_validated = pointer_validated;
            existing.writeback_disk_id = writeback_disk_id;
            existing.writeback_start_lba = writeback_start_lba;
            existing.reject_reason = None;
            existing.pending = write;
            return;
        }
        self.persisted_queue_records.push(QueuePersistedRecord {
            state,
            complete_record: true,
            verified_readback,
            pointer_validated,
            writeback_disk_id,
            writeback_start_lba,
            reject_reason: None,
            pending: write,
        });
    }

    pub fn process_cycle(
        &mut self,
        scheduler: &mut HwScheduler,
        coordinator: &mut CommitCoordinator,
        now_ms: u64,
    ) -> Result<Vec<DispatchDecision>, TuffError> {
        let monitoring = core::mem::take(&mut self.monitoring_queue);
        for (disk_id, snapshot) in monitoring {
            run_monitoring_cycle(scheduler, disk_id, snapshot, now_ms)?;
        }

        if !self.evacuation_candidates.is_empty() {
            sort_evacuation_candidates(&mut self.evacuation_candidates);
            let staged_candidates = self.evacuation_candidates.clone();
            let queued = enqueue_evacuation_candidates(
                self,
                &staged_candidates,
                self.paused,
            );
            if queued > 0 {
                self.evacuation_candidates.drain(..queued);
            }
        }

        let mut requests = [DispatchRequest {
            epoch: 0,
            priority: IoPriority::Maintenance,
            sectors: 0,
            target_disk: None,
            exclude_disks: [0; 3],
            exclude_len: 0,
        }; 8];
        let mut request_count = 0usize;
        let mut original_entries = [None; 8];
        let mut cycle_epoch = None;

        while request_count < requests.len() && !self.entries.is_empty() {
            let entry = self.entries[0];
            if let Some(expected_epoch) = cycle_epoch {
                if entry.epoch != expected_epoch {
                    break;
                }
            } else {
                cycle_epoch = Some(entry.epoch);
            }
            let entry = self.entries.remove(0);
            requests[request_count] = DispatchRequest {
                epoch: entry.epoch,
                priority: entry.priority,
                sectors: entry.sectors,
                target_disk: None,
                exclude_disks: entry.exclude_disks,
                exclude_len: entry.exclude_len,
            };
            original_entries[request_count] = Some(entry);
            request_count += 1;
        }

        let decisions = dispatch_loop(scheduler, &requests[..request_count], self.usage_percent, now_ms)?;
        let mut committed = Vec::new();

        for (index, decision) in decisions.into_iter().enumerate() {
            let Some(decision) = decision else {
                continue;
            };
            let Some(original) = original_entries[index] else {
                continue;
            };
            coordinator.push_update(PointerUpdate {
                file_id: original.file_id,
                entry_index: original.entry_index,
                old_lba: original.old_lba,
                new_lba: decision.start_lba,
            });
            committed.push(decision);
            self.usage_percent = self.usage_percent.saturating_add(8);
        }

        let data_writes = core::mem::take(&mut self.pending_data_writes);
        let mut deferred_data_writes = Vec::new();
        for write in data_writes {
            if let Some(expected_epoch) = cycle_epoch {
                if write.epoch != expected_epoch {
                    deferred_data_writes.push(write);
                    continue;
                }
            } else {
                cycle_epoch = Some(write.epoch);
            }
            self.upsert_runtime_record(write, QueueWriteState::UqIngesting, false, false, 0, 0);
            let mut encrypted_chunk = write.chunk;
            let mut descriptor = write.descriptor;
            CseEngine::process_data_block_secure(
                &mut encrypted_chunk,
                &mut descriptor,
                &write.tk,
                &write.pk,
                true,
            ).map_err(|_| TuffError::ReservationFailed)?;

            let decision = scheduler.enqueue_write(
                write.epoch,
                write.priority,
                write.sectors,
                write.target_disk,
                write.exclude_disks,
                write.exclude_len,
                now_ms,
            )?;
            coordinator.enqueue_runtime_writeback(
                decision.disk_id,
                decision.start_lba,
                write.priority,
                encrypted_chunk,
            );
            coordinator.push_update(PointerUpdate {
                file_id: write.file_id,
                entry_index: write.entry_index,
                old_lba: write.old_lba,
                new_lba: decision.start_lba,
            });
            self.upsert_runtime_record(
                write,
                QueueWriteState::HwWriting,
                false,
                false,
                decision.disk_id,
                decision.start_lba,
            );
            committed.push(decision);
            self.usage_percent = self.usage_percent.saturating_add(8);
        }
        self.pending_data_writes.extend(deferred_data_writes);

        let flow = update_uq_flow_control(
            UqFlowControl {
                paused: self.paused,
                usage_percent: self.usage_percent,
            },
            self.usage_percent,
        );
        self.paused = flow.paused;
        self.usage_percent = flow.usage_percent;

        if let Some(epoch) = cycle_epoch {
            let should_checkpoint = !committed.is_empty()
                && !coordinator.registered_fmcs.is_empty()
                && (
                    self.entries.is_empty()
                        || coordinator.pending_updates.len() >= self.checkpoint_batch_size
                        || now_ms.saturating_sub(self.last_checkpoint_at) >= self.checkpoint_timeout_ms
                );
            if should_checkpoint {
                coordinator.finalize_epoch(epoch, scheduler, now_ms)?;
                self.last_checkpoint_at = now_ms;
                self.usage_percent = self.usage_percent.saturating_sub(16);
                let flow = update_uq_flow_control(
                    UqFlowControl {
                        paused: self.paused,
                        usage_percent: self.usage_percent,
                    },
                    self.usage_percent,
                );
                self.paused = flow.paused;
                self.usage_percent = flow.usage_percent;
            }
        }

        Ok(committed)
    }
}

pub fn stage_n_redundancy_candidate(
    file_ex: &mut FileExState,
    pending_hw_id: u64,
    pending_chunk_id: u64,
) -> FileExTransitionReport {
    file_ex.folder_status = FolderStatus::Pending;
    file_ex.pending_op = Some(PendingOperation {
        kind: PendingOperationKind::NRedundancyUpdate,
        source_file_id: None,
        target_file_id: file_ex.n_state.committed_hw_id,
        base_epoch: Some(file_ex.j_state.current_epoch),
        base_chunk_id: Some(file_ex.j_state.current_chunk_id),
    });
    file_ex.n_state.pending_hw_id = Some(pending_hw_id);
    file_ex.n_state.pending_chunk_id = Some(pending_chunk_id);
    FileExTransitionReport {
        became_pending: true,
        committed: false,
        rejected: false,
        freed_pending_chunk: None,
    }
}

pub fn stage_j_generation_candidate(
    file_ex: &mut FileExState,
    pending_epoch: u64,
    pending_chunk_id: u64,
) -> FileExTransitionReport {
    file_ex.folder_status = FolderStatus::Pending;
    file_ex.pending_op = Some(PendingOperation {
        kind: PendingOperationKind::AppendOnly,
        source_file_id: None,
        target_file_id: file_ex.n_state.committed_hw_id,
        base_epoch: Some(file_ex.j_state.current_epoch),
        base_chunk_id: Some(file_ex.j_state.current_chunk_id),
    });
    file_ex.j_state.pending_epoch = Some(pending_epoch);
    file_ex.j_state.pending_chunk_id = Some(pending_chunk_id);
    file_ex.j_state.pending_base_epoch = None;
    file_ex.j_state.pending_base_chunk_id = None;
    FileExTransitionReport {
        became_pending: true,
        committed: false,
        rejected: false,
        freed_pending_chunk: None,
    }
}

pub fn commit_file_ex_pending(file_ex: &mut FileExState) -> FileExTransitionReport {
    if let (Some(hw_id), Some(chunk_id)) = (file_ex.n_state.pending_hw_id, file_ex.n_state.pending_chunk_id) {
        file_ex.n_state.committed_hw_id = hw_id;
        file_ex.n_state.committed_chunk_id = chunk_id;
    }
    file_ex.n_state.pending_hw_id = None;
    file_ex.n_state.pending_chunk_id = None;

    if let (Some(epoch), Some(chunk_id)) = (file_ex.j_state.pending_epoch, file_ex.j_state.pending_chunk_id) {
        file_ex.j_state.current_epoch = epoch;
        file_ex.j_state.current_chunk_id = chunk_id;
    }
    file_ex.j_state.pending_epoch = None;
    file_ex.j_state.pending_chunk_id = None;
    file_ex.j_state.pending_base_epoch = None;
    file_ex.j_state.pending_base_chunk_id = None;
    file_ex.pending_op = None;
    file_ex.folder_status = FolderStatus::Stable;
    FileExTransitionReport {
        became_pending: false,
        committed: true,
        rejected: false,
        freed_pending_chunk: None,
    }
}

pub fn reject_file_ex_pending(file_ex: &mut FileExState) -> FileExTransitionReport {
    let freed_pending_chunk = file_ex.j_state.pending_chunk_id;
    file_ex.n_state.pending_hw_id = None;
    file_ex.n_state.pending_chunk_id = None;
    file_ex.j_state.pending_epoch = None;
    file_ex.j_state.pending_chunk_id = None;
    file_ex.j_state.pending_base_epoch = None;
    file_ex.j_state.pending_base_chunk_id = None;
    file_ex.pending_op = None;
    file_ex.folder_status = FolderStatus::Aborted;
    FileExTransitionReport {
        became_pending: false,
        committed: false,
        rejected: true,
        freed_pending_chunk,
    }
}

pub fn read_existing_then_overlay(
    existing_committed_image: Option<&[u8]>,
    range: AppendWriteRange,
    payload: &[u8],
) -> Result<Vec<u8>, AppendOnlyError> {
    let start = range.offset as usize;
    let end = start
        .checked_add(payload.len())
        .ok_or(AppendOnlyError::RangeOverflow)?;
    let mut full_image = existing_committed_image
        .map(|bytes| bytes.to_vec())
        .unwrap_or_default();
    if full_image.len() < end {
        full_image.resize(end, 0);
    }
    full_image[start..end].copy_from_slice(payload);
    Ok(full_image)
}

pub fn stage_append_only_generation(
    file_ex: &mut FileExState,
    request: AppendOnlyWriteRequest,
    existing_committed_image: Option<&[u8]>,
    pending_epoch: u64,
    pending_chunk_id: u64,
) -> Result<AppendOnlyStageResult, AppendOnlyError> {
    if file_ex.j_state.current_epoch != request.base.epoch
        || file_ex.j_state.current_chunk_id != request.base.chunk_id
    {
        return Err(AppendOnlyError::BaseGenerationMismatch);
    }
    let full_image = read_existing_then_overlay(
        existing_committed_image,
        request.range,
        &request.payload,
    )?;
    stage_j_generation_candidate(file_ex, pending_epoch, pending_chunk_id);
    file_ex.j_state.pending_base_epoch = Some(request.base.epoch);
    file_ex.j_state.pending_base_chunk_id = Some(request.base.chunk_id);
    Ok(AppendOnlyStageResult { request, full_image })
}

pub fn commit_append_only_generation(
    file_ex: &mut FileExState,
) -> Result<FileExTransitionReport, AppendOnlyError> {
    if let (Some(base_epoch), Some(base_chunk)) =
        (file_ex.j_state.pending_base_epoch, file_ex.j_state.pending_base_chunk_id)
    {
        if file_ex.j_state.current_epoch != base_epoch || file_ex.j_state.current_chunk_id != base_chunk {
            let _ = reject_file_ex_pending(file_ex);
            return Err(AppendOnlyError::BaseGenerationMismatch);
        }
    }
    Ok(commit_file_ex_pending(file_ex))
}

pub fn stage_pending_operation(
    file_ex: &mut FileExState,
    operation: PendingOperation,
) {
    file_ex.folder_status = FolderStatus::Pending;
    file_ex.pending_op = Some(operation);
    match operation.kind {
        PendingOperationKind::Remove => {}
        PendingOperationKind::CreateFromSource | PendingOperationKind::MoveTarget => {
            file_ex.j_state.pending_base_epoch = operation.base_epoch;
            file_ex.j_state.pending_base_chunk_id = operation.base_chunk_id;
        }
        PendingOperationKind::MoveSource => {}
        PendingOperationKind::AppendOnly => {
            file_ex.j_state.pending_base_epoch = operation.base_epoch;
            file_ex.j_state.pending_base_chunk_id = operation.base_chunk_id;
        }
        PendingOperationKind::NRedundancyUpdate => {}
    }
}

pub fn commit_pending_operation(
    file_ex: &mut FileExState,
    operation: PendingOperation,
) -> Result<FileExTransitionReport, PendingOperationError> {
    match operation.kind {
        PendingOperationKind::Remove | PendingOperationKind::MoveSource => {
            file_ex.n_state.committed_hw_id = 0;
            file_ex.n_state.committed_chunk_id = 0;
            file_ex.n_state.pending_hw_id = None;
            file_ex.n_state.pending_chunk_id = None;
            file_ex.j_state.current_epoch = 0;
            file_ex.j_state.current_chunk_id = 0;
            file_ex.j_state.pending_epoch = None;
            file_ex.j_state.pending_chunk_id = None;
            file_ex.j_state.pending_base_epoch = None;
            file_ex.j_state.pending_base_chunk_id = None;
            file_ex.folder_status = FolderStatus::Stable;
            Ok(FileExTransitionReport {
                became_pending: false,
                committed: true,
                rejected: false,
                freed_pending_chunk: None,
            })
        }
        PendingOperationKind::CreateFromSource | PendingOperationKind::MoveTarget => {
            if let (Some(base_epoch), Some(base_chunk)) = (operation.base_epoch, operation.base_chunk_id) {
                if file_ex.j_state.current_epoch != base_epoch || file_ex.j_state.current_chunk_id != base_chunk {
                    let _ = reject_file_ex_pending(file_ex);
                    return Err(PendingOperationError::BaseGenerationMismatch);
                }
            }
            Ok(commit_file_ex_pending(file_ex))
        }
        PendingOperationKind::AppendOnly => {
            commit_append_only_generation(file_ex).map_err(|_| PendingOperationError::BaseGenerationMismatch)
        }
        PendingOperationKind::NRedundancyUpdate => Ok(commit_file_ex_pending(file_ex)),
    }
}

pub fn reject_pending_operation(file_ex: &mut FileExState) -> FileExTransitionReport {
    reject_file_ex_pending(file_ex)
}

pub fn reject_pending_operation_with_reclaim(
    file_ex: &mut FileExState,
    reclaim: &mut ReclaimState,
    current_epoch: u64,
) -> FileExTransitionReport {
    let report = reject_file_ex_pending(file_ex);
    if let Some(chunk_id) = report.freed_pending_chunk {
        enqueue_reclaim_pending_chunk(reclaim, chunk_id, current_epoch);
    }
    report
}

pub fn commit_pending_operation_with_reclaim(
    file_ex: &mut FileExState,
    operation: PendingOperation,
    reclaim: &mut ReclaimState,
    current_epoch: u64,
) -> Result<FileExTransitionReport, PendingOperationError> {
    let old_current_chunk = file_ex.j_state.current_chunk_id;
    let report = commit_pending_operation(file_ex, operation)?;
    if matches!(operation.kind, PendingOperationKind::Remove | PendingOperationKind::MoveSource)
        && old_current_chunk != 0
    {
        enqueue_reclaim_pending_chunk(reclaim, old_current_chunk, current_epoch);
    }
    Ok(report)
}

pub fn enqueue_reclaim_pending_chunk(
    reclaim: &mut ReclaimState,
    chunk_id: u64,
    current_epoch: u64,
) {
    reclaim.reclaim_pending_list.push(ReclaimPendingEntry {
        chunk_id,
        queued_at_epoch: current_epoch,
        reclaim_after_epoch: current_epoch.saturating_add(2),
    });
}

pub fn drain_reclaim_pending_to_free_list(
    reclaim: &mut ReclaimState,
    safe_epoch: u64,
) -> usize {
    let mut moved = 0usize;
    let mut remaining = alloc::vec::Vec::new();
    for entry in reclaim.reclaim_pending_list.iter().copied() {
        if safe_epoch >= entry.reclaim_after_epoch {
            reclaim.free_list.push(entry.chunk_id);
            moved += 1;
        } else {
            remaining.push(entry);
        }
    }
    reclaim.reclaim_pending_list = remaining;
    moved
}

pub fn drain_reclaim_pending_to_free_list_reader_safe(
    reclaim: &mut ReclaimState,
    readers: &ReaderTrackingState,
    safe_epoch: u64,
) -> usize {
    drain_reclaim_pending_to_free_list_reader_safe_with_policy(
        reclaim,
        readers,
        safe_epoch,
        default_reader_reclaim_policy(),
    )
}

pub fn drain_reclaim_pending_to_free_list_reader_safe_with_policy(
    reclaim: &mut ReclaimState,
    readers: &ReaderTrackingState,
    safe_epoch: u64,
    policy: ReaderReclaimPolicy,
) -> usize {
    let mut moved = 0usize;
    let mut remaining = alloc::vec::Vec::new();
    for entry in reclaim.reclaim_pending_list.iter().copied() {
        let reader_active = readers
            .active_readers_by_chunk
            .iter()
            .filter(|tracked| tracked.chunk_id == entry.chunk_id)
            .any(|tracked| {
                tracked.in_flight_read_count > 0
                    || tracked.last_seen_epoch
                        >= safe_epoch.saturating_sub(policy.recent_epoch_guard)
            });
        let tracked_any = readers
            .active_readers_by_chunk
            .iter()
            .any(|tracked| tracked.chunk_id == entry.chunk_id);
        let epoch_safe = if tracked_any {
            safe_epoch >= entry.queued_at_epoch.saturating_add(policy.recent_epoch_guard)
        } else {
            safe_epoch >= entry.queued_at_epoch.saturating_add(policy.fallback_epoch_guard)
                && safe_epoch >= entry.reclaim_after_epoch
        };
        if !reader_active && epoch_safe {
            reclaim.free_list.push(entry.chunk_id);
            moved += 1;
        } else {
            remaining.push(entry);
        }
    }
    reclaim.reclaim_pending_list = remaining;
    moved
}

pub fn encode_file_ex_state(file_ex: &FileExState) -> Vec<u8> {
    let payload = encode_file_ex_payload(file_ex);
    let mut out = Vec::new();
    out.extend_from_slice(&FILE_EX_META_MAGIC);
    out.extend_from_slice(&FILE_EX_META_VERSION.to_le_bytes());
    out.extend_from_slice(&(payload.len() as u32).to_le_bytes());
    let digest = sha2::Sha256::digest(&payload);
    out.extend_from_slice(&digest);
    out.extend_from_slice(&payload);
    out
}

pub fn decode_file_ex_state(bytes: &[u8]) -> Result<FileExState, TuffError> {
    if bytes.len() < 12 || bytes[..8] != FILE_EX_META_MAGIC {
        return Err(TuffError::ReservationFailed);
    }
    let version = u32::from_le_bytes(bytes[8..12].try_into().map_err(|_| TuffError::ReservationFailed)?);
    if version == 1 {
        return decode_file_ex_payload_v1(&bytes[12..]);
    }
    if version != FILE_EX_META_VERSION || bytes.len() < 48 {
        return Err(TuffError::ReservationFailed);
    }
    let payload_len =
        u32::from_le_bytes(bytes[12..16].try_into().map_err(|_| TuffError::ReservationFailed)?) as usize;
    if bytes.len() != 48 + payload_len {
        return Err(TuffError::ReservationFailed);
    }
    let expected = &bytes[16..48];
    let payload = &bytes[48..];
    let digest = sha2::Sha256::digest(payload);
    if digest.as_slice() != expected {
        return Err(TuffError::ReservationFailed);
    }
    decode_file_ex_payload_v1(payload)
}

fn encode_file_ex_payload(file_ex: &FileExState) -> Vec<u8> {
    let mut out = Vec::new();
    out.push(file_ex.folder_status as u8);
    out.extend_from_slice(&file_ex.n_state.committed_hw_id.to_le_bytes());
    out.extend_from_slice(&file_ex.n_state.committed_chunk_id.to_le_bytes());
    encode_opt_u64(&mut out, file_ex.n_state.pending_hw_id);
    encode_opt_u64(&mut out, file_ex.n_state.pending_chunk_id);
    out.extend_from_slice(&file_ex.j_state.current_epoch.to_le_bytes());
    out.extend_from_slice(&file_ex.j_state.current_chunk_id.to_le_bytes());
    encode_opt_u64(&mut out, file_ex.j_state.pending_epoch);
    encode_opt_u64(&mut out, file_ex.j_state.pending_chunk_id);
    encode_opt_u64(&mut out, file_ex.j_state.pending_base_epoch);
    encode_opt_u64(&mut out, file_ex.j_state.pending_base_chunk_id);
    match file_ex.pending_op {
        Some(op) => {
            out.push(1);
            out.push(op.kind as u8);
            encode_opt_u64(&mut out, op.source_file_id);
            out.extend_from_slice(&op.target_file_id.to_le_bytes());
            encode_opt_u64(&mut out, op.base_epoch);
            encode_opt_u64(&mut out, op.base_chunk_id);
        }
        None => out.push(0),
    }
    out
}

fn decode_file_ex_payload_v1(bytes: &[u8]) -> Result<FileExState, TuffError> {
    let mut offset = 0usize;
    let folder_status = match *bytes.get(offset).ok_or(TuffError::ReservationFailed)? {
        0 => FolderStatus::Stable,
        1 => FolderStatus::Pending,
        2 => FolderStatus::Aborted,
        _ => return Err(TuffError::ReservationFailed),
    };
    offset += 1;
    let committed_hw_id = read_u64(bytes, &mut offset)?;
    let committed_chunk_id = read_u64(bytes, &mut offset)?;
    let pending_hw_id = read_opt_u64(bytes, &mut offset)?;
    let pending_chunk_id = read_opt_u64(bytes, &mut offset)?;
    let current_epoch = read_u64(bytes, &mut offset)?;
    let current_chunk_id = read_u64(bytes, &mut offset)?;
    let pending_epoch = read_opt_u64(bytes, &mut offset)?;
    let pending_chunk_id_j = read_opt_u64(bytes, &mut offset)?;
    let pending_base_epoch = read_opt_u64(bytes, &mut offset)?;
    let pending_base_chunk_id = read_opt_u64(bytes, &mut offset)?;

    let has_pending_op = *bytes.get(offset).ok_or(TuffError::ReservationFailed)? != 0;
    offset += 1;
    let pending_op = if has_pending_op {
        let kind = match *bytes.get(offset).ok_or(TuffError::ReservationFailed)? {
            0 => PendingOperationKind::Remove,
            1 => PendingOperationKind::CreateFromSource,
            2 => PendingOperationKind::MoveSource,
            3 => PendingOperationKind::MoveTarget,
            4 => PendingOperationKind::AppendOnly,
            5 => PendingOperationKind::NRedundancyUpdate,
            _ => return Err(TuffError::ReservationFailed),
        };
        offset += 1;
        let source_file_id = read_opt_u64(bytes, &mut offset)?;
        let target_file_id = read_u64(bytes, &mut offset)?;
        let base_epoch = read_opt_u64(bytes, &mut offset)?;
        let base_chunk_id = read_opt_u64(bytes, &mut offset)?;
        Some(PendingOperation {
            kind,
            source_file_id,
            target_file_id,
            base_epoch,
            base_chunk_id,
        })
    } else {
        None
    };

    if offset != bytes.len() {
        return Err(TuffError::ReservationFailed);
    }

    Ok(FileExState {
        folder_status,
        n_state: crate::fs_structs::NRedundancyState {
            committed_hw_id,
            committed_chunk_id,
            pending_hw_id,
            pending_chunk_id,
        },
        j_state: crate::fs_structs::JGenerationState {
            current_epoch,
            current_chunk_id,
            pending_epoch,
            pending_chunk_id: pending_chunk_id_j,
            pending_base_epoch,
            pending_base_chunk_id,
        },
        pending_op,
    })
}

pub fn encode_file_ex_metadata_region(
    file_id: u64,
    commit_epoch: u64,
    file_ex: &FileExState,
) -> Result<[u8; 4096], TuffError> {
    let payload = encode_file_ex_state(file_ex);
    if payload.len() > FILE_EX_METADATA_PAYLOAD_MAX {
        return Err(TuffError::ReservationFailed);
    }

    let mut out = [0u8; 4096];
    out[..8].copy_from_slice(&FILE_EX_METADATA_REGION_MAGIC);
    out[8..12].copy_from_slice(&FILE_EX_METADATA_REGION_VERSION.to_le_bytes());
    out[12..20].copy_from_slice(&file_id.to_le_bytes());
    out[20..28].copy_from_slice(&commit_epoch.to_le_bytes());
    out[28..32].copy_from_slice(&(payload.len() as u32).to_le_bytes());
    let payload_checksum = compute_block_checksum_slice(&payload);
    out[32..64].copy_from_slice(&payload_checksum);
    out[64..64 + payload.len()].copy_from_slice(&payload);
    Ok(out)
}

pub fn decode_file_ex_metadata_region(
    bytes: &[u8; 4096],
) -> Result<(u64, u64, FileExState), TuffError> {
    if bytes[..8] != FILE_EX_METADATA_REGION_MAGIC {
        return Err(TuffError::ReservationFailed);
    }
    let version = u32::from_le_bytes(bytes[8..12].try_into().map_err(|_| TuffError::ReservationFailed)?);
    if version != FILE_EX_METADATA_REGION_VERSION {
        return Err(TuffError::ReservationFailed);
    }
    let file_id = u64::from_le_bytes(bytes[12..20].try_into().map_err(|_| TuffError::ReservationFailed)?);
    let commit_epoch = u64::from_le_bytes(bytes[20..28].try_into().map_err(|_| TuffError::ReservationFailed)?);
    let payload_len = u32::from_le_bytes(bytes[28..32].try_into().map_err(|_| TuffError::ReservationFailed)?) as usize;
    if payload_len == 0 || payload_len > FILE_EX_METADATA_PAYLOAD_MAX {
        return Err(TuffError::ReservationFailed);
    }
    let expected_checksum: [u8; 32] = bytes[32..64].try_into().map_err(|_| TuffError::ReservationFailed)?;
    let payload = &bytes[64..64 + payload_len];
    if compute_block_checksum_slice(payload) != expected_checksum {
        return Err(TuffError::ReservationFailed);
    }
    let file_ex = decode_file_ex_state(payload)?;
    Ok((file_id, commit_epoch, file_ex))
}

fn encode_opt_u64(out: &mut Vec<u8>, value: Option<u64>) {
    match value {
        Some(v) => {
            out.push(1);
            out.extend_from_slice(&v.to_le_bytes());
        }
        None => {
            out.push(0);
            out.extend_from_slice(&0u64.to_le_bytes());
        }
    }
}

fn compute_block_checksum_slice(bytes: &[u8]) -> [u8; 32] {
    let mut hasher = Sha256::new();
    hasher.update(bytes);
    hasher.finalize().into()
}

pub fn init_alert_shared_memory_page() -> AlertSharedMemoryPage {
    AlertSharedMemoryPage {
        write_index: 0,
        next_sequence: 1,
        dropped_events: 0,
        events: [EMPTY_ALERT_EVENT; ALERT_IPC_RING_CAPACITY],
    }
}

pub fn init_alert_consumer_cursor() -> AlertConsumerCursor {
    AlertConsumerCursor {
        last_sequence: 0,
        overflowed: false,
        consumed_events: 0,
    }
}

pub fn push_alert_event(page: &mut AlertSharedMemoryPage, mut event: AlertEvent) {
    event.sequence = page.next_sequence;
    page.next_sequence = page.next_sequence.saturating_add(1);
    let slot = page.write_index % ALERT_IPC_RING_CAPACITY;
    if page.events[slot].sequence != 0 {
        page.dropped_events = page.dropped_events.saturating_add(1);
    }
    page.events[slot] = event;
    page.write_index = (page.write_index + 1) % ALERT_IPC_RING_CAPACITY;
}

pub fn consume_alert_events(
    page: &AlertSharedMemoryPage,
    cursor: &mut AlertConsumerCursor,
    out: &mut [AlertEvent; ALERT_IPC_RING_CAPACITY],
) -> usize {
    let newest_sequence = page.next_sequence.saturating_sub(1);
    if newest_sequence <= cursor.last_sequence {
        cursor.overflowed = false;
        return 0;
    }

    let capacity = ALERT_IPC_RING_CAPACITY as u64;
    let available = newest_sequence.saturating_sub(cursor.last_sequence);
    let first_sequence = if available > capacity {
        cursor.overflowed = true;
        newest_sequence.saturating_sub(capacity).saturating_add(1)
    } else {
        cursor.overflowed = false;
        cursor.last_sequence.saturating_add(1)
    };

    let mut count = 0usize;
    let mut sequence = first_sequence;
    while sequence <= newest_sequence && count < out.len() {
        let slot = ((sequence - 1) % ALERT_IPC_RING_CAPACITY as u64) as usize;
        let event = page.events[slot];
        if event.sequence == sequence {
            out[count] = event;
            count += 1;
        }
        sequence = sequence.saturating_add(1);
    }
    if count > 0 {
        cursor.last_sequence = out[count - 1].sequence;
        cursor.consumed_events = cursor.consumed_events.saturating_add(count as u64);
    }
    count
}

pub fn merge_target_meta_chunk_truth(
    current: Option<u64>,
    candidate: u64,
) -> Result<Option<u64>, RecoverTargetSelectionError> {
    match current {
        Some(existing) if existing != candidate => Err(RecoverTargetSelectionError::AmbiguousTargetMetaId),
        Some(existing) => Ok(Some(existing)),
        None => Ok(Some(candidate)),
    }
}

pub fn merge_target_meta_chunk_truths(
    candidates: &[u64],
) -> Result<Option<u64>, RecoverTargetSelectionError> {
    let mut current = None;
    for candidate in candidates.iter().copied() {
        current = merge_target_meta_chunk_truth(current, candidate)?;
    }
    Ok(current)
}

pub fn select_alert_consumer_mode(external_shared_memory: bool) -> AlertConsumerMode {
    if external_shared_memory {
        AlertConsumerMode::ExternalSharedMemory
    } else {
        AlertConsumerMode::InRuntimePolling
    }
}

pub fn classify_cross_hw_transfer(source_hw_id: u64, target_hw_id: u64) -> CrossHwTransferPlan {
    let class = if source_hw_id == target_hw_id {
        CrossHwTransferClass::SameHw
    } else {
        CrossHwTransferClass::CrossHw
    };
    let policy = match class {
        CrossHwTransferClass::SameHw => CrossHwTransferPolicy::PreserveLocalClone,
        CrossHwTransferClass::CrossHw => CrossHwTransferPolicy::RequireFullReplicaCopy,
    };
    CrossHwTransferPlan {
        class,
        policy,
        source_hw_id,
        target_hw_id,
    }
}

pub fn classify_pending_operation_transfer(
    source: &FileExState,
    target: &FileExState,
    operation: PendingOperation,
) -> Option<CrossHwTransferPlan> {
    match operation.kind {
        PendingOperationKind::CreateFromSource | PendingOperationKind::MoveTarget => Some(
            classify_cross_hw_transfer(
                source.n_state.committed_hw_id,
                target
                    .n_state
                    .pending_hw_id
                    .unwrap_or(target.n_state.committed_hw_id),
            ),
        ),
        _ => None,
    }
}

fn read_opt_u64(data: &[u8], offset: &mut usize) -> Result<Option<u64>, TuffError> {
    let has_value = *data.get(*offset).ok_or(TuffError::ReservationFailed)? != 0;
    *offset += 1;
    let raw = read_u64(data, offset)?;
    Ok(if has_value { Some(raw) } else { None })
}

pub fn commit_move_pair(
    source: &mut FileExState,
    target: &mut FileExState,
    source_op: PendingOperation,
    target_op: PendingOperation,
) -> Result<(FileExTransitionReport, FileExTransitionReport), PendingOperationError> {
    let target_report = commit_pending_operation(target, target_op)?;
    let source_report = commit_pending_operation(source, source_op)?;
    Ok((source_report, target_report))
}

pub fn metadata_critical_placement_for_file(
    chunk_kind: MetadataCriticalChunkKind,
    file_id: u64,
) -> MetadataCriticalPlacement {
    metadata_critical_placement_for_file_with_policy(
        chunk_kind,
        file_id,
        default_metadata_critical_placement_policy(),
    )
}

pub fn metadata_critical_placement_for_file_with_policy(
    chunk_kind: MetadataCriticalChunkKind,
    file_id: u64,
    policy: MetadataCriticalPlacementPolicy,
) -> MetadataCriticalPlacement {
    let zone_base = match chunk_kind {
        MetadataCriticalChunkKind::InitialChunk => policy.initial_zone_base_lba,
        MetadataCriticalChunkKind::IndexChunk => policy.index_zone_base_lba,
    };
    MetadataCriticalPlacement {
        base_lba: zone_base
            .saturating_add((file_id & policy.file_slot_mask).saturating_mul(policy.file_slot_stride_lbas)),
        replica_stride_lbas: policy.replica_stride_lbas,
    }
}

pub fn expand_metadata_critical_same_hw_3n_plan(placement: MetadataCriticalPlacement) -> [u64; 3] {
    [
        placement.base_lba,
        placement.base_lba.saturating_add(placement.replica_stride_lbas),
        placement
            .base_lba
            .saturating_add(placement.replica_stride_lbas.saturating_mul(2)),
    ]
}

pub fn build_metadata_critical_replica_set(
    request: &MetadataCriticalWriteRequest,
) -> MetadataCriticalReplicaSet {
    let replica_lbas = expand_metadata_critical_same_hw_3n_plan(request.placement);
    let checksum = compute_block_checksum(&request.payload);
    MetadataCriticalReplicaSet {
        chunk_kind: request.chunk_kind,
        disk_id: request.disk_id,
        file_id: request.file_id,
        epoch: request.epoch,
        replica_lbas,
        replica_checksums: [checksum; 3],
    }
}

pub fn verify_metadata_critical_replica_buffers(
    set: &MetadataCriticalReplicaSet,
    buffers: &[[u8; 4096]; 3],
) -> Result<(), MetadataCriticalAlertReason> {
    for (index, buffer) in buffers.iter().enumerate() {
        if compute_block_checksum(buffer) != set.replica_checksums[index] {
            return Err(MetadataCriticalAlertReason::ReplicaMismatch);
        }
    }
    Ok(())
}

pub fn verify_metadata_critical_replica_set_periodic(
    set: &MetadataCriticalReplicaSet,
    now_ms: u64,
    last_verified_ms: &mut u64,
    buffers: Option<[[u8; 4096]; 3]>,
) -> Metadata3nVerificationResult {
    if now_ms.saturating_sub(*last_verified_ms) < METADATA_3N_VERIFY_INTERVAL_MS {
        return Metadata3nVerificationResult {
            alert: None,
            checked: false,
        };
    }
    *last_verified_ms = now_ms;
    let Some(buffers) = buffers else {
        return Metadata3nVerificationResult {
            alert: Some(MetadataCriticalAlert {
                chunk_kind: set.chunk_kind,
                disk_id: set.disk_id,
                epoch: set.epoch,
                reason: MetadataCriticalAlertReason::MissingReplica,
            }),
            checked: true,
        };
    };
    let alert = verify_metadata_critical_replica_buffers(set, &buffers)
        .err()
        .map(|reason| MetadataCriticalAlert {
            chunk_kind: set.chunk_kind,
            disk_id: set.disk_id,
            epoch: set.epoch,
            reason,
        });
    Metadata3nVerificationResult { alert, checked: true }
}

pub fn stop_hw_write_queue_for_metadata_alert(
    scheduler: &mut HwScheduler,
    alert: MetadataCriticalAlert,
) {
    if let Some(disk) = scheduler.disks.iter_mut().find(|disk| disk.disk_id == alert.disk_id) {
        disk.pending_write = None;
        disk.state = HwQueueState::Faulted;
    }
}

pub fn evaluate_rejected_policy(record: &QueuePersistedRecord) -> Option<QueueRejectReason> {
    if !record.complete_record && record.state != QueueWriteState::UqIngesting {
        return Some(QueueRejectReason::IncompleteNonIngesting);
    }
    if matches!(record.state, QueueWriteState::HwWriting | QueueWriteState::CommitPending)
        && record.writeback_start_lba == 0
    {
        return Some(QueueRejectReason::MissingWritebackLocation);
    }
    if let Some(target) = record.pending.target_disk {
        if record.writeback_disk_id != 0 && record.writeback_disk_id != target {
            return Some(QueueRejectReason::TargetDiskMismatch);
        }
    }
    None
}

pub fn compact_queue_records(
    records: &mut Vec<QueuePersistedRecord>,
    keep_recent_epochs: usize,
) -> QueueCompactionReport {
    compact_queue_records_with_policy(
        records,
        MqRetentionPolicy {
            keep_recent_epochs,
            retain_rejected_epochs: keep_recent_epochs,
            retain_verified_commit_epochs: 1,
        },
    )
}

pub fn compact_queue_records_with_policy(
    records: &mut Vec<QueuePersistedRecord>,
    policy: MqRetentionPolicy,
) -> QueueCompactionReport {
    if policy.keep_recent_epochs == 0 {
        return QueueCompactionReport {
            removed_terminal_records: 0,
            deduplicated_records: 0,
        };
    }
    let mut epochs = Vec::new();
    for record in records.iter() {
        if !epochs.contains(&record.pending.epoch) {
            epochs.push(record.pending.epoch);
        }
    }
    epochs.sort_unstable();
    let threshold_index = epochs.len().saturating_sub(policy.keep_recent_epochs);
    let rejected_threshold_index = epochs.len().saturating_sub(policy.retain_rejected_epochs);
    let verified_threshold_index = epochs
        .len()
        .saturating_sub(policy.retain_verified_commit_epochs);
    let min_epoch_to_keep = epochs.get(threshold_index).copied().unwrap_or(0);
    let min_rejected_epoch = epochs.get(rejected_threshold_index).copied().unwrap_or(0);
    let min_verified_epoch = epochs.get(verified_threshold_index).copied().unwrap_or(0);

    let before_gc = records.len();
    records.retain(|record| {
        if record.pending.epoch >= min_epoch_to_keep {
            return true;
        }
        if record.state == QueueWriteState::Rejected {
            return record.pending.epoch >= min_rejected_epoch;
        }
        if record.state == QueueWriteState::CommitPending
            && record.verified_readback
            && record.pointer_validated
        {
            return record.pending.epoch >= min_verified_epoch;
        }
        true
    });
    let removed_terminal_records = before_gc.saturating_sub(records.len());

    let mut deduped = Vec::new();
    for record in records.iter().copied() {
        if let Some(existing) = deduped.iter_mut().find(|existing: &&mut QueuePersistedRecord| {
            existing.pending.epoch == record.pending.epoch
                && existing.pending.descriptor.chunk_id == record.pending.descriptor.chunk_id
                && existing.pending.target_disk == record.pending.target_disk
        }) {
            *existing = record;
        } else {
            deduped.push(record);
        }
    }
    let deduplicated_records = records.len().saturating_sub(deduped.len());
    *records = deduped;

    QueueCompactionReport {
        removed_terminal_records,
        deduplicated_records,
    }
}

impl QueueBackendPolicy {
    pub fn with_preference(
        prefer_file_backed: bool,
        memory_bytes: Option<usize>,
        ssd_available: bool,
    ) -> Self {
        let requested_mem = memory_bytes.unwrap_or(DEFAULT_MEMORY_BACKED_UQ_BYTES);
        let memory_bytes = core::cmp::max(4096, requested_mem);
        let kind = if prefer_file_backed && ssd_available {
            QueueBackendKind::FileBacked
        } else {
            QueueBackendKind::MemoryBacked
        };
        Self { kind, memory_bytes }
    }
}

impl Default for QueueBackendPolicy {
    fn default() -> Self {
        Self {
            kind: QueueBackendKind::MemoryBacked,
            memory_bytes: DEFAULT_MEMORY_BACKED_UQ_BYTES,
        }
    }
}

pub fn encode_queue_records(records: &[QueuePersistedRecord]) -> Vec<u8> {
    let mut out = Vec::new();
    out.extend_from_slice(&TUFF_MQ_MAGIC);
    out.extend_from_slice(&TUFF_MQ_VERSION.to_le_bytes());
    out.extend_from_slice(&(records.len() as u32).to_le_bytes());
    for record in records {
        out.push(record.state as u8);
        out.push(record.complete_record as u8);
        out.push(record.verified_readback as u8);
        out.push(record.pointer_validated as u8);
        out.extend_from_slice(&record.writeback_disk_id.to_le_bytes());
        out.extend_from_slice(&record.writeback_start_lba.to_le_bytes());
        out.push(record.reject_reason.map(|reason| reason.as_u8()).unwrap_or(0));

        out.extend_from_slice(&record.pending.epoch.to_le_bytes());
        out.extend_from_slice(&record.pending.file_id.to_le_bytes());
        out.extend_from_slice(&(record.pending.entry_index as u64).to_le_bytes());
        out.extend_from_slice(&record.pending.old_lba.to_le_bytes());
        out.push(record.pending.priority as u8);
        out.extend_from_slice(&record.pending.sectors.to_le_bytes());
        match record.pending.target_disk {
            Some(disk_id) => {
                out.push(1);
                out.extend_from_slice(&disk_id.to_le_bytes());
            }
            None => {
                out.push(0);
                out.extend_from_slice(&0u64.to_le_bytes());
            }
        }
        for disk in record.pending.exclude_disks {
            out.extend_from_slice(&disk.to_le_bytes());
        }
        out.push(record.pending.exclude_len as u8);
        out.extend_from_slice(&record.pending.chunk);
        out.extend_from_slice(&record.pending.descriptor.chunk_id);
        out.extend_from_slice(&record.pending.descriptor.epoch.to_le_bytes());
        out.extend_from_slice(&record.pending.descriptor.info.algorithm_chain);
        out.extend_from_slice(&record.pending.descriptor.info.structural_seed);
        out.extend_from_slice(&record.pending.descriptor.info.integrity_tag);
        out.extend_from_slice(&record.pending.tk);
        out.extend_from_slice(&record.pending.pk);
    }
    out
}

pub fn decode_queue_records(data: &[u8]) -> Result<Vec<QueuePersistedRecord>, TuffError> {
    if data.len() < 16 {
        return Err(TuffError::ReservationFailed);
    }
    if data[..8] != TUFF_MQ_MAGIC {
        return Err(TuffError::ReservationFailed);
    }
    let version = u32::from_le_bytes(data[8..12].try_into().map_err(|_| TuffError::ReservationFailed)?);
    if version != 1 && version != TUFF_MQ_VERSION {
        return Err(TuffError::ReservationFailed);
    }
    let count = u32::from_le_bytes(data[12..16].try_into().map_err(|_| TuffError::ReservationFailed)?) as usize;
    let mut offset = 16usize;
    let mut out = Vec::with_capacity(count);
    for _ in 0..count {
        let state = match *data.get(offset).ok_or(TuffError::ReservationFailed)? {
            0 => QueueWriteState::UqIngesting,
            1 => QueueWriteState::UqStored,
            2 => QueueWriteState::HwWriting,
            3 => QueueWriteState::CommitPending,
            4 => QueueWriteState::Rejected,
            _ => return Err(TuffError::ReservationFailed),
        };
        offset += 1;
        let complete_record = *data.get(offset).ok_or(TuffError::ReservationFailed)? != 0;
        offset += 1;
        let verified_readback = *data.get(offset).ok_or(TuffError::ReservationFailed)? != 0;
        offset += 1;
        let pointer_validated = *data.get(offset).ok_or(TuffError::ReservationFailed)? != 0;
        offset += 1;
        let writeback_disk_id = read_u64(data, &mut offset)?;
        let writeback_start_lba = read_u64(data, &mut offset)?;
        let reject_reason = if version >= 2 {
            let reason_raw = *data.get(offset).ok_or(TuffError::ReservationFailed)?;
            offset += 1;
            if reason_raw == 0 {
                None
            } else {
                Some(QueueRejectReason::from_u8(reason_raw).ok_or(TuffError::ReservationFailed)?)
            }
        } else {
            None
        };

        let epoch = read_u64(data, &mut offset)?;
        let (file_id, entry_index, old_lba) = if version >= TUFF_MQ_VERSION {
            (
                read_u64(data, &mut offset)?,
                read_u64(data, &mut offset)? as usize,
                read_u64(data, &mut offset)?,
            )
        } else {
            (0, 0, 0)
        };
        let priority = match *data.get(offset).ok_or(TuffError::ReservationFailed)? {
            0 => IoPriority::CriticalRead,
            1 => IoPriority::HighMetadata,
            2 => IoPriority::NormalData,
            3 => IoPriority::LowRestore,
            4 => IoPriority::BackgroundDefrag,
            5 => IoPriority::Maintenance,
            _ => return Err(TuffError::ReservationFailed),
        };
        offset += 1;
        let sectors = read_u64(data, &mut offset)?;
        let has_target = *data.get(offset).ok_or(TuffError::ReservationFailed)? != 0;
        offset += 1;
        let target_disk_raw = read_u64(data, &mut offset)?;
        let target_disk = if has_target { Some(target_disk_raw) } else { None };

        let mut exclude_disks = [0u64; 3];
        for disk in exclude_disks.iter_mut() {
            *disk = read_u64(data, &mut offset)?;
        }
        let exclude_len = *data.get(offset).ok_or(TuffError::ReservationFailed)? as usize;
        offset += 1;
        if exclude_len > 3 {
            return Err(TuffError::ReservationFailed);
        }

        let mut chunk = [0u8; CSE_BLOCK_SIZE];
        copy_exact(data, &mut offset, &mut chunk)?;
        let mut chunk_id = [0u8; 16];
        copy_exact(data, &mut offset, &mut chunk_id)?;
        let descriptor_epoch = read_u64(data, &mut offset)?;
        let mut algorithm_chain = [0u8; 8];
        copy_exact(data, &mut offset, &mut algorithm_chain)?;
        let mut structural_seed = [0u8; 8];
        copy_exact(data, &mut offset, &mut structural_seed)?;
        let mut integrity_tag = [0u8; 16];
        copy_exact(data, &mut offset, &mut integrity_tag)?;
        let mut tk = [0u8; 32];
        copy_exact(data, &mut offset, &mut tk)?;
        let mut pk = [0u8; 32];
        copy_exact(data, &mut offset, &mut pk)?;

        out.push(QueuePersistedRecord {
            state,
            complete_record,
            verified_readback,
            pointer_validated,
            writeback_disk_id,
            writeback_start_lba,
            reject_reason,
            pending: PendingDataWrite {
                file_id,
                entry_index,
                old_lba,
                epoch,
                priority,
                sectors,
                target_disk,
                exclude_disks,
                exclude_len,
                chunk,
                descriptor: CseDescriptor {
                    chunk_id,
                    epoch: descriptor_epoch,
                    info: crate::cse::types::CseInfo::with_integrity_tag(
                        algorithm_chain,
                        structural_seed,
                        integrity_tag,
                    ),
                },
                tk,
                pk,
            },
        });
    }
    if offset != data.len() {
        return Err(TuffError::ReservationFailed);
    }
    Ok(out)
}

fn read_u64(data: &[u8], offset: &mut usize) -> Result<u64, TuffError> {
    let end = offset.saturating_add(8);
    let bytes: [u8; 8] = data
        .get(*offset..end)
        .ok_or(TuffError::ReservationFailed)?
        .try_into()
        .map_err(|_| TuffError::ReservationFailed)?;
    *offset = end;
    Ok(u64::from_le_bytes(bytes))
}

fn copy_exact<const N: usize>(
    data: &[u8],
    offset: &mut usize,
    out: &mut [u8; N],
) -> Result<(), TuffError> {
    let end = offset.saturating_add(N);
    let src = data.get(*offset..end).ok_or(TuffError::ReservationFailed)?;
    out.copy_from_slice(src);
    *offset = end;
    Ok(())
}

pub fn submit_runtime_data_write(
    runtime: &mut UniqueQueueRuntime,
    request: RuntimeDataWriteRequest,
) {
    runtime.enqueue_data_write(PendingDataWrite {
        file_id: request.file_id,
        entry_index: request.entry_index,
        old_lba: request.old_lba,
        epoch: request.epoch,
        priority: request.priority,
        sectors: request.sectors,
        target_disk: request.target_disk,
        exclude_disks: request.exclude_disks,
        exclude_len: request.exclude_len,
        chunk: request.chunk,
        descriptor: request.descriptor,
        tk: request.tk,
        pk: request.pk,
    });
}

pub fn register_discovered_fmc(
    coordinator: &mut CommitCoordinator,
    replica: FmcDiscoveryReplica,
) {
    coordinator.register_fmc(
        replica.file_id,
        replica.disk_id,
        replica.start_lba,
        replica.buffer,
    );
}

pub fn execute_physical_writebacks(
    bt: &BootServices,
    handle_map: &[(u64, Handle)],
    coordinator: &mut CommitCoordinator,
) -> Result<Vec<CompletedWriteback>, TuffError> {
    let writebacks = coordinator.take_physical_writebacks();
    if writebacks.is_empty() {
        return Ok(Vec::new());
    }

    let mut completed = Vec::new();
    for PhysicalWriteback {
        disk_id,
        start_lba,
        priority,
        buffer,
        expected_checksum,
    } in writebacks
    {
        let Some((_, handle)) = handle_map.iter().find(|(candidate_id, _)| *candidate_id == disk_id) else {
            return Err(TuffError::DiskNotFound);
        };
        let Ok(mut block_io) = bt.open_protocol_exclusive::<BlockIO>(*handle) else {
            return Err(TuffError::DeviceFault);
        };
        let (media_present, media_read_only, media_id) = {
            let media = block_io.media();
            (media.is_media_present(), media.is_read_only(), media.media_id())
        };
        if !media_present || media_read_only {
            return Err(TuffError::DeviceFault);
        }
        block_io
            .write_blocks(media_id, start_lba, &buffer)
            .map_err(|_| TuffError::DeviceFault)?;
        let mut verify_buffer = [0u8; 4096];
        block_io
            .read_blocks(media_id, start_lba, &mut verify_buffer)
            .map_err(|_| TuffError::DeviceFault)?;
        revalidate_reloaded_block(&verify_buffer, &expected_checksum)?;
        completed.push(CompletedWriteback {
            disk_id,
            start_lba,
            priority,
        });
    }

    Ok(completed)
}

fn revalidate_reloaded_block(
    reloaded_block: &[u8; 4096],
    expected_checksum: &[u8; 32],
) -> Result<(), TuffError> {
    if compute_block_checksum(reloaded_block) != *expected_checksum {
        return Err(TuffError::ReservationFailed);
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use alloc::vec;
    use super::{
        AppendOnlyError, AppendOnlyWriteRequest, QueueBackendKind, QueueBackendPolicy,
        QueuePersistedRecord, QueueRejectReason, RuntimeDataWriteRequest, UniqueQueueRuntime,
        build_metadata_critical_replica_set, commit_append_only_generation, commit_file_ex_pending, commit_move_pair,
        commit_pending_operation, commit_pending_operation_with_reclaim,
        compact_queue_records, compact_queue_records_with_policy, decode_queue_records, encode_queue_records,
        classify_pending_operation_transfer,
        decode_file_ex_metadata_region, encode_file_ex_metadata_region, evaluate_rejected_policy,
        expand_metadata_critical_same_hw_3n_plan, classify_cross_hw_transfer, default_metadata_critical_placement_policy,
        default_reader_reclaim_policy,
        init_alert_consumer_cursor,
        init_alert_shared_memory_page, merge_target_meta_chunk_truth, merge_target_meta_chunk_truths,
        metadata_critical_placement_for_file, metadata_critical_placement_for_file_with_policy,
        metadata_critical_placement_safety_assumptions, push_alert_event, consume_alert_events,
        read_existing_then_overlay, reject_file_ex_pending, reject_pending_operation,
        revalidate_reloaded_block, stage_append_only_generation, stage_j_generation_candidate,
        stage_n_redundancy_candidate, stage_pending_operation, stop_hw_write_queue_for_metadata_alert,
        submit_runtime_data_write, verify_metadata_critical_replica_set_periodic, encode_file_ex_state,
        decode_file_ex_state, enqueue_reclaim_pending_chunk, drain_reclaim_pending_to_free_list,
        drain_reclaim_pending_to_free_list_reader_safe,
        drain_reclaim_pending_to_free_list_reader_safe_with_policy,
        reject_pending_operation_with_reclaim,
    };
    use crate::cse::types::{CseDescriptor, CseInfo};
    use crate::fs_structs::{
        ActiveChunkRead, AlertClass, AlertEvent, ALERT_IPC_RING_CAPACITY, AppendBaseGeneration,
        AppendWriteRange, CrossHwTransferClass, CrossHwTransferPolicy, FileExState, FolderStatus,
        JGenerationState, MetadataCriticalChunkKind, MetadataPlacementSafetyAssumption,
        MqRetentionPolicy, NRedundancyState, PendingOperation, PendingOperationKind,
        QueueRejectSeverity, QueueWriteState, ReaderReclaimPolicy, ReaderTrackingState, ReclaimState,
    };
    use crate::scheduler::{CommitCoordinator, HwScheduler, IoPriority};
    use crate::scheduler::compute_block_checksum;

    fn sample_pending_write() -> super::PendingDataWrite {
        super::PendingDataWrite {
            file_id: 3,
            entry_index: 0,
            old_lba: 16,
            epoch: 9,
            priority: IoPriority::NormalData,
            sectors: 1,
            target_disk: Some(0),
            exclude_disks: [0; 3],
            exclude_len: 0,
            chunk: [0x33; 4096],
            descriptor: CseDescriptor {
                chunk_id: [0x11; 16],
                epoch: 9,
                info: CseInfo::new([8, 73, 110, 143, 176, 205, 222, 247], [0x21; 8]),
            },
            tk: [0x5a; 32],
            pk: [0xa5; 32],
        }
    }

    #[test]
    fn revalidate_reloaded_block_accepts_matching_checksum() {
        let block = [0x5a; 4096];
        let checksum = compute_block_checksum(&block);
        let result = revalidate_reloaded_block(&block, &checksum);
        assert!(result.is_ok());
    }

    #[test]
    fn revalidate_reloaded_block_rejects_mismatched_checksum() {
        let mut block = [0x11; 4096];
        let checksum = compute_block_checksum(&block);
        block[0] ^= 0xff;
        let result = revalidate_reloaded_block(&block, &checksum);
        assert!(result.is_err());
    }

    #[test]
    fn runtime_data_write_reaches_encrypted_writeback() {
        let mut scheduler = HwScheduler::new(&[(0, 32_768)]);
        let mut coordinator = CommitCoordinator::new();
        let mut uq = UniqueQueueRuntime::new();

        let mut plain = [0u8; 4096];
        for (idx, byte) in plain.iter_mut().enumerate() {
            *byte = (idx & 0xff) as u8;
        }
        submit_runtime_data_write(&mut uq, RuntimeDataWriteRequest {
            file_id: 9,
            entry_index: 0,
            old_lba: 16,
            epoch: 7,
            priority: IoPriority::NormalData,
            sectors: 1,
            target_disk: None,
            exclude_disks: [0; 3],
            exclude_len: 0,
            chunk: plain,
            descriptor: CseDescriptor {
                chunk_id: [0x44; 16],
                epoch: 7,
                info: CseInfo::new([8, 73, 110, 143, 176, 205, 222, 247], [0x2d; 8]),
            },
            tk: [0x5a; 32],
            pk: [0xa5; 32],
        });

        let committed = uq.process_cycle(&mut scheduler, &mut coordinator, 100).unwrap();
        assert_eq!(committed.len(), 1);
        assert_eq!(coordinator.pending_writebacks.len(), 1);
        let wb = &coordinator.pending_writebacks[0];
        assert_ne!(wb.buffer, plain);
        assert_eq!(wb.expected_checksum, compute_block_checksum(&wb.buffer));
    }

    #[test]
    fn runtime_data_write_only_cycle_finalizes_epoch_when_pointer_update_is_present() {
        let mut scheduler = HwScheduler::new(&[(0, 65_536), (1, 65_536), (2, 65_536)]);
        let mut coordinator = CommitCoordinator::new();
        let fmc_buffer = [0u8; 4096];
        coordinator.register_fmc(9, 0, 24, fmc_buffer);
        coordinator.register_fmc(9, 1, 24, fmc_buffer);
        coordinator.register_fmc(9, 2, 24, fmc_buffer);

        let mut uq = UniqueQueueRuntime::new();
        submit_runtime_data_write(&mut uq, RuntimeDataWriteRequest {
            file_id: 9,
            entry_index: 0,
            old_lba: 0,
            epoch: 7,
            priority: IoPriority::NormalData,
            sectors: 1,
            target_disk: Some(0),
            exclude_disks: [0; 3],
            exclude_len: 0,
            chunk: [0x44; 4096],
            descriptor: CseDescriptor {
                chunk_id: [0x55; 16],
                epoch: 7,
                info: CseInfo::new([8, 73, 110, 143, 176, 205, 222, 247], [0x2d; 8]),
            },
            tk: [0x5a; 32],
            pk: [0xa5; 32],
        });

        let committed = uq.process_cycle(&mut scheduler, &mut coordinator, 100).unwrap();
        assert_eq!(committed.len(), 1);
        assert!(coordinator.pending_updates.is_empty());
        assert_eq!(
            coordinator
                .pending_writebacks
                .iter()
                .filter(|wb| wb.priority == IoPriority::HighMetadata)
                .count(),
            3
        );
    }

    #[test]
    fn resume_truncates_only_tail_incomplete_uq_ingesting() {
        let mut uq = UniqueQueueRuntime::new();
        let pending = sample_pending_write();
        uq.persisted_queue_records = vec![QueuePersistedRecord {
            state: QueueWriteState::UqIngesting,
            complete_record: false,
            verified_readback: false,
            pointer_validated: false,
            writeback_disk_id: 0,
            writeback_start_lba: 0,
            reject_reason: None,
            pending,
        }];
        let report = uq.resume_from_persisted_queue().unwrap();
        assert_eq!(report.truncated_tail_records, 1);
        assert_eq!(report.resumed_records, 0);
        assert!(uq.pending_data_writes.is_empty());
    }

    #[test]
    fn resume_rejects_non_tail_incomplete_uq_ingesting() {
        let mut uq = UniqueQueueRuntime::new();
        let pending = sample_pending_write();
        uq.persisted_queue_records = vec![
            QueuePersistedRecord {
                state: QueueWriteState::UqIngesting,
                complete_record: false,
                verified_readback: false,
                pointer_validated: false,
                writeback_disk_id: 0,
                writeback_start_lba: 0,
                reject_reason: None,
                pending,
            },
            QueuePersistedRecord {
                state: QueueWriteState::UqStored,
                complete_record: true,
                verified_readback: false,
                pointer_validated: false,
                writeback_disk_id: 0,
                writeback_start_lba: 0,
                reject_reason: None,
                pending,
            },
        ];
        assert!(uq.resume_from_persisted_queue().is_err());
    }

    #[test]
    fn resume_requeues_uq_stored() {
        let mut uq = UniqueQueueRuntime::new();
        let pending = sample_pending_write();
        uq.persisted_queue_records = vec![QueuePersistedRecord {
            state: QueueWriteState::UqStored,
            complete_record: true,
            verified_readback: false,
            pointer_validated: false,
            writeback_disk_id: 0,
            writeback_start_lba: 0,
            reject_reason: None,
            pending,
        }];
        let report = uq.resume_from_persisted_queue().unwrap();
        assert_eq!(report.resumed_records, 1);
        assert_eq!(uq.pending_data_writes.len(), 1);
    }

    #[test]
    fn resume_requeues_hw_writing_for_safe_retry() {
        let mut uq = UniqueQueueRuntime::new();
        let pending = sample_pending_write();
        uq.persisted_queue_records = vec![QueuePersistedRecord {
            state: QueueWriteState::HwWriting,
            complete_record: true,
            verified_readback: false,
            pointer_validated: false,
            writeback_disk_id: 0,
            writeback_start_lba: 128,
            reject_reason: None,
            pending,
        }];
        let report = uq.resume_from_persisted_queue().unwrap();
        assert_eq!(report.resumed_records, 1);
        assert_eq!(uq.pending_data_writes.len(), 1);
    }

    #[test]
    fn backend_policy_forces_memory_when_ssd_unavailable() {
        let policy = QueueBackendPolicy::with_preference(true, None, false);
        assert_eq!(policy.kind, QueueBackendKind::MemoryBacked);
    }

    #[test]
    fn queue_record_binary_roundtrip() {
        let record = QueuePersistedRecord {
            state: QueueWriteState::CommitPending,
            complete_record: true,
            verified_readback: true,
            pointer_validated: false,
            writeback_disk_id: 2,
            writeback_start_lba: 128,
            reject_reason: None,
            pending: sample_pending_write(),
        };
        let encoded = encode_queue_records(&[record]);
        let decoded = decode_queue_records(&encoded).unwrap();
        assert_eq!(decoded.len(), 1);
        assert_eq!(decoded[0].state, QueueWriteState::CommitPending);
        assert!(decoded[0].verified_readback);
        assert_eq!(decoded[0].pending.epoch, record.pending.epoch);
        assert_eq!(decoded[0].pending.chunk[0], record.pending.chunk[0]);
    }

    #[test]
    fn queue_record_decode_fails_closed_on_truncated_data() {
        let record = QueuePersistedRecord {
            state: QueueWriteState::UqStored,
            complete_record: true,
            verified_readback: false,
            pointer_validated: false,
            writeback_disk_id: 0,
            writeback_start_lba: 0,
            reject_reason: None,
            pending: sample_pending_write(),
        };
        let mut encoded = encode_queue_records(&[record]);
        encoded.truncate(encoded.len().saturating_sub(5));
        assert!(decode_queue_records(&encoded).is_err());
    }

    #[test]
    fn rejected_state_is_decoded_and_not_resumed() {
        let record = QueuePersistedRecord {
            state: QueueWriteState::Rejected,
            complete_record: true,
            verified_readback: false,
            pointer_validated: false,
            writeback_disk_id: 0,
            writeback_start_lba: 0,
            reject_reason: Some(QueueRejectReason::IncompleteNonIngesting),
            pending: sample_pending_write(),
        };
        let encoded = encode_queue_records(&[record]);
        let decoded = decode_queue_records(&encoded).unwrap();
        assert_eq!(decoded[0].state, QueueWriteState::Rejected);
        assert_eq!(
            decoded[0].reject_reason,
            Some(QueueRejectReason::IncompleteNonIngesting)
        );

        let mut uq = UniqueQueueRuntime::new();
        uq.persisted_queue_records = decoded;
        let report = uq.resume_from_persisted_queue().unwrap();
        assert_eq!(report.resumed_records, 0);
        assert!(uq.pending_data_writes.is_empty());
    }

    #[test]
    fn rejected_policy_flags_missing_writeback_location() {
        let record = QueuePersistedRecord {
            state: QueueWriteState::HwWriting,
            complete_record: true,
            verified_readback: false,
            pointer_validated: false,
            writeback_disk_id: 0,
            writeback_start_lba: 0,
            reject_reason: None,
            pending: sample_pending_write(),
        };
        assert!(evaluate_rejected_policy(&record).is_some());
    }

    #[test]
    fn compaction_drops_old_terminal_records() {
        let mut records = vec![
            QueuePersistedRecord {
                state: QueueWriteState::CommitPending,
                complete_record: true,
                verified_readback: true,
                pointer_validated: true,
                writeback_disk_id: 1,
                writeback_start_lba: 10,
                reject_reason: None,
                pending: super::PendingDataWrite {
                    epoch: 1,
                    ..sample_pending_write()
                },
            },
            QueuePersistedRecord {
                state: QueueWriteState::UqStored,
                complete_record: true,
                verified_readback: false,
                pointer_validated: false,
                writeback_disk_id: 0,
                writeback_start_lba: 0,
                reject_reason: None,
                pending: super::PendingDataWrite {
                    epoch: 2,
                    ..sample_pending_write()
                },
            },
        ];
        let report = compact_queue_records(&mut records, 1);
        assert_eq!(report.removed_terminal_records, 1);
        assert_eq!(records.len(), 1);
        assert_eq!(records[0].pending.epoch, 2);
    }

    #[test]
    fn n_commit_promotes_pending_redundancy() {
        let mut file_ex = FileExState {
            folder_status: FolderStatus::Stable,
            n_state: NRedundancyState {
                committed_hw_id: 1,
                committed_chunk_id: 100,
                pending_hw_id: None,
                pending_chunk_id: None,
            },
            j_state: JGenerationState {
                current_epoch: 1,
                current_chunk_id: 100,
                pending_epoch: None,
                pending_chunk_id: None,
                pending_base_epoch: None,
                pending_base_chunk_id: None,
            },
            pending_op: None,
        };
        stage_n_redundancy_candidate(&mut file_ex, 2, 200);
        commit_file_ex_pending(&mut file_ex);
        assert_eq!(file_ex.n_state.committed_hw_id, 2);
        assert_eq!(file_ex.n_state.committed_chunk_id, 200);
        assert_eq!(file_ex.n_state.pending_hw_id, None);
        assert_eq!(file_ex.folder_status, FolderStatus::Stable);
    }

    #[test]
    fn n_reject_discards_pending_and_keeps_committed() {
        let mut file_ex = FileExState {
            folder_status: FolderStatus::Stable,
            n_state: NRedundancyState {
                committed_hw_id: 1,
                committed_chunk_id: 100,
                pending_hw_id: None,
                pending_chunk_id: None,
            },
            j_state: JGenerationState {
                current_epoch: 1,
                current_chunk_id: 100,
                pending_epoch: None,
                pending_chunk_id: None,
                pending_base_epoch: None,
                pending_base_chunk_id: None,
            },
            pending_op: None,
        };
        stage_n_redundancy_candidate(&mut file_ex, 3, 300);
        reject_file_ex_pending(&mut file_ex);
        assert_eq!(file_ex.n_state.committed_hw_id, 1);
        assert_eq!(file_ex.n_state.committed_chunk_id, 100);
        assert_eq!(file_ex.n_state.pending_hw_id, None);
    }

    #[test]
    fn j_commit_promotes_pending_generation() {
        let mut file_ex = FileExState {
            folder_status: FolderStatus::Stable,
            n_state: NRedundancyState {
                committed_hw_id: 1,
                committed_chunk_id: 100,
                pending_hw_id: None,
                pending_chunk_id: None,
            },
            j_state: JGenerationState {
                current_epoch: 10,
                current_chunk_id: 100,
                pending_epoch: None,
                pending_chunk_id: None,
                pending_base_epoch: None,
                pending_base_chunk_id: None,
            },
            pending_op: None,
        };
        stage_j_generation_candidate(&mut file_ex, 11, 110);
        commit_file_ex_pending(&mut file_ex);
        assert_eq!(file_ex.j_state.current_epoch, 11);
        assert_eq!(file_ex.j_state.current_chunk_id, 110);
        assert_eq!(file_ex.j_state.pending_epoch, None);
    }

    #[test]
    fn j_reject_restores_current_and_frees_pending_target() {
        let mut file_ex = FileExState {
            folder_status: FolderStatus::Stable,
            n_state: NRedundancyState {
                committed_hw_id: 1,
                committed_chunk_id: 100,
                pending_hw_id: None,
                pending_chunk_id: None,
            },
            j_state: JGenerationState {
                current_epoch: 10,
                current_chunk_id: 100,
                pending_epoch: None,
                pending_chunk_id: None,
                pending_base_epoch: None,
                pending_base_chunk_id: None,
            },
            pending_op: None,
        };
        stage_j_generation_candidate(&mut file_ex, 11, 110);
        let report = reject_file_ex_pending(&mut file_ex);
        assert_eq!(file_ex.j_state.current_epoch, 10);
        assert_eq!(file_ex.j_state.current_chunk_id, 100);
        assert_eq!(file_ex.j_state.pending_epoch, None);
        assert_eq!(report.freed_pending_chunk, Some(110));
    }

    #[test]
    fn append_existing_image_overlay_stages_pending_generation() {
        let mut file_ex = FileExState {
            folder_status: FolderStatus::Stable,
            n_state: NRedundancyState {
                committed_hw_id: 1,
                committed_chunk_id: 100,
                pending_hw_id: None,
                pending_chunk_id: None,
            },
            j_state: JGenerationState {
                current_epoch: 5,
                current_chunk_id: 55,
                pending_epoch: None,
                pending_chunk_id: None,
                pending_base_epoch: None,
                pending_base_chunk_id: None,
            },
            pending_op: None,
        };
        let existing = [0x11u8; 16];
        let req = AppendOnlyWriteRequest {
            file_id: 7,
            base: AppendBaseGeneration { epoch: 5, chunk_id: 55 },
            range: AppendWriteRange { offset: 4, len: 3 },
            payload: vec![0xaa, 0xbb, 0xcc],
        };
        let staged = stage_append_only_generation(&mut file_ex, req, Some(&existing), 6, 66).unwrap();
        assert_eq!(staged.full_image[0], 0x11);
        assert_eq!(&staged.full_image[4..7], &[0xaa, 0xbb, 0xcc]);
        assert_eq!(file_ex.j_state.pending_epoch, Some(6));
        assert_eq!(file_ex.j_state.pending_base_epoch, Some(5));
    }

    #[test]
    fn append_new_file_creates_image_without_read() {
        let image = read_existing_then_overlay(
            None,
            AppendWriteRange { offset: 2, len: 2 },
            &[0xde, 0xad],
        ).unwrap();
        assert_eq!(image.len(), 4);
        assert_eq!(&image[2..4], &[0xde, 0xad]);
    }

    #[test]
    fn append_commit_promotes_pending_to_current() {
        let mut file_ex = FileExState {
            folder_status: FolderStatus::Stable,
            n_state: NRedundancyState {
                committed_hw_id: 1,
                committed_chunk_id: 100,
                pending_hw_id: None,
                pending_chunk_id: None,
            },
            j_state: JGenerationState {
                current_epoch: 5,
                current_chunk_id: 55,
                pending_epoch: Some(6),
                pending_chunk_id: Some(66),
                pending_base_epoch: Some(5),
                pending_base_chunk_id: Some(55),
            },
            pending_op: None,
        };
        commit_append_only_generation(&mut file_ex).unwrap();
        assert_eq!(file_ex.j_state.current_epoch, 6);
        assert_eq!(file_ex.j_state.current_chunk_id, 66);
    }

    #[test]
    fn append_reject_keeps_current_generation() {
        let mut file_ex = FileExState {
            folder_status: FolderStatus::Stable,
            n_state: NRedundancyState {
                committed_hw_id: 1,
                committed_chunk_id: 100,
                pending_hw_id: None,
                pending_chunk_id: None,
            },
            j_state: JGenerationState {
                current_epoch: 5,
                current_chunk_id: 55,
                pending_epoch: Some(6),
                pending_chunk_id: Some(66),
                pending_base_epoch: Some(5),
                pending_base_chunk_id: Some(55),
            },
            pending_op: None,
        };
        reject_file_ex_pending(&mut file_ex);
        assert_eq!(file_ex.j_state.current_epoch, 5);
        assert_eq!(file_ex.j_state.current_chunk_id, 55);
    }

    #[test]
    fn append_base_generation_mismatch_fails_closed() {
        let mut file_ex = FileExState {
            folder_status: FolderStatus::Stable,
            n_state: NRedundancyState {
                committed_hw_id: 1,
                committed_chunk_id: 100,
                pending_hw_id: None,
                pending_chunk_id: None,
            },
            j_state: JGenerationState {
                current_epoch: 9,
                current_chunk_id: 99,
                pending_epoch: Some(10),
                pending_chunk_id: Some(100),
                pending_base_epoch: Some(8),
                pending_base_chunk_id: Some(88),
            },
            pending_op: None,
        };
        let err = commit_append_only_generation(&mut file_ex).unwrap_err();
        assert_eq!(err, AppendOnlyError::BaseGenerationMismatch);
        assert_eq!(file_ex.folder_status, FolderStatus::Aborted);
    }

    #[test]
    fn rm_is_pending_remove_and_commit_clears_committed_ids() {
        let mut file_ex = FileExState {
            folder_status: FolderStatus::Stable,
            n_state: NRedundancyState {
                committed_hw_id: 5,
                committed_chunk_id: 500,
                pending_hw_id: None,
                pending_chunk_id: None,
            },
            j_state: JGenerationState {
                current_epoch: 7,
                current_chunk_id: 700,
                pending_epoch: None,
                pending_chunk_id: None,
                pending_base_epoch: None,
                pending_base_chunk_id: None,
            },
            pending_op: None,
        };
        let op = PendingOperation {
            kind: PendingOperationKind::Remove,
            source_file_id: None,
            target_file_id: 10,
            base_epoch: None,
            base_chunk_id: None,
        };
        stage_pending_operation(&mut file_ex, op);
        assert_eq!(file_ex.folder_status, FolderStatus::Pending);
        commit_pending_operation(&mut file_ex, op).unwrap();
        assert_eq!(file_ex.n_state.committed_hw_id, 0);
        assert_eq!(file_ex.j_state.current_epoch, 0);
    }

    #[test]
    fn rm_reject_preserves_committed_truth() {
        let mut file_ex = FileExState {
            folder_status: FolderStatus::Stable,
            n_state: NRedundancyState {
                committed_hw_id: 5,
                committed_chunk_id: 500,
                pending_hw_id: Some(9),
                pending_chunk_id: Some(900),
            },
            j_state: JGenerationState {
                current_epoch: 7,
                current_chunk_id: 700,
                pending_epoch: Some(8),
                pending_chunk_id: Some(800),
                pending_base_epoch: Some(7),
                pending_base_chunk_id: Some(700),
            },
            pending_op: None,
        };
        let committed_before = file_ex.n_state.committed_chunk_id;
        let _ = reject_pending_operation(&mut file_ex);
        assert_eq!(file_ex.n_state.committed_chunk_id, committed_before);
        assert_eq!(file_ex.j_state.current_chunk_id, 700);
    }

    #[test]
    fn cp_commit_preserves_source_and_commits_target() {
        let source = FileExState {
            folder_status: FolderStatus::Stable,
            n_state: NRedundancyState {
                committed_hw_id: 1,
                committed_chunk_id: 111,
                pending_hw_id: None,
                pending_chunk_id: None,
            },
            j_state: JGenerationState {
                current_epoch: 3,
                current_chunk_id: 333,
                pending_epoch: None,
                pending_chunk_id: None,
                pending_base_epoch: None,
                pending_base_chunk_id: None,
            },
            pending_op: None,
        };
        let mut target = source;
        stage_j_generation_candidate(&mut target, 4, 444);
        let op = PendingOperation {
            kind: PendingOperationKind::CreateFromSource,
            source_file_id: Some(1),
            target_file_id: 2,
            base_epoch: Some(3),
            base_chunk_id: Some(333),
        };
        commit_pending_operation(&mut target, op).unwrap();
        assert_eq!(source.j_state.current_chunk_id, 333);
        assert_eq!(target.j_state.current_chunk_id, 444);
    }

    #[test]
    fn mv_commit_removes_source_only_after_target_commit() {
        let mut source = FileExState {
            folder_status: FolderStatus::Stable,
            n_state: NRedundancyState {
                committed_hw_id: 1,
                committed_chunk_id: 111,
                pending_hw_id: None,
                pending_chunk_id: None,
            },
            j_state: JGenerationState {
                current_epoch: 3,
                current_chunk_id: 333,
                pending_epoch: None,
                pending_chunk_id: None,
                pending_base_epoch: None,
                pending_base_chunk_id: None,
            },
            pending_op: None,
        };
        let mut target = source;
        stage_j_generation_candidate(&mut target, 4, 444);
        let source_op = PendingOperation {
            kind: PendingOperationKind::MoveSource,
            source_file_id: Some(1),
            target_file_id: 1,
            base_epoch: None,
            base_chunk_id: None,
        };
        let target_op = PendingOperation {
            kind: PendingOperationKind::MoveTarget,
            source_file_id: Some(1),
            target_file_id: 2,
            base_epoch: Some(3),
            base_chunk_id: Some(333),
        };
        let _ = commit_move_pair(&mut source, &mut target, source_op, target_op).unwrap();
        assert_eq!(target.j_state.current_chunk_id, 444);
        assert_eq!(source.j_state.current_chunk_id, 0);
    }

    #[test]
    fn mv_reject_preserves_original_source() {
        let mut source = FileExState {
            folder_status: FolderStatus::Stable,
            n_state: NRedundancyState {
                committed_hw_id: 1,
                committed_chunk_id: 111,
                pending_hw_id: None,
                pending_chunk_id: None,
            },
            j_state: JGenerationState {
                current_epoch: 3,
                current_chunk_id: 333,
                pending_epoch: None,
                pending_chunk_id: None,
                pending_base_epoch: None,
                pending_base_chunk_id: None,
            },
            pending_op: None,
        };
        let mut target = source;
        stage_j_generation_candidate(&mut target, 4, 444);
        let _ = reject_pending_operation(&mut source);
        let _ = reject_pending_operation(&mut target);
        assert_eq!(source.j_state.current_chunk_id, 333);
        assert_eq!(target.j_state.current_chunk_id, 333);
    }

    #[test]
    fn append_operation_variant_is_supported() {
        let mut file_ex = FileExState {
            folder_status: FolderStatus::Stable,
            n_state: NRedundancyState {
                committed_hw_id: 1,
                committed_chunk_id: 111,
                pending_hw_id: None,
                pending_chunk_id: None,
            },
            j_state: JGenerationState {
                current_epoch: 3,
                current_chunk_id: 333,
                pending_epoch: Some(4),
                pending_chunk_id: Some(444),
                pending_base_epoch: Some(3),
                pending_base_chunk_id: Some(333),
            },
            pending_op: None,
        };
        let op = PendingOperation {
            kind: PendingOperationKind::AppendOnly,
            source_file_id: None,
            target_file_id: 1,
            base_epoch: Some(3),
            base_chunk_id: Some(333),
        };
        commit_pending_operation(&mut file_ex, op).unwrap();
        assert_eq!(file_ex.j_state.current_chunk_id, 444);
    }

    #[test]
    fn file_ex_state_serialization_roundtrip() {
        let file_ex = FileExState {
            folder_status: FolderStatus::Pending,
            n_state: NRedundancyState {
                committed_hw_id: 9,
                committed_chunk_id: 90,
                pending_hw_id: Some(10),
                pending_chunk_id: Some(100),
            },
            j_state: JGenerationState {
                current_epoch: 3,
                current_chunk_id: 33,
                pending_epoch: Some(4),
                pending_chunk_id: Some(44),
                pending_base_epoch: Some(3),
                pending_base_chunk_id: Some(33),
            },
            pending_op: Some(PendingOperation {
                kind: PendingOperationKind::AppendOnly,
                source_file_id: None,
                target_file_id: 9,
                base_epoch: Some(3),
                base_chunk_id: Some(33),
            }),
        };
        let encoded = encode_file_ex_state(&file_ex);
        let decoded = decode_file_ex_state(&encoded).unwrap();
        assert_eq!(decoded, file_ex);
    }

    #[test]
    fn file_ex_state_decode_fails_closed_on_malformed() {
        let bad = [0u8; 12];
        assert!(decode_file_ex_state(&bad).is_err());
    }

    #[test]
    fn freed_pending_chunk_goes_to_reclaim_pending_list() {
        let mut file_ex = FileExState {
            folder_status: FolderStatus::Pending,
            n_state: NRedundancyState {
                committed_hw_id: 1,
                committed_chunk_id: 11,
                pending_hw_id: None,
                pending_chunk_id: None,
            },
            j_state: JGenerationState {
                current_epoch: 5,
                current_chunk_id: 55,
                pending_epoch: Some(6),
                pending_chunk_id: Some(66),
                pending_base_epoch: Some(5),
                pending_base_chunk_id: Some(55),
            },
            pending_op: Some(PendingOperation {
                kind: PendingOperationKind::AppendOnly,
                source_file_id: None,
                target_file_id: 1,
                base_epoch: Some(5),
                base_chunk_id: Some(55),
            }),
        };
        let mut reclaim = ReclaimState {
            reclaim_pending_list: vec![],
            free_list: vec![],
        };
        let _ = reject_pending_operation_with_reclaim(&mut file_ex, &mut reclaim, 10);
        assert_eq!(reclaim.reclaim_pending_list.len(), 1);
        assert!(reclaim.free_list.is_empty());
    }

    #[test]
    fn safe_reclaim_moves_chunk_after_epoch_threshold() {
        let mut reclaim = ReclaimState {
            reclaim_pending_list: vec![],
            free_list: vec![],
        };
        enqueue_reclaim_pending_chunk(&mut reclaim, 77, 5);
        assert_eq!(drain_reclaim_pending_to_free_list(&mut reclaim, 6), 0);
        assert!(reclaim.free_list.is_empty());
        assert_eq!(drain_reclaim_pending_to_free_list(&mut reclaim, 7), 1);
        assert_eq!(reclaim.free_list, vec![77]);
    }

    #[test]
    fn reader_safe_reclaim_blocks_inflight_chunk() {
        let mut reclaim = ReclaimState {
            reclaim_pending_list: vec![],
            free_list: vec![],
        };
        enqueue_reclaim_pending_chunk(&mut reclaim, 77, 5);
        let readers = ReaderTrackingState {
            active_readers_by_chunk: vec![ActiveChunkRead {
                chunk_id: 77,
                last_seen_epoch: 7,
                in_flight_read_count: 1,
            }],
        };
        assert_eq!(
            drain_reclaim_pending_to_free_list_reader_safe(&mut reclaim, &readers, 8),
            0
        );
        assert!(reclaim.free_list.is_empty());
    }

    #[test]
    fn reader_safe_reclaim_uses_tracking_before_epoch_fallback() {
        let mut reclaim = ReclaimState {
            reclaim_pending_list: vec![],
            free_list: vec![],
        };
        enqueue_reclaim_pending_chunk(&mut reclaim, 77, 5);
        let readers = ReaderTrackingState {
            active_readers_by_chunk: vec![ActiveChunkRead {
                chunk_id: 77,
                last_seen_epoch: 5,
                in_flight_read_count: 0,
            }],
        };
        let policy = ReaderReclaimPolicy {
            recent_epoch_guard: 1,
            fallback_epoch_guard: 4,
        };
        assert_eq!(
            drain_reclaim_pending_to_free_list_reader_safe_with_policy(
                &mut reclaim,
                &readers,
                7,
                policy,
            ),
            1
        );
        assert_eq!(reclaim.free_list, vec![77]);
    }

    #[test]
    fn reader_safe_reclaim_keeps_epoch_fallback_when_no_tracking_exists() {
        let mut reclaim = ReclaimState {
            reclaim_pending_list: vec![],
            free_list: vec![],
        };
        enqueue_reclaim_pending_chunk(&mut reclaim, 77, 5);
        let readers = ReaderTrackingState {
            active_readers_by_chunk: vec![],
        };
        let policy = ReaderReclaimPolicy {
            recent_epoch_guard: 1,
            fallback_epoch_guard: 4,
        };
        assert_eq!(
            drain_reclaim_pending_to_free_list_reader_safe_with_policy(
                &mut reclaim,
                &readers,
                7,
                policy,
            ),
            0
        );
        assert!(reclaim.free_list.is_empty());
        assert_eq!(
            drain_reclaim_pending_to_free_list_reader_safe_with_policy(
                &mut reclaim,
                &readers,
                9,
                policy,
            ),
            1
        );
        assert_eq!(reclaim.free_list, vec![77]);
        assert_eq!(default_reader_reclaim_policy().fallback_epoch_guard, 2);
    }

    #[test]
    fn remove_commit_queues_old_chunk_for_delayed_reclaim() {
        let mut file_ex = FileExState {
            folder_status: FolderStatus::Pending,
            n_state: NRedundancyState {
                committed_hw_id: 2,
                committed_chunk_id: 22,
                pending_hw_id: None,
                pending_chunk_id: None,
            },
            j_state: JGenerationState {
                current_epoch: 8,
                current_chunk_id: 88,
                pending_epoch: None,
                pending_chunk_id: None,
                pending_base_epoch: None,
                pending_base_chunk_id: None,
            },
            pending_op: Some(PendingOperation {
                kind: PendingOperationKind::Remove,
                source_file_id: None,
                target_file_id: 2,
                base_epoch: None,
                base_chunk_id: None,
            }),
        };
        let mut reclaim = ReclaimState {
            reclaim_pending_list: vec![],
            free_list: vec![],
        };
        let op = PendingOperation {
            kind: PendingOperationKind::Remove,
            source_file_id: None,
            target_file_id: 2,
            base_epoch: None,
            base_chunk_id: None,
        };
        let _ = commit_pending_operation_with_reclaim(&mut file_ex, op, &mut reclaim, 20).unwrap();
        assert_eq!(reclaim.reclaim_pending_list.len(), 1);
        assert_eq!(reclaim.reclaim_pending_list[0].chunk_id, 88);
    }

    #[test]
    fn metadata_critical_logical_write_expands_to_three_same_hw_replicas() {
        let placement = metadata_critical_placement_for_file(MetadataCriticalChunkKind::InitialChunk, 9);
        let plan = expand_metadata_critical_same_hw_3n_plan(placement);
        assert_eq!(plan, [0x2240, 0x2248, 0x2250]);
        let request = super::MetadataCriticalWriteRequest {
            source: crate::fs_structs::MetadataCriticalEventSource::NRedundancyStage,
            chunk_kind: MetadataCriticalChunkKind::InitialChunk,
            disk_id: 3,
            file_id: 9,
            epoch: 9,
            placement,
            payload: [0x5a; 4096],
        };
        let set = build_metadata_critical_replica_set(&request);
        assert_eq!(set.disk_id, 3);
        assert_eq!(set.file_id, 9);
        assert_eq!(set.replica_lbas, [0x2240, 0x2248, 0x2250]);
    }

    #[test]
    fn metadata_critical_3n_verification_success() {
        let request = super::MetadataCriticalWriteRequest {
            source: crate::fs_structs::MetadataCriticalEventSource::AppendOnlyStage,
            chunk_kind: MetadataCriticalChunkKind::IndexChunk,
            disk_id: 1,
            file_id: 1,
            epoch: 4,
            placement: metadata_critical_placement_for_file(MetadataCriticalChunkKind::IndexChunk, 1),
            payload: [0x3c; 4096],
        };
        let set = build_metadata_critical_replica_set(&request);
        let buffers = [request.payload, request.payload, request.payload];
        let mut last = 0;
        let result = verify_metadata_critical_replica_set_periodic(&set, 20_000, &mut last, Some(buffers));
        assert!(result.checked);
        assert!(result.alert.is_none());
    }

    #[test]
    fn metadata_critical_mismatch_triggers_stop_and_alert() {
        let request = super::MetadataCriticalWriteRequest {
            source: crate::fs_structs::MetadataCriticalEventSource::AppendOnlyStage,
            chunk_kind: MetadataCriticalChunkKind::IndexChunk,
            disk_id: 7,
            file_id: 7,
            epoch: 11,
            placement: metadata_critical_placement_for_file(MetadataCriticalChunkKind::IndexChunk, 7),
            payload: [0xaa; 4096],
        };
        let set = build_metadata_critical_replica_set(&request);
        let mut bad = [0xaa; 4096];
        bad[0] ^= 0xff;
        let buffers = [request.payload, request.payload, bad];
        let mut last = 0;
        let result = verify_metadata_critical_replica_set_periodic(&set, 20_000, &mut last, Some(buffers));
        let alert = result.alert.expect("alert expected");
        let mut scheduler = HwScheduler::new(&[(7, 4096)]);
        stop_hw_write_queue_for_metadata_alert(&mut scheduler, alert);
        assert_eq!(scheduler.disks[0].state, crate::scheduler::HwQueueState::Faulted);
    }

    #[test]
    fn file_ex_metadata_region_roundtrips() {
        let file_ex = FileExState {
            folder_status: FolderStatus::Pending,
            n_state: crate::fs_structs::NRedundancyState {
                committed_hw_id: 3,
                committed_chunk_id: 55,
                pending_hw_id: Some(4),
                pending_chunk_id: Some(77),
            },
            j_state: crate::fs_structs::JGenerationState {
                current_epoch: 11,
                current_chunk_id: 22,
                pending_epoch: Some(12),
                pending_chunk_id: Some(23),
                pending_base_epoch: Some(11),
                pending_base_chunk_id: Some(22),
            },
            pending_op: Some(PendingOperation {
                kind: PendingOperationKind::AppendOnly,
                source_file_id: None,
                target_file_id: 3,
                base_epoch: Some(11),
                base_chunk_id: Some(22),
            }),
        };
        let region = encode_file_ex_metadata_region(3, 12, &file_ex).unwrap();
        let decoded = decode_file_ex_metadata_region(&region).unwrap();
        assert_eq!(decoded.0, 3);
        assert_eq!(decoded.1, 12);
        assert_eq!(decoded.2, file_ex);
    }

    #[test]
    fn alert_consumer_reads_events_in_order() {
        let mut page = init_alert_shared_memory_page();
        let mut cursor = init_alert_consumer_cursor();
        let mut out = [AlertEvent {
            sequence: 0,
            class: AlertClass::QueueFault,
            disk_id: 0,
            file_id: 0,
            epoch: 0,
            code: 0,
            aux: 0,
        }; ALERT_IPC_RING_CAPACITY];

        push_alert_event(&mut page, AlertEvent {
            sequence: 0,
            class: AlertClass::Metadata3nInconsistency,
            disk_id: 1,
            file_id: 9,
            epoch: 11,
            code: 1,
            aux: 2,
        });
        push_alert_event(&mut page, AlertEvent {
            sequence: 0,
            class: AlertClass::ReclaimAnomaly,
            disk_id: 2,
            file_id: 9,
            epoch: 12,
            code: 20,
            aux: 77,
        });

        let consumed = consume_alert_events(&page, &mut cursor, &mut out);
        assert_eq!(consumed, 2);
        assert_eq!(out[0].class, AlertClass::Metadata3nInconsistency);
        assert_eq!(out[1].class, AlertClass::ReclaimAnomaly);
        assert!(!cursor.overflowed);
    }

    #[test]
    fn alert_consumer_detects_overflow() {
        let mut page = init_alert_shared_memory_page();
        let mut cursor = init_alert_consumer_cursor();
        let mut out = [AlertEvent {
            sequence: 0,
            class: AlertClass::QueueFault,
            disk_id: 0,
            file_id: 0,
            epoch: 0,
            code: 0,
            aux: 0,
        }; ALERT_IPC_RING_CAPACITY];

        for seq in 0..(ALERT_IPC_RING_CAPACITY as u64 + 3) {
            push_alert_event(&mut page, AlertEvent {
                sequence: 0,
                class: AlertClass::QueueFault,
                disk_id: seq,
                file_id: 1,
                epoch: seq,
                code: 10,
                aux: 0,
            });
        }

        let consumed = consume_alert_events(&page, &mut cursor, &mut out);
        assert_eq!(consumed, ALERT_IPC_RING_CAPACITY);
        assert!(cursor.overflowed);
        assert_eq!(out[0].sequence, 4);
    }

    #[test]
    fn target_meta_chunk_truth_fails_closed_on_ambiguity() {
        assert_eq!(merge_target_meta_chunk_truth(None, 41).unwrap(), Some(41));
        assert_eq!(merge_target_meta_chunk_truth(Some(41), 41).unwrap(), Some(41));
        assert!(merge_target_meta_chunk_truth(Some(41), 42).is_err());
    }

    #[test]
    fn target_meta_chunk_truth_list_merges_identical_candidates() {
        assert_eq!(
            merge_target_meta_chunk_truths(&[41, 41, 41]).unwrap(),
            Some(41)
        );
        assert!(merge_target_meta_chunk_truths(&[41, 42]).is_err());
    }

    #[test]
    fn metadata_critical_policy_is_named_and_stable() {
        let policy = default_metadata_critical_placement_policy();
        assert_eq!(policy.initial_zone_base_lba, 0x2000);
        assert_eq!(policy.index_zone_base_lba, 0x4000);
        assert_eq!(policy.file_slot_stride_lbas, 0x40);
        assert_eq!(policy.replica_stride_lbas, 0x08);
        assert_eq!(policy.file_slot_mask, 0x1f);
        let assumptions = metadata_critical_placement_safety_assumptions();
        assert_eq!(
            assumptions,
            [
                MetadataPlacementSafetyAssumption::SameHwOnly3n,
                MetadataPlacementSafetyAssumption::DistinctZonePerChunkKind,
                MetadataPlacementSafetyAssumption::FixedSlotMasking,
            ]
        );
        let placement = metadata_critical_placement_for_file_with_policy(
            MetadataCriticalChunkKind::IndexChunk,
            9,
            policy,
        );
        assert_eq!(placement.base_lba, 0x4240);
    }

    #[test]
    fn cross_hw_transfer_policy_differs_for_cp_mv_paths() {
        let same_hw = classify_cross_hw_transfer(3, 3);
        assert_eq!(same_hw.class, CrossHwTransferClass::SameHw);
        assert_eq!(same_hw.policy, CrossHwTransferPolicy::PreserveLocalClone);

        let cross_hw = classify_cross_hw_transfer(3, 7);
        assert_eq!(cross_hw.class, CrossHwTransferClass::CrossHw);
        assert_eq!(cross_hw.policy, CrossHwTransferPolicy::RequireFullReplicaCopy);
    }

    #[test]
    fn pending_operation_transfer_classifies_copy_target_path() {
        let source = FileExState {
            folder_status: FolderStatus::Stable,
            n_state: NRedundancyState {
                committed_hw_id: 1,
                committed_chunk_id: 11,
                pending_hw_id: None,
                pending_chunk_id: None,
            },
            j_state: JGenerationState {
                current_epoch: 1,
                current_chunk_id: 10,
                pending_epoch: None,
                pending_chunk_id: None,
                pending_base_epoch: None,
                pending_base_chunk_id: None,
            },
            pending_op: None,
        };
        let target = FileExState {
            n_state: NRedundancyState {
                pending_hw_id: Some(9),
                ..source.n_state
            },
            ..source
        };
        let op = PendingOperation {
            kind: PendingOperationKind::CreateFromSource,
            source_file_id: Some(1),
            target_file_id: 2,
            base_epoch: Some(1),
            base_chunk_id: Some(10),
        };
        let plan = classify_pending_operation_transfer(&source, &target, op).unwrap();
        assert_eq!(plan.class, CrossHwTransferClass::CrossHw);
        assert_eq!(plan.policy, CrossHwTransferPolicy::RequireFullReplicaCopy);
    }

    #[test]
    fn queue_reject_reason_exposes_severity() {
        assert_eq!(
            QueueRejectReason::IncompleteNonIngesting.severity(),
            QueueRejectSeverity::HardReject
        );
        assert_eq!(
            QueueRejectReason::MissingWritebackLocation.severity(),
            QueueRejectSeverity::CriticalFault
        );
    }

    #[test]
    fn mq_retention_policy_keeps_recent_rejected_epochs() {
        let mut records = vec![
            QueuePersistedRecord {
                state: QueueWriteState::Rejected,
                complete_record: true,
                verified_readback: false,
                pointer_validated: false,
                writeback_disk_id: 0,
                writeback_start_lba: 0,
                reject_reason: Some(QueueRejectReason::IncompleteNonIngesting),
                pending: super::PendingDataWrite {
                    epoch: 1,
                    ..sample_pending_write()
                },
            },
            QueuePersistedRecord {
                state: QueueWriteState::Rejected,
                complete_record: true,
                verified_readback: false,
                pointer_validated: false,
                writeback_disk_id: 0,
                writeback_start_lba: 0,
                reject_reason: Some(QueueRejectReason::MissingWritebackLocation),
                pending: super::PendingDataWrite {
                    epoch: 2,
                    ..sample_pending_write()
                },
            },
            QueuePersistedRecord {
                state: QueueWriteState::CommitPending,
                complete_record: true,
                verified_readback: true,
                pointer_validated: true,
                writeback_disk_id: 1,
                writeback_start_lba: 10,
                reject_reason: None,
                pending: super::PendingDataWrite {
                    epoch: 1,
                    ..sample_pending_write()
                },
            },
        ];
        let report = compact_queue_records_with_policy(
            &mut records,
            MqRetentionPolicy {
                keep_recent_epochs: 1,
                retain_rejected_epochs: 1,
                retain_verified_commit_epochs: 0,
            },
        );
        assert_eq!(report.removed_terminal_records, 1);
        assert_eq!(records.len(), 2);
        assert!(records.iter().any(|record| record.pending.epoch == 2));
    }
}
