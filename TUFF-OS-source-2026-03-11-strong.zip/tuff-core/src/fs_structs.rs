#![allow(dead_code)]

use crate::cse::types::CseInfo;
use crate::pq::PqSignatureAlgorithm;
use core::mem::size_of;
use sha2::{Digest, Sha256};

pub const CHUNK_SIZE: usize = 4096;
pub const KEC_CHUNK_NUMBER: u64 = 1;
pub const FIC_CHUNK_NUMBER: u64 = 2;
pub const FMC_TARGET_CHUNK_NUMBER: u64 = 3;
pub const FIC_CSE_INFO_OFFSET: usize = 75 + FIC_HEADER_ALIGN_PADDING;
pub const FIC_CSE_INFO_SIZE: usize = size_of::<CseInfo>();
pub const FIC_PROTECTED_DATA_OFFSET: usize = FIC_CSE_INFO_OFFSET + FIC_CSE_INFO_SIZE + 8;
pub const FMC_CSE_INFO_OFFSET: usize = 75 + FMC_HEADER_ALIGN_PADDING + 8 + 8;
pub const FMC_CSE_INFO_SIZE: usize = size_of::<CseInfo>();
pub const FMC_PROTECTED_DATA_OFFSET: usize = FMC_CSE_INFO_OFFSET + FMC_CSE_INFO_SIZE;
pub const FILE_EX_METADATA_FMC_EXTENSION_OFFSET_CHUNKS: u64 = 1;
pub const ALERT_IPC_RING_CAPACITY: usize = 16;

const CHUNK_HEADER_RESERVED_SIZE: usize = CHUNK_SIZE - (8 + 4 + 8 + 1 + 8);
const KEY_ENVELOPE_RESERVED_SIZE: usize = CHUNK_SIZE - (8 + 4 + 4 + 4 + 2 + 1 + 1 + 16 + 32 + 32 + 48 + 48 + 32 + 32 + 32);
const EXTRA_CHUNK_RESERVED_SIZE: usize = CHUNK_SIZE - (32 + 4 + 1 + 1 + 1);
const FIC_ENTRY_SIZE: usize = 32 + 8 + 8 + 1 + 15;
const FIC_ENTRIES_COUNT: usize = 62;
const FIC_HEADER_ALIGN_PADDING: usize = 5;
const FIC_RESERVED_SIZE: usize = CHUNK_SIZE
    - (75 + FIC_HEADER_ALIGN_PADDING + 32 + 8 + (FIC_ENTRY_SIZE * FIC_ENTRIES_COUNT));
const FMC_DATA_TAG_COUNT: usize = 32;
const FMC_POINTER_COUNT: usize = 428;
const FMC_HEADER_ALIGN_PADDING: usize = 5;
const FMC_RESERVED_SIZE: usize =
    CHUNK_SIZE - (75 + FMC_HEADER_ALIGN_PADDING + 8 + 8 + 32 + 32 + (8 * FMC_POINTER_COUNT) + (16 * FMC_DATA_TAG_COUNT));

#[repr(C)]
pub struct ChunkHeader {
    pub magic: [u8; 8],
    pub version: u32,
    pub generation: u64,
    pub wrote_flag: u8,
    pub checksum: u64,
    pub reserved: [u8; CHUNK_HEADER_RESERVED_SIZE],
}

#[repr(C, align(4096))]
pub struct KeyEnvelopeChunk {
    pub magic: [u8; 8],
    pub version: u32,
    pub envelope_version: u32,
    pub kdf_params: u32,
    pub flags: u16,
    pub signature_algorithm: PqSignatureAlgorithm,
    pub reserved0: u8,
    pub fs_uuid: [u8; 16],
    pub genesis_salt: [u8; 32],
    pub mk_verifier: [u8; 32],
    pub wrapped_tk: [u8; 48],
    pub wrapped_pk: [u8; 48],
    pub key_bundle_hash: [u8; 32],
    pub policy_root_hash: [u8; 32],
    pub reserved1: [u8; 32],
    pub reserved: [u8; KEY_ENVELOPE_RESERVED_SIZE],
}

impl KeyEnvelopeChunk {
    pub fn compute_key_bundle_hash(&self) -> [u8; 32] {
        let mut hasher = Sha256::new();
        hasher.update(self.magic);
        hasher.update(self.version.to_le_bytes());
        hasher.update(self.envelope_version.to_le_bytes());
        hasher.update(self.kdf_params.to_le_bytes());
        hasher.update(self.flags.to_le_bytes());
        hasher.update([self.signature_algorithm as u8]);
        hasher.update([self.reserved0]);
        hasher.update(self.fs_uuid);
        hasher.update(self.genesis_salt);
        hasher.update(self.mk_verifier);
        hasher.update(self.wrapped_tk);
        hasher.update(self.wrapped_pk);
        hasher.update(self.policy_root_hash);
        hasher.update(self.reserved1);
        hasher.update(self.reserved);
        hasher.finalize().into()
    }

    pub fn compute_envelope_hash(&self) -> [u8; 32] {
        self.compute_key_bundle_hash()
    }
}

#[repr(u8)]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub enum DeceptionMode {
    None = 0,
    StealthDenied = 1,
    ShadowConsistency = 2,
    HardFail = 3,
}

#[repr(u8)]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub enum ExecPolicy {
    Ignore = 0,
    VerifyHash = 1,
    VerifySystemPath = 2,
}

#[repr(C, align(4096))]
pub struct ExtraChunk {
    pub trusted_hash: [u8; 32],
    pub policy_class: u32,
    pub exec_policy: ExecPolicy,
    pub deception_mode: DeceptionMode,
    pub append_only: u8,
    pub reserved: [u8; EXTRA_CHUNK_RESERVED_SIZE],
}

#[repr(C)]
#[derive(Copy, Clone)]
pub struct FicEntry {
    pub filename_hash: [u8; 32],
    pub tag_id: u64,
    pub meta_id: u64,
    pub entry_type: u8,
    pub reserved: [u8; 15],
}

#[repr(C, align(4096))]
pub struct FicChunk {
    pub header: [u8; 75],
    pub header_padding: [u8; FIC_HEADER_ALIGN_PADDING],
    pub cse_info: CseInfo,
    pub entry_count: u64,
    pub entries: [FicEntry; FIC_ENTRIES_COUNT],
    pub reserved: [u8; FIC_RESERVED_SIZE],
}

#[repr(C, align(4096))]
pub struct FmcChunk {
    pub header: [u8; 75],
    pub header_padding: [u8; FMC_HEADER_ALIGN_PADDING],
    pub file_size: u64,
    pub extra_chunk_id: u64,
    pub cse_info: CseInfo,
    pub fingerprint: [u8; 32],
    pub data_chunk_tags: [[u8; 16]; FMC_DATA_TAG_COUNT],
    pub pointer_matrix: [u64; FMC_POINTER_COUNT],
    pub reserved: [u8; FMC_RESERVED_SIZE],
}

const _: [(); CHUNK_SIZE] = [(); core::mem::size_of::<ExtraChunk>()];
const _: [(); CHUNK_SIZE] = [(); core::mem::size_of::<KeyEnvelopeChunk>()];
const _: [(); CHUNK_SIZE] = [(); core::mem::size_of::<FicChunk>()];
const _: [(); CHUNK_SIZE] = [(); core::mem::size_of::<FmcChunk>()];
const _: [(); 80] = [(); FIC_CSE_INFO_OFFSET];
const _: [(); 32] = [(); FIC_CSE_INFO_SIZE];
const _: [(); 120] = [(); FIC_PROTECTED_DATA_OFFSET];
const _: [(); 96] = [(); FMC_CSE_INFO_OFFSET];
const _: [(); 32] = [(); FMC_CSE_INFO_SIZE];
const _: [(); 128] = [(); FMC_PROTECTED_DATA_OFFSET];

#[repr(align(4096))]
pub struct PageAlignedBuffer(pub [u8; CHUNK_SIZE]);

#[repr(u8)]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub enum QueueWriteState {
    UqIngesting = 0,
    UqStored = 1,
    HwWriting = 2,
    CommitPending = 3,
    Rejected = 4,
}

#[repr(u8)]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub enum FolderStatus {
    Stable = 0,
    Pending = 1,
    Aborted = 2,
}

#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct NRedundancyState {
    pub committed_hw_id: u64,
    pub committed_chunk_id: u64,
    pub pending_hw_id: Option<u64>,
    pub pending_chunk_id: Option<u64>,
}

#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct JGenerationState {
    pub current_epoch: u64,
    pub current_chunk_id: u64,
    pub pending_epoch: Option<u64>,
    pub pending_chunk_id: Option<u64>,
    pub pending_base_epoch: Option<u64>,
    pub pending_base_chunk_id: Option<u64>,
}

#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct FileExState {
    pub folder_status: FolderStatus,
    pub n_state: NRedundancyState,
    pub j_state: JGenerationState,
    pub pending_op: Option<PendingOperation>,
}

#[repr(u8)]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub enum PendingOperationKind {
    Remove = 0,
    CreateFromSource = 1,
    MoveSource = 2,
    MoveTarget = 3,
    AppendOnly = 4,
    NRedundancyUpdate = 5,
}

#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct PendingOperation {
    pub kind: PendingOperationKind,
    pub source_file_id: Option<u64>,
    pub target_file_id: u64,
    pub base_epoch: Option<u64>,
    pub base_chunk_id: Option<u64>,
}

#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct ReclaimPendingEntry {
    pub chunk_id: u64,
    pub queued_at_epoch: u64,
    pub reclaim_after_epoch: u64,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ReclaimState {
    pub reclaim_pending_list: alloc::vec::Vec<ReclaimPendingEntry>,
    pub free_list: alloc::vec::Vec<u64>,
}

#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct ActiveChunkRead {
    pub chunk_id: u64,
    pub last_seen_epoch: u64,
    pub in_flight_read_count: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ReaderTrackingState {
    pub active_readers_by_chunk: alloc::vec::Vec<ActiveChunkRead>,
}

#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct ReaderReclaimPolicy {
    pub recent_epoch_guard: u64,
    pub fallback_epoch_guard: u64,
}

#[repr(u8)]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub enum MetadataCriticalChunkKind {
    InitialChunk = 0,
    IndexChunk = 1,
}

#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct MetadataCriticalReplicaSet {
    pub chunk_kind: MetadataCriticalChunkKind,
    pub disk_id: u64,
    pub file_id: u64,
    pub epoch: u64,
    pub replica_lbas: [u64; 3],
    pub replica_checksums: [[u8; 32]; 3],
}

#[repr(u8)]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub enum MetadataCriticalEventSource {
    NRedundancyStage = 0,
    AppendOnlyStage = 1,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct MetadataCriticalPlacement {
    pub base_lba: u64,
    pub replica_stride_lbas: u64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct MetadataCriticalPlacementPolicy {
    pub initial_zone_base_lba: u64,
    pub index_zone_base_lba: u64,
    pub file_slot_stride_lbas: u64,
    pub replica_stride_lbas: u64,
    pub file_slot_mask: u64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MetadataPlacementSafetyAssumption {
    SameHwOnly3n,
    DistinctZonePerChunkKind,
    FixedSlotMasking,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CrossHwTransferClass {
    SameHw,
    CrossHw,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CrossHwTransferPolicy {
    PreserveLocalClone,
    RequireFullReplicaCopy,
}

#[repr(u8)]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub enum AlertClass {
    Metadata3nInconsistency = 0,
    QueueFault = 1,
    ReclaimAnomaly = 2,
}

#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct AlertEvent {
    pub sequence: u64,
    pub class: AlertClass,
    pub disk_id: u64,
    pub file_id: u64,
    pub epoch: u64,
    pub code: u32,
    pub aux: u64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct AlertConsumerCursor {
    pub last_sequence: u64,
    pub overflowed: bool,
    pub consumed_events: u64,
}

#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub enum AlertConsumerMode {
    InRuntimePolling,
    ExternalSharedMemory,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct AlertSharedMemoryPage {
    pub write_index: usize,
    pub next_sequence: u64,
    pub dropped_events: u64,
    pub events: [AlertEvent; ALERT_IPC_RING_CAPACITY],
}

#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum QueueRejectSeverity {
    SoftRetry = 0,
    HardReject = 1,
    CriticalFault = 2,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct MqRetentionPolicy {
    pub keep_recent_epochs: usize,
    pub retain_rejected_epochs: usize,
    pub retain_verified_commit_epochs: usize,
}

#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct AppendBaseGeneration {
    pub epoch: u64,
    pub chunk_id: u64,
}

#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct AppendWriteRange {
    pub offset: u64,
    pub len: u64,
}
