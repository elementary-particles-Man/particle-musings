#![allow(dead_code)]

pub const GENESIS_SIZE: usize = 4096;
const GENESIS_HEADER_SIZE: usize = 8 + 4 + 8 + 16 + 32;
const GENESIS_RESERVED_SIZE: usize = GENESIS_SIZE - GENESIS_HEADER_SIZE;

#[repr(C, align(4096))]
#[derive(Clone, Copy)]
pub struct Genesis {
    pub magic: [u8; 8],
    pub timestamp: u64,
    pub version: u32,
    pub hardware_id: [u8; 16],
    pub initial_key_hash: [u8; 32],
    pub reserved: [u8; GENESIS_RESERVED_SIZE],
}

impl Genesis {
    pub const MAGIC: [u8; 8] = *b"TUFFGEN ";

    pub fn new(hw_id: [u8; 16]) -> Self {
        Self {
            magic: Self::MAGIC,
            version: 1,
            timestamp: 0,
            hardware_id: hw_id,
            initial_key_hash: [0u8; 32],
            reserved: [0u8; GENESIS_RESERVED_SIZE],
        }
    }
}

const _: [(); GENESIS_SIZE] = [(); core::mem::size_of::<Genesis>()];
