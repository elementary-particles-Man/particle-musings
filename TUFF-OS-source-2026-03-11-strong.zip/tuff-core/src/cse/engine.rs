use crate::cse::types::{
    volatile_zero_bytes, CseArtifacts, CseContext, CseDescriptor, CseError, CseFamily,
    CSE_BLOCK_SIZE, CSE_KEY_POOL_SIZE, CSE_LAYER_COUNT,
};
use crate::fs_structs::{
    FicChunk, FmcChunk, FIC_CSE_INFO_OFFSET, FIC_CSE_INFO_SIZE, FIC_PROTECTED_DATA_OFFSET,
    FMC_CSE_INFO_OFFSET, FMC_CSE_INFO_SIZE, FMC_PROTECTED_DATA_OFFSET,
};
#[cfg(all(target_arch = "x86_64", not(target_os = "uefi")))]
use core::arch::x86_64::{
    __cpuid, __m128i, _mm_aesenc_si128, _mm_loadu_si128, _mm_set_epi64x, _mm_shuffle_epi8,
    _mm_storeu_si128, _mm_xor_si128,
};
use sha2::{Digest, Sha256};
use zeroize::Zeroize;

pub struct CseEngine;

impl CseEngine {
    pub fn load_descriptor(chunk_id: [u8; 16], epoch: u64, fmc: &FmcChunk) -> CseDescriptor {
        CseDescriptor {
            chunk_id,
            epoch,
            info: fmc.cse_info,
        }
    }

    pub fn load_fic_descriptor(chunk_id: [u8; 16], epoch: u64, fic: &FicChunk) -> CseDescriptor {
        CseDescriptor {
            chunk_id,
            epoch,
            info: fic.cse_info,
        }
    }

    pub fn generate_artifacts(ctx: &CseContext) -> CseArtifacts {
        let mut key_pool = [0u8; CSE_KEY_POOL_SIZE];
        fill_from_seed(&pool_seed(ctx), &mut key_pool);

        let mut table = [0u8; CSE_LAYER_COUNT];
        generate_algorithm_chain(&table_seed(ctx), &mut table);

        CseArtifacts { table, key_pool }
    }

    pub fn encrypt_block(
        data: &mut [u8; CSE_BLOCK_SIZE],
        ctx: &CseContext,
    ) -> Result<(), CseError> {
        let artifacts = Self::generate_artifacts(ctx);
        for layer in artifacts.table.iter() {
            Self::apply_algorithm(*layer, data, ctx, &artifacts.key_pool, false, true)?;
        }
        Ok(())
    }

    pub fn decrypt_block(
        data: &mut [u8; CSE_BLOCK_SIZE],
        ctx: &CseContext,
    ) -> Result<(), CseError> {
        let artifacts = Self::generate_artifacts(ctx);
        for layer in artifacts.table.iter().rev() {
            Self::apply_algorithm(*layer, data, ctx, &artifacts.key_pool, true, true)?;
        }
        Ok(())
    }

    pub fn encrypt_with_algorithm_id(
        algorithm_id: u8,
        data: &mut [u8; CSE_BLOCK_SIZE],
        ctx: &CseContext,
    ) -> Result<(), CseError> {
        let artifacts = Self::generate_artifacts(ctx);
        Self::apply_algorithm(algorithm_id, data, ctx, &artifacts.key_pool, false, true)
    }

    pub fn decrypt_with_algorithm_id(
        algorithm_id: u8,
        data: &mut [u8; CSE_BLOCK_SIZE],
        ctx: &CseContext,
    ) -> Result<(), CseError> {
        let artifacts = Self::generate_artifacts(ctx);
        Self::apply_algorithm(algorithm_id, data, ctx, &artifacts.key_pool, true, true)
    }

    pub fn process_fmc_block(
        data: &mut [u8; CSE_BLOCK_SIZE],
        desc: &CseDescriptor,
        tk: &[u8; 32],
        pk: &[u8; 32],
        encrypt: bool,
    ) -> Result<(), CseError> {
        Self::process_chunk_block(data, desc, tk, pk, encrypt, FMC_PROTECTED_DATA_OFFSET)
    }

    pub fn process_fic_block(
        data: &mut [u8; CSE_BLOCK_SIZE],
        desc: &CseDescriptor,
        tk: &[u8; 32],
        pk: &[u8; 32],
        encrypt: bool,
    ) -> Result<(), CseError> {
        Self::process_chunk_block(data, desc, tk, pk, encrypt, FIC_PROTECTED_DATA_OFFSET)
    }

    pub fn process_data_block(
        data: &mut [u8; CSE_BLOCK_SIZE],
        desc: &CseDescriptor,
        tk: &[u8; 32],
        pk: &[u8; 32],
        encrypt: bool,
    ) -> Result<(), CseError> {
        Self::process_chunk_block(data, desc, tk, pk, encrypt, 0)
    }

    fn process_chunk_block(
        data: &mut [u8; CSE_BLOCK_SIZE],
        desc: &CseDescriptor,
        tk: &[u8; 32],
        pk: &[u8; 32],
        encrypt: bool,
        protected_offset: usize,
    ) -> Result<(), CseError> {
        let mut ctx = CseContext {
            chunk_id: desc.chunk_id,
            epoch: desc.epoch,
            tk: *tk,
            pk: *pk,
        };
        let mut artifacts = Self::generate_artifacts(&ctx);

        // Blend the FMC-side structural seed into the ephemeral key pool.
        for (idx, byte) in desc.info.structural_seed.iter().enumerate() {
            let slot = idx * (CSE_KEY_POOL_SIZE / desc.info.structural_seed.len());
            artifacts.key_pool[slot] ^= *byte;
        }

        let protected = &mut data[protected_offset..];

        if encrypt {
            apply_whitening(protected, &artifacts.key_pool, 0x41);
            for algorithm_id in desc.info.algorithm_chain {
                Self::apply_algorithm(
                    algorithm_id,
                    protected,
                    &ctx,
                    &artifacts.key_pool,
                    false,
                    false,
                )?;
            }
            apply_whitening(protected, &artifacts.key_pool, 0xa7);
        } else {
            apply_whitening(protected, &artifacts.key_pool, 0xa7);
            for algorithm_id in desc.info.algorithm_chain.iter().rev() {
                Self::apply_algorithm(
                    *algorithm_id,
                    protected,
                    &ctx,
                    &artifacts.key_pool,
                    true,
                    false,
                )?;
            }
            apply_whitening(protected, &artifacts.key_pool, 0x41);
        }

        volatile_zero_bytes(&mut ctx.tk);
        volatile_zero_bytes(&mut ctx.pk);
        Ok(())
    }

    pub fn process_fic_block_secure(
        data: &mut [u8; CSE_BLOCK_SIZE],
        desc: &mut CseDescriptor,
        tk: &[u8; 32],
        pk: &[u8; 32],
        encrypt: bool,
    ) -> Result<(), CseError> {
        if encrypt {
            Self::process_fic_block(data, desc, tk, pk, true)?;
            desc.info.integrity_tag = Self::calculate_fic_ciphertext_tag(data, desc);
            return Ok(());
        }

        let current_tag = Self::calculate_fic_ciphertext_tag(data, desc);
        if !constant_time_eq_16(&current_tag, &desc.info.integrity_tag) {
            return Err(CseError::IntegrityCheckFailed);
        }
        Self::process_fic_block(data, desc, tk, pk, false)?;
        Ok(())
    }

    pub fn process_fmc_block_secure(
        data: &mut [u8; CSE_BLOCK_SIZE],
        desc: &mut CseDescriptor,
        tk: &[u8; 32],
        pk: &[u8; 32],
        encrypt: bool,
    ) -> Result<(), CseError> {
        if encrypt {
            Self::process_fmc_block(data, desc, tk, pk, true)?;
            desc.info.integrity_tag = Self::calculate_fmc_ciphertext_tag(data, desc);
            return Ok(());
        }

        let current_tag = Self::calculate_fmc_ciphertext_tag(data, desc);
        if !constant_time_eq_16(&current_tag, &desc.info.integrity_tag) {
            return Err(CseError::IntegrityCheckFailed);
        }
        Self::process_fmc_block(data, desc, tk, pk, false)?;
        Ok(())
    }

    pub fn process_data_block_secure(
        data: &mut [u8; CSE_BLOCK_SIZE],
        desc: &mut CseDescriptor,
        tk: &[u8; 32],
        pk: &[u8; 32],
        encrypt: bool,
    ) -> Result<(), CseError> {
        if encrypt {
            Self::process_data_block(data, desc, tk, pk, true)?;
            desc.info.integrity_tag = Self::calculate_data_ciphertext_tag(data, desc);
            return Ok(());
        }

        let current_tag = Self::calculate_data_ciphertext_tag(data, desc);
        if !constant_time_eq_16(&current_tag, &desc.info.integrity_tag) {
            return Err(CseError::IntegrityCheckFailed);
        }
        Self::process_data_block(data, desc, tk, pk, false)?;
        Ok(())
    }

    pub fn decrypt_fic_block_secure(
        data: &mut [u8; CSE_BLOCK_SIZE],
        desc: &CseDescriptor,
        tk: &[u8; 32],
        pk: &[u8; 32],
    ) -> Result<(), CseError> {
        let mut derived = *desc;
        Self::process_fic_block_secure(data, &mut derived, tk, pk, false)
    }

    pub fn decrypt_fmc_block_secure(
        data: &mut [u8; CSE_BLOCK_SIZE],
        desc: &CseDescriptor,
        tk: &[u8; 32],
        pk: &[u8; 32],
    ) -> Result<(), CseError> {
        let mut derived = *desc;
        Self::process_fmc_block_secure(data, &mut derived, tk, pk, false)
    }

    pub fn family_for_algorithm(algorithm_id: u8) -> CseFamily {
        match algorithm_id {
            0..=63 => CseFamily::BlockCipher,
            64..=127 => CseFamily::Lightweight,
            128..=191 => CseFamily::StreamCipher,
            _ => CseFamily::Structural,
        }
    }

    pub fn calculate_integrity_tag(
        data: &[u8; CSE_BLOCK_SIZE],
        desc: &CseDescriptor,
    ) -> [u8; 16] {
        Self::calculate_fmc_ciphertext_tag(data, desc)
    }

    pub fn calculate_fic_integrity_tag(
        data: &[u8; CSE_BLOCK_SIZE],
        desc: &CseDescriptor,
    ) -> [u8; 16] {
        Self::calculate_fic_ciphertext_tag(data, desc)
    }

    pub fn calculate_fmc_integrity_tag(
        data: &[u8; CSE_BLOCK_SIZE],
        desc: &CseDescriptor,
    ) -> [u8; 16] {
        Self::calculate_fmc_ciphertext_tag(data, desc)
    }

    pub fn calculate_fic_ciphertext_tag(
        data: &[u8; CSE_BLOCK_SIZE],
        desc: &CseDescriptor,
    ) -> [u8; 16] {
        fast_ciphertext_tag(
            data,
            desc,
            FIC_CSE_INFO_OFFSET,
            FIC_CSE_INFO_SIZE,
            FIC_PROTECTED_DATA_OFFSET,
        )
    }

    pub fn calculate_fmc_ciphertext_tag(
        data: &[u8; CSE_BLOCK_SIZE],
        desc: &CseDescriptor,
    ) -> [u8; 16] {
        fast_ciphertext_tag(
            data,
            desc,
            FMC_CSE_INFO_OFFSET,
            FMC_CSE_INFO_SIZE,
            FMC_PROTECTED_DATA_OFFSET,
        )
    }

    pub fn calculate_data_ciphertext_tag(
        data: &[u8; CSE_BLOCK_SIZE],
        desc: &CseDescriptor,
    ) -> [u8; 16] {
        fast_ciphertext_tag(data, desc, 0, 0, 0)
    }

    pub fn fill_deterministic_padding(
        out: &mut [u8],
        chunk_id: [u8; 16],
        epoch: u64,
        label: u8,
    ) {
        let mut seed = [0u8; 64];
        seed[..16].copy_from_slice(&chunk_id);
        seed[16..24].copy_from_slice(&epoch.to_le_bytes());
        seed[24] = label;
        fill_from_seed(&seed, out);
        seed.zeroize();
    }

    fn apply_algorithm(
        algorithm_id: u8,
        data: &mut [u8],
        ctx: &CseContext,
        key_pool: &[u8; CSE_KEY_POOL_SIZE],
        inverse: bool,
        allow_hardware: bool,
    ) -> Result<(), CseError> {
        let family = Self::family_for_algorithm(algorithm_id);
        let variant = (algorithm_id & 0x1f) as usize;
        match family {
            CseFamily::BlockCipher => {
                if allow_hardware
                    && !apply_hardware_block_cipher(data, algorithm_id, ctx, key_pool, inverse, variant)
                {
                    apply_arx_fallback_layer(data, algorithm_id, ctx, key_pool, inverse, variant);
                } else if !allow_hardware
                {
                    apply_arx_fallback_layer(data, algorithm_id, ctx, key_pool, inverse, variant);
                }
                Ok(())
            }
            CseFamily::Lightweight => {
                let mut key = derive_key_16(algorithm_id, ctx, key_pool);
                let mut nonce = derive_nonce_16(algorithm_id, ctx, key_pool);
                let result = apply_speck128_ctr(data, &key, &nonce, inverse, variant);
                key.zeroize();
                nonce.zeroize();
                result
            }
            CseFamily::StreamCipher => {
                apply_stream_prng_layer(data, algorithm_id, ctx, key_pool, inverse, variant);
                Ok(())
            }
            CseFamily::Structural => {
                if algorithm_id < 224 {
                    apply_window_shuffle(data, algorithm_id, ctx, key_pool, inverse, variant);
                } else {
                    apply_xorshift_layer(data, algorithm_id, ctx, key_pool, inverse, variant);
                }
                Ok(())
            }
        }
    }

}

#[cfg(all(target_arch = "x86_64", not(target_os = "uefi")))]
#[allow(unused_unsafe)]
fn aes_ni_available() -> bool {
    unsafe { (__cpuid(1).ecx & (1 << 25)) != 0 }
}

#[cfg(not(all(target_arch = "x86_64", not(target_os = "uefi"))))]
#[allow(dead_code)]
fn aes_ni_available() -> bool {
    false
}

fn apply_hardware_block_cipher(
    data: &mut [u8],
    algorithm_id: u8,
    ctx: &CseContext,
    key_pool: &[u8; CSE_KEY_POOL_SIZE],
    inverse: bool,
    variant: usize,
) -> bool {
    #[cfg(all(target_arch = "x86_64", not(target_os = "uefi")))]
    {
        if aes_ni_available() {
            let mut round_key = derive_material::<16>(algorithm_id, ctx, key_pool, 0x90);
            let mut shuffle_seed = derive_material::<16>(algorithm_id, ctx, key_pool, 0x91);
            unsafe {
                hardware_aes_prng_layer(data, &round_key, &shuffle_seed, inverse, variant);
            }
            volatile_zero_bytes(&mut round_key);
            volatile_zero_bytes(&mut shuffle_seed);
            return true;
        }
    }

    let _ = (data, algorithm_id, ctx, key_pool, inverse, variant);
    false
}

fn table_seed(ctx: &CseContext) -> [u8; 64] {
    let mut seed = [0u8; 64];
    seed[..16].copy_from_slice(&ctx.chunk_id);
    seed[16..24].copy_from_slice(&ctx.epoch.to_le_bytes());
    seed[24..56].copy_from_slice(&ctx.tk);
    seed[56..64].copy_from_slice(&ctx.pk[..8]);
    seed
}

fn pool_seed(ctx: &CseContext) -> [u8; 64] {
    let mut seed = [0u8; 64];
    seed[..16].copy_from_slice(&ctx.chunk_id);
    seed[16..24].copy_from_slice(&ctx.epoch.to_le_bytes());
    seed[24..56].copy_from_slice(&ctx.pk);
    seed[56..64].copy_from_slice(&ctx.tk[..8]);
    seed
}

fn fill_from_seed(seed: &[u8], out: &mut [u8]) {
    let digest = Sha256::digest(seed);
    let mut state = [
        u64::from_le_bytes(digest[0..8].try_into().unwrap()),
        u64::from_le_bytes(digest[8..16].try_into().unwrap()),
        u64::from_le_bytes(digest[16..24].try_into().unwrap()),
        u64::from_le_bytes(digest[24..32].try_into().unwrap()),
    ];

    let mut chunks = out.chunks_exact_mut(8);
    for chunk in &mut chunks {
        let word = xoshiro256pp_next(&mut state);
        chunk.copy_from_slice(&word.to_le_bytes());
    }

    let remainder = chunks.into_remainder();
    if !remainder.is_empty() {
        let word = xoshiro256pp_next(&mut state).to_le_bytes();
        remainder.copy_from_slice(&word[..remainder.len()]);
    }
}

fn generate_algorithm_chain(seed: &[u8], out: &mut [u8; CSE_LAYER_COUNT]) {
    let mut entropy = [0u8; 64];
    fill_from_seed(seed, &mut entropy);

    let family_bases = [0u8, 64, 128, 192];
    let mut picks = [0u8; CSE_LAYER_COUNT];
    let mut cursor = 0usize;
    for (family_idx, family_base) in family_bases.iter().enumerate() {
        let mut family_used = [false; 32];
        for pick_idx in 0..2 {
            let entropy_idx = family_idx * 2 + pick_idx;
            let mut candidate = (entropy[entropy_idx] & 0x1f) as usize;
            while family_used[candidate] {
                candidate = (candidate + 5) & 0x1f;
            }
            family_used[candidate] = true;
            picks[cursor] = *family_base + candidate as u8;
            cursor += 1;
        }
    }

    for idx in (1..CSE_LAYER_COUNT).rev() {
        let swap_idx = (entropy[16 + idx] as usize) % (idx + 1);
        picks.swap(idx, swap_idx);
    }

    // Guarantee at least two non-linear families land in the first four positions.
    let nonlinear_count = picks[..4]
        .iter()
        .filter(|algorithm_id| matches!(CseEngine::family_for_algorithm(**algorithm_id), CseFamily::BlockCipher | CseFamily::Lightweight))
        .count();
    if nonlinear_count < 2 {
        picks.swap(1, 4);
        picks.swap(3, 5);
    }

    out.copy_from_slice(&picks);
}

fn derive_material<const N: usize>(
    algorithm_id: u8,
    ctx: &CseContext,
    key_pool: &[u8; CSE_KEY_POOL_SIZE],
    label: u8,
) -> [u8; N] {
    let mut seed = [0u8; 64];
    seed[..16].copy_from_slice(&ctx.chunk_id);
    seed[16..24].copy_from_slice(&ctx.epoch.to_le_bytes());
    seed[24] = algorithm_id;
    seed[25] = label;

    let base = ((algorithm_id as usize) * 29 + (label as usize) * 131) % (CSE_KEY_POOL_SIZE - 32);
    seed[32..64].copy_from_slice(&key_pool[base..base + 32]);

    let mut out = [0u8; N];
    fill_from_seed(&seed, &mut out);
    seed.zeroize();
    out
}

fn derive_key_16(algorithm_id: u8, ctx: &CseContext, key_pool: &[u8; CSE_KEY_POOL_SIZE]) -> [u8; 16] {
    derive_material::<16>(algorithm_id, ctx, key_pool, 0x11)
}

fn derive_nonce_16(algorithm_id: u8, ctx: &CseContext, key_pool: &[u8; CSE_KEY_POOL_SIZE]) -> [u8; 16] {
    derive_material::<16>(algorithm_id, ctx, key_pool, 0x40)
}

fn apply_hash_stream_layer(
    data: &mut [u8],
    algorithm_id: u8,
    ctx: &CseContext,
    key_pool: &[u8; CSE_KEY_POOL_SIZE],
    label: u8,
    variant: usize,
) {
    let seed = derive_material::<32>(algorithm_id, ctx, key_pool, label);
    let mut state = u64::from_le_bytes(seed[..8].try_into().unwrap())
        ^ u64::from_le_bytes(seed[8..16].try_into().unwrap())
        ^ u64::from_le_bytes(seed[16..24].try_into().unwrap())
        ^ u64::from_le_bytes(seed[24..32].try_into().unwrap())
        ^ ((variant as u64) << 32);

    for (idx, dst) in data.iter_mut().enumerate() {
        if (idx & 7) == 0 {
            state = xorshift64(state);
        }
        *dst ^= ((state >> ((idx & 7) * 8)) & 0xff) as u8;
    }
}

fn apply_arx_fallback_layer(
    data: &mut [u8],
    algorithm_id: u8,
    ctx: &CseContext,
    key_pool: &[u8; CSE_KEY_POOL_SIZE],
    inverse: bool,
    variant: usize,
) {
    let rotation = ((variant * 7) % data.len()).max(1);
    if inverse {
        data.rotate_right(rotation);
    }

    let key = derive_material::<32>(algorithm_id, ctx, key_pool, 0x81);
    let nonce = derive_material::<12>(algorithm_id, ctx, key_pool, 0x82);
    if inverse {
        undo_neighbor_diffusion(data, variant);
    }
    apply_chacha8_stream(data, &key, &nonce, variant as u32);
    if !inverse {
        apply_neighbor_diffusion(data, variant);
    }

    if !inverse {
        data.rotate_left(rotation);
    }
}

#[cfg(all(target_arch = "x86_64", not(target_os = "uefi")))]
#[target_feature(enable = "aes,ssse3")]
unsafe fn hardware_aes_prng_layer(
    data: &mut [u8],
    round_key: &[u8; 16],
    shuffle_seed: &[u8; 16],
    inverse: bool,
    variant: usize,
) {
    let rotation = ((variant * 11) % data.len()).max(1);
    if inverse {
        data.rotate_right(rotation);
    }

    let key = _mm_loadu_si128(round_key.as_ptr() as *const __m128i);
    let state_seed = _mm_set_epi64x(
        i64::from_le_bytes(shuffle_seed[8..16].try_into().unwrap()),
        i64::from_le_bytes(shuffle_seed[..8].try_into().unwrap()),
    );

    for (block_idx, chunk) in data.chunks_exact_mut(16).enumerate() {
        let counter = _mm_set_epi64x(
            (variant as i64) ^ ((block_idx as i64) << 1),
            (block_idx as i64) ^ ((variant as i64) << 33),
        );
        let mut keystream = _mm_xor_si128(state_seed, counter);
        keystream = _mm_aesenc_si128(keystream, key);
        keystream = _mm_aesenc_si128(keystream, _mm_xor_si128(key, counter));

        let lane_rotation = ((variant + block_idx) & 0x0f) as u8;
        let mut fwd_mask = [0u8; 16];
        let mut inv_mask = [0u8; 16];
        for idx in 0..16 {
            fwd_mask[idx] = ((idx + lane_rotation as usize) & 0x0f) as u8;
            inv_mask[idx] = ((idx + 16 - lane_rotation as usize) & 0x0f) as u8;
        }
        let lane_mask = if inverse { inv_mask } else { fwd_mask };
        let lane_mask = _mm_loadu_si128(lane_mask.as_ptr() as *const __m128i);
        let mut block = _mm_loadu_si128(chunk.as_ptr() as *const __m128i);
        if inverse {
            block = _mm_shuffle_epi8(block, lane_mask);
            block = _mm_xor_si128(block, keystream);
        } else {
            block = _mm_xor_si128(block, keystream);
            block = _mm_shuffle_epi8(block, lane_mask);
        }
        _mm_storeu_si128(chunk.as_mut_ptr() as *mut __m128i, block);
    }

    if !inverse {
        data.rotate_left(rotation);
    }
}

fn apply_stream_prng_layer(
    data: &mut [u8],
    algorithm_id: u8,
    ctx: &CseContext,
    key_pool: &[u8; CSE_KEY_POOL_SIZE],
    inverse: bool,
    variant: usize,
) {
    let rotation = ((variant * 13) % data.len()).max(1);
    if inverse {
        data.rotate_right(rotation);
        undo_neighbor_diffusion(data, variant ^ 0x15);
    }
    apply_hash_stream_layer(data, algorithm_id, ctx, key_pool, 0xa0, variant);
    if !inverse {
        apply_neighbor_diffusion(data, variant ^ 0x15);
        data.rotate_left(rotation);
    }
}

fn apply_window_shuffle(
    data: &mut [u8],
    algorithm_id: u8,
    ctx: &CseContext,
    key_pool: &[u8; CSE_KEY_POOL_SIZE],
    inverse: bool,
    variant: usize,
) {
    const WINDOW: usize = 16;
    let seed = derive_material::<32>(algorithm_id, ctx, key_pool, 0x66);
    let mut perm = [0u8; WINDOW];
    let mut inv_perm = [0u8; WINDOW];
    for (idx, slot) in perm.iter_mut().enumerate() {
        *slot = idx as u8;
    }
    let mut state = seed_to_state(&seed) ^ ((variant as u64) << 9);
    for i in (1..WINDOW).rev() {
        state = xorshift64(state);
        let j = (state as usize) % (i + 1);
        perm.swap(i, j);
    }
    for (idx, slot) in perm.iter().enumerate() {
        inv_perm[*slot as usize] = idx as u8;
    }

    let mut tmp = [0u8; WINDOW];
    for window in data.chunks_exact_mut(WINDOW) {
        tmp.copy_from_slice(window);
        if inverse {
            for idx in 0..WINDOW {
                window[idx] = tmp[inv_perm[idx] as usize];
            }
        } else {
            for idx in 0..WINDOW {
                window[idx] = tmp[perm[idx] as usize];
            }
        }
    }
}

fn apply_speck128_ctr(
    data: &mut [u8],
    key: &[u8; 16],
    nonce: &[u8; 16],
    inverse: bool,
    variant: usize,
) -> Result<(), CseError> {
    if inverse {
        undo_neighbor_diffusion(data, variant ^ 0x2a);
    }

    let round_keys = speck128_expand(key);
    for (counter, chunk) in data.chunks_mut(16).enumerate() {
        let mut block = [0u8; 16];
        block[..8].copy_from_slice(&nonce[..8]);
        block[8..].copy_from_slice(&(counter as u64).to_le_bytes());
        let keystream = speck128_encrypt_block(block, &round_keys);
        for (dst, src) in chunk.iter_mut().zip(keystream.iter()) {
            *dst ^= *src;
        }
    }

    if !inverse {
        apply_neighbor_diffusion(data, variant ^ 0x2a);
    }
    Ok(())
}

const SPECK_ROUNDS: usize = 16;

fn speck128_expand(key: &[u8; 16]) -> [u64; SPECK_ROUNDS] {
    let mut round_keys = [0u64; SPECK_ROUNDS];
    let mut l = [0u64; SPECK_ROUNDS];
    round_keys[0] = u64::from_le_bytes(key[..8].try_into().unwrap());
    l[0] = u64::from_le_bytes(key[8..16].try_into().unwrap());

    for i in 0..(SPECK_ROUNDS - 1) {
        l[i + 1] = (round_keys[i].wrapping_add(l[i].rotate_right(8))) ^ (i as u64);
        round_keys[i + 1] = round_keys[i].rotate_left(3) ^ l[i + 1];
    }

    round_keys
}

fn speck128_encrypt_block(block: [u8; 16], round_keys: &[u64; SPECK_ROUNDS]) -> [u8; 16] {
    let mut x = u64::from_le_bytes(block[..8].try_into().unwrap());
    let mut y = u64::from_le_bytes(block[8..16].try_into().unwrap());

    for key in round_keys {
        x = (x.rotate_right(8).wrapping_add(y)) ^ key;
        y = y.rotate_left(3) ^ x;
    }

    let mut out = [0u8; 16];
    out[..8].copy_from_slice(&x.to_le_bytes());
    out[8..].copy_from_slice(&y.to_le_bytes());
    out
}

fn apply_xorshift_layer(
    data: &mut [u8],
    algorithm_id: u8,
    ctx: &CseContext,
    key_pool: &[u8; CSE_KEY_POOL_SIZE],
    inverse: bool,
    variant: usize,
) {
    let rotation = variant % data.len();
    if inverse && rotation != 0 {
        data.rotate_right(rotation);
    }
    if inverse {
        undo_neighbor_diffusion(data, variant ^ 0x3f);
    }

    let seed = derive_material::<32>(algorithm_id, ctx, key_pool, 0x77);
    let mut state = u64::from_le_bytes(seed[..8].try_into().unwrap())
        ^ u64::from_le_bytes(seed[8..16].try_into().unwrap())
        ^ u64::from_le_bytes(seed[16..24].try_into().unwrap())
        ^ u64::from_le_bytes(seed[24..32].try_into().unwrap());

    for byte in data.iter_mut() {
        state = xorshift64(state);
        *byte ^= (state & 0xff) as u8;
    }

    if !inverse {
        apply_neighbor_diffusion(data, variant ^ 0x3f);
    }
    if !inverse && rotation != 0 {
        data.rotate_left(rotation);
    }
}

fn xorshift64(mut x: u64) -> u64 {
    x ^= x << 13;
    x ^= x >> 7;
    x ^= x << 17;
    x
}

fn xoshiro256pp_next(state: &mut [u64; 4]) -> u64 {
    let result = state[0]
        .wrapping_add(state[3])
        .rotate_left(23)
        .wrapping_add(state[0]);

    let t = state[1] << 17;
    state[2] ^= state[0];
    state[3] ^= state[1];
    state[1] ^= state[2];
    state[0] ^= state[3];
    state[2] ^= t;
    state[3] = state[3].rotate_left(45);

    result
}

fn seed_to_state(seed: &[u8; 32]) -> u64 {
    u64::from_le_bytes(seed[..8].try_into().unwrap())
        ^ u64::from_le_bytes(seed[8..16].try_into().unwrap())
        ^ u64::from_le_bytes(seed[16..24].try_into().unwrap())
        ^ u64::from_le_bytes(seed[24..32].try_into().unwrap())
}

fn fast_ciphertext_tag(
    data: &[u8; CSE_BLOCK_SIZE],
    desc: &CseDescriptor,
    skip_offset: usize,
    skip_len: usize,
    protected_offset: usize,
) -> [u8; 16] {
    let k0 = u64::from_le_bytes(desc.chunk_id[0..8].try_into().unwrap()) ^ desc.epoch.rotate_left(17);
    let k1 = u64::from_le_bytes(desc.chunk_id[8..16].try_into().unwrap())
        ^ u64::from_le_bytes(desc.info.structural_seed)
        ^ u64::from_le_bytes(desc.info.algorithm_chain);
    let mut state = siphash_state(k0, k1);

    absorb_sip_word(&mut state, protected_offset as u64);
    absorb_sip_word(
        &mut state,
        ((skip_offset as u64) << 32) | skip_len as u64,
    );

    for (offset, chunk) in data.chunks_exact(8).enumerate() {
        let byte_offset = offset * 8;
        if byte_offset >= skip_offset && byte_offset < skip_offset + skip_len {
            continue;
        }

        let word = u64::from_le_bytes(chunk.try_into().unwrap()) ^ ((byte_offset as u64) << 19);
        absorb_sip_word(&mut state, word);
    }

    let final_left = finalize_siphash(state, (CSE_BLOCK_SIZE - skip_len) as u64);
    let final_right = finalize_siphash(state, (protected_offset as u64) ^ 0xff00_ff00_ff00_ff00);
    let mut out = [0u8; 16];
    out[..8].copy_from_slice(&final_left.to_le_bytes());
    out[8..].copy_from_slice(&final_right.to_le_bytes());
    out
}

fn siphash_state(k0: u64, k1: u64) -> [u64; 4] {
    [
        0x736f6d6570736575 ^ k0,
        0x646f72616e646f6d ^ k1,
        0x6c7967656e657261 ^ k0,
        0x7465646279746573 ^ k1,
    ]
}

fn absorb_sip_word(state: &mut [u64; 4], word: u64) {
    state[3] ^= word;
    sip_round(state);
    sip_round(state);
    state[0] ^= word;
}

fn apply_neighbor_diffusion(data: &mut [u8], variant: usize) {
    for idx in 1..data.len() {
        let shift = ((variant + idx) & 7) as u32;
        data[idx] ^= data[idx - 1].rotate_left(shift);
    }
}

fn undo_neighbor_diffusion(data: &mut [u8], variant: usize) {
    for idx in (1..data.len()).rev() {
        let shift = ((variant + idx) & 7) as u32;
        data[idx] ^= data[idx - 1].rotate_left(shift);
    }
}

fn constant_time_eq_16(left: &[u8; 16], right: &[u8; 16]) -> bool {
    let mut diff = 0u8;
    for idx in 0..16 {
        diff |= left[idx] ^ right[idx];
    }
    diff == 0
}

fn sip_round(state: &mut [u64; 4]) {
    state[0] = state[0].wrapping_add(state[1]);
    state[1] = state[1].rotate_left(13) ^ state[0];
    state[0] = state[0].rotate_left(32);
    state[2] = state[2].wrapping_add(state[3]);
    state[3] = state[3].rotate_left(16) ^ state[2];
    state[0] = state[0].wrapping_add(state[3]);
    state[3] = state[3].rotate_left(21) ^ state[0];
    state[2] = state[2].wrapping_add(state[1]);
    state[1] = state[1].rotate_left(17) ^ state[2];
    state[2] = state[2].rotate_left(32);
}

fn finalize_siphash(mut state: [u64; 4], trailer: u64) -> u64 {
    state[3] ^= trailer;
    sip_round(&mut state);
    sip_round(&mut state);
    state[0] ^= trailer;
    state[2] ^= 0xff;
    sip_round(&mut state);
    sip_round(&mut state);
    sip_round(&mut state);
    sip_round(&mut state);
    state[0] ^ state[1] ^ state[2] ^ state[3]
}

fn apply_whitening(data: &mut [u8], key_pool: &[u8; CSE_KEY_POOL_SIZE], domain: u8) {
    for (idx, byte) in data.iter_mut().enumerate() {
        let kp = key_pool[idx % CSE_KEY_POOL_SIZE];
        let tweak = domain.wrapping_add((idx as u8).rotate_left((idx & 7) as u32));
        *byte ^= kp ^ tweak;
    }
}

fn apply_chacha8_stream(data: &mut [u8], key: &[u8; 32], nonce: &[u8; 12], counter_seed: u32) {
    for (counter, chunk) in data.chunks_mut(64).enumerate() {
        let block = chacha8_block(key, nonce, counter_seed.wrapping_add(counter as u32));
        for (dst, src) in chunk.iter_mut().zip(block.iter()) {
            *dst ^= *src;
        }
    }
}

fn chacha8_block(key: &[u8; 32], nonce: &[u8; 12], counter: u32) -> [u8; 64] {
    let constants = [0x6170_7865u32, 0x3320_646eu32, 0x7962_2d32u32, 0x6b20_6574u32];
    let mut state = [0u32; 16];
    state[0..4].copy_from_slice(&constants);
    for idx in 0..8 {
        state[4 + idx] = u32::from_le_bytes(key[idx * 4..idx * 4 + 4].try_into().unwrap());
    }
    state[12] = counter;
    state[13] = u32::from_le_bytes(nonce[0..4].try_into().unwrap());
    state[14] = u32::from_le_bytes(nonce[4..8].try_into().unwrap());
    state[15] = u32::from_le_bytes(nonce[8..12].try_into().unwrap());

    let mut working = state;
    for _ in 0..4 {
        quarter_round_state(&mut working, 0, 4, 8, 12);
        quarter_round_state(&mut working, 1, 5, 9, 13);
        quarter_round_state(&mut working, 2, 6, 10, 14);
        quarter_round_state(&mut working, 3, 7, 11, 15);
        quarter_round_state(&mut working, 0, 5, 10, 15);
        quarter_round_state(&mut working, 1, 6, 11, 12);
        quarter_round_state(&mut working, 2, 7, 8, 13);
        quarter_round_state(&mut working, 3, 4, 9, 14);
    }
    for idx in 0..16 {
        working[idx] = working[idx].wrapping_add(state[idx]);
    }

    let mut out = [0u8; 64];
    for (idx, word) in working.iter().enumerate() {
        out[idx * 4..idx * 4 + 4].copy_from_slice(&word.to_le_bytes());
    }
    out
}

fn quarter_round(a: &mut u32, b: &mut u32, c: &mut u32, d: &mut u32) {
    *a = a.wrapping_add(*b);
    *d ^= *a;
    *d = d.rotate_left(16);
    *c = c.wrapping_add(*d);
    *b ^= *c;
    *b = b.rotate_left(12);
    *a = a.wrapping_add(*b);
    *d ^= *a;
    *d = d.rotate_left(8);
    *c = c.wrapping_add(*d);
    *b ^= *c;
    *b = b.rotate_left(7);
}

fn quarter_round_state(state: &mut [u32; 16], ai: usize, bi: usize, ci: usize, di: usize) {
    let (mut a, mut b, mut c, mut d) = (state[ai], state[bi], state[ci], state[di]);
    quarter_round(&mut a, &mut b, &mut c, &mut d);
    state[ai] = a;
    state[bi] = b;
    state[ci] = c;
    state[di] = d;
}

#[cfg(test)]
mod tests {
    use super::CseEngine;
    use crate::cse::types::{CseContext, CseDescriptor, CseFamily, CseInfo, CSE_BLOCK_SIZE};
    use crate::fs_structs::FmcChunk;

    fn dummy_ctx() -> CseContext {
        CseContext {
            chunk_id: [
                0x00, 0xff, 0xee, 0xdd, 0xcc, 0xbb, 0xaa, 0x99, 0x88, 0x77, 0x66, 0x55, 0x44,
                0x33, 0x22, 0x11,
            ],
            epoch: 7,
            tk: [0x5a; 32],
            pk: [0xa5; 32],
        }
    }

    #[test]
    fn all_algorithm_ids_roundtrip() {
        let ctx = dummy_ctx();
        let mut original = [0u8; CSE_BLOCK_SIZE];
        for (idx, slot) in original.iter_mut().enumerate() {
            *slot = (idx & 0xff) as u8;
        }

        for algorithm_id in 0u8..=255 {
            let mut block = original;
            CseEngine::encrypt_with_algorithm_id(algorithm_id, &mut block, &ctx).unwrap();
            CseEngine::decrypt_with_algorithm_id(algorithm_id, &mut block, &ctx).unwrap();
            assert_eq!(block, original, "algorithm_id={algorithm_id}");
        }
    }

    #[test]
    fn dynamic_table_roundtrip() {
        let ctx = dummy_ctx();
        let mut original = [0u8; CSE_BLOCK_SIZE];
        for (idx, slot) in original.iter_mut().enumerate() {
            *slot = ((idx * 3) & 0xff) as u8;
        }
        let mut block = original;
        CseEngine::encrypt_block(&mut block, &ctx).unwrap();
        assert_ne!(block, original);
        CseEngine::decrypt_block(&mut block, &ctx).unwrap();
        assert_eq!(block, original);
    }

    #[test]
    fn process_fmc_block_roundtrip() {
        let tk = [0x33; 32];
        let pk = [0x44; 32];
        let desc = CseDescriptor {
            chunk_id: [
                0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x20, 0x21, 0x22, 0x23, 0x24,
                0x25, 0x26, 0x27,
            ],
            epoch: 9,
            info: CseInfo::new([1, 72, 100, 144, 168, 192, 224, 255], [0xaa; 8]),
        };
        let mut original = [0u8; CSE_BLOCK_SIZE];
        for (idx, slot) in original.iter_mut().enumerate() {
            *slot = ((idx * 5) & 0xff) as u8;
        }
        let mut block = original;
        CseEngine::process_fmc_block(&mut block, &desc, &tk, &pk, true).unwrap();
        assert_ne!(block, original);
        CseEngine::process_fmc_block(&mut block, &desc, &tk, &pk, false).unwrap();
        assert_eq!(block, original);
    }

    #[test]
    fn algorithm_family_mapping_is_stable() {
        assert_eq!(CseEngine::family_for_algorithm(0), CseFamily::BlockCipher);
        assert_eq!(CseEngine::family_for_algorithm(64), CseFamily::Lightweight);
        assert_eq!(CseEngine::family_for_algorithm(128), CseFamily::StreamCipher);
        assert_eq!(CseEngine::family_for_algorithm(192), CseFamily::Structural);
    }

    #[test]
    fn secure_processing_updates_and_checks_integrity_tag() {
        let tk = [0x33; 32];
        let pk = [0x44; 32];
        let mut desc = CseDescriptor {
            chunk_id: [
                0x42, 0x11, 0x42, 0x11, 0x42, 0x11, 0x42, 0x11, 0x99, 0x88, 0x77, 0x66, 0x55,
                0x44, 0x33, 0x22,
            ],
            epoch: 3,
            info: CseInfo::new([64, 72, 100, 144, 168, 192, 224, 255], [0x55; 8]),
        };
        let mut block = [0xabu8; CSE_BLOCK_SIZE];
        let original = block;

        CseEngine::process_fmc_block_secure(&mut block, &mut desc, &tk, &pk, true).unwrap();
        assert_ne!(desc.info.integrity_tag, [0u8; 16]);
        CseEngine::process_fmc_block_secure(&mut block, &mut desc, &tk, &pk, false).unwrap();
        assert_eq!(block, original);
    }

    #[test]
    fn secure_processing_rejects_tampered_ciphertext_before_decrypt() {
        let tk = [0x33; 32];
        let pk = [0x44; 32];
        let mut desc = CseDescriptor {
            chunk_id: [
                0x42, 0x11, 0x42, 0x11, 0x42, 0x11, 0x42, 0x11, 0x99, 0x88, 0x77, 0x66, 0x55,
                0x44, 0x33, 0x22,
            ],
            epoch: 3,
            info: CseInfo::new([64, 72, 100, 144, 168, 192, 224, 255], [0x55; 8]),
        };
        let mut block = [0xabu8; CSE_BLOCK_SIZE];

        CseEngine::process_fmc_block_secure(&mut block, &mut desc, &tk, &pk, true).unwrap();
        let ciphertext = block;
        block[300] ^= 0x40;

        let err = CseEngine::process_fmc_block_secure(&mut block, &mut desc, &tk, &pk, false)
            .unwrap_err();
        assert!(matches!(err, crate::cse::types::CseError::IntegrityCheckFailed));
        assert_ne!(block, ciphertext);
        assert_eq!(block[300], ciphertext[300] ^ 0x40);
    }

    #[test]
    fn load_descriptor_reads_fmc_cse_info() {
        let info = CseInfo::with_integrity_tag([1, 2, 3, 4, 5, 6, 7, 8], [0xaa; 8], [0xbb; 16]);
        let fmc = FmcChunk {
            header: [0u8; 75],
            header_padding: [0u8; 5],
            file_size: 0,
            extra_chunk_id: 0,
            cse_info: info,
            fingerprint: [0u8; 32],
            data_chunk_tags: [[0u8; 16]; 32],
            pointer_matrix: [0u64; 428],
            reserved: [0u8; 0],
        };
        let desc = CseEngine::load_descriptor([0x11; 16], 12, &fmc);
        assert_eq!(desc.chunk_id, [0x11; 16]);
        assert_eq!(desc.epoch, 12);
        assert_eq!(desc.info.algorithm_chain, [1, 2, 3, 4, 5, 6, 7, 8]);
        assert_eq!(desc.info.integrity_tag, [0xbb; 16]);
    }

    #[test]
    fn integrity_tag_has_avalanche_for_single_bit_flip() {
        let desc = CseDescriptor {
            chunk_id: [0x21; 16],
            epoch: 42,
            info: CseInfo::new([8, 73, 110, 143, 176, 205, 222, 247], [0x5c; 8]),
        };
        let mut block = [0u8; CSE_BLOCK_SIZE];
        for (idx, byte) in block.iter_mut().enumerate() {
            *byte = ((idx * 11) & 0xff) as u8;
        }

        let baseline = CseEngine::calculate_integrity_tag(&block, &desc);
        block[777] ^= 0x04;
        let changed = CseEngine::calculate_integrity_tag(&block, &desc);
        let distance = hamming_distance(&baseline, &changed);
        assert!(distance >= 48, "distance={distance}");
    }

    #[test]
    fn integrity_tag_changes_with_chunk_phase() {
        let mut block = [0u8; CSE_BLOCK_SIZE];
        for (idx, byte) in block.iter_mut().enumerate() {
            *byte = ((idx * 7) & 0xff) as u8;
        }

        let desc_a = CseDescriptor {
            chunk_id: [0x10; 16],
            epoch: 7,
            info: CseInfo::new([8, 73, 110, 143, 176, 205, 222, 247], [0x5c; 8]),
        };
        let desc_b = CseDescriptor {
            chunk_id: [0x11; 16],
            epoch: 8,
            info: CseInfo::new([8, 73, 110, 143, 176, 205, 222, 247], [0x5c; 8]),
        };

        let tag_a = CseEngine::calculate_integrity_tag(&block, &desc_a);
        let tag_b = CseEngine::calculate_integrity_tag(&block, &desc_b);
        assert_ne!(tag_a, tag_b);
        assert!(hamming_distance(&tag_a, &tag_b) >= 40);
    }

    #[test]
    fn representative_families_show_minimum_avalanche() {
        let ctx = dummy_ctx();
        let original = patterned_block(0x31);
        let flipped = bit_flipped_block(&original, 913, 0x20);
        let artifacts = CseEngine::generate_artifacts(&ctx);

        for algorithm_id in [8u8, 72, 144, 224] {
            let mut base = original;
            let mut diff = flipped;
            CseEngine::apply_algorithm(
                algorithm_id,
                &mut base,
                &ctx,
                &artifacts.key_pool,
                false,
                false,
            )
            .unwrap();
            CseEngine::apply_algorithm(
                algorithm_id,
                &mut diff,
                &ctx,
                &artifacts.key_pool,
                false,
                false,
            )
            .unwrap();
            let distance = hamming_distance(&base, &diff);
            assert!(
                distance >= 256,
                "algorithm_id={algorithm_id} distance={distance}"
            );
        }
    }

    #[test]
    fn generated_chain_has_balanced_family_distribution() {
        let ctx = dummy_ctx();
        let artifacts = CseEngine::generate_artifacts(&ctx);
        let mut counts = [0u8; 4];
        for algorithm_id in artifacts.table {
            match CseEngine::family_for_algorithm(algorithm_id) {
                CseFamily::BlockCipher => counts[0] += 1,
                CseFamily::Lightweight => counts[1] += 1,
                CseFamily::StreamCipher => counts[2] += 1,
                CseFamily::Structural => counts[3] += 1,
            }
        }
        assert_eq!(counts, [2, 2, 2, 2]);
    }

    fn patterned_block(seed: u8) -> [u8; CSE_BLOCK_SIZE] {
        let mut block = [0u8; CSE_BLOCK_SIZE];
        for (idx, byte) in block.iter_mut().enumerate() {
            *byte = seed.wrapping_add((idx as u8).wrapping_mul(17));
        }
        block
    }

    fn bit_flipped_block(block: &[u8; CSE_BLOCK_SIZE], index: usize, mask: u8) -> [u8; CSE_BLOCK_SIZE] {
        let mut out = *block;
        out[index] ^= mask;
        out
    }

    fn hamming_distance(lhs: &[u8], rhs: &[u8]) -> u32 {
        lhs.iter()
            .zip(rhs.iter())
            .map(|(left, right)| (left ^ right).count_ones())
            .sum()
    }
}
