use crate::cse::engine::CseEngine;
use crate::cse::types::{CseDescriptor, CseError, CSE_BLOCK_SIZE};

pub const DATA_BATCH_MAX: usize = 32;

pub struct CseWorker {
    pub worker_id: usize,
    pub busy: bool,
}

impl CseWorker {
    pub const fn new(worker_id: usize) -> Self {
        Self {
            worker_id,
            busy: false,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CseExecutionMode {
    Sequential,
    SequentialScaffold,
}

pub struct CseScheduler {
    pub mode: CseExecutionMode,
    pub worker_count: usize,
}

pub struct DataReadPlan {
    pub chunk_indices: [usize; DATA_BATCH_MAX],
    pub lbas: [u64; DATA_BATCH_MAX],
    pub bytes_to_consume: [usize; DATA_BATCH_MAX],
    pub count: usize,
}

impl DataReadPlan {
    pub const fn empty() -> Self {
        Self {
            chunk_indices: [0; DATA_BATCH_MAX],
            lbas: [0; DATA_BATCH_MAX],
            bytes_to_consume: [0; DATA_BATCH_MAX],
            count: 0,
        }
    }
}

impl CseScheduler {
    pub const fn for_uefi() -> Self {
        Self {
            mode: CseExecutionMode::SequentialScaffold,
            worker_count: 1,
        }
    }

    pub fn process_blocks_parallel(
        &self,
        blocks: &mut [&mut [u8; CSE_BLOCK_SIZE]],
        descs: &mut [CseDescriptor],
        tk: &[u8; 32],
        pk: &[u8; 32],
        encrypt: bool,
    ) -> Result<(), CseError> {
        if blocks.len() != descs.len() {
            return Err(CseError::InvalidStructure);
        }

        // UEFI/no_std 段階では安全性と determinism を優先し、逐次実行で API を固定する。
        // 将来の TUFF-Core runtime では、ここをコア数ベースの worker 実装へ差し替える。
        for (block, desc) in blocks.iter_mut().zip(descs.iter_mut()) {
            CseEngine::process_fmc_block_secure(block, desc, tk, pk, encrypt)?;
        }
        Ok(())
    }

    pub fn process_data_blocks_parallel(
        &self,
        blocks: &mut [&mut [u8; CSE_BLOCK_SIZE]],
        descs: &mut [CseDescriptor],
        tk: &[u8; 32],
        pk: &[u8; 32],
        encrypt: bool,
    ) -> Result<(), CseError> {
        if blocks.is_empty() || blocks.len() != descs.len() {
            return Err(CseError::InvalidStructure);
        }

        for (block, desc) in blocks.iter_mut().zip(descs.iter_mut()) {
            CseEngine::process_data_block_secure(block, desc, tk, pk, encrypt)?;
        }
        Ok(())
    }

    pub fn build_data_read_plan(
        &self,
        pointer_matrix: &[u64],
        file_size: usize,
        lba_per_chunk: u64,
    ) -> DataReadPlan {
        let _ = self;
        let mut plan = DataReadPlan::empty();
        let mut remaining_bytes = file_size;

        for (slot, chunk_id) in pointer_matrix.iter().enumerate() {
            if slot >= DATA_BATCH_MAX || *chunk_id == 0 || remaining_bytes == 0 {
                break;
            }

            let bytes_to_consume = core::cmp::min(remaining_bytes, CSE_BLOCK_SIZE);
            plan.chunk_indices[plan.count] = slot;
            plan.lbas[plan.count] = *chunk_id * lba_per_chunk;
            plan.bytes_to_consume[plan.count] = bytes_to_consume;
            plan.count += 1;
            remaining_bytes -= bytes_to_consume;
        }

        plan
    }
}
