use super::engine::CseEngine;
use super::types::{CseContext, CseDescriptor, CseInfo, CSE_BLOCK_SIZE};

fn ctx() -> CseContext {
    CseContext {
        chunk_id: [0x31; 16],
        epoch: 19,
        tk: [0x5a; 32],
        pk: [0xa5; 32],
    }
}

fn desc() -> CseDescriptor {
    CseDescriptor {
        chunk_id: [0x44; 16],
        epoch: 19,
        info: CseInfo::new([8, 73, 110, 143, 176, 205, 222, 247], [0x2d; 8]),
    }
}

fn patterned_block() -> [u8; CSE_BLOCK_SIZE] {
    let mut out = [0u8; CSE_BLOCK_SIZE];
    for (idx, byte) in out.iter_mut().enumerate() {
        *byte = ((idx * 9) & 0xff) as u8;
    }
    out
}

fn hamming_distance(lhs: &[u8], rhs: &[u8]) -> u32 {
    lhs.iter()
        .zip(rhs.iter())
        .map(|(left, right)| (left ^ right).count_ones())
        .sum()
}

#[test]
fn differential_attack_simulation_shows_ciphertext_avalanche() {
    let ctx = ctx();
    let original = patterned_block();
    let mut flipped = original;
    flipped[1234] ^= 0x01;

    let mut left = original;
    let mut right = flipped;
    CseEngine::encrypt_block(&mut left, &ctx).unwrap();
    CseEngine::encrypt_block(&mut right, &ctx).unwrap();

    let distance = hamming_distance(&left, &right);
    assert!(distance >= 512, "distance={distance}");
}

#[test]
fn kpa_simulation_reduces_plaintext_correlation() {
    let ctx = ctx();
    let plain = patterned_block();
    let mut cipher = plain;
    CseEngine::encrypt_block(&mut cipher, &ctx).unwrap();

    let mut same_position = 0usize;
    for idx in 0..CSE_BLOCK_SIZE {
        if plain[idx] == cipher[idx] {
            same_position += 1;
        }
    }

    assert!(same_position < 64, "same_position={same_position}");
}

#[test]
fn integrity_tag_varies_across_epoch_sweep() {
    let base_desc = desc();
    let block = patterned_block();
    let mut tags = [[0u8; 16]; 8];

    for epoch in 0..8u64 {
        let mut derived = base_desc;
        derived.epoch = epoch;
        tags[epoch as usize] = CseEngine::calculate_integrity_tag(&block, &derived);
    }

    for left in 0..tags.len() {
        for right in left + 1..tags.len() {
            assert_ne!(tags[left], tags[right], "left={left} right={right}");
        }
    }
}
