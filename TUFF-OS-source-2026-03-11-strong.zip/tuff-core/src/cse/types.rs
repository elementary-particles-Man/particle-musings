use core::ptr;
use core::sync::atomic::{compiler_fence, Ordering};

pub const CSE_BLOCK_SIZE: usize = 4096;
pub const CSE_LAYER_COUNT: usize = 8;
pub const CSE_KEY_POOL_SIZE: usize = 1024;

/// CSE Algorithm Families aligned to the current specification buckets.
#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CseFamily {
    BlockCipher = 0,
    Lightweight = 1,
    StreamCipher = 2,
    Structural = 3,
}

/// CSE Info field stored in FMC.
#[repr(C)]
#[derive(Debug, Clone, Copy)]
pub struct CseInfo {
    pub algorithm_chain: [u8; CSE_LAYER_COUNT],
    pub structural_seed: [u8; 8],
    pub integrity_tag: [u8; 16],
}

#[derive(Debug, Clone, Copy)]
pub struct CseContext {
    pub chunk_id: [u8; 16],
    pub epoch: u64,
    pub tk: [u8; 32],
    pub pk: [u8; 32],
}

#[derive(Debug, Clone, Copy)]
pub struct CseDescriptor {
    pub chunk_id: [u8; 16],
    pub epoch: u64,
    pub info: CseInfo,
}

#[derive(Debug)]
pub struct CseArtifacts {
    pub table: [u8; CSE_LAYER_COUNT],
    pub key_pool: [u8; CSE_KEY_POOL_SIZE],
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CseError {
    InvalidStructure,
    KeyMismatch,
    IntegrityCheckFailed,
}

impl CseInfo {
    pub fn new(algorithm_chain: [u8; CSE_LAYER_COUNT], structural_seed: [u8; 8]) -> Self {
        Self {
            algorithm_chain,
            structural_seed,
            integrity_tag: [0u8; 16],
        }
    }

    pub fn with_integrity_tag(
        algorithm_chain: [u8; CSE_LAYER_COUNT],
        structural_seed: [u8; 8],
        integrity_tag: [u8; 16],
    ) -> Self {
        Self {
            algorithm_chain,
            structural_seed,
            integrity_tag,
        }
    }
}

impl CseArtifacts {
    pub fn zeroize_volatile(&mut self) {
        volatile_zero_bytes(&mut self.table);
        volatile_zero_bytes(&mut self.key_pool);
    }
}

impl Drop for CseArtifacts {
    fn drop(&mut self) {
        self.zeroize_volatile();
    }
}

pub fn volatile_zero_bytes(bytes: &mut [u8]) {
    for byte in bytes.iter_mut() {
        unsafe {
            ptr::write_volatile(byte, 0);
        }
    }
    compiler_fence(Ordering::SeqCst);
}
