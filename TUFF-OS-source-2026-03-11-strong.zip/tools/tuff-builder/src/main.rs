use std::env;
use std::fs::{self, File, OpenOptions};
use std::io::{Read, Seek, SeekFrom, Write};
use std::mem::size_of;
use std::path::Path;
use std::time::{SystemTime, UNIX_EPOCH};

use sha2::{Digest, Sha256};
use tuff_core::cse::engine::CseEngine;
use tuff_core::cse::types::{CseDescriptor, CseInfo};
use tuff_core::fs_structs::{
    FicChunk, FicEntry, FmcChunk, KeyEnvelopeChunk, FIC_CHUNK_NUMBER, FIC_CSE_INFO_OFFSET,
    FIC_CSE_INFO_SIZE, FMC_CSE_INFO_OFFSET, FMC_CSE_INFO_SIZE, FMC_TARGET_CHUNK_NUMBER,
    KEC_CHUNK_NUMBER,
};
use tuff_core::genesis::{Genesis, GENESIS_SIZE};
use tuff_core::pq::signatures::{AuditLogEntry, BootPolicy, PqSignatureBlob, UpdateManifest};
use tuff_core::pq::{
    embedded_root_policy_public_key, mldsa_signing_message, KeyEnvelopeManager, PqDomain,
    PqSignatureAlgorithm, DEFAULT_KDF_PARAMS, EMBEDDED_ROOT_POLICY_SEED, MOCK_MASTER_KEY,
};
use fips204::traits::{KeyGen, Signer};

const TARGET_DIR: &str = "/home/flux/.cache/tuff-core-target";
const DISK0_IMAGE: &str = "/home/flux/.cache/tuff-core-target/disk0.img";
const DISK1_IMAGE: &str = "/home/flux/.cache/tuff-core-target/disk1.img";
const DISK2_IMAGE: &str = "/home/flux/.cache/tuff-core-target/disk2.img";
const LEGACY_DISK_IMAGE: &str = "/home/flux/.cache/tuff-core-target/tuff_test_disk.img";
const KEY_THUMB_DIR: &str = "/home/flux/.cache/tuff-core-target/key_thumb.img";
const TUFFKEY_JSON_PATH: &str = "/home/flux/.cache/tuff-core-target/key_thumb.img/TUFFkey.json";
const TUFFDEMO_JSON_PATH: &str = "/home/flux/.cache/tuff-core-target/key_thumb.img/TUFFdemo.json";
const DISK_SIZE: u64 = 64 * 1024 * 1024;
const BOOT_POLICY_CHUNK_NUMBER: u64 = 64;
const UPDATE_MANIFEST_CHUNK_NUMBER: u64 = 72;
const AUDIT_LOG_CHUNK_NUMBER: u64 = 80;
const TARGET_META_CHUNK_NUMBER: u64 = FMC_TARGET_CHUNK_NUMBER;
const TARGET_FILE_EX_METADATA_CHUNK_NUMBER: u64 = TARGET_META_CHUNK_NUMBER + 1;
const COPY_FILE_EX_METADATA_CHUNK_NUMBER: u64 = 9;
const MOVE_FILE_EX_METADATA_CHUNK_NUMBER: u64 = 11;
const CONFLICT_META_CHUNK_NUMBER: u64 = FMC_TARGET_CHUNK_NUMBER + 9;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<String> = env::args().skip(1).collect();
    let mut force_install = false;
    let mut corrupt_disks = [false; 3];
    let mut enable_vm_ops = false;
    let mut validation_profile: Option<String> = None;
    let mut conflict_target_meta_disk = None;
    let mut index = 0usize;
    while index < args.len() {
        match args[index].as_str() {
            "--recover" => return recover_existing_image(args.get(index + 1)),
            "--rekey" => return rekey_existing_image(args.get(index + 1)),
            "--force-install" => {
                force_install = true;
                index += 1;
            }
            "--corrupt-disk" => {
                let disk_index = args
                    .get(index + 1)
                    .ok_or_else(|| "--corrupt-disk requires 0, 1, or 2".to_string())?
                    .parse::<usize>()
                    .map_err(|_| "--corrupt-disk requires 0, 1, or 2".to_string())?;
                if disk_index > 2 {
                    return Err("--corrupt-disk requires 0, 1, or 2".into());
                }
                corrupt_disks[disk_index] = true;
                index += 2;
            }
            "--enable-vm-ops" => {
                enable_vm_ops = true;
                index += 1;
            }
            "--validation-profile" => {
                let profile = args
                    .get(index + 1)
                    .ok_or_else(|| "--validation-profile requires a value".to_string())?;
                validation_profile = Some(profile.clone());
                index += 2;
            }
            "--conflict-target-meta-disk" => {
                let disk_index = args
                    .get(index + 1)
                    .ok_or_else(|| "--conflict-target-meta-disk requires 0, 1, or 2".to_string())?
                    .parse::<usize>()
                    .map_err(|_| "--conflict-target-meta-disk requires 0, 1, or 2".to_string())?;
                if disk_index > 2 {
                    return Err("--conflict-target-meta-disk requires 0, 1, or 2".into());
                }
                conflict_target_meta_disk = Some(disk_index);
                index += 2;
            }
            _ => {
                index += 1;
            }
        }
    }

    if force_install {
        println!("WARNING: ForceInstall will ignore existing Genesis/KEC metadata.");
        println!("WARNING: Data protected by the previous MK becomes permanently silent.");
    }

    fs::create_dir_all(TARGET_DIR)?;
    fs::create_dir_all(KEY_THUMB_DIR)?;
    let mut genesis = Genesis::new(*b"TUFF-UQ-001\0\0\0\0\0");
    let install_stamp = if force_install {
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|duration| duration.as_secs())
            .unwrap_or(2)
    } else {
        1
    };
    genesis.timestamp = install_stamp;
    genesis.initial_key_hash = KeyEnvelopeManager::compute_owner_genesis_hash(&MOCK_MASTER_KEY);
    CseEngine::fill_deterministic_padding(&mut genesis.reserved, [0x01; 16], 0, 0xe0);
    let profile = validation_profile.as_deref().or_else(|| {
        if enable_vm_ops {
            Some("rm_cp_mv")
        } else {
            None
        }
    });
    let validation_mask = validation_profile_mask(profile);
    if profile.is_some() {
        genesis.reserved[0] = 0xa5;
        genesis.reserved[1] = validation_mask;
    }

    let fic_chunk_id = [0x11; 16];
    let fmc_chunk_id = [0x22; 16];
    let epoch = 100;

    let mut fs_uuid = [0u8; 16];
    fs_uuid.copy_from_slice(&sha256_name(if force_install {
        "tuff-core-fs-uuid-force-install"
    } else {
        "tuff-core-fs-uuid"
    })[..16]);
    let mut genesis_salt = [0u8; 32];
    CseEngine::fill_deterministic_padding(
        &mut genesis_salt,
        [0x09; 16],
        install_stamp,
        if force_install { 0xda } else { 0xcf },
    );
    let mut tk_entropy = [0u8; 32];
    let mut pk_entropy = [0u8; 32];
    CseEngine::fill_deterministic_padding(&mut tk_entropy, fic_chunk_id, install_stamp, 0xd2);
    CseEngine::fill_deterministic_padding(&mut pk_entropy, fmc_chunk_id, install_stamp, 0xd3);
    let (mut kec, tk, pk) = KeyEnvelopeManager::init_new_kec(
        &MOCK_MASTER_KEY,
        KeyEnvelopeManager::compute_policy_root_hash(&embedded_root_policy_public_key()),
        fs_uuid,
        genesis_salt,
        DEFAULT_KDF_PARAMS,
        &tk_entropy,
        &pk_entropy,
    );
    CseEngine::fill_deterministic_padding(&mut kec.reserved1, [0x10; 16], epoch, 0xd0);
    CseEngine::fill_deterministic_padding(&mut kec.reserved, [0x20; 16], epoch, 0xd5);
    kec.key_bundle_hash = kec.compute_key_bundle_hash();

    let mut fic = FicChunk {
        header: [0u8; 75],
        header_padding: [0u8; 5],
        cse_info: CseInfo::new([0; 8], [0x2d; 8]),
        entry_count: 1,
        entries: [empty_fic_entry(); 62],
        reserved: [0u8; 8],
    };
    fic.header[..8].copy_from_slice(b"TUFFFIC ");
    CseEngine::fill_deterministic_padding(&mut fic.reserved, fic_chunk_id, epoch, 0xf1);
    fic.entries[0] = FicEntry {
        filename_hash: sha256_name("target_file.txt"),
        tag_id: 0x5446_4943_0000_0001,
        meta_id: TARGET_META_CHUNK_NUMBER,
        entry_type: 1,
        reserved: deterministic_reserved::<15>(fic_chunk_id, epoch, 0xe1),
    };

    let mut fmc = FmcChunk {
        header: [0u8; 75],
        header_padding: [0u8; 5],
        file_size: 5000,
        extra_chunk_id: 0,
        cse_info: CseInfo::new([0; 8], [0x3c; 8]),
        fingerprint: [0x5a; 32],
        data_chunk_tags: [[0u8; 16]; 32],
        pointer_matrix: [0u64; 428],
        reserved: [0u8; 0],
    };
    fmc.header[..8].copy_from_slice(b"TUFFFMC ");
    CseEngine::fill_deterministic_padding(&mut fmc.fingerprint, fmc_chunk_id, epoch, 0xf2);
    fmc.pointer_matrix[0] = 16;
    fmc.pointer_matrix[1] = 17;

    let fic_ctx = cse_context(fic_chunk_id, epoch, tk, pk);
    fic.cse_info.algorithm_chain = CseEngine::generate_artifacts(&fic_ctx).table;
    let fmc_ctx = cse_context(fmc_chunk_id, epoch, tk, pk);
    fmc.cse_info.algorithm_chain = CseEngine::generate_artifacts(&fmc_ctx).table;

    let mut data_chunk_1 = [0u8; GENESIS_SIZE];
    for (idx, byte) in data_chunk_1.iter_mut().enumerate() {
        *byte = b'A' + (idx % 26) as u8;
    }
    data_chunk_1[..16].copy_from_slice(b"TUFFDATA-CHUNK-A");
    let mut data_desc_1 = CseDescriptor {
        chunk_id: [0x31; 16],
        epoch,
        info: CseInfo::new(fmc.cse_info.algorithm_chain, fmc.cse_info.structural_seed),
    };
    deposit_to_uq(&mut data_chunk_1, &mut data_desc_1, &tk, &pk, true)
        .map_err(|err| format!("Data chunk 1 secure processing failed: {err:?}"))?;
    fmc.data_chunk_tags[0] = data_desc_1.info.integrity_tag;

    let mut data_chunk_2 = [0u8; GENESIS_SIZE];
    for (idx, byte) in data_chunk_2.iter_mut().enumerate() {
        *byte = b'a' + (idx % 26) as u8;
    }
    data_chunk_2[..16].copy_from_slice(b"TUFFDATA-CHUNK-B");
    let mut data_desc_2 = CseDescriptor {
        chunk_id: [0x32; 16],
        epoch,
        info: CseInfo::new(fmc.cse_info.algorithm_chain, fmc.cse_info.structural_seed),
    };
    deposit_to_uq(&mut data_chunk_2, &mut data_desc_2, &tk, &pk, true)
        .map_err(|err| format!("Data chunk 2 secure processing failed: {err:?}"))?;
    fmc.data_chunk_tags[1] = data_desc_2.info.integrity_tag;

    let mut fmc_desc = CseDescriptor {
        chunk_id: fmc_chunk_id,
        epoch,
        info: fmc.cse_info,
    };
    let mut target_fmc_bytes = [0u8; GENESIS_SIZE];
    target_fmc_bytes.copy_from_slice(as_bytes(&fmc));
    deposit_to_uq(&mut target_fmc_bytes, &mut fmc_desc, &tk, &pk, false)
        .map_err(|err| format!("CSE secure processing failed: {err:?}"))?;
    target_fmc_bytes[FMC_CSE_INFO_OFFSET..FMC_CSE_INFO_OFFSET + FMC_CSE_INFO_SIZE]
        .copy_from_slice(as_bytes(&fmc_desc.info));
    let conflict_fmc_bytes = target_fmc_bytes;

    for (disk_index, disk_path) in [DISK0_IMAGE, DISK1_IMAGE, DISK2_IMAGE, LEGACY_DISK_IMAGE]
        .iter()
        .enumerate()
    {
        let mut disk_genesis = genesis;
        let mut disk_fic = FicChunk {
            header: fic.header,
            header_padding: fic.header_padding,
            cse_info: fic.cse_info,
            entry_count: fic.entry_count,
            entries: fic.entries,
            reserved: fic.reserved,
        };
        if disk_index < 3 && corrupt_disks[disk_index] {
            disk_genesis.timestamp = install_stamp.saturating_sub(1);
            disk_genesis.initial_key_hash[0] ^= 0xff;
            println!(
                "Corrupted disk{} Genesis for 3N testing: rewound epoch and invalid owner hash.",
                disk_index
            );
        }
        let mut conflict_meta = None;
        if Some(disk_index) == conflict_target_meta_disk {
            disk_fic.entries[0].meta_id = CONFLICT_META_CHUNK_NUMBER;
            conflict_meta = Some((&conflict_fmc_bytes, CONFLICT_META_CHUNK_NUMBER));
            println!(
                "Disk{} target_file.txt now points to conflicting meta chunk {}.",
                disk_index,
                CONFLICT_META_CHUNK_NUMBER
            );
        }
        let disk_fic_bytes = build_fic_bytes(&disk_fic, epoch, tk, pk)?;
        write_disk_image(
            disk_path,
            &disk_genesis,
            &kec,
            &disk_fic_bytes,
            &target_fmc_bytes,
            conflict_meta,
            &data_chunk_1,
            &data_chunk_2,
        )?;
    }

    println!(
        "Wrote cryptographically valid 3N test images to {}, {}, {}",
        Path::new(DISK0_IMAGE).display(),
        Path::new(DISK1_IMAGE).display(),
        Path::new(DISK2_IMAGE).display()
    );
    println!("WARNING: MK is the only recovery root. Store it offline.");
    print_hex32("MK", &MOCK_MASTER_KEY);
    print_hex32("KEC key bundle hash", &kec.key_bundle_hash);
    println!(
        "FIC descriptor offset {} size {}, FMC descriptor offset {} size {}, meta_id={}, pointers=[{}, {}]",
        FIC_CSE_INFO_OFFSET,
        FIC_CSE_INFO_SIZE,
        FMC_CSE_INFO_OFFSET,
        FMC_CSE_INFO_SIZE,
        TARGET_META_CHUNK_NUMBER,
        16,
        17
    );
    write_tuffkey_json(&kec)?;
    write_tuffdemo_json(profile)?;
    for disk_path in [DISK0_IMAGE, DISK1_IMAGE, DISK2_IMAGE, LEGACY_DISK_IMAGE] {
        let mut image = OpenOptions::new().read(true).write(true).open(disk_path)?;
        write_signature_samples(&mut image)?;
    }
    Ok(())
}

fn recover_existing_image(mk_arg: Option<&String>) -> Result<(), Box<dyn std::error::Error>> {
    let mk = parse_mk_arg(mk_arg).unwrap_or(MOCK_MASTER_KEY);
    let mut image = File::open(DISK0_IMAGE)?;
    let kec = read_kec(&mut image)?;
    let (_ok, tkw, pkw) = KeyEnvelopeManager::verify_mk_for_kec(&kec, &mk)
        .map_err(|err| format!("recover verify_mk_for_kec failed: {err:?}"))?;
    let tk = KeyEnvelopeManager::unwrap_tk(&kec.wrapped_tk, &tkw)
        .map_err(|err| format!("recover unwrap_tk failed: {err:?}"))?;
    let pk = KeyEnvelopeManager::unwrap_pk(&kec.wrapped_pk, &pkw)
        .map_err(|err| format!("recover unwrap_pk failed: {err:?}"))?;
    println!("Recover succeeded.");
    print_hex32("KEC key bundle hash", &kec.key_bundle_hash);
    println!("Restored TK prefix: {:02x}{:02x}{:02x}{:02x}", tk[0], tk[1], tk[2], tk[3]);
    println!("Restored PK prefix: {:02x}{:02x}{:02x}{:02x}", pk[0], pk[1], pk[2], pk[3]);
    Ok(())
}

fn rekey_existing_image(new_mk_arg: Option<&String>) -> Result<(), Box<dyn std::error::Error>> {
    let new_mk = parse_mk_arg(new_mk_arg)
        .ok_or_else(|| "rekey requires a 64-hex-digit NEW_MK".to_string())?;
    let mut image = OpenOptions::new().read(true).write(true).open(DISK0_IMAGE)?;
    let mut kec = read_kec(&mut image)?;
    let (_old_ok, old_tkw, old_pkw) = KeyEnvelopeManager::verify_mk_for_kec(&kec, &MOCK_MASTER_KEY)
        .map_err(|err| format!("rekey verify_mk_for_kec failed: {err:?}"))?;
    let tk = KeyEnvelopeManager::unwrap_tk(&kec.wrapped_tk, &old_tkw)
        .map_err(|err| format!("rekey unwrap_tk failed: {err:?}"))?;
    let pk = KeyEnvelopeManager::unwrap_pk(&kec.wrapped_pk, &old_pkw)
        .map_err(|err| format!("rekey unwrap_pk failed: {err:?}"))?;
    let (ok, tkw, pkw) = KeyEnvelopeManager::derive_wrap_keys(
        &new_mk,
        &kec.genesis_salt,
        &kec.fs_uuid,
        kec.kdf_params,
    );
    kec.mk_verifier = KeyEnvelopeManager::compute_mk_verifier(&ok);
    kec.wrapped_tk = KeyEnvelopeManager::wrap_tk(&tk, &tkw);
    kec.wrapped_pk = KeyEnvelopeManager::wrap_pk(&pk, &pkw);
    kec.key_bundle_hash = kec.compute_key_bundle_hash();
    write_chunk(&mut image, KEC_CHUNK_NUMBER, as_bytes(&kec))?;
    println!("Rekey succeeded.");
    print_hex32("New MK", &new_mk);
    print_hex32("New KEC key bundle hash", &kec.key_bundle_hash);
    Ok(())
}

fn parse_mk_arg(arg: Option<&String>) -> Option<[u8; 32]> {
    let arg = arg?;
    if arg.len() != 64 {
        return None;
    }
    let mut out = [0u8; 32];
    for idx in 0..32 {
        let byte = u8::from_str_radix(&arg[idx * 2..idx * 2 + 2], 16).ok()?;
        out[idx] = byte;
    }
    Some(out)
}

fn read_kec(image: &mut File) -> Result<KeyEnvelopeChunk, Box<dyn std::error::Error>> {
    let mut buffer = [0u8; GENESIS_SIZE];
    image.seek(SeekFrom::Start((GENESIS_SIZE as u64) * KEC_CHUNK_NUMBER))?;
    image.read_exact(&mut buffer)?;
    Ok(unsafe { core::ptr::read(buffer.as_ptr() as *const KeyEnvelopeChunk) })
}

fn build_fic_bytes(
    fic: &FicChunk,
    epoch: u64,
    tk: [u8; 32],
    pk: [u8; 32],
) -> Result<[u8; GENESIS_SIZE], Box<dyn std::error::Error>> {
    let mut fic_desc = CseDescriptor {
        chunk_id: [0x11; 16],
        epoch,
        info: fic.cse_info,
    };
    let mut fic_bytes = [0u8; GENESIS_SIZE];
    fic_bytes.copy_from_slice(as_bytes(fic));
    deposit_to_uq(&mut fic_bytes, &mut fic_desc, &tk, &pk, false)
        .map_err(|err| format!("FIC secure processing failed: {err:?}"))?;
    fic_bytes[FIC_CSE_INFO_OFFSET..FIC_CSE_INFO_OFFSET + FIC_CSE_INFO_SIZE]
        .copy_from_slice(as_bytes(&fic_desc.info));
    Ok(fic_bytes)
}

fn write_disk_image(
    path: &str,
    genesis: &Genesis,
    kec: &KeyEnvelopeChunk,
    fic_bytes: &[u8; GENESIS_SIZE],
    target_fmc_bytes: &[u8; GENESIS_SIZE],
    conflict_fmc: Option<(&[u8; GENESIS_SIZE], u64)>,
    data_chunk_1: &[u8; GENESIS_SIZE],
    data_chunk_2: &[u8; GENESIS_SIZE],
) -> Result<(), Box<dyn std::error::Error>> {
    let mut image = File::create(path)?;
    let zero_chunk = [0u8; GENESIS_SIZE];
    image.set_len(DISK_SIZE)?;
    image.write_all(as_bytes(genesis))?;
    flush_to_physical(&mut image, KEC_CHUNK_NUMBER, as_bytes(kec))?;
    flush_to_physical(&mut image, FIC_CHUNK_NUMBER, fic_bytes)?;
    flush_to_physical(&mut image, TARGET_META_CHUNK_NUMBER, target_fmc_bytes)?;
    flush_to_physical(&mut image, TARGET_FILE_EX_METADATA_CHUNK_NUMBER, &zero_chunk)?;
    flush_to_physical(&mut image, COPY_FILE_EX_METADATA_CHUNK_NUMBER, &zero_chunk)?;
    flush_to_physical(&mut image, MOVE_FILE_EX_METADATA_CHUNK_NUMBER, &zero_chunk)?;
    if let Some((conflict_fmc_bytes, conflict_meta_chunk)) = conflict_fmc {
        flush_to_physical(&mut image, conflict_meta_chunk, conflict_fmc_bytes)?;
    }
    flush_to_physical(&mut image, 16, data_chunk_1)?;
    flush_to_physical(&mut image, 17, data_chunk_2)?;
    image.flush()?;
    Ok(())
}

fn empty_fic_entry() -> FicEntry {
    FicEntry {
        filename_hash: [0u8; 32],
        tag_id: 0,
        meta_id: 0,
        entry_type: 0,
        reserved: [0u8; 15],
    }
}

fn as_bytes<T>(value: &T) -> &[u8] {
    unsafe { std::slice::from_raw_parts((value as *const T).cast::<u8>(), size_of::<T>()) }
}

fn sha256_name(name: &str) -> [u8; 32] {
    let mut hasher = Sha256::new();
    hasher.update(name.as_bytes());
    hasher.finalize().into()
}

fn cse_context(chunk_id: [u8; 16], epoch: u64, tk: [u8; 32], pk: [u8; 32]) -> tuff_core::cse::types::CseContext {
    tuff_core::cse::types::CseContext {
        chunk_id,
        epoch,
        tk,
        pk,
    }
}

fn deterministic_reserved<const N: usize>(chunk_id: [u8; 16], epoch: u64, label: u8) -> [u8; N] {
    let mut out = [0u8; N];
    CseEngine::fill_deterministic_padding(&mut out, chunk_id, epoch, label);
    out
}

fn write_signature_samples(image: &mut File) -> Result<(), Box<dyn std::error::Error>> {
    let signature_template = PqSignatureBlob {
        algorithm: PqSignatureAlgorithm::MlDsa44,
        domain: PqDomain::BootPolicy,
        length: 2420,
        bytes: [0u8; 2420],
    };

    let mut boot_policy = BootPolicy {
        policy_version: 1,
        policy_epoch: 100,
        allowed_genesis_version: 1,
        minimum_kec_version: 1,
        allowed_root_hashes: [
            sha256_name("root-a"),
            sha256_name("root-b"),
            sha256_name("root-c"),
            sha256_name("root-d"),
        ],
        allowed_update_signers: [sha256_name("signer-a"), sha256_name("signer-b")],
        required_pq_algorithm: PqSignatureAlgorithm::MlDsa44,
        reserved: [0u8; 19],
        signature: signature_template,
    };
    let boot_policy_hash = boot_policy.compute_hash();
    sign_scaffold_mldsa(
        &mut boot_policy.signature,
        &boot_policy_hash,
        &EMBEDDED_ROOT_POLICY_SEED,
    );

    let mut update_manifest = UpdateManifest {
        manifest_version: 1,
        manifest_epoch: 101,
        build_timestamp: 1_730_000_000,
        image_hash: sha256_name("image-current"),
        previous_image_hash: sha256_name("image-previous"),
        allowed_boot_hash: sha256_name("boot-policy"),
        action_type: 1,
        next_bank: 1,
        reserved: [0u8; 21],
        signature: PqSignatureBlob {
            domain: PqDomain::UpdateManifest,
            ..signature_template
        },
    };
    let update_manifest_hash = update_manifest.compute_hash();
    sign_scaffold_mldsa(
        &mut update_manifest.signature,
        &update_manifest_hash,
        &EMBEDDED_ROOT_POLICY_SEED,
    );

    let mut audit_log = AuditLogEntry {
        entry_version: 1,
        event_epoch: 102,
        timestamp_unix_ms: 1_730_000_123_456,
        event_type: 2,
        actor_class: 1,
        action_type: 7,
        result_code: 0,
        subject_hash: sha256_name("target_file.txt"),
        payload_hash: sha256_name("payload-hash"),
        previous_entry_hash: [0u8; 32],
        reserved: [0u8; 8],
        signature: PqSignatureBlob {
            domain: PqDomain::AuditLog,
            ..signature_template
        },
    };
    let audit_log_hash = audit_log.compute_hash();
    sign_scaffold_mldsa(
        &mut audit_log.signature,
        &audit_log_hash,
        &EMBEDDED_ROOT_POLICY_SEED,
    );

    let boot_policy_path = Path::new(TARGET_DIR).join("boot_policy_sample.bin");
    let update_manifest_path = Path::new(TARGET_DIR).join("update_manifest_sample.bin");
    let audit_log_path = Path::new(TARGET_DIR).join("audit_log_sample.bin");

    fs::write(&boot_policy_path, as_bytes(&boot_policy))?;
    fs::write(&update_manifest_path, as_bytes(&update_manifest))?;
    fs::write(&audit_log_path, as_bytes(&audit_log))?;
    write_chunk(image, BOOT_POLICY_CHUNK_NUMBER, as_bytes(&boot_policy))?;
    write_chunk(image, UPDATE_MANIFEST_CHUNK_NUMBER, as_bytes(&update_manifest))?;
    write_chunk(image, AUDIT_LOG_CHUNK_NUMBER, as_bytes(&audit_log))?;

    print_hex32_with_path(
        "BootPolicy hash",
        &boot_policy.compute_hash(),
        &boot_policy_path,
        BOOT_POLICY_CHUNK_NUMBER,
    );
    print_hex32_with_path(
        "UpdateManifest hash",
        &update_manifest.compute_hash(),
        &update_manifest_path,
        UPDATE_MANIFEST_CHUNK_NUMBER,
    );
    print_hex32_with_path(
        "AuditLogEntry hash",
        &audit_log.compute_hash(),
        &audit_log_path,
        AUDIT_LOG_CHUNK_NUMBER,
    );
    Ok(())
}

fn write_chunk(image: &mut File, chunk_number: u64, bytes: &[u8]) -> Result<(), Box<dyn std::error::Error>> {
    let mut chunk = [0u8; GENESIS_SIZE];
    chunk[..bytes.len()].copy_from_slice(bytes);
    image.seek(SeekFrom::Start((GENESIS_SIZE as u64) * chunk_number))?;
    image.write_all(&chunk)?;
    Ok(())
}

fn deposit_to_uq(
    block: &mut [u8; GENESIS_SIZE],
    desc: &mut CseDescriptor,
    tk: &[u8; 32],
    pk: &[u8; 32],
    is_data_chunk: bool,
) -> Result<(), tuff_core::cse::types::CseError> {
    if is_data_chunk {
        CseEngine::process_data_block_secure(block, desc, tk, pk, true)
    } else if desc.chunk_id == [0x11; 16] {
        CseEngine::process_fic_block_secure(block, desc, tk, pk, true)
    } else {
        CseEngine::process_fmc_block_secure(block, desc, tk, pk, true)
    }
}

fn flush_to_physical(
    image: &mut File,
    chunk_number: u64,
    bytes: &[u8],
) -> Result<(), Box<dyn std::error::Error>> {
    write_chunk(image, chunk_number, bytes)
}

fn print_hex32(label: &str, bytes: &[u8; 32]) {
    print!("{label}: ");
    for byte in bytes {
        print!("{:02x}", byte);
    }
    println!();
}

fn print_hex32_with_path(label: &str, bytes: &[u8; 32], path: &Path, chunk: u64) {
    print!("{label}: ");
    for byte in bytes {
        print!("{:02x}", byte);
    }
    println!(" ({} / chunk {})", path.display(), chunk);
}

fn write_tuffkey_json(kec: &KeyEnvelopeChunk) -> Result<(), Box<dyn std::error::Error>> {
    fs::create_dir_all(KEY_THUMB_DIR)?;
    let mut file = File::create(TUFFKEY_JSON_PATH)?;
    file.write_all(b"{\n  \"wrapped_tk\": \"")?;
    write_hex48(&mut file, &kec.wrapped_tk)?;
    file.write_all(b"\",\n  \"wrapped_pk\": \"")?;
    write_hex48(&mut file, &kec.wrapped_pk)?;
    file.write_all(b"\",\n  \"policy_root_hash\": \"")?;
    write_hex32(&mut file, &kec.policy_root_hash)?;
    file.write_all(b"\",\n  \"key_bundle_hash\": \"")?;
    write_hex32(&mut file, &kec.key_bundle_hash)?;
    file.write_all(b"\"\n}\n")?;
    println!("TUFFkey.json written to {}", TUFFKEY_JSON_PATH);
    Ok(())
}

fn write_tuffdemo_json(profile: Option<&str>) -> Result<(), Box<dyn std::error::Error>> {
    let _ = fs::remove_file(TUFFDEMO_JSON_PATH);
    let Some(profile) = profile else {
        return Ok(());
    };
    fs::create_dir_all(KEY_THUMB_DIR)?;
    let mut file = File::create(TUFFDEMO_JSON_PATH)?;
    writeln!(file, "{{")?;
    writeln!(file, "  \"validation_profile\": \"{}\"", profile)?;
    writeln!(file, "}}")?;
    println!("TUFFdemo.json written to {}", TUFFDEMO_JSON_PATH);
    Ok(())
}

fn validation_profile_mask(profile: Option<&str>) -> u8 {
    let Some(profile) = profile else {
        return 0;
    };
    let mut mask = 0u8;
    if profile.contains("rm_cp_mv") {
        mask |= 1 << 0;
    }
    if profile.contains("disk_full") {
        mask |= 1 << 1;
    }
    if profile.contains("flush_spoof") {
        mask |= 1 << 2;
    }
    if profile.contains("reclaim_interrupt") {
        mask |= 1 << 3;
    }
    if profile.contains("cse_probe") {
        mask |= 1 << 4;
    }
    mask
}

fn write_hex32(file: &mut File, bytes: &[u8; 32]) -> Result<(), Box<dyn std::error::Error>> {
    for byte in bytes {
        let chunk = [nibble_to_hex(byte >> 4), nibble_to_hex(byte & 0x0f)];
        file.write_all(&chunk)?;
    }
    Ok(())
}

fn write_hex48(file: &mut File, bytes: &[u8; 48]) -> Result<(), Box<dyn std::error::Error>> {
    for byte in bytes {
        let chunk = [nibble_to_hex(byte >> 4), nibble_to_hex(byte & 0x0f)];
        file.write_all(&chunk)?;
    }
    Ok(())
}

fn nibble_to_hex(nibble: u8) -> u8 {
    match nibble & 0x0f {
        0..=9 => b'0' + (nibble & 0x0f),
        _ => b'a' + ((nibble & 0x0f) - 10),
    }
}

fn sign_scaffold_mldsa(
    signature: &mut PqSignatureBlob,
    data_hash: &[u8; 32],
    key_seed: &[u8; 32],
) {
    let (_pk, sk) = fips204::ml_dsa_44::KG::keygen_from_seed(key_seed);
    let msg = mldsa_signing_message(data_hash, signature.domain);
    let raw = sk
        .try_sign_with_seed(key_seed, &msg, &[])
        .expect("ml-dsa signing must succeed in builder");
    signature.bytes[..raw.len()].copy_from_slice(&raw);
}
