(function () {
  const BUILD_TAG = "popup-20260210-2";
  console.info("[TUFF popup]", BUILD_TAG);
  const DEFAULT_BASE = "http://127.0.0.1:8787";
  const PAUSE_KEY = "TUFF_ADDON_PAUSED";
  const FALLBACK_BASES = [
    "http://127.0.0.1:8787",
    "http://localhost:8787",
  ];

  function normalizeBase(raw) {
    if (typeof raw !== "string") return DEFAULT_BASE;
    const t = raw.trim();
    if (!t) return DEFAULT_BASE;
    return t.replace(/\/+$/, "");
  }

  function getBase() {
    return new Promise((resolve) => {
      if (typeof chrome === "undefined" || !chrome.storage || !chrome.storage.local) {
        resolve(DEFAULT_BASE);
        return;
      }
      chrome.storage.local.get(["TUFF_WEB_BASE"], (res) => {
        resolve(normalizeBase(res && res.TUFF_WEB_BASE));
      });
    });
  }

  function getPaused() {
    return new Promise((resolve) => {
      if (typeof chrome === "undefined" || !chrome.storage || !chrome.storage.local) {
        resolve(false);
        return;
      }
      chrome.storage.local.get([PAUSE_KEY], (res) => {
        resolve(Boolean(res && res[PAUSE_KEY]));
      });
    });
  }

  function setPaused(next) {
    return new Promise((resolve) => {
      if (typeof chrome === "undefined" || !chrome.storage || !chrome.storage.local) {
        resolve();
        return;
      }
      chrome.storage.local.set({ [PAUSE_KEY]: Boolean(next) }, () => resolve());
    });
  }

  function uniqueBases(base) {
    const out = [];
    const push = (v) => {
      if (!v || out.includes(v)) return;
      out.push(v);
    };
    push(base);
    FALLBACK_BASES.forEach(push);
    return out;
  }

  async function fetchPendingFrom(base) {
    const res = await fetch(`${base}/facts/pending`, { cache: "no-store" });
    if (!res.ok) return [];
    return await res.json();
  }

  function wsUrlFromBase(base) {
    try {
      const u = new URL(base);
      const proto = u.protocol === "https:" ? "wss:" : "ws:";
      return `${proto}//${u.host}`;
    } catch (_) {
      return "ws://127.0.0.1:8787";
    }
  }

  async function openHistory() {
    const base = await getBase();
    if (typeof chrome !== "undefined" && chrome.tabs) {
      chrome.tabs.create({ url: `${base}/history` });
      window.close();
    } else {
      window.open(`${base}/history`, "_blank");
    }
  }

  async function fetchPending() {
    const base = await getBase();
    const bases = uniqueBases(base);
    for (const b of bases) {
      try {
        return await fetchPendingFrom(b);
      } catch (_) {
        // try next base
      }
    }
    return [];
  }

  function sendWsMessage(message) {
    return getBase().then((base) => {
      const bases = uniqueBases(base);
      let idx = 0;
      return new Promise((resolve, reject) => {
        const tryNext = (lastErr) => {
          if (idx >= bases.length) {
            reject(lastErr || new Error("ws connect failed"));
            return;
          }
          const wsUrl = wsUrlFromBase(bases[idx++]);
          let ws;
          try {
            ws = new WebSocket(wsUrl);
          } catch (e) {
            tryNext(e);
            return;
          }
          const timer = setTimeout(() => {
            try { ws.close(); } catch (_) {}
            tryNext(new Error("ws timeout"));
          }, 2500);

          ws.onopen = () => {
            ws.send(JSON.stringify(message));
            setTimeout(() => {
              clearTimeout(timer);
              try { ws.close(); } catch (_) {}
              resolve();
            }, 180);
          };
          ws.onerror = (e) => {
            clearTimeout(timer);
            tryNext(e);
          };
        };
        tryNext(null);
      });
    });
  }

  async function approve(id) {
    await sendWsMessage({
      type: "ApproveFact",
      id: crypto.randomUUID(),
      ts: new Date().toISOString(),
      payload: { id }
    });
  }

  async function repropose(tag, value) {
    await sendWsMessage({
      type: "ProposeFact",
      id: crypto.randomUUID(),
      ts: new Date().toISOString(),
      payload: { tag, value }
    });
  }

  function renderList(items) {
    const list = document.getElementById("list");
    list.innerHTML = "";
    if (!Array.isArray(items) || items.length === 0) {
      const empty = document.createElement("div");
      empty.className = "muted";
      empty.textContent = "pending はありません";
      list.appendChild(empty);
      return;
    }

    items.forEach((item) => {
      const card = document.createElement("div");
      card.className = "item";

      const tag = document.createElement("div");
      tag.className = "tag";
      tag.textContent = item.tag || "(no-tag)";

      const val = document.createElement("div");
      val.className = "val";
      val.textContent = item.value || "";

      const actions = document.createElement("div");
      actions.className = "actions";

      const edit = document.createElement("button");
      edit.className = "btn";
      edit.textContent = "Edit";
      edit.addEventListener("click", async () => {
        const newTag = prompt("Tag", item.tag || "");
        if (!newTag) return;
        const newVal = prompt("Value", item.value || "");
        if (!newVal) return;
        await repropose(newTag, newVal);
        await load();
      });

      const approveBtn = document.createElement("button");
      approveBtn.className = "btn ok";
      approveBtn.textContent = "Approve";
      approveBtn.addEventListener("click", async () => {
        await approve(item.id);
        await load();
      });

      actions.append(edit, approveBtn);
      card.append(tag, val, actions);
      list.appendChild(card);
    });
  }

  function renderPauseUi(paused) {
    const btn = document.getElementById("pause-toggle");
    const status = document.getElementById("pause-status");
    if (btn) {
      btn.textContent = paused ? "再開" : "一時停止";
      btn.className = paused ? "btn ok" : "btn warn";
    }
    if (status) {
      status.textContent = paused ? "状態: 一時停止中" : "状態: 稼働中";
    }
  }

  async function load() {
    try {
      const items = await fetchPending();
      renderList(items);
    } catch (_) {
      renderList([]);
    }
  }

  document.getElementById("open-history")?.addEventListener("click", openHistory);
  document.getElementById("refresh")?.addEventListener("click", load);
  document.getElementById("pause-toggle")?.addEventListener("click", async () => {
    const current = await getPaused();
    await setPaused(!current);
    renderPauseUi(!current);
  });
  getPaused().then(renderPauseUi);
  load();
})();
