// GPT-Booster v5.2 ultra-passive — ChatGPT output aware (standalone, body observer)

const DEBUG = false;
const DEV_MODE = false;
const BUILD_TAG = "booster-20260210-2";
if (DEBUG) console.info("[TUFF booster]", BUILD_TAG);
const CHATGPT_EMERGENCY_DISABLE = false;
const OBS_CONFIG = { childList: true, subtree: true };
const TIMESTAMP_STYLE_ID = "gpt-booster-visible-timestamp-style";
const BASE_SELECTORS = {
  default: {
    user: [
      '[data-message-author-role="user"]',
      '.user-query',
      '[data-test-id="user-query"]',
      'user-query',
      '[data-testid*="user"]'
    ].join(", "),
    assistant: [
      '[data-message-author-role="assistant"]',
      '.model-response',
      '[data-test-id="model-response"]',
      'message-content',
      '[data-testid*="assistant"]',
      '[data-testid*="model"]'
    ].join(", "),
    rootFallback: [
      '[role="article"]',
      'main article',
      'article[data-testid*="conversation"]',
      'article[data-message-id]',
      '[data-testid*="conversation-turn"]'
    ].join(", "),
    turns: [
      '[data-message-author-role]',
      '.user-query',
      '.model-response',
      '[data-test-id="user-query"]',
      '[data-test-id="model-response"]',
      'user-query',
      'message-content',
      'main article',
      'article[data-testid*="conversation"]',
      '[data-testid*="conversation-turn"]'
    ].join(", ")
  },
  gemini: {
    user: [
      'div[data-message-author-role="user"]',
      '[data-test-id="user-query"]',
      'user-query',
      'div[class*="user-query"]'
    ].join(", "),
    assistant: [
      'div[data-message-author-role="model"]',
      'div[data-message-author-role="assistant"]',
      '[data-test-id="model-response"]',
      'model-response',
      'message-content[data-message-author-role="model"]',
      'message-content[data-message-author-role="assistant"]'
    ].join(", "),
    turns: [
      'div[data-message-author-role]',
      '[data-test-id="user-query"]',
      '[data-test-id="model-response"]',
      'user-query',
      'model-response',
      'message-content[data-message-author-role]'
    ].join(", ")
  }
};
const STABLE_TEXT_MS = 900;
const SAFE_MODEL_RE = /\bgpt-?5\b/i;
const WS_URL = "ws://127.0.0.1:8787";
const WS_RETRY_BASE_MS = 800;
const WS_RETRY_MAX_MS = 8000;
const WS_SEND_DEBOUNCE_MS = 180;
const SEND_DELAY = 600;
const CHATGPT_POLL_INTERVAL_MS = 1200;
const CHATGPT_STABLE_HOLD_MS = 1200;
const CHATGPT_DOM_SAFE_MODE = true;
const SHOW_ALL_TURN_TIMESTAMPS = true;
const STOP_OVERLAY_ID = "tuff-brg-stop-overlay";
const CONTINUE_BUTTON_ID = "tuff-brg-continue-btn";
const META_COPY_ID = "tuff-brg-meta-copy";
const RETRY_BUTTON_ID = "tuff-brg-retry-btn";
const SELECTOR_WARNING_ID = "tuff-brg-selector-warning";
const DECISION_FLOAT_ID = "tuff-brg-decision-float";
const DECISION_STYLE_ID = "tuff-brg-decision-style";
const USER_TS_LITERAL_PREFIX = "USER";
const USER_TS_COOLDOWN_MS = 600;
const PAUSE_KEY = "TUFF_ADDON_PAUSED";

let lastScrollTop = null;
let activeAssistant = null;
let lastAssistantText = "";
let lastAssistantChange = 0;
let scrollClampEnabled = false;
let mutationDebounceTimer = null;
let finalizeTimer = null;
let responseSafeMode = false;
let ws = null;
let wsRetryTimer = null;
let wsRetryDelay = WS_RETRY_BASE_MS;
let wsReady = false;
let pendingFragments = [];
let convoId = crypto.randomUUID();
let seq = 0;
let lastSentText = "";
let lastSentHash = "";
let sendTimer = null;
let lastAbstractId = null;
let stopActive = false;
let aiOrigin = "Gemini";
let aiOriginOverride = "";
let tuffWebBase = "";
let lastJudgeStatus = null;
let lastJudgeReason = null;
let lastJudgeClaim = null;
let lastJudgeTs = null;
let lastDebugFragment = "";
let lastDebugTs = 0;
let activeSelectors = buildSelectorConfig();
let selectorMissSince = 0;
let chatgptLiteTimer = null;
let tsCopyHotkeyBound = false;
let chatgptTick = 0;
let decisionFadeTimer = null;
let lastJudgeFragmentHash = "";
const sentHashOrder = [];
const hashToTurnKey = new Map();
const userTsInjectedAt = new WeakMap();
let addonPaused = false;

window.__GPT_BOOSTER_NEW__ = true;

function nowRfc3339() {
  return new Date().toISOString();
}

function isAddonPaused() {
  return addonPaused;
}

function isGeminiPage() {
  return location.hostname.includes("gemini.google.com");
}

function isChatGptPage() {
  const host = (location.hostname || "").toLowerCase();
  return host.includes("chatgpt.com") || host.includes("chat.openai.com");
}

function shouldAvoidDomWrites() {
  return CHATGPT_DOM_SAFE_MODE && isChatGptPage();
}

function detectAiOriginFromUrl() {
  const host = (location.hostname || "").toLowerCase();
  if (host.includes("chatgpt.com") || host.includes("openai.com")) return "ChatGPT";
  if (host.includes("gemini.google.com")) return "Gemini";
  return "Unknown";
}

function applyAiOrigin() {
  if (aiOriginOverride) {
    aiOrigin = aiOriginOverride;
    return;
  }
  const detected = detectAiOriginFromUrl();
  if (detected !== "Unknown") aiOrigin = detected;
}

function validSelectorString(value, fallback) {
  return typeof value === "string" && value.trim() ? value.trim() : fallback;
}

function buildSelectorConfig(overrideRaw) {
  const o = overrideRaw && typeof overrideRaw === "object" ? overrideRaw : {};
  const od = o.default && typeof o.default === "object" ? o.default : {};
  const og = o.gemini && typeof o.gemini === "object" ? o.gemini : {};
  return {
    default: {
      user: validSelectorString(od.user, BASE_SELECTORS.default.user),
      assistant: validSelectorString(od.assistant, BASE_SELECTORS.default.assistant),
      rootFallback: validSelectorString(od.rootFallback, BASE_SELECTORS.default.rootFallback),
      turns: validSelectorString(od.turns, BASE_SELECTORS.default.turns)
    },
    gemini: {
      user: validSelectorString(og.user, BASE_SELECTORS.gemini.user),
      assistant: validSelectorString(og.assistant, BASE_SELECTORS.gemini.assistant),
      turns: validSelectorString(og.turns, BASE_SELECTORS.gemini.turns)
    }
  };
}

function selectorFor(kind) {
  if (isGeminiPage() && activeSelectors.gemini[kind]) {
    return activeSelectors.gemini[kind];
  }
  return activeSelectors.default[kind];
}

function debugLogFragment(source, text) {
  if (!DEBUG && !DEV_MODE) return;
  const now = Date.now();
  if (text === lastDebugFragment && now - lastDebugTs < 1000) return;
  lastDebugFragment = text;
  lastDebugTs = now;
  const snippet = text.length > 160 ? `${text.slice(0, 160)}...` : text;
  console.log(`[TUFF][${source}] ${snippet}`);
}

function wsScheduleReconnect() {
  if (wsRetryTimer) return;
  wsRetryTimer = setTimeout(() => {
    wsRetryTimer = null;
    wsRetryDelay = Math.min(WS_RETRY_MAX_MS, wsRetryDelay * 2);
    wsConnect();
  }, wsRetryDelay);
}

function wsConnect() {
  try {
    ws = new WebSocket(WS_URL);
  } catch (_) {
    if (DEV_MODE) console.warn("[TUFF][WS] connect failed", WS_URL);
    wsScheduleReconnect();
    return;
  }

  ws.addEventListener("open", () => {
    wsReady = true;
    if (DEV_MODE) console.info("[TUFF][WS] connected", WS_URL);
    wsRetryDelay = WS_RETRY_BASE_MS;
    flushPendingFragments();
  });

  ws.addEventListener("close", () => {
    wsReady = false;
    if (DEV_MODE) console.warn("[TUFF][WS] closed");
    wsScheduleReconnect();
  });

  ws.addEventListener("error", () => {
    wsReady = false;
    if (DEV_MODE) console.warn("[TUFF][WS] error");
    wsScheduleReconnect();
  });

  ws.addEventListener("message", (ev) => {
    if (typeof ev.data !== "string") return;
    let msg;
    try {
      msg = JSON.parse(ev.data);
    } catch (_) {
      return;
    }

    if (msg.type === "JudgeResult" && msg.payload) {
      if (msg.payload.abstract_id) {
        lastAbstractId = msg.payload.abstract_id;
      }
      lastJudgeStatus = msg.payload.status || null;
      lastJudgeReason = msg.payload.reason || null;
      lastJudgeClaim = msg.payload.claim || null;
      lastJudgeTs = msg.ts || nowRfc3339();
      const hashFromPayload =
        (msg.payload.fragment_hash && String(msg.payload.fragment_hash)) ||
        (msg.payload.claim ? hashText(String(msg.payload.claim)) : "");
      if (hashFromPayload) {
        lastJudgeFragmentHash = hashFromPayload;
      }
    }

    if (msg.type === "ControlCommand" && msg.payload) {
      const decision = String(msg.payload.decision || msg.payload.command || "").toUpperCase();
      if (decision !== "STOP" && decision !== "CONTINUE") return;
      const hashFromPayload =
        (msg.payload.fragment_hash && String(msg.payload.fragment_hash)) ||
        (msg.payload.claim_hash && String(msg.payload.claim_hash)) ||
        "";
      const decisionHash = hashFromPayload || lastJudgeFragmentHash || "";
      const detail = msg.payload.detail || decision;
      if (DEV_MODE) {
        console.log("[TUFF][decision]", { decision, fragment_hash: decisionHash, payload: msg.payload });
      }
      if (isChatGptPage()) {
        applyDecisionToTurn(decision, decisionHash, detail);
      } else if (decision === "STOP") {
        activateStopOverlay(detail);
      } else if (decision === "CONTINUE") {
        deactivateStopOverlay();
      }
    }
  });
}

function ensureDecisionStyle() {
  if (document.getElementById(DECISION_STYLE_ID)) return;
  const style = document.createElement("style");
  style.id = DECISION_STYLE_ID;
  style.textContent = `
#${DECISION_FLOAT_ID} {
  position: fixed;
  right: 14px;
  top: 14px;
  z-index: 2147483646;
  color: #fff;
  font: 600 12px/1.35 system-ui, -apple-system, Segoe UI, sans-serif;
  border-radius: 10px;
  padding: 9px 12px;
  box-shadow: 0 8px 22px rgba(0,0,0,0.25);
  pointer-events: none;
  opacity: 0;
  transform: translateY(-4px);
  transition: opacity 160ms ease, transform 160ms ease;
}
#${DECISION_FLOAT_ID}.show {
  opacity: 0.98;
  transform: translateY(0);
}
`;
  document.head.appendChild(style);
}

function showDecisionOverlay(decision, detail, fragmentHash) {
  if (!document.body) return;
  ensureDecisionStyle();
  let el = document.getElementById(DECISION_FLOAT_ID);
  if (!el) {
    el = document.createElement("div");
    el.id = DECISION_FLOAT_ID;
    document.body.appendChild(el);
  }
  const isStop = decision === "STOP";
  el.style.background = isStop ? "rgba(185, 28, 28, 0.96)" : "rgba(22, 163, 74, 0.96)";
  el.textContent = `${decision}${detail ? ` | ${detail}` : ""}${fragmentHash ? ` | #${fragmentHash.slice(0, 8)}` : ""}`;
  el.classList.add("show");
  if (decisionFadeTimer) clearTimeout(decisionFadeTimer);
  decisionFadeTimer = setTimeout(() => {
    const cur = document.getElementById(DECISION_FLOAT_ID);
    if (cur) cur.classList.remove("show");
  }, 6000);
}

function ensureTurnKey(node) {
  if (!(node instanceof HTMLElement)) return "";
  if (node.dataset.tuffTurnKey) return node.dataset.tuffTurnKey;
  const key = `turn_${crypto.randomUUID()}`;
  node.dataset.tuffTurnKey = key;
  return key;
}

function rememberFragmentHash(fragmentHash, node) {
  if (!fragmentHash || !(node instanceof HTMLElement)) return;
  const key = ensureTurnKey(node);
  if (!key) return;
  hashToTurnKey.set(fragmentHash, key);
  sentHashOrder.push(fragmentHash);
  if (sentHashOrder.length > 100) {
    const old = sentHashOrder.shift();
    if (old) hashToTurnKey.delete(old);
  }
}

function findTurnByHash(fragmentHash) {
  if (!fragmentHash) return null;
  const key = hashToTurnKey.get(fragmentHash);
  if (!key) return null;
  return document.querySelector(`[data-tuff-turn-key="${key}"]`);
}

function applyDecisionChip(node, decision) {
  if (!(node instanceof HTMLElement)) return;
  let tsBadge = node.querySelector(":scope > .gpt-booster-inline-ts-assistant");
  if (!tsBadge) {
    upsertVisibleTimestamp(node, "assistant");
    tsBadge = node.querySelector(":scope > .gpt-booster-inline-ts-assistant");
  }
  if (!tsBadge) return;
  let chip = tsBadge.querySelector(":scope > .tuff-decision-chip");
  if (!chip) {
    chip = document.createElement("span");
    chip.className = "tuff-decision-chip";
    chip.style.marginLeft = "6px";
    chip.style.padding = "1px 5px";
    chip.style.borderRadius = "999px";
    chip.style.fontSize = "10px";
    chip.style.fontWeight = "700";
    chip.style.letterSpacing = "0.01em";
    tsBadge.appendChild(chip);
  }
  if (decision === "STOP") {
    chip.textContent = "STOP";
    chip.style.background = "rgba(185, 28, 28, 0.16)";
    chip.style.color = "#991b1b";
    chip.style.border = "1px solid rgba(185, 28, 28, 0.35)";
  } else {
    chip.textContent = "CONTINUE";
    chip.style.background = "rgba(22, 163, 74, 0.16)";
    chip.style.color = "#166534";
    chip.style.border = "1px solid rgba(22, 163, 74, 0.35)";
  }
}

function applyDecisionToTurn(decision, fragmentHash, detail) {
  let node = findTurnByHash(fragmentHash);
  if (!(node instanceof HTMLElement)) {
    node = getLatestAssistant();
  }
  if (!(node instanceof HTMLElement)) {
    showDecisionOverlay(decision, detail, fragmentHash);
    return;
  }
  ensureTurnKey(node);
  const already = node.dataset.tuffDecisionApplied || "";
  if (already === decision) return;
  showDecisionOverlay(decision, detail, fragmentHash);
  node.dataset.tuffDecisionApplied = decision;
  if (fragmentHash) node.dataset.tuffDecisionHash = fragmentHash;
  if (decision === "STOP") {
    node.style.opacity = "0.5";
    node.style.transition = "opacity 140ms ease";
    disableClamp();
  } else {
    node.style.opacity = "";
  }
  applyDecisionChip(node, decision);
}

function loadAddonSettings() {
  if (typeof chrome === "undefined" || !chrome.storage || !chrome.storage.local) {
    return Promise.resolve();
  }
  return new Promise((resolve) => {
    chrome.storage.local.get(["TUFF_WEB_BASE", "AI_ORIGIN", "OVERRIDE_SELECTORS"], (res) => {
      if (res && typeof res.TUFF_WEB_BASE === "string") {
        tuffWebBase = res.TUFF_WEB_BASE.trim();
      }
      if (res && typeof res.AI_ORIGIN === "string" && res.AI_ORIGIN.trim()) {
        aiOriginOverride = res.AI_ORIGIN.trim();
      }
      if (res && res.OVERRIDE_SELECTORS) {
        try {
          const raw =
            typeof res.OVERRIDE_SELECTORS === "string"
              ? JSON.parse(res.OVERRIDE_SELECTORS)
              : res.OVERRIDE_SELECTORS;
          activeSelectors = buildSelectorConfig(raw);
        } catch (_) {
          activeSelectors = buildSelectorConfig();
        }
      } else {
        activeSelectors = buildSelectorConfig();
      }
      applyAiOrigin();
      resolve();
    });
  });
}

function ensureStopOverlayStyle() {
  if (document.getElementById("tuff-brg-stop-style")) return;
  const style = document.createElement("style");
  style.id = "tuff-brg-stop-style";
  style.textContent = `
#${STOP_OVERLAY_ID} {
  position: fixed;
  inset: 0;
  background: rgba(8, 8, 8, 0.85);
  color: #f6f6f6;
  z-index: 2147483647;
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: 24px;
  font-family: system-ui, -apple-system, Segoe UI, sans-serif;
}
#${STOP_OVERLAY_ID} .card {
  max-width: 520px;
  background: #111;
  border: 1px solid #333;
  border-radius: 12px;
  padding: 18px 20px;
  box-shadow: 0 10px 40px rgba(0,0,0,0.4);
}
#${STOP_OVERLAY_ID} .title { font-size: 18px; margin-bottom: 10px; }
#${STOP_OVERLAY_ID} .reason { font-size: 13px; opacity: 0.85; }
#${STOP_OVERLAY_ID} .link { margin-top: 12px; font-size: 12px; color: #7dd3fc; }
#${META_COPY_ID} { margin-top: 10px; font-size: 12px; color: #e5e7eb; user-select: text; cursor: copy; }
#${RETRY_BUTTON_ID} { margin-left: 8px; }
`;
  document.head.appendChild(style);
}

function buildMetaLine() {
  const ts = lastJudgeTs || nowRfc3339();
  const status = lastJudgeStatus || "UNKNOWN";
  const reason = lastJudgeReason ? ` (${lastJudgeReason})` : "";
  const claim = lastJudgeClaim || "(unknown claim)";
  return `[${ts}] [AI: ${aiOrigin}] Claim: ${claim} | Result: ${status}${reason}`;
}

function buildAbstractLink() {
  if (!lastAbstractId) return null;
  if (!tuffWebBase) return null;
  const base = tuffWebBase.replace(/\/+$/, "");
  return `${base}/abstract/${lastAbstractId}`;
}

function activateStopOverlay(detail) {
  stopActive = true;
  ensureStopOverlayStyle();
  if (document.getElementById(STOP_OVERLAY_ID)) return;
  const overlay = document.createElement("div");
  overlay.id = STOP_OVERLAY_ID;
  const abstractLink = buildAbstractLink();
  const link = abstractLink
    ? `Abstract: <a href="${abstractLink}" target="_blank" rel="noreferrer">${lastAbstractId}</a>`
    : lastAbstractId
      ? `Abstract ID: ${lastAbstractId}`
      : "Abstract ID: (pending)";
  overlay.innerHTML = `
    <div class="card">
      <div class="title">STOP: 検証失敗を検知</div>
      <div class="reason">${detail || "Smoke detected"}</div>
      <div class="link">${link}</div>
      <div id="${META_COPY_ID}">${buildMetaLine()}</div>
      <div style="margin-top:12px;">
        <button id="${CONTINUE_BUTTON_ID}" style="padding:6px 12px;border-radius:8px;border:1px solid #444;background:#222;color:#eee;cursor:pointer;">
          自己責任で続行
        </button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
  const btn = document.getElementById(CONTINUE_BUTTON_ID);
  if (btn) {
    btn.addEventListener("click", () => {
      sendManualOverride();
    });
  }
  const meta = document.getElementById(META_COPY_ID);
  if (meta) {
    meta.addEventListener("click", async () => {
      try {
        await navigator.clipboard.writeText(meta.textContent || "");
      } catch (_) {
        // Fallback: user can still select text manually.
      }
    });
  }
}

function deactivateStopOverlay() {
  stopActive = false;
  const overlay = document.getElementById(STOP_OVERLAY_ID);
  if (overlay) overlay.remove();
}

function ensureSelectorWarning(message) {
  if (shouldAvoidDomWrites()) return;
  if (document.getElementById(SELECTOR_WARNING_ID)) return;
  const box = document.createElement("div");
  box.id = SELECTOR_WARNING_ID;
  box.textContent = message;
  box.style.cssText = [
    "position:fixed",
    "right:12px",
    "bottom:12px",
    "z-index:2147483646",
    "padding:10px 12px",
    "border:1px solid #8b5e34",
    "background:#fff6e5",
    "color:#6b3f1d",
    "font-size:12px",
    "border-radius:8px",
    "max-width:320px",
    "line-height:1.4"
  ].join(";");
  document.body.appendChild(box);
}

function clearSelectorWarning() {
  if (shouldAvoidDomWrites()) return;
  const box = document.getElementById(SELECTOR_WARNING_ID);
  if (box) box.remove();
}

function buildStreamFragmentPayload(fragment) {
  const eventTs = nowRfc3339();
  const origin = isChatGptPage() ? "chatgpt" : isGeminiPage() ? "gemini" : "unknown";
  const fragmentHash = hashText(fragment || "");
  return {
    type: "StreamFragment",
    id: crypto.randomUUID(),
    ts: nowRfc3339(),
    payload: {
      conversation_id: convoId,
      sequence_number: seq++,
      url: window.location.href,
      selector: selectorFor("assistant"),
      fragment,
      event_ts: eventTs,
      role: "assistant",
      origin,
      fragment_hash: fragmentHash,
      context: {
        page_title: document.title || "",
        locale: navigator.language || ""
      }
    }
  };
}

function sendStreamFragment(fragment) {
  if (!fragment) return false;
  if (!wsReady || !ws || ws.readyState !== WebSocket.OPEN) {
    queuePendingFragment(fragment);
    return false;
  }
  try {
    debugLogFragment("send", fragment);
    const hash = hashText(fragment);
    const turnNode = getLatestAssistant();
    if (turnNode instanceof HTMLElement) {
      rememberFragmentHash(hash, turnNode);
    }
    const msg = buildStreamFragmentPayload(fragment);
    ws.send(JSON.stringify(msg));
    if (DEBUG) console.log("[TUFF] Sent to server!");
    return true;
  } catch (_) {
    queuePendingFragment(fragment);
    return false;
  }
}

function scheduleSend(fragment) {
  if (isAddonPaused()) return;
  if (!fragment || fragment.length < 4) return;
  const nextHash = hashText(fragment);
  if (fragment === lastSentText || nextHash === lastSentHash) return;
  if (isChatGptPage()) {
    const elapsed = Date.now() - lastAssistantChange;
    if (elapsed < CHATGPT_STABLE_HOLD_MS) return;
  }
  if (sendTimer) clearTimeout(sendTimer);
  sendTimer = setTimeout(() => {
    sendTimer = null;
    if (DEBUG || DEV_MODE) {
      const snippet = fragment.length > 10 ? `${fragment.slice(0, 10)}...` : fragment;
      console.log("[TUFF][send]", snippet);
    }
    sendStreamFragment(fragment);
    lastSentText = fragment;
    lastSentHash = nextHash;
  }, SEND_DELAY);
}

function queuePendingFragment(fragment) {
  if (!fragment) return;
  pendingFragments.push(fragment);
  if (pendingFragments.length > 50) {
    pendingFragments = pendingFragments.slice(-50);
  }
}

function flushPendingFragments() {
  if (!wsReady || !ws || ws.readyState !== WebSocket.OPEN) return;
  if (!pendingFragments.length) return;
  const queue = pendingFragments.slice();
  pendingFragments = [];
  queue.forEach((fragment) => {
    try {
      debugLogFragment("send", fragment);
      const hash = hashText(fragment);
      const turnNode = getLatestAssistant();
      if (turnNode instanceof HTMLElement) {
        rememberFragmentHash(hash, turnNode);
      }
      const msg = buildStreamFragmentPayload(fragment);
      ws.send(JSON.stringify(msg));
      if (DEBUG) console.log("[TUFF] Sent to server!");
    } catch (_) {
      queuePendingFragment(fragment);
    }
  });
}

function sendManualOverride() {
  if (isAddonPaused()) return;
  if (!wsReady || !ws || ws.readyState !== WebSocket.OPEN) return;
  const msg = {
    type: "ControlCommand",
    id: crypto.randomUUID(),
    ts: nowRfc3339(),
    payload: {
      command: "CONTINUE",
      trigger: "ManualOverride",
      detail: "User override",
      manual_override: {
        conversation_id: convoId,
        abstract_id: lastAbstractId,
        note: "No reason provided"
      }
    }
  };
  ws.send(JSON.stringify(msg));
}

function detectModelTokenFromLocation() {
  try {
    const url = new URL(window.location.href);
    const candidates = [url.searchParams.get("model"), url.searchParams.get("m"), url.hash, url.pathname];
    for (const value of candidates) {
      if (typeof value !== "string") continue;
      if (SAFE_MODEL_RE.test(value)) return value;
    }
  } catch (_) {
    // Ignore URL parsing issues.
  }
  return "";
}

function detectModelTokenFromUi() {
  const modelSwitcher = document.querySelector(
    '[data-testid*="model"], button[aria-haspopup="menu"], [aria-label*="Model"], [aria-label*="model"]'
  );
  if (!modelSwitcher) return "";
  const text = (modelSwitcher.textContent || "").replace(/\s+/g, " ").trim();
  return text;
}

function refreshResponseSafeMode() {
  const token = `${detectModelTokenFromLocation()} ${detectModelTokenFromUi()}`;
  responseSafeMode = SAFE_MODEL_RE.test(token);
}

function isThinking(root) {
  if (!root) return false;
  const testId = root.getAttribute("data-testid") || "";
  if (/thinking|generating|streaming/i.test(testId)) return true;
  const className = typeof root.className === "string" ? root.className : "";
  if (/thinking|generating|streaming/i.test(className)) return true;
  const thinkingNode = root.querySelector(
    '[data-testid*="thinking"], [data-testid*="generating"], [data-testid*="streaming"], .thinking, .generating, .streaming'
  );
  return Boolean(thinkingNode);
}

function hasStreamingCursor(root) {
  if (!root) return false;
  return Boolean(
    root.querySelector(
      '[data-testid="cursor"], [data-testid*="cursor"], .cursor, .result-streaming, .typing, [class*="streaming"]'
    )
  );
}

function pickLatestWithText(nodes, hintedRole = null) {
  const list = Array.from(nodes || []);
  for (let i = list.length - 1; i >= 0; i -= 1) {
    const node = list[i];
    if (!(node instanceof HTMLElement)) continue;
    const role = normalizeRole(detectRole(node) || hintedRole);
    const text = extractNodeText(node);
    if (isGeminiUiOnlyControlNode(node, role, text)) continue;
    if (text.length > 0) return node;
  }
  return null;
}

function getLatestGeminiAssistant() {
  const nodes = document.querySelectorAll(selectorFor("assistant"));
  return pickLatestWithText(nodes, "assistant");
}

function getLatestChatGptAssistant() {
  const profile = window.__TUFF_SELECTOR_PROFILE__;
  if (profile && typeof profile.pickLatestCompleteAssistantBlock === "function") {
    const picked = profile.pickLatestCompleteAssistantBlock(document);
    if (picked instanceof HTMLElement) return picked;
  }
  const nodes = document.querySelectorAll(selectorFor("assistant"));
  return pickLatestWithText(nodes, "assistant");
}

function getLatestAssistant() {
  if (isChatGptPage()) {
    return getLatestChatGptAssistant() || document.querySelector(selectorFor("rootFallback"));
  }
  if (isGeminiPage()) {
    return getLatestGeminiAssistant() || document.querySelector(selectorFor("rootFallback"));
  }
  const assistants = document.querySelectorAll(selectorFor("assistant"));
  const picked = pickLatestWithText(assistants, "assistant");
  if (picked) return picked;
  const fallbackNodes = document.querySelectorAll(selectorFor("rootFallback"));
  return pickLatestWithText(fallbackNodes) || fallbackNodes[fallbackNodes.length - 1] || null;
}

function ensureTimestampStyle() {
  if (document.getElementById(TIMESTAMP_STYLE_ID)) return;
  const style = document.createElement("style");
  style.id = TIMESTAMP_STYLE_ID;
  style.textContent = `
    .gpt-booster-inline-ts {
      display: block !important;
      font-size: 12px !important;
      line-height: 1.4 !important;
      margin: 0 0 6px 0 !important;
      user-select: text !important;
      white-space: pre-wrap !important;
      word-break: break-word !important;
    }
    .gpt-booster-inline-ts-assistant {
      color: #335272 !important;
    }
  `;
  document.head.appendChild(style);
}

function formatLocalTimestamp(ms) {
  const parts = new Intl.DateTimeFormat("ja-JP", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false
  }).formatToParts(new Date(ms));
  const map = Object.create(null);
  parts.forEach((p) => {
    map[p.type] = p.value;
  });
  return `${map.year}-${map.month}-${map.day} ${map.hour}:${map.minute}:${map.second}`;
}

function formatJstTimestamp(ms) {
  const parts = new Intl.DateTimeFormat("ja-JP", {
    timeZone: "Asia/Tokyo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false
  }).formatToParts(new Date(ms));
  const map = Object.create(null);
  parts.forEach((p) => {
    map[p.type] = p.value;
  });
  return `${map.year}-${map.month}-${map.day} ${map.hour}:${map.minute}:${map.second}`;
}

function getLocalTimeZoneLabel() {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || "local";
  } catch (_) {
    return "local";
  }
}

const STORAGE_PREFIX = "gpt-booster-ts";

function getStableId(node) {
  if (node.id) return node.id;
  const testId = node.getAttribute("data-testid");
  if (testId) return testId;
  const article = node.closest('article[data-testid]');
  if (article) {
    const articleTestId = article.getAttribute("data-testid");
    if (articleTestId) return articleTestId;
  }
  const childWithId = node.querySelector('[id^="user-query-content-"], [id^="message-content-id-"]');
  if (childWithId && childWithId.id) return childWithId.id;
  return null;
}

function getStorageKey(stableId) {
  // Scope by pathname to prevent collisions for generic IDs (like user-query-content-10)
  // key format: gpt-booster-ts:<pathname>:<elementId>
  const scope = window.location.pathname.replace(/\/+$/, "");
  return `${STORAGE_PREFIX}:${scope}:${stableId}`;
}

function collectNodeText(root, maxLen = 0) {
  if (!root) return "";
  try {
    const walker = document.createTreeWalker(
      root,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode(node) {
          const parent = node && node.parentElement;
          if (!parent) return NodeFilter.FILTER_REJECT;
          const tag = parent.tagName ? parent.tagName.toLowerCase() : "";
          if (tag === "script" || tag === "style" || tag === "noscript" || tag === "template") {
            return NodeFilter.FILTER_REJECT;
          }
          if (parent.closest(".gpt-booster-ts, .gpt-booster-inline-ts")) {
            return NodeFilter.FILTER_REJECT;
          }
          const text = (node.nodeValue || "").replace(/\s+/g, " ").trim();
          if (!text) return NodeFilter.FILTER_REJECT;
          return NodeFilter.FILTER_ACCEPT;
        }
      },
      false
    );

    const parts = [];
    let total = 0;
    while (true) {
      const current = walker.nextNode();
      if (!current) break;
      let chunk = (current.nodeValue || "").replace(/\s+/g, " ").trim();
      if (!chunk) continue;
      if (maxLen > 0 && total + chunk.length > maxLen) {
        const room = maxLen - total;
        if (room <= 0) break;
        chunk = chunk.slice(0, room);
      }
      parts.push(chunk);
      total += chunk.length;
      if (maxLen > 0 && total >= maxLen) break;
    }
    return parts.join(" ").replace(/\s+/g, " ").trim();
  } catch (_) {
    return String(root.textContent || "").replace(/\s+/g, " ").trim();
  }
}

function getNodeTextFingerprint(node) {
  // Ignore booster timestamp marker itself to keep fingerprints stable.
  const text = collectNodeText(node, 1800);
  if (!text) return "";
  return text;
}

function isComposerEditable(node) {
  if (!(node instanceof HTMLElement)) return false;
  const tag = node.tagName.toLowerCase();
  return tag === "textarea" || tag === "input" || node.isContentEditable || node.matches('[role="textbox"]');
}

function findEditableInScope(root) {
  if (!(root instanceof HTMLElement)) return null;
  return root.querySelector('textarea, input, [role="textbox"], [contenteditable="true"]');
}

function resolveComposerFromTarget(target) {
  if (!(target instanceof HTMLElement)) return null;
  if (isComposerEditable(target)) return target;
  const closestEditable = target.closest('textarea, input, [role="textbox"], [contenteditable="true"]');
  if (closestEditable instanceof HTMLElement) return closestEditable;
  const form = target.closest("form");
  if (form instanceof HTMLElement) {
    const inForm = findEditableInScope(form);
    if (inForm instanceof HTMLElement) return inForm;
  }
  return findEditableInScope(document.body);
}

function appendUserTimestampLiteral(editable) {
  if (isAddonPaused()) return false;
  if (!isComposerEditable(editable)) return false;
  const now = Date.now();
  const prev = userTsInjectedAt.get(editable) || 0;
  if (now - prev < USER_TS_COOLDOWN_MS) return false;

  const stamp = `[${USER_TS_LITERAL_PREFIX}:${formatJstTimestamp(now)}(JST)]`;
  const tsTailPattern = /\[(?:USER|USER_TS):[^\]]+\]\s*$/;
  let changed = false;
  const tag = editable.tagName.toLowerCase();
  if (tag === "textarea" || tag === "input") {
    const current = String(editable.value || "");
    if (!tsTailPattern.test(current)) {
      editable.value = current ? `${current}\n${stamp}` : stamp;
      editable.dispatchEvent(new Event("input", { bubbles: true }));
      changed = true;
    }
  } else {
    const current = String(editable.innerText || editable.textContent || "");
    if (!tsTailPattern.test(current)) {
      const next = current ? `${current}\n${stamp}` : stamp;
      editable.textContent = next;
      editable.dispatchEvent(new Event("input", { bubbles: true }));
      changed = true;
    }
  }
  if (changed) userTsInjectedAt.set(editable, now);
  return changed;
}

function isSendLikeButton(button) {
  if (!(button instanceof HTMLElement)) return false;
  const type = (button.getAttribute("type") || "").toLowerCase();
  if (type === "submit") return true;
  const label = [
    button.getAttribute("aria-label"),
    button.getAttribute("data-testid"),
    button.getAttribute("title"),
    button.textContent
  ]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();
  return /send|submit|送信|送る|paperplane|submit/.test(label);
}

function bindUserTimestampOnSend() {
  document.addEventListener(
    "keydown",
    (ev) => {
      if (!(ev.target instanceof HTMLElement)) return;
      if (ev.key !== "Enter" || ev.shiftKey || ev.altKey || ev.ctrlKey || ev.metaKey || ev.isComposing) return;
      const editable = resolveComposerFromTarget(ev.target);
      if (editable) appendUserTimestampLiteral(editable);
    },
    true
  );

  document.addEventListener(
    "submit",
    (ev) => {
      const form = ev.target instanceof HTMLElement ? ev.target : null;
      const editable = form ? resolveComposerFromTarget(form) : resolveComposerFromTarget(document.activeElement);
      if (editable) appendUserTimestampLiteral(editable);
    },
    true
  );

  document.addEventListener(
    "click",
    (ev) => {
      const target = ev.target instanceof HTMLElement ? ev.target : null;
      if (!target) return;
      const button = target.closest("button, [role='button']");
      if (!(button instanceof HTMLElement) || !isSendLikeButton(button)) return;
      const editable = resolveComposerFromTarget(button) || resolveComposerFromTarget(document.activeElement);
      if (editable) appendUserTimestampLiteral(editable);
    },
    true
  );
}

function hashText(text) {
  // FNV-1a 32-bit (compact, fast, stable in plain JS).
  let h = 0x811c9dc5;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = (h * 0x01000193) >>> 0;
  }
  return h.toString(16).padStart(8, "0");
}

function getFallbackStorageKey(node, role) {
  const scope = window.location.pathname.replace(/\/+$/, "");
  const fp = getNodeTextFingerprint(node);
  if (!fp) return null;
  return `${STORAGE_PREFIX}:${scope}:fp:${role}:${hashText(fp)}`;
}

function getNodeStorageBaseKey(node, role) {
  const stableId = getStableId(node);
  if (stableId) return getStorageKey(stableId);
  return getFallbackStorageKey(node, role);
}

function readTimestampForNode(node, role) {
  let ts = Number(node.getAttribute("data-gpt-booster-ts"));
  if (Number.isFinite(ts) && ts > 0) return ts;
  const storageKey = getNodeStorageBaseKey(node, role);
  if (!storageKey) return null;
  try {
    const raw = localStorage.getItem(storageKey);
    const n = Number(raw);
    if (Number.isFinite(n) && n > 0) return n;
  } catch (_) {
    // noop
  }
  return null;
}

function canonicalTurnNode(node) {
  if (!(node instanceof HTMLElement)) return null;
  if (isChatGptPage()) {
    const chatTurn = node.closest(
      'article[data-testid*="conversation-turn"], [data-message-author-role], article[data-message-id]'
    );
    if (chatTurn instanceof HTMLElement) return chatTurn;
  }
  const roleRoot = node.closest('[data-message-author-role]');
  if (roleRoot instanceof HTMLElement) return roleRoot;
  const article = node.closest("article");
  if (article instanceof HTMLElement) return article;
  return node;
}

function isLikelyChatTurnRoot(node) {
  if (!(node instanceof HTMLElement)) return false;
  if (!isChatGptPage()) return true;
  if (node.closest("header, nav")) return false;
  const testId = (node.getAttribute("data-testid") || "").toLowerCase();
  if (/conversation-turn|assistant|user|message/.test(testId)) return true;
  if (node.hasAttribute("data-message-author-role") || node.querySelector("[data-message-author-role]")) return true;
  if (!node.closest("main")) return false;
  return extractNodeText(node).length >= 8;
}

function isComposerLikeNode(node) {
  if (!(node instanceof HTMLElement)) return false;
  const tag = node.tagName.toLowerCase();
  if (tag === "textarea" || tag === "input") return true;
  if (node.isContentEditable) return true;
  if (node.matches('[role="textbox"]')) return true;
  const testId = (node.getAttribute("data-testid") || "").toLowerCase();
  const cls = (node.className || "").toString().toLowerCase();
  if (/composer|prompt|input|textbox/.test(testId)) return true;
  if (/composer|prompt|input|textbox/.test(cls)) return true;
  const editableDesc = node.querySelector('textarea, input, [role="textbox"], [contenteditable="true"]');
  if (editableDesc) return true;
  if (node.closest("form")) {
    const inFormEditable = node.closest("form").querySelector('textarea, input, [role="textbox"], [contenteditable="true"]');
    if (inFormEditable) return true;
  }
  return false;
}

function normalizedTurnText(text) {
  return String(text || "")
    .replace(/\[(?:USER|USER_TS|AI|[A-Za-z]+_TS):[^\]]+\]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function isGeminiUiOnlyControlNode(node, role, text) {
  if (!isGeminiPage()) return false;
  if (normalizeRole(role) !== "assistant") return false;
  const normalized = normalizedTurnText(text);
  if (!normalized) return true;
  if (/^(思考プロセスを表示|思考プロセス|show thinking process|thinking process)$/i.test(normalized)) return true;
  const hasButton = Boolean(node.querySelector("button, [role='button']"));
  if (
    hasButton &&
    normalized.length <= 32 &&
    /(thinking|思考|share|共有|copy|コピー|edit|編集|retry|再試行)/i.test(normalized)
  ) {
    return true;
  }
  return false;
}

function cleanupNodeBadges(node) {
  if (!(node instanceof HTMLElement)) return;
  // Remove legacy nested badges that were attached to descendants.
  node.querySelectorAll(".gpt-booster-ts").forEach((el) => {
    if (el.parentElement !== node) el.remove();
  });
  const directBadges = Array.from(node.children).filter(
    (el) => el instanceof HTMLElement && el.classList.contains("gpt-booster-ts")
  );
  if (directBadges.length > 1) {
    directBadges.slice(1).forEach((el) => el.remove());
  }
}

function normalizeRole(role) {
  if (!role) return null;
  const normalized = String(role).toLowerCase();
  if (normalized === "model") return "assistant";
  if (normalized === "ai") return "assistant";
  if (normalized === "human") return "user";
  return normalized;
}

function removeDuplicateBadgesByKey(node, badgeKey) {
  if (!badgeKey) return;
  document.querySelectorAll(".gpt-booster-ts").forEach((el) => {
    if (!(el instanceof HTMLElement)) return;
    if (el.getAttribute("data-booster-key") !== badgeKey) return;
    if (el.parentElement === node) return;
    el.remove();
  });
}

function removeOtherAssistantBadges(activeNode) {
  document.querySelectorAll(".gpt-booster-ts-assistant").forEach((el) => {
    if (!(el instanceof HTMLElement)) return;
    if (el.parentElement === activeNode) return;
    el.remove();
  });
}

function removeOtherUserBadges(activeNode) {
  document.querySelectorAll(".gpt-booster-ts-user").forEach((el) => {
    if (!(el instanceof HTMLElement)) return;
    if (el.parentElement === activeNode) return;
    el.remove();
  });
}

function llmLabelFromUrl() {
  const host = (location.hostname || "").toLowerCase();
  if (host.includes("gemini.google.com")) return "Gemini";
  if (host.includes("chatgpt.com") || host.includes("chat.openai.com") || host.includes("openai.com")) return "GPT";
  return "AI";
}

function resetTimestampBadges() {
  document.querySelectorAll(".gpt-booster-ts").forEach((el) => el.remove());
}

function upsertVisibleTimestamp(node, role, options = {}) {
  if (!(node instanceof HTMLElement)) return;
  const normalizedRole = normalizeRole(role);
  if (normalizedRole !== "user" && normalizedRole !== "assistant") return;
  cleanupNodeBadges(node);
  const markAssistantDone = Boolean(options.markAssistantDone) && normalizedRole === "assistant";
  const storageKey = getNodeStorageBaseKey(node, normalizedRole);
  const endStorageKey = storageKey ? `${storageKey}:end` : null;
  const badgeKey = storageKey || getFallbackStorageKey(node, normalizedRole);
  removeDuplicateBadgesByKey(node, badgeKey);
  let ts;
  let endTs;

  if (storageKey) {
    try {
      const stored = localStorage.getItem(storageKey);
      if (stored) {
        ts = Number(stored);
      }
      if (endStorageKey) {
        const storedEnd = localStorage.getItem(endStorageKey);
        if (storedEnd) endTs = Number(storedEnd);
      }
    } catch (_) {
      // Ignore storage failures and keep DOM-only timestamp.
    }
  }

  // Fallback if not in storage or no stable ID
  if (!Number.isFinite(ts) || ts <= 0) {
    ts = Number(node.getAttribute("data-gpt-booster-ts"));
    if (!Number.isFinite(ts) || ts <= 0) {
      ts = Number(node.getAttribute("data-gpt-booster-jst-ts"));
    }
    if (!Number.isFinite(ts) || ts <= 0) {
      ts = Date.now();
    }
  }

  if (!Number.isFinite(endTs) || endTs <= 0) {
    endTs = Number(node.getAttribute("data-gpt-booster-ts-end"));
  }
  if (markAssistantDone) {
    const now = Date.now();
    if (!Number.isFinite(endTs) || endTs <= 0 || endTs < now) {
      endTs = now;
    }
  }

  // Save to storage if we have a valid key
  if (storageKey) {
    try {
      localStorage.setItem(storageKey, String(ts));
      if (endStorageKey && Number.isFinite(endTs) && endTs > 0) {
        localStorage.setItem(endStorageKey, String(endTs));
      }
    } catch (_) {
      // Storage quota or privacy mode can block writes.
    }
  }
  node.setAttribute("data-gpt-booster-ts", String(ts));
  if (Number.isFinite(endTs) && endTs > 0) {
    node.setAttribute("data-gpt-booster-ts-end", String(endTs));
  }

  // Double-check attribute consistency
  if (ts && node.getAttribute("data-gpt-booster-ts") !== String(ts)) {
    node.setAttribute("data-gpt-booster-ts", String(ts));
  }

  if (normalizedRole === "assistant") {
    let inline = node.querySelector(":scope > .gpt-booster-inline-ts-assistant");
    if (!inline) {
      inline = document.createElement("div");
      inline.className = "gpt-booster-inline-ts gpt-booster-inline-ts-assistant";
      node.prepend(inline);
    }
    if (badgeKey) inline.setAttribute("data-booster-key", badgeKey);
    inline.textContent = `[AI:${formatJstTimestamp(ts)}(JST)]`;
  }

  if (!SHOW_ALL_TURN_TIMESTAMPS) {
    if (normalizedRole === "assistant") {
      removeOtherAssistantBadges(node);
    } else if (normalizedRole === "user") {
      removeOtherUserBadges(node);
    }
  }
}

function detectRole(node) {
  const roleAttr = node.getAttribute("data-message-author-role");
  if (roleAttr) return roleAttr.toLowerCase();
  const roleDesc = node.querySelector("[data-message-author-role]");
  if (roleDesc) {
    const descRole = roleDesc.getAttribute("data-message-author-role");
    if (descRole) return descRole.toLowerCase();
  }

  const tagName = node.tagName.toLowerCase();
  const testId = node.getAttribute("data-test-id") || "";
  const testId2 = node.getAttribute("data-testid") || "";
  const className = (node.className || "").toString().toLowerCase();

  if (tagName === "user-query" || testId === "user-query" || node.classList.contains("user-query")) return "user";
  if (tagName === "message-content" || testId === "model-response" || node.classList.contains("model-response")) return "assistant";
  if (/user/.test(testId2) || /user/.test(className)) return "user";
  if (/assistant|model-response|model/.test(testId2) || /assistant|model-response|model/.test(className)) return "assistant";
  if (isGeminiPage() && node.classList.contains("message-content")) return "assistant";

  // ChatGPTのDOM変更でrole属性が取れない場合の最終フォールバック。
  const layoutClass = className;
  if (/justify-end|items-end|self-end|ml-auto/.test(layoutClass)) return "user";
  if (/justify-start|items-start|self-start|mr-auto/.test(layoutClass)) return "assistant";

  const rect = node.getBoundingClientRect();
  if (rect && rect.width > 0) {
    const center = rect.left + rect.width / 2;
    const ww = window.innerWidth || 0;
    if (ww > 0) {
      if (center >= ww * 0.58) return "user";
      if (center <= ww * 0.42) return "assistant";
    }
  }

  return null;
}

function annotateTurns() {
  if (isAddonPaused()) return;
  const candidates = [];
  if (!isGeminiPage()) {
    const turns = document.querySelectorAll(selectorFor("turns"));
    turns.forEach((n) => candidates.push({ node: n, hintedRole: null }));
  }
  const users = document.querySelectorAll(selectorFor("user"));
  users.forEach((n) => candidates.push({ node: n, hintedRole: "user" }));
  const assistants = document.querySelectorAll(selectorFor("assistant"));
  assistants.forEach((n) => candidates.push({ node: n, hintedRole: "assistant" }));

  const seen = new Set();
  let latestUserRoot = null;
  candidates.forEach(({ node, hintedRole }) => {
    const root = canonicalTurnNode(node);
    if (!(root instanceof HTMLElement)) return;
    if (!isLikelyChatTurnRoot(root)) return;
    if (isComposerLikeNode(root)) return;
    if (seen.has(root)) return;
    seen.add(root);
    const role = normalizeRole(detectRole(root) || hintedRole);
    if (role !== "user" && role !== "assistant") return;
    const rootText = extractNodeText(root);
    if (rootText.length < 2) return;
    if (isGeminiUiOnlyControlNode(root, role, rootText)) return;

    if (role === "user") {
      // Keep timestamp data for every user turn so copied logs have full pairs.
      upsertVisibleTimestamp(root, "user");
      latestUserRoot = root;
      return;
    }
    if (role === "assistant") {
      upsertVisibleTimestamp(root, "assistant");
    }
  });

  if (!SHOW_ALL_TURN_TIMESTAMPS) {
    if (latestUserRoot) {
      removeOtherUserBadges(latestUserRoot);
    } else {
      removeOtherUserBadges(null);
    }
  }
}

function collectConversationLogWithTimestamps() {
  if (isAddonPaused()) return "";
  const nodes = Array.from(document.querySelectorAll(selectorFor("turns")));
  const seen = new Set();
  const lines = [];
  nodes.forEach((node) => {
    const root = canonicalTurnNode(node);
    if (!(root instanceof HTMLElement)) return;
    if (seen.has(root)) return;
    seen.add(root);
    const role = normalizeRole(detectRole(root));
    if (role !== "user" && role !== "assistant") return;
    const text = extractNodeText(root);
    if (!text) return;
    if (isGeminiUiOnlyControlNode(root, role, text)) return;
    const ts = readTimestampForNode(root, role) || Date.now();
    const roleLabel = role === "user" ? "USER" : llmLabelFromUrl();
    lines.push(`[${formatLocalTimestamp(ts)}] [${roleLabel}] ${text}`);
  });
  return lines.join("\n\n");
}

function bindTimestampCopyHotkey() {
  if (tsCopyHotkeyBound) return;
  tsCopyHotkeyBound = true;
  window.addEventListener("keydown", async (ev) => {
    if (!ev.altKey || !ev.shiftKey || ev.key.toLowerCase() !== "l") return;
    const payload = collectConversationLogWithTimestamps();
    if (!payload) return;
    try {
      await navigator.clipboard.writeText(payload);
      console.log("[TUFF] timestamp log copied (Alt+Shift+L)");
    } catch (_) {
      console.log("[TUFF] copy failed");
    }
  });
}

function annotateRecentTurns(limit = 8) {
  if (isAddonPaused()) return;
  const seen = new Set();
  let latestUserRoot = null;
  const addRecent = (selector, hintedRole) => {
    const list = Array.from(document.querySelectorAll(selector));
    const recent = list.slice(-Math.max(1, limit));
    recent.forEach((node) => {
      const root = canonicalTurnNode(node);
      if (!(root instanceof HTMLElement)) return;
      if (!isLikelyChatTurnRoot(root)) return;
      if (isComposerLikeNode(root)) return;
      if (seen.has(root)) return;
      seen.add(root);
      const role = normalizeRole(detectRole(root) || hintedRole);
      if (role !== "user" && role !== "assistant") return;
      const rootText = extractNodeText(root);
      if (rootText.length < 2) return;
      if (isGeminiUiOnlyControlNode(root, role, rootText)) return;
      if (role === "user") {
        upsertVisibleTimestamp(root, "user");
        latestUserRoot = root;
        return;
      }
      if (role === "assistant") {
        upsertVisibleTimestamp(root, "assistant");
      }
    });
  };

  if (!isGeminiPage()) addRecent(selectorFor("turns"), null);
  addRecent(selectorFor("user"), "user");
  addRecent(selectorFor("assistant"), "assistant");
  if (!SHOW_ALL_TURN_TIMESTAMPS) {
    if (latestUserRoot) {
      removeOtherUserBadges(latestUserRoot);
    } else {
      removeOtherUserBadges(null);
    }
  }
}

function pruneTimestampBadges(maxBadges = 80) {
  const badges = Array.from(document.querySelectorAll(".gpt-booster-ts"));
  if (badges.length <= maxBadges) return;
  const removeCount = badges.length - maxBadges;
  badges.slice(0, removeCount).forEach((el) => {
    if (el && el.parentElement) el.remove();
  });
}

function markAssistantState(node) {
  const text = node ? extractNodeText(node) : "";
  if (node !== activeAssistant) {
    activeAssistant = node;
    lastAssistantText = text;
    lastAssistantChange = Date.now();
    return false;
  }
  if (text !== lastAssistantText) {
    lastAssistantText = text;
    lastAssistantChange = Date.now();
    return false;
  }
  return true;
}

function enableClamp() {
  if (scrollClampEnabled) return;
  window.addEventListener("scroll", clampScroll, { passive: true });
  scrollClampEnabled = true;
}

function disableClamp() {
  if (!scrollClampEnabled) return;
  window.removeEventListener("scroll", clampScroll, { passive: true });
  scrollClampEnabled = false;
}

function scheduleFinalizeCheck() {
  if (finalizeTimer) return;
  finalizeTimer = setTimeout(() => {
    finalizeTimer = null;
    handleMutations();
  }, STABLE_TEXT_MS);
}

function handleMutations() {
  if (isAddonPaused()) return;
  applyAiOrigin();
  refreshResponseSafeMode();
  if (mutationDebounceTimer) {
    clearTimeout(mutationDebounceTimer);
    mutationDebounceTimer = null;
  }
  if (stopActive) {
    return;
  }
  // タイムスタンプ表示は全対象ページで有効化する。
  // ChatGPTでは他のDOM改変を抑止しても、この軽量バッジは維持する。
  const enableTurnBadges = true;
  let annotated = false;
  if (shouldAvoidDomWrites()) {
    // ChatGPTではDOM改変を抑止してストリーミング安定性を優先する。
    disableClamp();
  }
  if (responseSafeMode) {
    // GPT-5等のsafe modeでも送信監視は継続する。
    // DOM改変のみ抑止し、下流へのフラグメント送信は止めない。
    if (enableTurnBadges) {
      annotateTurns();
      annotated = true;
    }
    disableClamp();
  }
  const latest = getLatestAssistant();
  if (!annotated && enableTurnBadges) annotateTurns();
  if (!latest) {
    if (!selectorMissSince) selectorMissSince = Date.now();
    if (Date.now() - selectorMissSince > 3000) {
      ensureSelectorWarning("TUFF-BRG: セレクタが一致せず監視対象を検出できません。OVERRIDE_SELECTORS を確認してください。");
    }
    return;
  }
  selectorMissSince = 0;
  clearSelectorWarning();

  const latestText = extractNodeText(latest);
  if (latestText) debugLogFragment("pick", latestText);

  if (isThinking(latest)) {
    disableClamp();
    scheduleFinalizeCheck();
    return;
  }

  const stableText = markAssistantState(latest);
  const streaming = hasStreamingCursor(latest);
  const sinceChange = Date.now() - lastAssistantChange;
  const isStable = stableText && !streaming && sinceChange >= STABLE_TEXT_MS;
  scheduleSend(latestText);

  if (isStable) {
    upsertVisibleTimestamp(latest, "assistant", { markAssistantDone: true });
    const decisionApplied = latest.dataset && latest.dataset.tuffDecisionApplied;
    if (isChatGptPage() && decisionApplied === "STOP") {
      disableClamp();
    } else {
      enableClamp();
    }
  } else {
    scheduleFinalizeCheck();
  }
}

function scheduleMutationHandling() {
  if (mutationDebounceTimer) clearTimeout(mutationDebounceTimer);
  mutationDebounceTimer = setTimeout(handleMutations, 300);
}

function extractNodeText(node) {
  if (!node) return "";
  return collectNodeText(node);
}

function clampScroll() {
  const scroller = document.scrollingElement || document.documentElement;
  if (!scroller) return;
  const current = scroller.scrollTop;
  if (lastScrollTop === null) {
    lastScrollTop = current;
    return;
  }
  const delta = current - lastScrollTop;
  if (delta < -800) {
    scroller.scrollTop = lastScrollTop - 800;
    lastScrollTop = scroller.scrollTop;
    return;
  }
  lastScrollTop = current;
}

function start() {
  if (CHATGPT_EMERGENCY_DISABLE && isChatGptPage()) {
    // Emergency stop on ChatGPT: cleanup any legacy artifacts then do nothing.
    try {
      document.querySelectorAll(".gpt-booster-ts").forEach((el) => el.remove());
      const tsStyle = document.getElementById(TIMESTAMP_STYLE_ID);
      if (tsStyle) tsStyle.remove();
      const stopStyle = document.getElementById("tuff-brg-stop-style");
      if (stopStyle) stopStyle.remove();
      const stop = document.getElementById(STOP_OVERLAY_ID);
      if (stop) stop.remove();
      const warn = document.getElementById(SELECTOR_WARNING_ID);
      if (warn) warn.remove();
      document.querySelectorAll("[data-gpt-booster-ts], [data-gpt-booster-ts-end]").forEach((el) => {
        el.removeAttribute("data-gpt-booster-ts");
        el.removeAttribute("data-gpt-booster-ts-end");
      });
    } catch (_) {
      // no-op
    }
    return;
  }
  if (!document.body) return;
  refreshResponseSafeMode();
  loadAddonSettings().finally(() => {
    if (!isAddonPaused()) wsConnect();
  });
  bindTimestampCopyHotkey();
  bindUserTimestampOnSend();

  // ChatGPTは描画負荷が高いため、Observerは使わず軽量ポーリングで処理する。
  if (isChatGptPage()) {
    ensureTimestampStyle();
    annotateRecentTurns(16);
    handleMutations();
    if (chatgptLiteTimer) clearInterval(chatgptLiteTimer);
    chatgptLiteTimer = setInterval(() => {
      if (isAddonPaused()) return;
      chatgptTick = (chatgptTick + 1) % 6;
      if (chatgptTick === 0) {
        annotateRecentTurns(16);
      }
      pruneTimestampBadges(120);
      const latest = getLatestAssistant();
      if (!latest) return;
      const stableText = markAssistantState(latest);
      const streaming = hasStreamingCursor(latest) || isThinking(latest);
      const latestText = extractNodeText(latest);
      if (!latestText) return;
      if (!stableText || streaming) return;
      scheduleSend(latestText);
    }, CHATGPT_POLL_INTERVAL_MS);
    return;
  }

  ensureTimestampStyle();
  resetTimestampBadges();
  const observer = new MutationObserver(scheduleMutationHandling);
  observer.observe(document.body, OBS_CONFIG);
  annotateTurns();
  handleMutations();
}

function unbindLiveStateArtifacts() {
  disableClamp();
  deactivateStopOverlay();
  const warn = document.getElementById(SELECTOR_WARNING_ID);
  if (warn) warn.remove();
}

function applyPauseState(nextPaused) {
  addonPaused = Boolean(nextPaused);
  if (addonPaused) {
    if (sendTimer) {
      clearTimeout(sendTimer);
      sendTimer = null;
    }
    if (wsRetryTimer) {
      clearTimeout(wsRetryTimer);
      wsRetryTimer = null;
    }
    wsReady = false;
    if (ws) {
      try {
        ws.close();
      } catch (_) {
        // noop
      }
      ws = null;
    }
    unbindLiveStateArtifacts();
    return;
  }
  if (!wsReady) wsConnect();
  handleMutations();
}

function loadPauseState() {
  return new Promise((resolve) => {
    if (typeof chrome === "undefined" || !chrome.storage || !chrome.storage.local) {
      applyPauseState(false);
      resolve();
      return;
    }
    chrome.storage.local.get([PAUSE_KEY], (res) => {
      applyPauseState(Boolean(res && res[PAUSE_KEY]));
      resolve();
    });
  });
}

function bindPauseStateSync() {
  if (typeof chrome === "undefined" || !chrome.storage || !chrome.storage.onChanged) return;
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (!changes || !changes[PAUSE_KEY]) return;
    applyPauseState(Boolean(changes[PAUSE_KEY].newValue));
  });
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => {
    loadPauseState().finally(() => {
      bindPauseStateSync();
      start();
    });
  }, { once: true });
} else {
  loadPauseState().finally(() => {
    bindPauseStateSync();
    start();
  });
}
