# AGENTS

- 本リポジトリでのやり取りは日本語で対応してください。
- 返答や提案は原則 `ans.json` に記載し、レビュー結果（改善案・不明点）も同ファイルに含めてください。

## 作業進捗（後続CODEX向け）
### 直近の実装/変更
- tuff-brg: WebSocket受信/送信の分離、INGESTのmpsc分離＋timeout導入、強制フラッシュログ追加、Ctrl+C対策（SIGINT/SIGTERMのgraceful shutdown）などを実施。
- tuff-brg/addon/booster.js: Gemini DOM対応セレクタ拡張、送信間引き（600ms & 差分5文字以上）、送信キュー、送信成功ログ追加、タイムスタンプをコピー可能な実テキストに修正。
- tuff-db: TUFF-DB-LIGHTWEIGHT（平文WAL + オンメモリTag/Meaning + 物理切断）を追加。
  - 追加: `tuff-db/src/lightweight/{storage.rs,verifier.rs,main.rs}`
  - 依存追加: `tuff-db/Cargo.toml` に `hex` と bin `tuff_db_lightweight`
- docs/BUILD_GUIDE.md と history_out/*.json を生成・追加（静的History）。
- 上記を含む全変更を main に push 済み（commit: b99bf05）。

### 現状の注意点
- /history は `history_out/*.json` を読むだけで、ランタイム更新はしない（仕様上）。
- Ctrl+C が効かない場合は「別TTYのプロセス」が残っているケースが多い。`ps -o pid,tty,cmd -C tuffbrg` で確認。
- INGEST は mpsc分離＋timeout後でも過負荷になり得るため、送信間引きは必須。

### これからのタスク（要対応）
1) TUFF-DB-LIGHTWEIGHTの仕様レビューと最終仕様確定
   - TagDBキー形式 / MeaningDBの値定義 / 即答条件の明文化
2) tuffbrg と lightweight DB の接続方針
   - 既存IngestPipelineとの統合 or 別系統で即答ルート追加
3) Ctrl+C停止の確実化検証
   - `exec RUST_LOG=debug ./target/debug/tuffbrg` でフォア起動しSIGINTを確認
4) History更新の自動化（必要なら）
   - `history_compile` を定期実行 or ingest後に更新
