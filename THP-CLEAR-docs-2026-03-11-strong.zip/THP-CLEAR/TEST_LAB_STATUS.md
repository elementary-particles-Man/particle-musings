# TEST LAB STATUS（仮想実稼働テスト構成）

- 運用手順（作成/停止）: `docs/KVM_TEST_LAB_RUNBOOK.md`
- VMログイン経路の引継ぎ注意: `docs/VM_ACCESS_HANDOVER.md`

## 1. 構成概要
- 方式: KVM/libvirt（`qemu:///system`）
- ネットワーク: libvirt NAT（`default`）
- セグメント: `192.168.122.0/24`
- Ops: ホストOS上で実行（VM化しない）
- ノード構成:
  - MQ+CSI: 3台
  - DB+CSI: 3台
- CSI: 各ノードで3重起動（`csi-n-1`,`csi-n-2`,`csi-n-3`）

## 2. ノード一覧
- `clear-mq-1`: `192.168.122.101`
- `clear-mq-2`: `192.168.122.50`
- `clear-mq-3`: `192.168.122.86`
- `clear-db-1`: `192.168.122.185`
- `clear-db-2`: `192.168.122.54`
- `clear-db-3`: `192.168.122.196`

## 3. 導入済みコンポーネント
- 全VM:
  - Rust toolchain（`rustup` minimal）
  - `csi-n`（VM内ビルド済み）
- MQノード:
  - `mqd`（`core-mq-s`、VM内ビルド済み）
- DBノード:
  - `dbd`（`core-dbd`、VM内ビルド済み）
  - `dbd-query`（VM内ビルド済み）
  - PostgreSQL 15（`clear` DB / `clear` ユーザー）
  - `rust/clear-vnext/migrations/*.sql` 適用済み

## 4. systemdサービス
- CSI（全ノード）
  - `csi-n-1` : `0.0.0.0:9109`
  - `csi-n-2` : `0.0.0.0:9110`
  - `csi-n-3` : `0.0.0.0:9111`
- MQノード
  - `mqd` : `0.0.0.0:50051`
- DBノード
  - `dbd` : `0.0.0.0:38090`

## 5. 稼働確認結果
- 各ノードで `csi-n-1/2/3` が `active`
- MQ3台で `mqd` が `active`
- DB3台で `dbd` と `postgresql` が `active`
- HTTP投入テスト:
  - `POST /mq/enqueue/stable` が `202` 応答
  - DB側 `clear_ledger_vnext` へレコード保存を確認（`tx-test-2`, `direct-2`）

## 6. 主要パス（VM内）
- バイナリ: `/opt/clear/bin/`
- 擬似 cmd: `/opt/clear/cmd/`
- CSI設定: `/etc/clear/process_list.json`, `/etc/clear/csi.conf`
- ソース配置: `/opt/clear/src/`

## 7. 既知制約
- TRON RPC は未接続（E-20検証は fail-closed 維持）
- WN専用crateは未分離（設計上必須だが現実装はMQ/DBに責務分散）
- Ops→CSI→dbd-query の本格運用フローは、鍵運用（NTK/CRK）未整備

## 8. 最小運用コマンド
- VM一覧:
  - `sudo virsh -c qemu:///system list --all`
- VM IP確認:
  - `sudo virsh -c qemu:///system net-dhcp-leases default`
- ノード状態確認（例: MQ1）:
  - `ssh clear@192.168.122.101 'systemctl status csi-n-1 csi-n-2 csi-n-3 mqd --no-pager'`
- DB保存確認（例: DB1）:
  - `ssh clear@192.168.122.185 'PGPASSWORD=clear psql -h localhost -U clear -d clear -c "select tx_id,stable_amount,currency_code from clear_ledger_vnext order by created_at desc limit 5;"'`
