# WORK SUMMARY (Phase 6: KMS Integration)

## 目的
WNノードから秘密鍵を分離し、CSI経由のリモート署名に切り替え可能な構成を実装。

## 実装内容
### KMS-001: Signer Trait / 抽象化 (`core-wn`)
- 追加: `rust/clear-vnext/crates/core-wn/src/signing.rs`
  - `Signer` trait: `async fn sign(&self, data: &[u8]) -> Result<String, anyhow::Error>`
  - `LocalFileSigner` (既存SK方式)
  - `RemoteSigner` (`POST {CLEAR_CSI_URL}/kms/sign` 呼び出し)
- 変更: `rust/clear-vnext/crates/core-wn/src/main.rs`
  - 直接 `SigningKey` を保持しない構成へ変更
  - `Box<dyn Signer>` を生成し、状態では `Arc<Box<dyn Signer>>` で利用
  - `CLEAR_WN_SIGNING_MODE=local|remote` を追加
  - `remote` 時は `CLEAR_WN_ED25519_SK` を読まず、存在しても警告して無視
- 変更: `rust/clear-vnext/crates/core-wn/src/lib.rs`（`signing` 公開）
- 変更: `rust/clear-vnext/crates/core-wn/Cargo.toml`（`async-trait`/`hex` 追加）

### KMS-002: CSI中央署名エンドポイント (`csi-n`)
- 変更: `csi-n/src/http_api.rs`
  - 追加エンドポイント: `POST /kms/sign`
  - Request:
    - `node_id: UUID`
    - `data_hash: String`（hex / 0xhex / base64 を受理）
    - `signature_type: "Ed25519"`
  - 認可:
    - NodeRegistry 上で `role == WN` のノードのみ許可
  - レスポンス:
    - `signature`（Base64）
  - `KmsSigner::from_env()` 実装:
    - `CLEAR_CSI_KMS_ED25519_SK_PATH`（優先）
    - または `CLEAR_CSI_KMS_ED25519_SK`
- 変更: `csi-n/src/main.rs`
  - 起動時にKMS鍵をロードし、HTTP APIへ注入
- 変更: `csi-n/Cargo.toml`
  - `ed25519-dalek` 追加

### KMS-003: RemoteSigner実装 (`core-wn`)
- `RemoteSigner::sign()` が `CLEAR_CSI_URL/kms/sign` に署名要求
- WNはローカル秘密鍵を保持せずに commit 可能（remoteモード）

### KMS-004: 統合テスト手順
- 追加: `scripts/run_keyless_kms_pipeline_test.sh`
  - WNサービス環境に `CLEAR_WN_ED25519_SK` が無いことを確認
  - BANKペア電文投入（MQ経由）
  - DB commit（`witness_signature IS NOT NULL`）をポーリング確認
  - `audit_verify` があれば実行

## 検証結果
- `cargo test -p core-wn` : PASS
- `cd csi-n && cargo test` : PASS

## 運用に必要な環境変数（最小）
- WN:
  - `CLEAR_WN_SIGNING_MODE=remote`
  - `CLEAR_CSI_URL=http://<CSI_HOST>:9108`
  - `CLEAR_WN_ED25519_SK` は未設定推奨（設定されても無視）
- CSI:
  - `CLEAR_CSI_KMS_ED25519_SK_PATH=/secure/path/kms.key`（推奨）
  - または `CLEAR_CSI_KMS_ED25519_SK=<base64 32bytes>`

