# テストガイド

THP-CLEAR のテスト戦略はユニットテストと統合テストを明確に分離し、変更に対する迅速なフィードバックと本番相当の整合性検証を両立します。

## 戦略

- **ユニットテスト (`make test`)**
  - 対象: ドメインサービス、HTTP ハンドラ、暗号ユーティリティ。
  - 依存: インメモリストアとモック (`pkg/fakes`) を使用し、I/O を伴わない。
  - 実行時間: 1 分以内を維持。プルリクエストの必須チェック。
- **統合テスト (`make itest`)**
  - 対象: SQLite アダプタ、Witness ログ追記、MQ パイプライン。
  - 依存: `modernc.org/sqlite` を用いた実データベースとファイル I/O。
  - 実行時間: 数分。メインブランチへのマージ前とリリース前に実施。

## カバレッジ目標

- ドメインロジック・暗号処理は 85% 以上のステートメントカバレッジを維持。
- HTTP ハンドラとエラー経路は 70% 以上のブランチカバレッジを目標。
- `go test ./... -coverprofile=coverage.out` を CI で収集し、`go tool cover -html=coverage.out` でレビューします。

## 実行コマンド

```bash
make test      # ユニットテスト
make itest     # 統合テスト
```

初回実行時に `modernc.org/sqlite` のビルドが走るため時間が掛かります。CI 上ではビルドキャッシュを有効にし、`GOMAXPROCS` を環境で指定することで安定した実行時間を確保してください。

## Witness→SQLite再材料化 試験シナリオ

THP-CLEARのデータ層設計思想に基づき、WitnessログからSQLiteデータベースを再材料化するシナリオをテストします。これは、ノード破損時やデータ不整合発生時の復旧プロセスを検証するものです。

### 目的

*   Witnessログ（JSONL形式）からSQLiteデータベースが正確に再構築されることを確認する。
*   再材料化されたデータベースの内容が、元のWitnessログと整合していることを検証する。
*   再材料化ツール（`witness-to-sqlite` CLIツールを想定）の機能と堅牢性を確認する。

### テスト手順（想定）

1.  **Witnessログの生成**: 通常のシステム運用フローを通じて、テスト用のWitnessログを生成する。
2.  **SQLiteデータベースの破損/削除**: テスト対象のSQLiteデータベースファイルを意図的に破損させるか、削除する。
3.  **再材料化ツールの実行**: `witness-to-sqlite` CLIツールを使用して、生成されたWitnessログから新しいSQLiteデータベースを再材料化する。
    ```bash
    witness-to-sqlite \
      --input ./witness_logs/test_log.jsonl \
      --output ./local/rematerialized_test.db \
      --schema ./schema/materialized.sql \
      --verify-merkle ./witness_roots/test_root.root
    ```
4.  **データ整合性の検証**: 再材料化されたデータベースの内容を、元のWitnessログや既知の期待値と比較し、データが正確に復元されていることを確認する。これには、特定のトランザクションの存在、口座残高の一致などが含まれる。
5.  **性能検証**: 大量のWitnessログからの再材料化にかかる時間やリソース消費を測定する。

### 期待結果

*   `witness-to-sqlite` ツールがエラーなく正常に完了する。
*   再材料化されたSQLiteデータベースが、元のWitnessログの内容と完全に一致する。
*   再材料化プロセスが許容可能な時間内に完了する。
