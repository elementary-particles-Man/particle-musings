# TAX Integration Test Plan
1) Key broadcast unwrap -> kid_current update
2) MQ-TAX -> WN-TAX batching (4-8MiB)
3) AES-GCM POST -> DBE-TAX decrypt -> append -> flush -> ACK
4) CLEAR Witness 128B pointer emission
5) CSV catalog PUT/GET and compute reproducibility (Excel parity)
