# THP-CLEAR-TAX End-to-End Integration Test

## 実行手順
```bash
# DBE-TAX サーバ起動 (別ターミナル)
go run cmd/dbe-tax/server.go

# 統合テスト実行
go test ./tests/integration/tax -v -run TestEndToEndTAX
```

### 期待結果
- DBE-TAX が `/tax/ingest` を受信しファイルを生成
- CLEAR Mock (`:9555`) が Witness commit を受信し `[E2E] PASS` 出力
- `report/THP_CLEAR_TAX_E2E_Summary.md` に詳細ログ生成
