# CLEAR vNext — 最終仕様書（Implementation-Aligned Final）

**Version:** 2026-02-02  
**Status:** Implementation-Final（現行コード準拠）  
**Scope:** clear-vnext（MQ / DBD / CSI / KMS / Ops / Query）

---

## 0. 目的と非目的

### 0.1 目的

- 非同期パイプラインにより  
    **「事実受付 → 外部検証 → 不可逆保存（Witness）」** を成立させる
    
- ノード責務を厳密に固定し、  
    _判断・保存・照会_ を分離した実装を可能にする
    
- Witness を **外部に読ませない前提**で、  
    冗長化・検索・復旧が成立する構造を確定する
    

### 0.2 非目的

- 運用手順（USB複製頻度、人的バックアップ）を本体仕様に含めない
    
- ID/KYC/2FA/UI を議論しない（CLEAR-ID は別系で凍結済み）
    
- 外部チェーン（TRON/E-20）の経済的意味・残高管理を扱わない
    

---

## 1. ノード責務（確定）

### 1.1 MQ（core-mq-s / core-mq-c）

**役割：受付・整列・最小検証**

- トランザクションを受付し、キューイングする
    
- **TRON / TRC-20（E-20）の最小事実検証を実施**
    
    - tx の存在
        
    - receipt 成功
        
    - Transfer(from/to/amount/token) 一致
        
    - confirmations ≥ 閾値（default 19）
        
- 検証失敗時は **fail-closed（DBDへ送らない）**
    
- 検証結果の最小4項目を `metadata_json.e20` に付加
    
- **判断・保存・検索は行わない**
    

> 現行実装では、E-20 検証は MQ に集約されている  
> （WN は将来拡張ノードとして定義のみ残す）

---

### 1.2 WN（core-wn：将来拡張）

**役割：高度な判断・正規化（※未常駐）**

- ID-Sync 解決（from/to の主体解決）
    
- 外部検証の高度化（reorg 対応等）
    
- Witness 生成に必要な確定値の補完
    

※ 現行 clear-vnext 実装では **WN は未配置**  
※ その責務の一部は MQ にて最小化して実装済み

---

### 1.3 DBD（core-dbd）

**役割：保存・Witness化・検索プロセス実行**

- MQ から受け取った処理ログを **保存のみ**行う
    
- 再判断は一切しない
    
- DB が閾値に達した場合：
    
    - 128B レコード単位で Witness へフラッシュ
        
    - シグネチャは保存しない
        
- 検索要求時：
    
    - **常駐せず、検索専用プロセス（dbd-query）を spawn**
        

---

### 1.4 CSI（Control / Supervisor Interface）

**役割：制御・起動ゲート**

- Ops からの要求を受信
    
- 自ノード種別を検査（「俺はDBノードか？」）
    
- DBノードの場合のみ：
    
    - **dbd-query を spawn（待たない）**
        
- 検索結果・判断には関与しない
    

---

### 1.5 Ops（運用管理デーモン）

**役割：一時集合点（非SPOF）**

- 本体必須要素ではない（無くても系は動く）
    
- 検索要求の発行
    
- 全 DB ノードからの検索結果 JSON を集約・統合
    
- 参加メンバーリスト（epoch 付き）の配布・確定通知
    

---

## 2. データフロー（確定）

### 2.1 通常処理

```
Client
  ↓
MQ（受付・E-20最小検証）
  ↓
DBD（保存）
  ↓
Witness Storage（append-only）
```

### 2.2 照会（検索）

```
Ops
  ↓
CSI
  ↓（spawn）
DBD-Query（各DBノードで個別起動）
  ↓
Ops（JSON集約）
```

---

## 3. MQ → DBD 処理ログ構造（確定）

### 3.1 Process Log（最小）

- `tx_id`
    
- `ledger_entry`（正規化済み）
    
- `id_hash`（32B）
    
- `e20`
    
    - `tx_hash`
        
    - `token`
        
    - `from`
        
    - `to`
        
    - `amount`
        
- `created_at`（epoch）
    

※ DBD は **内容を信じて保存するのみ**

---

## 4. Witness 仕様（確定）

### 4.1 Witness Record（128B）

- `tx_hash` 32
    
- `account_hash` 32
    
- `amount_hash` 32
    
- `id_hash` 32
    

### 4.2 原則

- 追記専用
    
- シグネチャ保存なし
    
- **真偽判定不能**（DBD の真鍵なしでは不可読）
    

---

## 5. 鍵モデル（確定）

### 5.1 KMS 世代鍵

- AES / ISE の世代セットを保持
    
- 復号は **新→旧→旧々** のフォールバック
    

### 5.2 NTK / CRK

- **NTK（Node TPM True Key）**
    
    - 各ノード固有
        
    - 外部に出ない
        
    - ローカル封緘専用
        
- **CRK（Cluster Recovery Key）**
    
    - クラスタ共通鍵
        
    - 検索結果・冗長ログの封緘に使用
        
    - Ops 台帳では **運営鍵で ISE 封緘**された形で保持
        

---

## 6. DBD 冗長化・復旧

### 6.1 冗長化

- Witness ログを分割し、他 DB ノードへ送付可能
    
- 送付時保護：**通信層暗号**
    
- 受信後保管：**CRK 封緘**
    

### 6.2 復旧

- 新 DB ノード初期化時：
    
    - 「ログをください」ブロードキャスト
        
- 既存 DB ノード：
    
    - 冗長ログを返送
        
- 新 DB ノード：
    
    - 受領後 NTK で封緘
        
    - ACK 送信
        
- 送信側：
    
    - ACK 受領後 Drop
        

---

## 7. 検索プロセス（dbd-query：確定）

### 7.1 起動条件

- Ops → CSI → DB ノード
    
- **spawn のみ、待機なし**
    

### 7.2 動作仕様

- ストレージ：read-only
    
- レコード：
    
    - 128B
        
    - **50,000件単位で一括リード**
        
- 処理：
    
    - NTK で in-memory 復号
        
    - 条件マッチ判定
        
- 出力：
    
    - JSON を **CRK で封緘**
        
    - Ops へ送信
        
    - **ACK（`OK\n`）待ち**
        
    - 正常終了
        

### 7.3 出力 JSON（最小）

- `node_id`
    
- `request_ts`
    
- `recommended_scan_records`
    
- `found`
    
- `cases`
    
- `eor`
    

---

## 8. 参加メンバーリスト（Ops配布）

### 8.1 最小フィールド

- `node_type`
    
- `ntk_fingerprint`
    
- `location`
    
- `endpoint`
    
- `epoch`
    

### 8.2 配布原則

- 盗聴耐性：通信層
    
- 保存耐性：各 CSI が **自身の NTK で即封緘**
    
- ACK 回収後に epoch 確定
    

---

## 9. 設計変更点（ドラフト比）

- TRON / E-20 検証を **MQ に正式移管**
    
- 検索は **常駐禁止・spawn 専用プロセス**
    
- Ops → CSI → DBD の間接経路を明文化
    
- ACK 仕様を **固定文字列（OK\n）**で確定
    
- sqlx は **offline mode 前提**と明記
    

---

### 結語

CLEAR vNext は、

> **判断しない  
> 書き換えない  
> 復元しない  
> ただ「起きた事実」を保持し、条件一致を返す**

という原則を、  
**実装レベルで一切崩さずに完成域に到達した。**

---

## 既知差分一覧（仕様と実装の齟齬・未接続点）

以下は **意図的に未接続／未活性化** されている箇所であり、  
**fail-closed を維持したまま残している既知差分** である。

### 1.1 MQ の E-20 最小検証

- TRON RPC 未接続のため **常時 fail-closed（DBDへ送られない）**
- 仕様逸脱ではなく **検証経路の未接続状態の明示的停止**

### 1.2 WN の扱い

- **WN 未実装**のため、判断ロジックの一部が **DBD 内に残存**
- 仕様上は WN が担うべき責務の **切り出し未完**

### 3.1 MQ → DBD Process Log 構造

- `ledger_entry` に **id_hash / created_at が未反映**
- E-20 メタは **最小検証用のダイジェスト止まり**（完全復元不可）

### 4.1 Witness Record（128B）

- `id_hash` が未使用（代わりに `amount_id_hash` を保持）
- **同一性証明には未影響だが仕様完全一致ではない**

### 5.1 KMS 世代鍵フォールバック

- vNext 側は **未接続**
- `dbd-query` は **env 受けのみ**で保持

### 7.2 dbd-query の NTK 復号

- **プレースホルダ**
- fail-open ではなく、**復号失敗時は eor=false で終了**

### 7.2 ACK 仕様

- **`OK\n` のみを受理**（仕様より厳格）
- 仕様外の ACK 文字列は受け付けない
