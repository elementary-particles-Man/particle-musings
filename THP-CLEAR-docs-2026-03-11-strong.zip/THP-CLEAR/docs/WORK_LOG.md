# 作業ログ（概要）

以下は本セッションで行った作業の要約です。タイムスタンプはJSTです。

- 2026-02-02 03:39:23 +0900
  - THP-CLEAR で Git 同期状況を確認し、`feature/clear-tax-e2e` を `main` に merge。
  - README 競合は feature 側を採用。
  - `main` を `origin/main` に push。
- 2026-02-02 03:39:23 +0900
  - `HEAD` 基準でリポジトリ構造を分析。
  - `REPO_STRUCTURE.md` をルートに作成（作業ツリーは変更せずに別 worktree で検証）。
  - `cargo check -p clear-node` を実行し、警告内容を記載。

---

**End of log.**

## 2026-02-02
- Move root-level markdown documents to docs/ (except README.md, README_RUST_ONLY.md kept at root).
- Add TRON/TRC-20 minimal verification gate in core-mq-s (DBD send pre-check, fail-closed).
- Add dbd-query subprocess for read-only witness scan; CSI spawn path; ACK=OK\n enforced.
- Enable sqlx offline mode; generate .sqlx and sqlx-data.json; local Postgres bootstrapped for prepare.
- 2026-02-02 05:30:00 +0900
  - docs/ を実装合わせで再編成（実装非整合の旧資料は retired/ に退避）。
  - Go 関連ソース/テストは retired/ に退避（Git 管理外）。
  - index / repository_overview / REPO_STRUCTURE を現行実装に合わせて更新。
- 2026-02-02 05:40:00 +0900
  - docs/index / repository_overview / REPO_STRUCTURE に WN ノード（設計必須・未分離）を明記。
