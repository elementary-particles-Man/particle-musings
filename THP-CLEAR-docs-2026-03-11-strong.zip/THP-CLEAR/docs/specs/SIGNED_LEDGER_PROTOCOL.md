# Signed Ledger Protocol (WN -> DB)

## Overview
This document specifies the signed payload that WN sends to DB and how DB verifies it.
The payload is a `LedgerEntry` wrapped in `CommitRequest`.

## Payload

### HTTP Endpoint
- `POST /ledger/commit`
- Body (JSON):

```json
{
  "entry": {
    "tx_id": "string",
    "from_account": "string",
    "to_account": "string",
    "from_id": 123,
    "to_id": 456,
    "stable_amount": 1000,
    "void_amount": "base64 bytes or null",
    "currency_code": "JPY",
    "nonce": 0,
    "sig": "base64 bytes",
    "metadata_json": { "evidence": { "unmapped": {"ROLE": {"k":"v"}}, "infra_type": "..." } },
    "witness_signature": "base64(ed25519 signature)",
    "committed_at": "2026-02-06T00:00:00Z"
  }
}
```

## Field Semantics
- `tx_id`: pairing_id (canonical ID)
- `from_account`: derived from facts (e.g. `from`, `pan_hash`, `sender_id`)
- `to_account`: derived from facts (e.g. `to`, `merchant_id`, `recipient_id`)
- `stable_amount`: integer amount (minor units)
- `currency_code`: currency or token symbol
- `metadata_json`: only unstructured evidence (no committed_at)
- `committed_at`: the committed timestamp as RFC3339 (UTC)

## Signature
WN signs the canonical hash of the `LedgerEntry`, excluding the signature itself.

**Signing formula**:
```
Ed25519( CanonicalHash( LedgerEntry - witness_signature ) )
```

### CanonicalHash
- Build a JSON array in the following field order:
  1. `tx_id`
  2. `from_account`
  3. `to_account`
  4. `from_id`
  5. `to_id`
  6. `stable_amount`
  7. `void_amount` (byte array or null)
  8. `currency_code`
  9. `nonce`
  10. `sig` (byte array)
  11. `metadata_json` with **sorted keys** (recursive)
  12. `committed_at` (RFC3339 string)

- Serialize the array to UTF-8 JSON bytes.
- Compute `SHA-256` hash of those bytes.

### Verification
DB reconstructs the canonical hash and verifies:
```
Verify( WN_PubKey, CanonicalHash(entry), entry.witness_signature )
```

## Keys
- WN signs with `CLEAR_WN_ED25519_SK` (base64-encoded 32-byte private key).
- DB verifies with `CLEAR_WN_ED25519_PK` (base64-encoded 32-byte public key).

## Error Handling
- Invalid signature → `403 Forbidden`
- Missing signature → `403 Forbidden`
- All other errors → `500`
