# MQ Metadata JSON Schema (MQ -> WN Contract)

## Overview
This document defines the JSON contract that `core-mq` must populate in `metadata_json` for WN processing.
The WN adapter (`core-wn`) maps these structures into `WitnessEvent`.

Principles:
- `metadata_json` is an object with zero or more top-level keys.
- Each schema below is identified by a unique top-level key (e.g. `e20`, `iso_pacs008`).
- Amount and timestamp formats are standardized across schemas.

## Standard Types
- `amount`: string or number.
  - Preferred: **string** for exactness (e.g. "1000").
  - Acceptable: number (int).
- `timestamp`: ISO8601 string (UTC) or epoch seconds.
  - Preferred: ISO8601 (e.g. "2026-02-06T00:00:00Z").

## Schemas

### 1) `e20` (EVM / TRON / E-20)
Used for on-chain token transfer verification.

**Location**: `metadata_json.e20`

**Fields**:
- `chain` (number): chain id (e.g. 1 for Ethereum, TRON chain id for TRC-20).
- `tx_hash` (string): 0x-prefixed 32B hex string.
- `token` (string): 0x-prefixed 20B hex string.
- `from` (string): 0x-prefixed 20B hex string.
- `to` (string): 0x-prefixed 20B hex string.
- `amount` (string|number): transfer amount.
- `confirmations` (number): current confirmation count.
- `finality` (boolean, optional): `true`=confirmed, `false`=probabilistic.
- `fee` (number, optional): network fee in SUN.

**MQ -> JSON mapping (core-mq)**:
- `chain` -> `e20.chain`
- `tx_hash` -> `e20.tx_hash`
- `token_contract` -> `e20.token`
- `from` -> `e20.from`
- `to` -> `e20.to`
- `amount` -> `e20.amount`
- `confirmations` -> `e20.confirmations`
- `finality` -> `e20.finality`
- `fee_sun` -> `e20.fee`

**WN Adapter output (core-wn)**:
- `infra_type`: `BLOCKCHAIN_EVM`
- `role`: `ONCHAIN_EVENT`
- `facts`: `tx_hash`, `chain`, `token`, `from`, `to`, `amount`, `confirmations`, `finality`, `fee`(opt)

---

### 2) `iso_pacs008` (Bank Instruction)
Used for ISO20022 credit transfer instruction.

**Location**: `metadata_json.iso_pacs008`

**Fields**:
- `uetr` (string): Unique End-to-end Transaction Reference.
- `end_to_end_id` (string, optional): EndToEndId if available.
- `amount` (string|number)
- `currency` (string): ISO-4217 code, uppercase.
- `debtor_account` (string): source account id (from).
- `creditor_account` (string): destination account id (to).
- `timestamp` (string|number, optional)

**WN Adapter output**:
- `infra_type`: `BANK_TRANSFER_ISO20022`
- `role`: `INSTRUCTION_PACS008`
- `facts`: `uetr`, `end_to_end_id`(opt), `amount`, `currency`, `from`, `to`

---

### 3) `iso_camt054` (Bank Notification)
Used for ISO20022 credit notification.

**Location**: `metadata_json.iso_camt054`

**Fields**:
- `uetr` (string)
- `end_to_end_id` (string, optional)
- `amount` (string|number)
- `currency` (string)
- `debtor_account` (string): source account id (from).
- `creditor_account` (string): destination account id (to).
- `timestamp` (string|number, optional)

**WN Adapter output**:
- `infra_type`: `BANK_TRANSFER_ISO20022`
- `role`: `CREDIT_NOTIFICATION_CAMT054`
- `facts`: `uetr`, `end_to_end_id`(opt), `amount`, `currency`, `from`, `to`

---

### 4) `card_auth` (Card Authorization)
Used for card auth event.

**Location**: `metadata_json.card_auth`

**Fields**:
- `rrn` (string): Retrieval Reference Number.
- `stan` (string, optional): System Trace Audit Number.
- `date` (string, optional): Date in `YYYY-MM-DD`.
- `amount` (string|number)
- `currency` (string)
- `pan_hash` (string): source identity (from).
- `merchant_id` (string): destination identity (to).
- `timestamp` (string|number, optional)

**WN Adapter output**:
- `infra_type`: `CARD_CREDIT_DUAL_MESSAGE`
- `role`: `AUTH_EVENT`
- `facts`: `rrn`, `stan`(opt), `date`(opt), `amount`, `currency`, `from`, `to`

---

### 5) `card_clearing` (Card Clearing)
Used for card clearing event.

**Location**: `metadata_json.card_clearing`

**Fields**:
- `rrn` (string)
- `stan` (string, optional)
- `date` (string, optional)
- `amount` (string|number)
- `currency` (string)
- `pan_hash` (string): source identity (from).
- `merchant_id` (string): destination identity (to).
- `timestamp` (string|number, optional)

**WN Adapter output**:
- `infra_type`: `CARD_CREDIT_DUAL_MESSAGE`
- `role`: `CLEARING_EVENT`
- `facts`: `rrn`, `stan`(opt), `date`(opt), `amount`, `currency`, `from`, `to`

## Notes
- `metadata_json` MUST NOT include business logic outputs. It only carries factual fields needed for WN matching.
- If multiple schemas exist in `metadata_json`, WN adapter currently picks the first recognized schema in priority order.
- Fallback rule: when schema-specific account fields are absent, generic `from` / `to` in `metadata_json` are used.
