# FINAL TEST RESULTS REPORT

- Date: 2026-02-15
- Environment: KVM 6-node cluster (1 MQ / 3 WN / 2 DB) + CSI host
- Network: `virbr0 (192.168.122.0/24)`

## 1. 対象構成
- MQ: `192.168.122.94`
- WN: `192.168.122.113`, `192.168.122.73`, `192.168.122.133`
- DB: `192.168.122.111`, `192.168.122.87`
- CSI: `192.168.122.1:9108`

## 2. 今日の検証サマリ

### 2.1 Keyless KMS
- WN全台で `CLEAR_WN_SIGNING_MODE=remote` を確認
- WN service から `CLEAR_WN_ED25519_SK` 除去を確認
- WNログに `Signing mode: remote` / `CSI URL: http://192.168.122.1:9108`
- CSI `/kms/sign`:
  - 未認可 node_id -> `403 Forbidden`
  - 認可 WN node_id -> `200 OK` + Base64署名

結果: Secret-less WN アーキテクチャ成立

### 2.2 BANK 分散commit
- テストID: `bank-kms-20260215171542`
- シナリオ: `pacs.008 + camt.054` ペア照合
- DB結果: `signed=true`
- `audit_verify`: `OK`

結果: 多ロール照合commit 成立

### 2.3 TRON/EVM 実RPC連携
- 実トランザクション事実で `e20_verify_ok` を確認
- 代表tx: `0x627b642ca4858040c9a3565e493b20de9b52c7b039fa86d1663027d79a4cc5f3`
- DB結果: `signed=true`, `currency_code=E20`
- `audit_verify`: `OK`

結果: 実チェーン同期を伴うcommit 成立

## 3. メトリクス（本日検証範囲）
- 有効入力（BANKペア/有効TRON）: commit成立
- 不正認可要求（KMS）: 100% reject
- 監査検証（対象2件）: 100% `OK`

注記:
- TRON RPC は外部依存のため一時的 `RpcError` が観測される。
- ただし fail-closed で誤commitは発生せず、再送で確定可能。

## 4. CSI/通信の観測
- CSIにてノード `registered` と `heartbeat` を継続受信
- 6ノードが `virbr0` 経由で相互疎通し、制御プレーン接続を維持

## 5. Operational Readiness 判定
本日検証対象（BANK/EVM + Keyless署名 + 監査）において、分散構成での運用成立を確認。

判定: **Operationally Ready (for validated scope)**

## 6. 参照証跡
- `KEYLESS_KMS_VERIFICATION_REPORT.md`
- `docs/TEST_CASE_SPECIFICATION.md`
- `scripts/run_keyless_kms_pipeline_test.sh`
