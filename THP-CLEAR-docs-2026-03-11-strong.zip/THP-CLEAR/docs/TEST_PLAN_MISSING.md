# TEST PLAN MISSING（CLEAR vNext + CLEAR-ID）

最終更新: 2026-02-03

## 方針
- 既存レポート未記載のテストを優先度順で追加。
- 実行不能項目は BLOCKED として根拠を記録。
- fail-closed 前提を維持。

## CLEAR vNext
| ID | 優先 | 状態 | 備考 |
|---|---:|---|---|
| CLEAR_VNEXT_T01_TRON_RPC_E2E | 1 | DONE | 実RPC接続E2E実施済み（2026-02-03） |
| CLEAR_VNEXT_T02_TRON_LOGIC_UNIT | 2 | DONE | `core-mq-s` に5ケース追加・実行済み |
| CLEAR_VNEXT_T03_PROCESS_LOG_SCHEMA_CONSISTENCY | 3 | DONE | 欠落検出テスト追加（検出専用） |
| CLEAR_VNEXT_T04_WITNESS_METADATA_TAMPER_COVERAGE | 4 | DONE | metadata 非対象を再現テスト化 |
| CLEAR_VNEXT_T05_KMS_KEYGEN_FALLBACK_BLOCKED | 5 | PARTIAL | 3世代鍵フォールバック単体検証を追加、実KMS接続E2Eは未実施 |
| CLEAR_VNEXT_T06_DBD_QUERY_CRYPTO_PLACEHOLDER_DETECTION | 6 | DONE | プレースホルダ検出テスト追加 |
| CLEAR_VNEXT_T07_OPS_TO_CSI_TO_DBD_QUERY_E2E_WITH_KEYS_BLOCKED | 7 | BLOCKED | 鍵運用未整備 |
| CLEAR_VNEXT_T08_TRANSPORT_ENCRYPTION_VERIFICATION | 8 | TODO | tcpdump/pcap 実施未着手 |
| CLEAR_VNEXT_T09_REPLAY_DUPLICATE_RESISTANCE | 9 | DONE | 同一tx_id 100回投入テスト追加 |
| CLEAR_VNEXT_T10_FAULT_INJECTION_ACK_BEFORE_DROP | 10 | TODO | kill/network遮断試験未着手 |
| CLEAR_VNEXT_T11_PERF_SCAN_50000 | 11 | TODO | 負荷計測未着手 |

## CLEAR-ID
| ID | 優先 | 状態 | 備考 |
|---|---:|---|---|
| CLEAR_ID_T01_MIGRATION_APPLY | 1 | DONE | 空DB/既存DB適用を確認 |
| CLEAR_ID_T02_REGISTER_LOGIN_CHANGE_PASSWORD_E2E | 2 | DONE | E2E実行で正常/異常確認 |
| CLEAR_ID_T03_COOKIE_FLAGS_AND_TTL | 3 | PARTIAL | Cookie属性/Max-Age確認、実時間TTL失効は未確認 |
| CLEAR_ID_T04_LOGOUT_REUSE_OLD_COOKIE | 4 | DONE | logout後の旧cookie無効化を確認 |
| CLEAR_ID_T05_REVOKE_FLOW | 5 | DONE | revoke後 login/me 拒否を確認 |
| CLEAR_ID_T06_CONCURRENCY_UNIQUE_EMAIL | 6 | DONE | 50並列で1作成のみ確認 |

## 今回追加したテストコード
- `rust/clear-vnext/crates/core-mq-s/tests/e20_logic_unit.rs`
- `rust/clear-vnext/crates/common-types/tests/process_log_schema.rs`
- `rust/clear-vnext/crates/core-witness/tests/tamper_coverage_metadata.rs`
- `rust/clear-vnext/crates/core-dbd/tests/dbd_query_crypto_placeholder.rs`
- `rust/clear-vnext/crates/core-dbd/tests/kms_key_fallback_window.rs`
- `rust/clear-vnext/crates/core-ledger/tests/replay_duplicate_resistance.rs`
