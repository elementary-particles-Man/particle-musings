# HANDOVER（後続CODEX向け / 2026-02-03 時点）

## 0. 先に結論
- `TASK-VN-001`（TRON RPC 実接続E2E）は **DONE** まで完了。
- その後、`TASK-VN-002` の前段として **KMS 3世代鍵フォールバックの単体検証（PARTIAL）** を追加。
- さらに、Witness再評価要求に対応し、**Witness必須項目 vs 補助項目の分類テスト**を追加。

---

## 1. Git状態

### 1.1 Push済み
- 基準コミット: `1b5c4d4`（`origin/main` へ push 済み）
  - TRON RPC 実装
  - TRON E2E 実施とレポート反映
  - KVM/VMアクセス handover 資料追加

### 1.2 未コミット（作業ツリーに残っている差分）
- 変更:
  - `docs/TEST_PLAN_MISSING.md`
  - `docs/TEST_REPORT_MISSING_CLEAR_VNEXT.md`
  - `docs/index.md`
  - `rust/clear-vnext/crates/core-dbd/src/lib.rs`
- 新規:
  - `docs/WITNESS_TRUTH_RETEST_20260203.md`
  - `rust/clear-vnext/crates/core-dbd/src/key_fallback.rs`
  - `rust/clear-vnext/crates/core-dbd/tests/kms_key_fallback_window.rs`
  - `rust/clear-vnext/crates/core-witness/tests/witness_truth_retest.rs`

---

## 2. 今回の実施内容

### 2.1 TRON RPC E2E（TASK-VN-001）
- MQへ `CLEAR_MQ_TRON_RPC_URL=https://api.trongrid.io` を注入して `mqd` 再起動。
- 実Tx（`b02049...5891`）を使って正常系/異常系を投入。
- 結果:
  - 正常系: `e20_verify_ok` / DB保存あり
  - 異常系(amount改ざん): `e20_verify_fail` / DB未保存（fail-closed）

### 2.2 KMS 3世代フォールバック（TASK-VN-002 前段）
- `core-dbd` に鍵窓ロジックを追加:
  - `KeyWindow { current, old1, old2 }`
  - 復号順: **新→旧→旧々**
  - 全失敗時: fail-closed
- 追加テスト（モックE2E相当）:
  - 旧鍵暗号データ復号
  - 鍵欠損時失敗
  - 並列参照安全
  - 鍵未設定拒否

### 2.3 Witness再評価（RETEST-W/A/D）
- 要求に合わせて「tamper検知率」ではなく「真偽再構成可否」で評価。
- 分類結果:
  - Witness-required: `tx_id`, `from_account`, `to_account`, `from_id`, `to_id`, `stable_amount`, `void_amount`, `currency_code`
  - Auxiliary: `nonce`, `sig`, `metadata_json`
- `metadata_json` 改変は真偽評価に影響しないことを確認。

---

## 3. 実行済みテスト
- `cargo test -p core-mq-s --test e20_logic_unit`
- `cargo test -p core-dbd --test kms_key_fallback_window`
- `cargo test -p core-dbd --test dbd_query_crypto_placeholder --test kms_key_fallback_window`
- `cargo test -p core-witness --test witness_truth_retest`

---

## 4. ドキュメント反映状況
- 更新済み（未コミット差分含む）:
  - `docs/TEST_PLAN_MISSING.md`
  - `docs/TEST_REPORT_MISSING_CLEAR_VNEXT.md`
  - `docs/index.md`
  - `docs/WITNESS_TRUTH_RETEST_20260203.md`（新規）

---

## 5. 後続CODEXが次にやること（優先順）
1. 未コミット差分を内容確認し、1コミットにまとめて push。
2. `TASK-VN-002` 本体（実KMSまたはKMS互換モックとの実接続E2E）を実施し、`PARTIAL -> DONE` へ。
3. `TASK-VN-003`（Ops→CSI→dbd-query 鍵運用込みE2E）に着手。

---

## 6. 注意（運用）
- 日本語対応は必須。
- 推測タスク禁止（仕様記載または不足テストのみ）。
- `/id` `/pat` `CLEAR-ID` リポジトリ領域は触らない。
- VMアクセスで詰まった場合は `docs/VM_ACCESS_HANDOVER.md` を先に確認。
