# TEST REPORT MISSING: CLEAR vNext

実施日: 2026-02-03

## 実施結果サマリ
- 実施: T01, T02, T03, T04, T06, T09
- PARTIAL: T05
- BLOCKED: T07
- 未実施: T08, T10, T11

## T01 TRON RPC E2E（DONE）
- 実施日: 2026-02-03
- 環境:
  - MQ: `192.168.122.101`（`CLEAR_MQ_TRON_RPC_URL=https://api.trongrid.io`）
  - timeout: `CLEAR_MQ_TRON_RPC_TIMEOUT_MS=5000`
  - Tx: `b02049daa9a0de0e10187dfa4d1ce560c3e8dd23625e92d2adfcf242e1af5891`（TRC-20 Transfer）
- 実行:
  - 正常系 `tx_id=tron-e2e-ok-20260203102152` を投入（HTTP 202）
  - 異常系 `tx_id=tron-e2e-fail-20260203102152`（amount+1改ざん）を投入（HTTP 202）
- 確認ログ（MQ）:
  - `event="e20_tron_rpc_client" mode="http"` を確認
  - `event="e20_verify_ok"` を正常系で確認
  - `event="e20_verify_fail" error=MismatchAmount` を異常系で確認
- DB確認（DB1）:
  - 正常系Txのみ `clear_ledger_vnext` に保存
  - 異常系Txは未保存（fail-closed）
- 判定: **BLOCKED解除（DONE）**

## T02 TRON_LOGIC_UNIT（DONE）
- 追加: `rust/clear-vnext/crates/core-mq-s/tests/e20_logic_unit.rs`
- 実行: `cargo test -p core-mq-s --test e20_logic_unit`
- 結果: 5/5 pass
  - 正常: tx存在 + receipt成功 + Transfer一致 + confirmations>=threshold
  - 異常: tx不存在 / receipt失敗 / amount不一致 / confirmations不足
- 判定: fail-closed 挙動をユニットで固定。

## T03 PROCESS_LOG_SCHEMA_CONSISTENCY（DONE）
- 追加: `rust/clear-vnext/crates/common-types/tests/process_log_schema.rs`
- 実行: `cargo test -p common-types --test process_log_schema -- --nocapture`
- 結果: pass（検出専用）
- 検出: `missing_top_keys=["ledger_entry","id_hash","created_at","e20"]`
- 判定: 現行型と仕様要求の差分をテストで可視化。

## T04 WITNESS_METADATA_TAMPER_COVERAGE（DONE）
- 追加: `rust/clear-vnext/crates/core-witness/tests/tamper_coverage_metadata.rs`
- 実行: `cargo test -p core-witness --test tamper_coverage_metadata`
- 結果: 2/2 pass
  - ハッシュ対象フィールド改変: 検知（hash変化）
  - metadata_jsonのみ改変: 非検知（現状仕様どおり）

## T06 DBD_QUERY_CRYPTO_PLACEHOLDER_DETECTION（DONE）
- 追加: `rust/clear-vnext/crates/core-dbd/tests/dbd_query_crypto_placeholder.rs`
- 実行: `cargo test -p core-dbd --test dbd_query_crypto_placeholder`
- 結果: pass
- 検出: `dbd_query.rs` に placeholder (`Ok(record.to_vec())`) が残存。

## T05 KMS_KEYGEN_FALLBACK（PARTIAL）
- 追加: `rust/clear-vnext/crates/core-dbd/src/key_fallback.rs`
- 追加: `rust/clear-vnext/crates/core-dbd/tests/kms_key_fallback_window.rs`
- 実行: `cargo test -p core-dbd --test kms_key_fallback_window`
- 結果: 4/4 pass
  - 旧鍵データを `新→旧→旧々` 順フォールバックで復号可能
  - 旧鍵欠損時は `AllGenerationsFailed` で fail-closed
  - 並列復号（30スレッド）で競合なく動作
  - 鍵未設定時は `NoKeysConfigured`
- 判定: フォールバックロジック単体は検証済み。実KMS接続E2Eは未実施のため PARTIAL。

## T09 REPLAY_DUPLICATE_RESISTANCE（DONE）
- 追加: `rust/clear-vnext/crates/core-ledger/tests/replay_duplicate_resistance.rs`
- 実行:
  - `export DATABASE_URL='postgres://clear:clear@127.0.0.1:5432/clear_vnext_tamper'`
  - `cargo test -p core-ledger --test replay_duplicate_resistance -- --nocapture`
- 結果: pass
  - 同一 `tx_id` を100回投入
  - 重複99件はエラー
  - DB行数は1件を維持

## BLOCKED項目
- T07 Ops→CSI→dbd-query鍵運用E2E: NTK/CRK/KMS未整備

## 未実施
- T08 通信暗号のpcap検証
- T10 ACK前障害注入
- T11 50,000件スキャン性能計測
