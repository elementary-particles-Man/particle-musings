# THP-CLEAR Repository Index (Current Implementation)

## Overview
This repository currently focuses on the **Rust vNext implementation** and the **CSI node**. The **WN node is a required component by design**, but its dedicated crate is not yet present in the current implementation (roles are split between MQ and DBD for now). Legacy/experimental materials have been moved to `retired/` and are intentionally ignored by Git.

---
## Directory Map (Current)

| Path | Description |
|------|-------------|
| `rust/clear-vnext/` | Rust vNext workspace (MQ/DBD/Ledger/Witness/ID-Sync mock; WN is design-required but not yet isolated) |
| `csi-n/` | CSI node (control/supervisor interface) |
| `docs/` | Implementation-aligned documentation (curated) |
| `retired/` | Legacy materials (ignored; not tracked) |
| `config/` | Runtime configuration assets (if any) |
| `deploy/` / `docker-compose*.yml` | Deployment assets |

---
## Core Documents (Current)
- `docs/CLEAR-vNext最終仕様書.md`
- `docs/TRON_E20_IMPLEMENTATION_STATUS.md`
- `docs/WITNESS_ENCRYPTION_FLOW.md`
- `docs/WITNESS_TRUTH_RETEST_20260203.md`
- `docs/KVM_TEST_LAB_RUNBOOK.md`
- `docs/VM_ACCESS_HANDOVER.md`
- `docs/HANDOVER_CODEX_NEXT_20260203_POST.md`
- `docs/REPO_STRUCTURE.md`
- `docs/repository_overview.md`

---
## Notes
- Legacy Go sources and legacy docs are preserved under `retired/` and are **excluded from version control**.
- The implementation source of truth is `rust/clear-vnext/` and `csi-n/`.
