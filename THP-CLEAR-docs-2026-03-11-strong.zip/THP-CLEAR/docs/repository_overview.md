# THP-CLEAR Repository Overview (Current Implementation)

This document describes the **current implementation scope** and the **active code layout**.

## 1. Scope
- Source of truth: **Rust vNext** implementation under `rust/clear-vnext/`.
- Control plane: **CSI node** under `csi-n/` (Ops-triggered spawn for dbd-query, role checks).
- **WN node is required by design**; a dedicated crate is not present yet, so MQ/DBD currently cover the minimal responsibilities.
- Legacy Go sources and legacy documents are preserved under `retired/` and are **ignored by Git**.

## 2. Architecture (Implemented)
- **MQ**: `core-mq-s` (server) and `core-mq-c` (client).
- **WN**: design-required node (not yet isolated as a crate; responsibility is temporarily split between MQ and DBD).
- **DBD**: `core-dbd` persists process logs and writes Witness records.
- **Ledger/Witness**: `core-ledger`, `core-witness` provide data structures and witness flow.
- **ID Sync**: `core-id-sync-mock` (mock only; real ID system is out of scope).
- **CSI**: `csi-n` spawns `dbd-query` on DB nodes upon Ops request.

Data flow (implemented):
```
Client -> MQ (min TRON/E-20 verify) -> DBD -> Witness
Ops -> CSI -> (spawn) dbd-query -> Ops (CRK-sealed JSON)
```

## 3. Directory Structure (Current)
```
/
├── csi-n/                 # CSI node (control/supervisor interface)
├── docs/                  # Implementation-aligned documentation (curated)
├── retired/               # Legacy materials (ignored; not tracked)
├── rust/clear-vnext/       # Rust vNext workspace (MQ/DBD/Witness/etc.)
├── config/                 # Configuration assets (if any)
├── deploy/                 # Deployment assets
├── docker-compose*.yml     # Compose definitions
└── Dockerfile*             # Container build definitions
```

## 4. Notes
- Legacy Go code/tests were moved to `retired/` to avoid divergence from the Rust implementation.
- Documentation in `docs/` is curated to reflect the **current** codebase only.
