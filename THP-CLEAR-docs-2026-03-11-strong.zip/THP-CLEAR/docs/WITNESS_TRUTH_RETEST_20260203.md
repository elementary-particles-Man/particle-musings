# Witness Truth Retest (2026-02-03)

対象: THP-CLEAR vNext  
基準: 「不変なのは Witness のみ。その他は運用データ（可変）」

## 実施項目と結果

### RETEST-W-001 Witness Integrity
- 内容: Witness の各ハッシュ領域と `tx_id` を改変して真偽評価を実行。
- 結果: すべて失敗（真偽評価不可）。

### RETEST-W-002 Witness Completeness
- 内容: Witness JSON から必須項目を1つずつ削除して評価。
- 結果: すべて deterministic に失敗（復元不可）。

### RETEST-A-001 Auxiliary Data Necessity
- 内容: 非Witness側のDB項目を1項目ずつ改変し、Witness基準評価を実行。
- 結果: 下表の通り分類確定。

### RETEST-A-002 Metadata Evaluation
- 内容: `metadata_json` を改変して評価。
- 結果: 影響なし（評価成功）。

### RETEST-D-001 Design Validation
- 内容: Witnessを「見た目一貫」に再計算した改ざん候補を投入。
- 結果: すべて失敗。代替の有効真実は成立しない。

## 分類（明示）

### Witness-required（改変すると評価失敗）
- `tx_id`
- `from_account`
- `to_account`
- `from_id`
- `to_id`
- `stable_amount`
- `void_amount`
- `currency_code`
- Witness側必須: `h`, `tx_hash`, `account_hash`, `amount_id_hash`, `tx_id`

### Auxiliary（改変してもWitness基準評価は成立）
- `nonce`
- `sig`
- `metadata_json`

## 実装テスト
- `rust/clear-vnext/crates/core-witness/tests/witness_truth_retest.rs`
- 実行コマンド:
  - `cargo test -p core-witness --test witness_truth_retest`

## 推奨（Witnessスキーマ変更）
- 現時点: `metadata_json` は Auxiliary のまま維持可能（真偽判定には不要）。
- 変更が必要な場合（vNext+1）:
  - `metadata_json` のうち「真偽に必須なキーのみ」を正規化して新ハッシュ欄に追加。
  - 全metadataをそのままハッシュ対象化するのではなく、必須キーを限定して運用責任範囲を明確化。
