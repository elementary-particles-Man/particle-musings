# TEST REPORT MISSING: CLEAR-ID

実施日: 2026-02-03
対象: `/mnt/Ext4-Data/Develop/CLEAR-ID/clearid_server`

## 0. 今回の前提
- 先に `clearid_server` のビルドエラーを修正してから再試験。
- 修正箇所:
  - `clearid_server/src/auth.rs`（レスポンス型整合、`let...else` 構文、時刻型整合）
  - `clearid_server/Cargo.toml`（`tower-http` に `fs` feature 追加）
- ビルド確認: `DATABASE_URL=... cargo build` 成功。

## 1. CLEAR_ID_T01_MIGRATION_APPLY（DONE）
### 1-1. 空DB適用
- DB: `clear_id_empty`
- 適用順:
  1. `20251202_create_pat_sessions.sql`
  2. `20251203_create_clearid_identities.sql`
  3. `20260201_create_users.sql`
  4. `20260201_create_sessions.sql`
  5. `20260201_add_must_change_password.sql`
  6. `20260201_add_revoked_at.sql`
- 結果: `users/sessions` 含む必要テーブル作成確認。

### 1-2. 既存DB（旧users想定）適用
- DB: `clear_id_existing`
- 事前: `users(id,email,password_hash,created_at)` のみ作成
- 実施: `add_must_change_password`, `add_revoked_at`
- 結果: 追加列を確認。

## 2. CLEAR_ID_T02_REGISTER_LOGIN_CHANGE_PASSWORD_E2E（DONE）
- 対象フロー: register -> login(temp) -> me -> change_password -> me
- 結果:
  - `register`: `201`
  - temp password ログ出力: 取得成功
  - `login`(誤PW): `401`
  - `login`(temp PW): `200`
  - `me`(変更前): `200`, `must_change_password=true`
  - `change_password`(ASCII外): `400`
  - `change_password`(正常): `200`
  - `me`(変更後): `200`, `must_change_password=false`

## 3. CLEAR_ID_T03_COOKIE_FLAGS_AND_TTL（PARTIAL）
- Set-Cookie確認:
  - `HttpOnly` あり
  - `SameSite=Lax` あり
  - `Path=/` あり
  - `Max-Age=604800`（7日）
- TTL失効の実時間確認:
  - 未実施（7日経過待ちが必要なため）。
  - よって本項目は PARTIAL。

## 4. CLEAR_ID_T04_LOGOUT_REUSE_OLD_COOKIE（DONE）
- `logout`: `200`
- 旧cookieで `/auth/me`: `401`
- 判定: 旧セッション無効化を確認。

## 5. CLEAR_ID_T05_REVOKE_FLOW（DONE）
- `revoke`: `200`
- revoke後 `/auth/me`: `401`
- revoke後 `login`: `401`
- 判定: revoke後の利用拒否が一貫。

## 6. CLEAR_ID_T06_CONCURRENCY_UNIQUE_EMAIL（DONE）
- 条件: 同一emailで 50並列 register
- 結果:
  - `201`: 1件
  - `400`: 49件
  - DB `users` 件数: 1件
- 判定: unique制約維持を確認。

## 7. 主要エビデンス（要約）
- `REG1=201`
- `LOGIN_WRONG=401`
- `LOGIN_OK=200`
- `CP_BAD=400`
- `CP_OK=200`
- `ME_OLD_COOKIE=401`
- `REVOKE=200`
- `LOGIN_AFTER_REVOKE=401`
- `CONC_CREATED=1`
- `CONC_BADREQ=49`
- `USERS_COUNT=1`
- `COOKIE_FLAGS=set-cookie: ... HttpOnly; SameSite=Lax; Path=/; Max-Age=604800`

