# VM Access Handover（後続向け）

## 1. 先に結論
- 本ラボで必要なのは **VMログイン用の通常SSH（OpenSSH）**。
- GitHub用SSH鍵、TLS証明書、NTK/CRK鍵とは別物。

## 2. なぜ「単体は通るがE2Eで止まる」のか
- `cargo test` / unit test: SSH不要。
- MQ API疎通（`/mq/enqueue/stable`）: SSH不要。
- systemd設定変更（環境変数注入）と `mqd` 再起動: **SSHまたはVMコンソール必須**。

## 3. ラボ特性（重要）
- セグメント `192.168.122.0/24` は libvirt NAT ローカル。
- VM到達性と認証は、**ホスト側のVMログイン経路定義**に依存する。
- 経路未共有の状態では、後続はE2Eを再現できない。
- サーバ実体パスは `/media/flux/THPDOC/Develop/THP-CLEAR`（`thpdoc/Develop/THP-CLEAR/` に対応）。
- SMB/GVFS マウント経由では `chmod/chown` が失敗し得るため、権限変更は `192.168.234.7` にリモートログインし、上記実体パスで実行すること。

## 4. まず確認すること（後続チェックリスト）
1. VMへ入る正規経路は何か（`ssh` / `virsh console` / `virt-manager` / 既存運用ユーザー）。
2. SSHユーザー名（例: `clear` 以外が正の場合あり）。
3. 認証方式（公開鍵/パスワード）と鍵配布場所。
4. `sudo` 実行可否（systemd反映に必要）。

### 補足（本ラボ実績）
- cloud-init 定義は `/var/lib/libvirt/images/clear/*-cloudinit.yaml` にある。
- 本テストラボでは `clear` ユーザーが `sudo NOPASSWD` で作成されていた。
- ただし認証情報は再生成・変更され得るため、固定値として過信しないこと。

## 5. 最短復旧フロー
### A) まず通常SSH確認
```bash
ssh <user>@192.168.122.101
```

### B) SSH不可ならコンソールで鍵登録
```bash
virsh list --all
virsh console <vm-name>
```

VM内で `authorized_keys` を整備し、再度SSH確認する。

## 6. 禁止・非推奨
- GitHub用鍵をそのままVMログイン用途とみなすこと。
- CLEAR暗号鍵（NTK/CRK等）とOSログイン鍵の混同。
- リポジトリ内で認証鍵を探索して代用する運用。

## 7. TASK-VN-001 への影響
- 実装・単体試験が完了していても、VMログイン経路未共有ならE2Eは停止する。
- 判定は `READY_FOR_VERIFICATION` のまま維持し、経路確立後にE2Eを実施する。
