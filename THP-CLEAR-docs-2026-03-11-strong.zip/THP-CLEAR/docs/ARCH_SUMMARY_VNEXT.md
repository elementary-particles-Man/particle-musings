# ARCH SUMMARY vNext

## 1. 目的と設計思想
THP-CLEAR vNext は、金融取引の真正性を「中央の信頼」ではなく「証言の整合性」で担保する分散台帳基盤です。

中核思想は以下です。
- Witness-driven Integrity: 取引を複数イベントの整合で確定する。
- Atomic Decomposition: 複合取引を最小イベントへ分解し、後段で再構成する。
- TICT (Witness Integrity Rules): 取引種別ごとに「必要ロール」「照合条件」「時間条件」を契約化する。

## 2. データプレーン
標準パイプラインは以下です。
- MQ (`core-mq-s`): 正規化・最小検証・ルーティング
- WN (`core-wn`): TICTベースの照合、commit判定、署名生成
- DB (`core-dbd` + `core-ledger`): 署名付き台帳保存と監査可能状態の維持

流れ:
1. MQ が入力電文を `metadata_json` に正規化。
2. WN が `infra_type` ごとにイベントロールを解釈し、`pairing_id` 単位で照合。
3. 条件成立時のみ LedgerEntry を生成し署名。
4. DB が署名検証後に永続化。

## 3. コントロールプレーン (CSI-n)
CSI-n は運用制御と可観測性を担います。
- ノード登録 (`/infra/register`)
- ハートビート受信 (`/infra/heartbeat`)
- 警告集約 (`/ops/alert`)
- KMS署名エンドポイント (`/kms/sign`)

KVMラボの 1-3-2 構成では、`virbr0 (192.168.122.0/24)` 上で全ノードがCSIへ接続し、状態監視を一元化します。

## 4. Keyless KMS セキュリティモデル
Phase 6 で WN の秘密鍵ローカル保持を廃止しました。

- WN は `CLEAR_WN_SIGNING_MODE=remote` で起動。
- WN は `CLEAR_WN_ED25519_SK` を持たず、署名要求のみ CSI に送信。
- CSI は単一保護領域の Master SK で署名実行。
- `/kms/sign` は NodeMap 登録済みかつ `role=WN` のノードのみ許可。

この構成により、署名能力は残しつつ、秘密鍵漏えい面を WN ノードから切り離せます。

## 5. 監査可能性
`audit_verify` により、DB保存済みエントリの署名を再検証できます。
- 改ざん（1bit変更含む）時は `TAMPERED`
- 正常時は `OK`

この仕組みにより、保存後の不正更新を高確度で検出できます。

## 6. 現在のKVM実装像 (1-3-2)
- MQ: 1台（受付・検証・WN転送）
- WN: 3台（分散照合・証言生成）
- DB: 2台（保存・検証）
- CSI: ホスト側集約制御

実運用に近い分散条件で、BANK/CARD/EVM（TRON連携）とKeyless署名の成立を確認済みです。
