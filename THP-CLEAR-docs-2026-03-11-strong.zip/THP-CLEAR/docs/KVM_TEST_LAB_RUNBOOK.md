# KVMテストラボ Runbook（作成 / 停止）

## 1. 目的
- THP-CLEAR の仮想実稼働テスト環境（MQ+CSI 3台 / DB+CSI 3台）を、KVM/libvirt 上で再作成・停止するための手順。
- 既存の構成情報は `TEST_LAB_STATUS.md` を正本とし、本書は運用手順を補完する。

## 2. 前提
- ホスト: Linux（libvirt 利用可能）
- 仮想化: KVM/libvirt（`qemu:///system`）
- ネットワーク: libvirt NAT（`default`, `192.168.122.0/24`）
- 操作ユーザー: `sudo` 権限あり
- `systemd` 前提の運用（`systemctl` / unit再起動 / watchdog連携）を実行する場合は、`192.168.234.7`（PID1=systemd）上で実施すること。
- ノートPC等（`192.168.234.7` 以外）では PID1 が systemd でない場合があり、`systemctl` 前提テストが失敗し得る。
- サーバ実体パス: `/media/flux/THPDOC/Develop/THP-CLEAR`（共有上の `thpdoc/Develop/THP-CLEAR/` に対応）。
- `chmod/chown` が必要な作業は、SMB/GVFS マウント側ではなく、`192.168.234.7` にログインして上記実体パスで実行すること。

## 3. 事前準備（ホスト）
```bash
sudo apt-get update
sudo apt-get install -y qemu-kvm libvirt-daemon-system libvirt-clients virtinst cloud-image-utils
sudo systemctl enable --now libvirtd
sudo virsh -c qemu:///system net-start default || true
sudo virsh -c qemu:///system net-autostart default
```

## 4. テスト用仮想環境の作成手順

### 4.1 作業ディレクトリ作成
```bash
mkdir -p tmp/kvm-lab/images tmp/kvm-lab/cloud-init tmp/kvm-lab/logs
```

### 4.2 ベースイメージ配置
- 例: Ubuntu Cloud Image を `tmp/kvm-lab/images/base.qcow2` として配置。
- 配置後、各ノード向け overlay を作成。

```bash
for n in clear-mq-1 clear-mq-2 clear-mq-3 clear-db-1 clear-db-2 clear-db-3; do
  qemu-img create -f qcow2 -F qcow2 -b tmp/kvm-lab/images/base.qcow2 tmp/kvm-lab/images/${n}.qcow2
done
```

### 4.3 cloud-init seed 生成（各ノード）
- ノードごとに `user-data` / `meta-data` を作り `seed.iso` を生成する。
- 例（`clear-mq-1`）:

```bash
cat > tmp/kvm-lab/cloud-init/clear-mq-1-user-data <<'EOF'
#cloud-config
users:
  - name: clear
    sudo: ALL=(ALL) NOPASSWD:ALL
    groups: [sudo]
    shell: /bin/bash
ssh_pwauth: false
package_update: true
packages:
  - qemu-guest-agent
runcmd:
  - systemctl enable --now qemu-guest-agent
EOF

cat > tmp/kvm-lab/cloud-init/clear-mq-1-meta-data <<'EOF'
instance-id: clear-mq-1
local-hostname: clear-mq-1
EOF

cloud-localds \
  tmp/kvm-lab/cloud-init/clear-mq-1-seed.iso \
  tmp/kvm-lab/cloud-init/clear-mq-1-user-data \
  tmp/kvm-lab/cloud-init/clear-mq-1-meta-data
```

### 4.4 VM 作成（6台）
- 以下をノードごとに実行（CPU/メモリ/ディスクは必要に応じて調整）。

```bash
sudo virt-install \
  --connect qemu:///system \
  --name clear-mq-1 \
  --memory 4096 \
  --vcpus 2 \
  --import \
  --os-variant ubuntu22.04 \
  --disk path=tmp/kvm-lab/images/clear-mq-1.qcow2,format=qcow2,bus=virtio \
  --disk path=tmp/kvm-lab/cloud-init/clear-mq-1-seed.iso,device=cdrom \
  --network network=default,model=virtio \
  --graphics none \
  --noautoconsole
```

### 4.5 IP確認と初期疎通
```bash
sudo virsh -c qemu:///system list --all
sudo virsh -c qemu:///system net-dhcp-leases default
```

- 目標IP（既存ラボ）:
  - MQ: `192.168.122.101`, `192.168.122.50`, `192.168.122.86`
  - DB: `192.168.122.185`, `192.168.122.54`, `192.168.122.196`

## 5. テスト実行後の停止手順

### 5.1 ノード内サービス停止（推奨）
```bash
ssh clear@192.168.122.101 'sudo systemctl stop mqd csi-n-1 csi-n-2 csi-n-3'
ssh clear@192.168.122.185 'sudo systemctl stop dbd csi-n-1 csi-n-2 csi-n-3'
```

### 5.2 VM停止
```bash
for n in clear-mq-1 clear-mq-2 clear-mq-3 clear-db-1 clear-db-2 clear-db-3; do
  sudo virsh -c qemu:///system shutdown "$n"
done
```

### 5.3 停止確認
```bash
sudo virsh -c qemu:///system list --all
```

### 5.4 強制停止（graceful停止失敗時のみ）
```bash
for n in clear-mq-1 clear-mq-2 clear-mq-3 clear-db-1 clear-db-2 clear-db-3; do
  sudo virsh -c qemu:///system destroy "$n"
done
```

## 6. 再開手順
```bash
for n in clear-mq-1 clear-mq-2 clear-mq-3 clear-db-1 clear-db-2 clear-db-3; do
  sudo virsh -c qemu:///system start "$n"
done
```

### 6.1 再開後の健全性確認
```bash
sudo virsh -c qemu:///system list --all
sudo virsh -c qemu:///system net-dhcp-leases default
```

```bash
ssh clear@192.168.122.101 'systemctl status csi-n-1 csi-n-2 csi-n-3 mqd --no-pager'
ssh clear@192.168.122.185 'systemctl status csi-n-1 csi-n-2 csi-n-3 dbd postgresql --no-pager'
```

## 7. ホスト再起動時の手順（今回用途）

### 7.1 再起動前（安全停止）
```bash
# 1) まずVM内サービスを停止（推奨）
ssh clear@192.168.122.101 'sudo systemctl stop mqd csi-n-1 csi-n-2 csi-n-3'
ssh clear@192.168.122.185 'sudo systemctl stop dbd csi-n-1 csi-n-2 csi-n-3'

# 2) VMを停止
for n in clear-mq-1 clear-mq-2 clear-mq-3 clear-db-1 clear-db-2 clear-db-3; do
  sudo virsh -c qemu:///system shutdown "$n"
done

# 3) 停止確認
sudo virsh -c qemu:///system list --all
```

### 7.2 ホスト起動後（復帰）
```bash
# libvirt起動確認
sudo systemctl status libvirtd --no-pager

# default NATネットワークを有効化
sudo virsh -c qemu:///system net-start default || true
sudo virsh -c qemu:///system net-autostart default

# VM起動
for n in clear-mq-1 clear-mq-2 clear-mq-3 clear-db-1 clear-db-2 clear-db-3; do
  sudo virsh -c qemu:///system start "$n"
done

# 状態確認
sudo virsh -c qemu:///system list --all
sudo virsh -c qemu:///system net-dhcp-leases default
```

## 8. 運用メモ
- テスト投入前に `systemctl status` で `mqd` / `dbd` / `csi-n-*` を確認すること。
- TRON RPC を使う試験では、MQ 側に `CLEAR_MQ_TRON_RPC_URL` を設定して実施すること。
- CSI の避難ダンプを使う場合は、環境変数を設定すること:
  - `CLEAR_EVAC_DUMP_CMD='/usr/local/bin/core-mq-s --dump-queue'`
  - 必要に応じて `CLEAR_MQ_QUEUE_SNAPSHOT_PATH=/var/lib/clear/mq_pending_queue.json` を MQ/CSI で共通化すること。
- `/id` `/pat` `CLEAR-ID` リポジトリ領域には触らないこと。
- VMログイン経路の引継ぎ不備があるとE2Eが停止するため、`docs/VM_ACCESS_HANDOVER.md` を先に確認すること。
