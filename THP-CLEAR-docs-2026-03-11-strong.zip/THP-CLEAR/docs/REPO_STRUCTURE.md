# THP-CLEAR Repository Structure（現行実装準拠）

本資料は **現行実装（Rust vNext + CSI）** に合わせた構造説明です。

---

## 1. ルート直下（現行の事実）

主要ディレクトリ/ファイル:

- `.github/` — GitHub Actions
- `csi-n/` — CSI ノード（Ops → CSI → dbd-query の spawn 経路）
- `docs/` — 実装合わせ済みのドキュメント（本ディレクトリ）
- `retired/` — 旧資料/旧Go資産の退避領域（**git 管理外**）
- `rust/` — Rust 実装の主要領域（`rust/clear-vnext` が現行）
- `Dockerfile*` / `docker-compose*.yml` — 配布/実行用のアセット（現行で使用）
- `config/` / `deploy/` / `infra/` / `scripts/` / `tests/` / `witness_logs/` — 参考・補助資産（現行実装の必須構成ではない）

> 注: 旧Go資産は **すべて `retired/` に退避**しています。

---

## 2. Rust vNext 実装（現行）

### `rust/clear-vnext/`

- `crates/`
  - `common-types` — 共通型
  - `core-mq-s` — MQ サーバ（受付・E-20最小検証）
  - `core-mq-c` — MQ クライアント
  - `core-dbd` — DB ノード（保存・Witness化・dbd-query）
  - `core-ledger` — Ledger 構造体
  - `core-witness` — Witness 記録
  - `core-id-sync-mock` — ID 同期のモック

> 重要: **WN ノードは設計上必須**だが、現時点では専用クレートが存在しない。  
> そのため **MQ/DBD に最低限の責務が分散**している。

---

## 3. CSI ノード

### `csi-n/`

- Ops からの要求を受信し、**DB ノードでのみ `dbd-query` を spawn**
- 起動待ちは行わない（spawn-only）

---

## 4. 退避資産

### `retired/`

- 旧Goソース、旧ドキュメント、過去アーカイブを保持
- **Git 管理外（.gitignore 対象）**
- 参照専用

---

**End of document.**
