# TRON E-20 Implementation Status (core-mq-s)

## Files changed
- `rust/clear-vnext/crates/core-mq-s/src/e20.rs`
- `rust/clear-vnext/crates/core-mq-s/src/runner.rs`
- `rust/clear-vnext/crates/core-mq-s/Cargo.toml`

## Insert point confirmation
- `rust/clear-vnext/crates/core-mq-s/src/runner.rs:run()`
- Inserted immediately after `to_ledger_entry()` and before `dbd_client.send()`.

## What is verified
- tx exists (via `TronRpc::get_tx`)
- receipt exists + success (via `TronRpc::get_receipt`)
- TRC-20 Transfer event match (token/from/to/amount)
- confirmation threshold (default 19; configurable via `CLEAR_MQ_E20_CONFIRMATIONS`)
- TRON HTTP API接続（`/wallet/gettransactionbyid`, `/wallet/gettransactioninfobyid`, `/wallet/getnowblock`）

## What is explicitly out of scope
- balances or account state
- UI / Web UI
- search/indexing
- WN/DB behavior changes
- CLEAR-ID or /id /pat

## Notes on output to DBD
- On successful verification, `metadata_json.e20` is updated with:
  - `chain`
  - `token`
  - `finality` (1 confirmed / 0 otherwise)
  - `transfer_digest` (tx hash hex)
- On verification failure, entry is dropped before DBD send (fail-closed).

## Runtime switch
- `CLEAR_MQ_TRON_RPC_URL` 未設定: `TronRpcStub` を使用（従来通り fail-closed）
- `CLEAR_MQ_TRON_RPC_URL` 設定あり: `HttpTronRpc` を使用
- `CLEAR_MQ_TRON_RPC_TIMEOUT_MS` でHTTPタイムアウトを調整（default: 3000ms）

## Remaining TODO
- 実運用チェーンデータでのイベント互換性確認（ノード実装差分吸収）

## Lab verification (2026-02-03)
- 実RPC: `https://api.trongrid.io`
- 正常系で `e20_verify_ok` を確認し DB保存を確認
- 異常系（amount改ざん）で `e20_verify_fail`（`MismatchAmount`）を確認
- fail-closed（異常系未保存）が動作することを確認
