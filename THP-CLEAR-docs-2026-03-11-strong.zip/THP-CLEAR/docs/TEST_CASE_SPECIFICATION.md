# TEST CASE SPECIFICATION

## 1. 目的
本仕様は、THP-CLEAR vNext の整合性検証が「なぜ妥当か」「どう検証するか」をケース単位で明示します。

## 2. テスト設計原則
- 正常系だけでなく不整合系を必ず含める。
- すべて TICT ルールの成立/不成立で判定する。
- commit の成否は DB の `witness_signature` と `audit_verify` で最終確認する。

## 3. ケース定義

### 3.1 EVM (TRON / E20)
対象:
- 単一イベント型 (`ONCHAIN_EVENT`) で commit するシナリオ

検証観点:
- MQ が TRON RPC から `blockNumber` と最新高を取得し `confirmations` を算出
- `confirmations >= 閾値` で finality を confirmed として WN へ送る
- WN が `STATUS(confirmations >= min_value)` を満たした場合のみ commit

失敗観点:
- RPCエラー時は fail-closed（DBへ送らない）
- receipt mismatch / transfer mismatch は reject

妥当性:
- チェーン確定性を「イベント事実＋深さ条件」で検証するため、単発送信でも恣意的commitを防止できる。

### 3.2 BANK (ISO20022: pacs.008 + camt.054)
対象:
- 多ロール照合型 (`INSTRUCTION_PACS008` + `CREDIT_NOTIFICATION_CAMT054`)

検証観点:
- `pairing_id = uetr` で同一取引を束ねる
- `VALUE_MATCH(amount, currency)` が成立したときのみ commit
- 1本目のみ投入時は `pending`

失敗観点:
- 金額/通貨不一致で mismatch
- 必須ロール欠落が timeout すると mismatch

妥当性:
- 指図電文と入金通知の二相一致を要求するため、片系偽装を排除できる。

### 3.3 CARD (Auth + Clearing)
対象:
- `AUTH_EVENT` と `CLEARING_EVENT` の照合

検証観点:
- `pairing_id = rrn`
- `VALUE_MATCH(amount, currency)`
- `TEMPORAL(max_seconds)` を満たす時のみ commit

失敗観点:
- 時間窓超過で mismatch
- amount/currency の差分で mismatch

妥当性:
- カード二重電文モデルの業務整合を時系列制約込みで再現できる。

### 3.4 Tamper Detection
対象:
- DBに保存済み LedgerEntry の改ざん検知

検証観点:
- `audit_verify` で署名と canonical hash を再計算
- 正常: `OK`
- 改ざん: `TAMPERED`

妥当性:
- 保存後改変の検知能力をオフラインで再現可能。

### 3.5 KMS (Keyless Signing)
対象:
- WN秘密鍵なしでの署名成立

検証観点:
- WN起動設定: `CLEAR_WN_SIGNING_MODE=remote`、`CLEAR_WN_ED25519_SK` 未設定
- WN -> CSI `/kms/sign` 呼び出し
- CSI 側 NodeMap 認可（`role=WN` のみ許可）
- DB保存後に `audit_verify=OK`

失敗観点:
- 未認可 node_id は `403 Forbidden`
- KMS鍵未設定時は署名不能

妥当性:
- 署名能力と鍵分離を同時に成立させる。

## 4. 合否判定
- commit成立: DBに対象 `tx_id` が保存され `witness_signature IS NOT NULL`
- mismatch成立: WN/CSIログに不一致理由が記録され commitされない
- 監査成立: `audit_verify` が `OK`

## 5. 補足
TRON系は外部RPCの可用性に依存するため、再試行戦略と fail-closed の両立で運用する。
