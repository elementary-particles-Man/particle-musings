# CLEAR vNext – Rust-only Workspace

This repository has been fully migrated to the Rust vNext architecture.
All Go-based components (legacy CLEAR v2) have been removed.

## Active Components
- rust/clear-vnext/
  - core-ledger
  - core-witness
  - core-mq-s / core-mq-c
  - core-dbd
  - core-id-sync-mock

## Removed Components
- Go runtime (cmd/src/internal)
- Legacy CLEAR pipeline
- old MQ/DBD implementations

## Notes
- docker-compose.dev.yml provides full dev stack.
- Run E2E tests with:
  ```bash
  CARGO_TARGET_DIR=~/.cargo-target \
  DATABASE_URL=postgres://clear:clear@127.0.0.1:55432/clear_vnext \
  RUN_E2E_VNEXT=1 \
  cargo test -- --ignored
  ```

Workspace is now *fully Rust-native*.
