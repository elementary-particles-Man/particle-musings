# Tamper Evidence Demo

## Setup
Waiting for PostgreSQL to be ready
Applying migrations (assumes permissions)
psql:/mnt/Ext4-Data/Develop/THP-CLEAR/rust/clear-vnext/migrations/20251205_create_ledger_witness.sql:22: NOTICE:  リレーション"clear_ledger_vnext"はすでに存在します、スキップします
psql:/mnt/Ext4-Data/Develop/THP-CLEAR/rust/clear-vnext/migrations/20251205_create_ledger_witness.sql:24: NOTICE:  リレーション"idx_ledger_from_account_vnext"はすでに存在します、スキップします
psql:/mnt/Ext4-Data/Develop/THP-CLEAR/rust/clear-vnext/migrations/20251205_create_ledger_witness.sql:25: NOTICE:  リレーション"idx_ledger_to_account_vnext"はすでに存在します、スキップします
psql:/mnt/Ext4-Data/Develop/THP-CLEAR/rust/clear-vnext/migrations/20251205_create_ledger_witness.sql:26: NOTICE:  リレーション"idx_ledger_from_id_vnext"はすでに存在します、スキップします
psql:/mnt/Ext4-Data/Develop/THP-CLEAR/rust/clear-vnext/migrations/20251205_create_ledger_witness.sql:27: NOTICE:  リレーション"idx_ledger_to_id_vnext"はすでに存在します、スキップします
psql:/mnt/Ext4-Data/Develop/THP-CLEAR/rust/clear-vnext/migrations/20251205_create_ledger_witness.sql:28: NOTICE:  リレーション"idx_ledger_currency_vnext"はすでに存在します、スキップします
psql:/mnt/Ext4-Data/Develop/THP-CLEAR/rust/clear-vnext/migrations/20251205_create_ledger_witness.sql:29: NOTICE:  リレーション"idx_ledger_created_at_vnext"はすでに存在します、スキップします
psql:/mnt/Ext4-Data/Develop/THP-CLEAR/rust/clear-vnext/migrations/20251205_create_ledger_witness.sql:36: NOTICE:  リレーション"clear_witness_vnext"はすでに存在します、スキップします
psql:/mnt/Ext4-Data/Develop/THP-CLEAR/rust/clear-vnext/migrations/20251205_create_ledger_witness.sql:38: NOTICE:  リレーション"idx_witness_tx_id_vnext"はすでに存在します、スキップします
Applied 20251205_create_ledger_witness.sql
Applied 20251206_finalize_schema.sql
psql:/mnt/Ext4-Data/Develop/THP-CLEAR/rust/clear-vnext/migrations/20260206_add_committed_at_to_ledger.sql:4: NOTICE:  リレーション"clear_ledger_vnext"の列"committed_at"はすでに存在します、スキップします
psql:/mnt/Ext4-Data/Develop/THP-CLEAR/rust/clear-vnext/migrations/20260206_add_committed_at_to_ledger.sql:6: NOTICE:  リレーション"idx_ledger_committed_at_vnext"はすでに存在します、スキップします
Applied 20260206_add_committed_at_to_ledger.sql
psql:/mnt/Ext4-Data/Develop/THP-CLEAR/rust/clear-vnext/migrations/20260206_add_signature_to_ledger.sql:4: NOTICE:  リレーション"clear_ledger_vnext"の列"witness_signature"はすでに存在します、スキップします
Applied 20260206_add_signature_to_ledger.sql
Generating Ed25519 keypair
Starting core-id-sync-mock
Starting core-dbd
Starting core-wn
Starting core-mq-s
Waiting for DBD port
warning: fields `from_account` and `to_account` are never read
  --> crates/core-id-sync-mock/src/main.rs:10:5
   |
 9 | struct IdSyncRequest {
   |        ------------- fields in this struct
10 |     from_account: u64,
   |     ^^^^^^^^^^^^
11 |     to_account: u64,
   |     ^^^^^^^^^^
   |
   = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

2026-02-07T01:31:49.783778Z  INFO core_id_sync_mock: starting core-id-sync-mock on 0.0.0.0:38080
2026-02-07T01:31:50.979803Z  INFO core_wn: starting core-wn on 0.0.0.0:39090
warning: unused import: `blake3::Hasher as Blake3`
 --> crates/core-witness/src/lib.rs:4:5
  |
4 | use blake3::Hasher as Blake3;
  |     ^^^^^^^^^^^^^^^^^^^^^^^^
  |
  = note: `#[warn(unused_imports)]` (part of `#[warn(unused)]`) on by default

warning: unused imports: `LedgerEntry` and `Witness128`
 --> crates/core-witness/src/lib.rs:5:20
  |
5 | use common_types::{LedgerEntry, Witness128};
  |                    ^^^^^^^^^^^  ^^^^^^^^^^

warning: field `cfg` is never read
  --> crates/core-ledger/src/lib.rs:26:5
   |
25 | pub struct LedgerService<S> {
   |            ------------- field in this struct
26 |     cfg: LedgerConfig,
   |     ^^^
   |
   = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: struct `NoopStore` is never constructed
 --> crates/core-dbd/src/store.rs:5:12
  |
5 | pub struct NoopStore;
  |            ^^^^^^^^^
  |
  = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

2026-02-07T01:31:51.030237Z  INFO core_dbd: starting core-dbd on 0.0.0.0:38090
Waiting for WN port
## Demo
Running tamper evidence demo
Injecting transaction tx_id=0x5a89d1b484fabc50d2361ea7c0db81ba94a4a86a5447538274e8910a9ddeaf27
WN ingest response:
{"status":"commit"}Waiting for ledger row to be persisted
Audit check (should be OK)
warning: unused import: `blake3::Hasher as Blake3`
 --> crates/core-witness/src/lib.rs:4:5
  |
4 | use blake3::Hasher as Blake3;
  |     ^^^^^^^^^^^^^^^^^^^^^^^^
  |
  = note: `#[warn(unused_imports)]` (part of `#[warn(unused)]`) on by default

warning: unused imports: `LedgerEntry` and `Witness128`
 --> crates/core-witness/src/lib.rs:5:20
  |
5 | use common_types::{LedgerEntry, Witness128};
  |                    ^^^^^^^^^^^  ^^^^^^^^^^

warning: `core-witness` (lib) generated 2 warnings (run `cargo fix --lib -p core-witness` to apply 2 suggestions)
warning: field `cfg` is never read
  --> crates/core-ledger/src/lib.rs:26:5
   |
25 | pub struct LedgerService<S> {
   |            ------------- field in this struct
26 |     cfg: LedgerConfig,
   |     ^^^
   |
   = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: `core-ledger` (lib) generated 1 warning
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 0.10s
     Running `rust/clear-vnext/target/debug/audit_verify 0x5a89d1b484fabc50d2361ea7c0db81ba94a4a86a5447538274e8910a9ddeaf27`
OK
Tampering DB row
UPDATE 1
Audit check (should be TAMPERED)
warning: unused import: `blake3::Hasher as Blake3`
 --> crates/core-witness/src/lib.rs:4:5
  |
4 | use blake3::Hasher as Blake3;
  |     ^^^^^^^^^^^^^^^^^^^^^^^^
  |
  = note: `#[warn(unused_imports)]` (part of `#[warn(unused)]`) on by default

warning: unused imports: `LedgerEntry` and `Witness128`
 --> crates/core-witness/src/lib.rs:5:20
  |
5 | use common_types::{LedgerEntry, Witness128};
  |                    ^^^^^^^^^^^  ^^^^^^^^^^

warning: `core-witness` (lib) generated 2 warnings (run `cargo fix --lib -p core-witness` to apply 2 suggestions)
warning: field `cfg` is never read
  --> crates/core-ledger/src/lib.rs:26:5
   |
25 | pub struct LedgerService<S> {
   |            ------------- field in this struct
26 |     cfg: LedgerConfig,
   |     ^^^
   |
   = note: `#[warn(dead_code)]` (part of `#[warn(unused)]`) on by default

warning: `core-ledger` (lib) generated 1 warning
    Finished `dev` profile [unoptimized + debuginfo] target(s) in 0.10s
     Running `rust/clear-vnext/target/debug/audit_verify 0x5a89d1b484fabc50d2361ea7c0db81ba94a4a86a5447538274e8910a9ddeaf27`
TAMPERED
SUCCESS: Tampering Detected
## Teardown
Stopping services
Done
