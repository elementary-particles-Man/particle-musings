# TAMPER EVIDENCE REPORT

## 実施概要
- 実施日: 2026-02-02
- 対象: Witness 生成/保存の改ざん検知性（tamper-evidence）
- 実行場所: `rust/clear-vnext`
- 使用ストア: `core-ledger` の `PostgresStore`（NoopStore不使用）

## DBエンドポイント（資格情報は伏せ）
- `postgres://127.0.0.1:5432/clear_vnext_tamper`

## ケース数
- 正常系: 2000 件
- 異常系: 2000 件
  - メモリ上フィールド改変検証: 2000 件
  - DB保存後の改変検証: 2000 件

## 実行コマンド
```bash
cd /mnt/Ext4-Data/Develop/THP-CLEAR/rust/clear-vnext
export DATABASE_URL='postgres://clear:clear@127.0.0.1:5432/clear_vnext_tamper'
export TAMPER_NORMAL_CASES=2000
export TAMPER_ABNORMAL_CASES=2000
cargo test -p core-ledger --test _tmp_witness_tamper_1000plus -- --nocapture
```

## 結果
- 出力:
  - `TAMPER_RESULT normal_cases=2000 abnormal_cases=2000 memory_detected=1667 memory_expected=1667 db_mismatch=1667 db_expected_mismatch=1667 metadata_unchanged=333 db_metadata_no_mismatch=333`
- 検知率（異常系）:
  - `1667 / 2000 = 83.35%`
- 理由:
  - `metadata_json` は現在の Witness 入力に含まれないため、`metadata_json` 改変 333 件は不一致にならない（設計どおり）。

## 何を証明したか（Proven）
- Witness入力対象フィールド（`tx_id`, `from_id`, `to_id`, `stable_amount`, `currency_code`）の改変でハッシュが変化することを確認。
- DB保存後に Ledger 側または Witness 側を書き換えると、再計算値と保存値の不一致で検知できることを確認。
- 実DB経路（`PostgresStore`）で 1000 件以上の正常/異常を通した。

## 何を証明していないか（Not Proven）
- 暗号学的な「不変性（immutability）」そのものは未証明。
- ハッシュチェーン、外部アンカー、WORM、外部署名台帳などの append-only 証跡は本試験対象外。

## 参照
- 一時テストファイル（実行時）:
  - `crates/core-ledger/tests/_tmp_witness_tamper_1000plus.rs`
