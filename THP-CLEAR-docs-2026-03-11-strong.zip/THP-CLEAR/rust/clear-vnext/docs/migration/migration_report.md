# Migration Report (CLEAR vNext)

Ground truth priority: vNext schema docs > Rust vNext types > Go implementation (behavioural reference only).

## Status (2025-12-05)
- P1: Inventory / type map / schema diffs — completed (go_inventory.md, go_to_rust_type_map.md, schema_differences_p1.md).
- P2–P4: Pending (ledger/witness logic, MQ/DBD wiring, HTTP API/tests).

## TODO / Open Items
- Map Go DB schema (witness_envelopes.sql) to vNext ledger/witness schema; drop legacy-only fields.
- Define LedgerStore trait and Postgres/sqlx implementation aligned to vNext.
- Migrate packet → LedgerEntry mapping (stable/void split) from src/MQ/builder_v2.go.
- Implement witness builder against vNext Witness128 (blake3) and add tests from fixtures.
- Wire ID-Sync mock HTTP call into DBD flow (core-dbd).
- Rebuild MQ daemons (core-mq-s/core-mq-c) with tokio mpsc and HTTP calls to DBD.
- Recreate HTTP API (axum) for health/enqueue/commit/query and integration tests.

## Notes
- On ambiguous semantics: leave TODO in code and record here with go_file/go_symbol/rust_target.
- On type conflicts: prefer vNext Rust types; note legacy fields here if dropped.
- On unmapped dependencies: wrap thin adapters or mark TODO here.
