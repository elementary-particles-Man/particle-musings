# Go Source Inventory (from clear_vnext_inputs.zip)

Root extracted at `/home/flux/workspace/tmp/go_raw`.

## Top-level
- cmd/mqd (config.go, main.go)
- cmd/mq-tax (config.go, main.go)
- configs/ (node configs, kms, etc.)
- src/ (PoC Go impl)
- internal/ (Go domain/http/crypto/etc.)
- docs/, docs_jp/ (specs), docs/schema/ (JSON schemas, vNext markdown)
- dependency_inventory/ (go_list, cargo_metadata, flutter_pub_deps)

## src/
- DB: db.go, ingest.go, witness_store.go, witness_verify.go, migrations/20251031_witness_envelopes.sql
- MQ: builder_v2.go, queue.go, dispatcher.go, scheduler_v2.go, encryptor/*
- WN: processor_v2.go, worker.go, e20/* (ERC20 adapter)
- model: packet_v2_2.go, witness_v2_2.go
- common: witness.go, kmsclient/*, nodeauth/*, audit/logger.go, message.go
- kms: client_v2.go, service_test.go
- tpm: handler_v2.go
- tax, ubi, crypto: ancillary modules

## internal/
- httpapi: handler.go (REST endpoints)
- domain: types.go, service.go, errors.go
- crypto: keyhub_client.go, master_seed.go, tpm_loader.go
- keyhub: http.go, service.go, metrics.go
- witness: client.go
- monitoring, health, adapters (memory/sqlite), dbearchiver, jptax, peppoljp, lto, tpm, zfs

## docs/schema/
- CLEAR vNext — Integrated Data Schema Specification.md (vNext spec)
- SCHEMA_OVERVIEW.md
- clear_invoice.json, tax_ledger.json, witness_log.json

## tests/
- integration/system/output fixtures
- packet_v2_2_test.go, witness_v2_2_test.go

This inventory is a reference for migration; vNext schema/doc + Rust workspace are the ground truth.
