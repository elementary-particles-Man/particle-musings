# Schema Differences / Notes (P1)

Ground truth: vNext docs (`docs/schema/CLEAR vNext — Integrated Data Schema Specification.md`, `SCHEMA_OVERVIEW.md`). Go code is reference only.

- Packet vs Ledger: Go `packet_v2_2` (352B AES-GCM) is legacy; vNext LedgerEntry is logical record (tx_id, accounts, amounts) without packet cipher. Migration should map packet → LedgerEntry where needed.
- Witness: Go `witness_v2_2` / `common/witness.go` differ (payload, hashes). vNext uses fixed 128B: tx_hash, account_hash, amount_hash, id_hash (blake3). Any extra fields in Go witness are dropped or recorded as TODO.
- ID Sync: Go has no CLEAR-ID integration; vNext requires HTTP-based ID-Sync (mock for now). Any account→ID linkage in Go (if present) is ignored unless needed as behavioural reference.
- Assets: vNext splits stable (i64) and void (U256 placeholder as String). Go amounts may use single int64; choose the correct branch per asset_type.
- DB schema: Go migrations include witness_envelopes (20251031) with legacy fields. vNext ledger/witness schema should be redefined; reuse only relevant columns (tx_id, accounts, hashes). Mark unmapped columns as TODO in migration_report.md.

Action: When migrating modules, prefer vNext types and record any legacy-only fields in migration_report.md.
