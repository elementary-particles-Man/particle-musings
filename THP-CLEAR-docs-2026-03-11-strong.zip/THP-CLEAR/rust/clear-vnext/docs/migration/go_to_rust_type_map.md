# Go → Rust Type Mapping (vNext ground truth)

Priority: vNext schema docs > Rust vNext types > Go code (behavioural ref only).

## Scalars / common
- `int64`/`int` → `i64`
- `uint64` → `u64`
- `string` → `String`
- `[]byte` → `Vec<u8>`
- `time.Time` → `i64` (epoch ms) or `chrono::DateTime<Utc>` if needed; prefer epoch_ms per vNext
- `map[string]interface{}` → `serde_json::Value`

## IDs / assets (vNext)
- `AccountId` = `u64`
- `ClearId` = `u64`
- `TxId` = `u128`
- `AssetType` = enum { Stable(0), Void(1) }
- `StableAmount` = `i64`
- `VoidAmount` = `String` placeholder (upgrade to U256 later)

## LedgerEntry (Rust common-types)
```rust
pub struct LedgerEntry {
    pub tx_id: TxId,
    pub from_account: AccountId,
    pub to_account: AccountId,
    pub asset_type: AssetType,
    pub amount_stable: Option<StableAmount>,
    pub amount_void: Option<VoidAmount>,
    pub timestamp_ms: i64,
    pub status: LedgerStatus,
}
```
- Go source references (packet_v2_2.go, domain/service.go) map into this. Choose `amount_stable` or `amount_void` based on asset.

## Witness128 (Rust common-types)
```rust
pub struct Witness128 {
    pub tx_hash: [u8; 32],
    pub account_hash: [u8; 32],
    pub amount_hash: [u8; 32],
    pub id_hash: [u8; 32],
}
```
- Go witness_v2_2.go / common/witness.go are behavioural refs only; vNext uses blake3 for four 32-byte fields.

## Errors
- Go `error`/`fmt.Errorf`/`errors.Wrap` → `anyhow::Result` + `thiserror` domain enums as needed.

## Concurrency
- Go goroutines/channels → `tokio::spawn` / `tokio::sync::mpsc`
- Go mutex → `tokio::sync::Mutex`

Unknown/ambiguous types: mark TODO and record in migration_report.md.
