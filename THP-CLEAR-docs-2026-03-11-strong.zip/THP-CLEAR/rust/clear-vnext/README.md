# CLEAR vNext (Rust workspace)

This workspace hosts the Rust refactor of CLEAR-Core according to vNext spec:

- CLEAR-ID independent accounts
- stable/voidcoin split asset types
- Ledger + DBD + Witness128
- ID-Sync is mocked (core-id-sync-mock) in this phase.

Crates:

- crates/common-types: shared types (IDs, accounts, assets, Witness128, LedgerEntry, etc.)
- crates/core-ledger: ledger and account DB integration
- crates/core-mq-s: MQ daemon for stable assets
- crates/core-mq-c: MQ daemon for voidcoin/crypto
- crates/core-dbd: DB writer and Witness128 generator (calls ID-Sync mock)
- crates/core-witness: Witness128 construction helpers
- crates/core-id-sync-mock: mock HTTP service for /idsync/resolve

Next steps:

1. Use clear_vnext_inputs.zip (legacy Go implementation) to port logic into these crates.
2. Replace core-id-sync-mock with real CLEAR-ID-backed service when ready.
3. Wire MQ and DB to production backends.

## Docker (dev stack)

`docker-compose.dev.yml` spins up a simple dev stack:

- Postgres (clear/clear, DB: clear_vnext, exposed 55432)
- core-id-sync-mock (port 38080)
- core-dbd (port 38090)
- core-mq-s (port 50051)
- core-mq-c (port 50052)

Usage:
```bash
cd rust/clear-vnext
docker compose -f docker-compose.dev.yml up --build
```

Notes:
- Source is mounted into containers; cargo builds will run inside. First build will be slow.
- Run migrations separately (from host): `DATABASE_URL=postgres://clear:clear@localhost:55432/clear_vnext sqlx migrate run`
- Ports are exposed for manual testing: e.g. POST `/mq/enqueue/stable` on 50051.
