# CLEAR-TAX Docker 多ノード検証レポート

## 実行コマンド結果概要
- `docker network create clear-net`：Docker デーモンソケットへのアクセス権がなく失敗（permission denied）。
- `docker compose up`：外部ネットワーク `clear-net` を作成できなかったため、Compose プロジェクト起動に失敗。
- `docker ps`／`docker stats`：Docker デーモンへの接続権限がなく失敗。
- `/health` 監視および `/tax/ingest`・`/metrics` 取得：対象コンテナ未起動のため想定エンドポイントへ接続できず（HTTP 404 もしくは接続失敗）。

## 既存レポートファイル
- `report/metrics_dbe.txt`：過去に取得されたメトリクスを保持（`tax_flush_total` を含む）が、最新試行に紐づくエビデンスではない。
- `report/metrics_mq.txt`：`mq_queue_depth` を含むメトリクスが未記録。
- `report/docker_stats.txt`：本試行では更新されず、Docker アクセス権限不足により空（または未生成）。

## 次のアクション推奨
1. 実行環境の Docker デーモンにアクセスできるよう権限調整（root 権限付与や `docker` グループへの参加）を実施。
2. `clear-net` ネットワークを再作成後、Compose スタックを再起動。
3. 3ノードの `/health` およびメトリクス URL を再試行し、Prometheus/Grafana 用メトリクスを採取。
