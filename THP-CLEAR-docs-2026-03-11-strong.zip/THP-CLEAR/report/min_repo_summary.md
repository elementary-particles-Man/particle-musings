# CLEAR-TAX Minimum Repo Prep 実行結果

## 実施内容
- `cmd/dbe-tax` にクエリ／クレジットノートハンドラと最小 JP PINT バリデータを追加。
- 新規メトリクス（`tax_warn_total`, `creditnote_link_total`, `duplicate_total`）を Prometheus 登録。
- テストデータ XML を `tests/tax/` 配下に配置。
- サーバーをポート `:9101` で起動し、指定の cURL シナリオを実行。

## 実行結果サマリ
- `/tax/ingest` への POST は既存実装が AES-GCM JSON 包を期待するため `invalid character '<' looking for beginning of value` で失敗。
- `/peppol/credit-note` および `/tax/query` はダミーハンドラにより 200 応答。
- `report/metrics_minimal.txt` にメトリクスを取得（新規 CounterVec は発火していないためエントリなし）。

## 参考ファイル
- メトリクス取得結果: `report/metrics_minimal.txt`
