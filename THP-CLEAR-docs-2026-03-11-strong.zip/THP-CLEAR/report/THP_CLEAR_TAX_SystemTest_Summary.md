# THP-CLEAR-TAX System Test Summary (v3.0)

## DBE-TAX Log

```
2025/11/03 08:55:25 [DBE-TAX] launching server daemon on :9443 ...
2025/11/03 08:55:25 [DBE-TAX] HTTP server listening :9443
```

## Receiver Log

```
2025/11/03 08:55:25 [Peppol-Receiver] listening :9555 /peppol/receive
2025/11/03 08:55:33 [Peppol-Receiver] len=1305 verified=true saved=/tmp/peppol/incoming-20251102-235533.xml
2025/11/03 08:55:33 [Peppol-Receiver] len=1305 verified=true saved=/tmp/peppol/incoming-20251102-235533.xml
2025/11/03 08:55:34 [Peppol-Receiver] len=1305 verified=true saved=/tmp/peppol/incoming-20251102-235534.xml
2025/11/03 08:55:34 [Peppol-Receiver] len=1305 verified=true saved=/tmp/peppol/incoming-20251102-235534.xml
2025/11/03 08:55:35 [Peppol-Receiver] len=1305 verified=true saved=/tmp/peppol/incoming-20251102-235535.xml
```

## Metrics Snapshot

```
# HELP tax_batch_bytes current batch size in bytes
# TYPE tax_batch_bytes gauge
tax_batch_bytes 0
# HELP tax_flush_total total flush operations
# TYPE tax_flush_total counter
tax_flush_total 0
```

## Receiver Analysis

# Peppol Receiver E2E Analysis

- **listening**: 1
- **verified_true**: 5
- **ack**: 5

## DBE Analysis

# DBE-TAX Log Analysis

- **start**: 1
- **flush**: 0
- **stub**: 0
