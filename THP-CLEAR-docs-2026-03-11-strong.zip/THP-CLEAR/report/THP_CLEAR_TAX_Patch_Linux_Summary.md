# THP-CLEAR-TAX Patch Linux Summary

## cmd/wn-tax/client.go

```go
package main

import (
  "bytes"
  "encoding/json"
  "log"
  "net/http"
  "thp-clear/pkg/crypto"
)

func postBatch(){
  key := make([]byte,32)
  nonce := make([]byte,12)
  aad := []byte("tax")
  plain := []byte("sample payload")
  env,_ := crypto.EncryptAESGCM(key,nonce,aad,plain)
  data,_ := json.Marshal(env.ToBase64())
  resp,err := http.Post("http://localhost:9443/tax/ingest","application/json",bytes.NewReader(data))
  if err!=nil{log.Println(err);return}
  defer resp.Body.Close()
  log.Printf("[WN-TAX] sent batch, status=%s",resp.Status)
}
```

## cmd/dbe-tax/main.go

```go
package main

import "log"

func main() {
  log.Println("[DBE-TAX] launching server daemon on :9443 ...")
  startServer()
}
```

## report/metrics_snapshot_linux.txt

```
# HELP tax_batch_bytes current batch size in bytes
# TYPE tax_batch_bytes gauge
tax_batch_bytes 0
# HELP tax_flush_total total flush operations
# TYPE tax_flush_total counter
tax_flush_total 1
```
