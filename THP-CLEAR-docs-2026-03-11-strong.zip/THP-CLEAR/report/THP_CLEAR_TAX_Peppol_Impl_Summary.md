# THP-CLEAR-TAX Peppol Implementation Summary

## pkg/peppol/ubl.go

```go
package peppol

import (
  "encoding/xml"
  "time"
  "fmt"
)

type Invoice struct {
  XMLName xml.Name `xml:"Invoice"`
  XMLNs   string   `xml:"xmlns,attr"`
  ID      string   `xml:"cbc:ID"`
  IssueDate string   `xml:"cbc:IssueDate"`
  InvoiceTypeCode string `xml:"cbc:InvoiceTypeCode"`
  DocumentCurrencyCode string `xml:"cbc:DocumentCurrencyCode"`
  AccountingSupplierParty Party `xml:"cac:AccountingSupplierParty"`
  AccountingCustomerParty Party `xml:"cac:AccountingCustomerParty"`
  LegalMonetaryTotal MonetaryTotal `xml:"cac:LegalMonetaryTotal"`
}

type Party struct {
  PartyName string `xml:"cac:PartyName>cbc:Name"`
  ID string `xml:"cac:PartyIdentification>cbc:ID"`
}

type MonetaryTotal struct {
  PayableAmount string `xml:"cbc:PayableAmount"`
}

func GenerateUBLInvoice(id string, supplier, customer string, amount float64) ([]byte,error){
  inv := Invoice{
    XMLNs: "urn:oasis:names:specification:ubl:schema:xsd:Invoice-2",
    ID: id,
    IssueDate: time.Now().Format("2006-01-02"),
    InvoiceTypeCode: "380",
    DocumentCurrencyCode: "JPY",
    AccountingSupplierParty: Party{PartyName:supplier,ID:"JP-SUP-001"},
    AccountingCustomerParty: Party{PartyName:customer,ID:"JP-CUS-001"},
    LegalMonetaryTotal: MonetaryTotal{PayableAmount: fmt.Sprintf("%.2f",amount)},
  }
  return xml.MarshalIndent(inv,"","  ")
}
```

## pkg/peppol/sbdh.go

```go
package peppol

import (
  "encoding/xml"
  "time"
)

type StandardBusinessDocument struct {
  XMLName xml.Name `xml:"StandardBusinessDocument"`
  Header  SBDHHeader `xml:"StandardBusinessDocumentHeader"`
  Payload []byte     `xml:",innerxml"`
}

type SBDHHeader struct {
  Sender string `xml:"Sender>Identifier"`
  Receiver string `xml:"Receiver>Identifier"`
  DocumentID string `xml:"DocumentIdentification>InstanceIdentifier"`
  CreationDateAndTime string `xml:"DocumentIdentification>CreationDateAndTime"`
}

func WrapSBDH(sender,receiver,docid string,payload []byte) ([]byte,error){
  sbd := StandardBusinessDocument{
    Header: SBDHHeader{Sender:sender,Receiver:receiver,DocumentID:docid,CreationDateAndTime:time.Now().Format(time.RFC3339)},
    Payload: payload,
  }
  return xml.MarshalIndent(sbd,"","  ")
}
```

## pkg/peppol/signature_stub.go

```go
package peppol

import (
  "crypto/sha256"
  "encoding/base64"
)

func SignPupeleStub(data []byte, certID string) string {
  h := sha256.Sum256(data)
  sig := base64.StdEncoding.EncodeToString(h[:])
  return "PupeleStub-"+certID+"-"+sig
}
```

## pkg/peppol/as4_emulator.go

```go
package peppol

import (
  "bytes"
  "log"
  "net/http"
)

func SendAS4(endpoint string, xmlData []byte) error {
  resp,err := http.Post(endpoint,"application/xml",bytes.NewReader(xmlData))
  if err!=nil { return err }
  defer resp.Body.Close()
  log.Printf("[Peppol-AS4] sent to %s status=%s",endpoint,resp.Status)
  return nil
}
```

## report/peppol_demo_output.log

```
Running Peppol UBL demo
```
