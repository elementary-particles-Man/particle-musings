# DBE-TAX Log Analysis

- **start**: 1
- **flush**: 0
- **stub**: 0
