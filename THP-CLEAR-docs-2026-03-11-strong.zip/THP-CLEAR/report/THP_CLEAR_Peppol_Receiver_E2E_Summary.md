# THP-CLEAR Peppol Receiver E2E Summary

## Mock Receiver Log

```
2025/11/03 07:05:16 [Peppol-Receiver] listening :9555 /peppol/receive
2025/11/03 07:05:18 [Peppol-Receiver] len=1305 verified=true saved=/tmp/peppol/incoming-20251102-220518.xml
```

## Analysis

# Peppol Receiver E2E Analysis

- **listening**: 1
- **sent**: 1
- **verified_true**: 1
- **ack**: 1
