# THP CLEAR Schema Generation Summary

| Schema | Title | Properties | Required Fields |
| ------ | ----- | ---------- | --------------- |
| `clear_invoice.json` | CLEAR Invoice | 8 | invoice_id, vendor_id, vendor_name, amount, tax, total, generated_at, signature |
| `witness_log.json` | Witness Log Entry | 8 | entry_id, invoice_id, vendor_id, amount, tax, total, recorded_at, signature |
| `tax_ledger.json` | Tax Ledger Entry | 10 | ledger_id, invoice_id, vendor_id, period, amount, tax, total, submitted_at, status |

Generated from struct extraction payload `tmp/structs_extract.json` using draft 2020-12 schema templates with example objects included.
