# TAX Pipeline Analysis

- **ok**: 1
- **dup**: 0
- **error**: 0
- **fail**: 0
