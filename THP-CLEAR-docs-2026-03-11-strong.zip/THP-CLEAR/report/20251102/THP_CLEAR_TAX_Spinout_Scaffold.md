# THP-CLEAR TAX Spin-out Scaffolding Report

**Job Name:** THP_CLEAR_TAX_Spinout
**Version:** 1.0
**Timestamp (JST):** 2025-11-03T04:36:00+09:00

## Summary

This job has successfully scaffolded the initial directory structure and files for the new CLEAR-TAX component. A total of 23 files and directories were created.

The new component is designed as an AES-only cold-log pipeline with separate daemons for the "Witness Node" (`wn-tax`) and "Database Engine" (`dbe-tax`).

## Key Files Created

### Configuration

*   **`configs/wn-tax.yaml`**: Configuration for the WN-TAX daemon, including MQ endpoints, batching strategy, and KMS settings for hourly key rotation.
*   **`configs/dbe-tax.yaml`**: Configuration for the DBE-TAX daemon, including listener settings, ZFS storage path, and monitoring endpoints.

### API and Schemas

*   **`openapi/dbe-tax.yaml`**: OpenAPI 3.0 specification for the DBE-TAX service. Defines endpoints for data ingestion (`/tax/ingest`), CSV catalog management (`/tax/catalog/{kind}`), and tax computation (`/tax/compute`).
*   **`schemas/tax_keyrotate.json`**: JSON schema for the `tax_keyrotate` event, which is broadcast to facilitate hourly key rotation.
*   **`schemas/csv/README_tax_csv.md`**: Specification for the human-editable CSV catalogs (`tax_rates.csv`, `tax_rules.csv`, `tax_mapping.csv`).

### Documentation

*   **`docs_jp/CLEAR_TAX_Witness_128B_Spec.md`**: Detailed specification for the 128-byte fixed-size witness pointer used in the CLEAR-TAX cold log.
*   **`docs_jp/DBE_TAX_Metrics.md`**: Key performance indicators (KPIs) for monitoring the DBE-TAX service.

### Stubs and Build Scripts

*   Go application stubs for `wn-tax` and `dbe-tax` have been created in the `cmd/` directory.
*   A `Makefile.tax` has been added to `scripts/` for building the new daemons.
*   Systemd service files have been created in `deploy/systemd/`.
*   An integration test plan has been created in `tests/integration/tax/`.

## Next Steps

1.  Implement the logic in the `wn-tax` and `dbe-tax` daemon stubs.
2.  Populate the CSV catalogs in `schemas/csv/`.
3.  Build and deploy the new daemons using the provided Makefile and systemd units.
4.  Execute the integration test plan to verify the end-to-end pipeline.