# TEST REPORT（正常系/異常系）

実施日: 2026-02-02
環境: `TEST_LAB_STATUS.md` 記載の6VM + Ops(ホスト)

## 1. 対象範囲
- フェーズ1: MQ受付→DB保存
- フェーズ2: Ops→CSI→dbd-query spawn
- フェーズ3: dbd-query の ACK 正常/異常

## 2. ノード
- MQ: `192.168.122.101`, `192.168.122.50`, `192.168.122.86`
- DB: `192.168.122.185`, `192.168.122.54`, `192.168.122.196`

## 3. 実施結果サマリ

### 3.1 フェーズ1（MQ→DBD）
- 正常系
  - `POST /mq/enqueue/stable` に正常JSON投入
  - 結果: `HTTP 202`
  - DB確認: `clear_ledger_vnext` に `tx_id=mq-normal-001` を確認
- 異常系
  - 必須項目欠落JSON投入
  - 結果: `HTTP 422`
  - エラー本文: `missing field from_account`

### 3.2 フェーズ2（Ops→CSIトリガ）
- 正常系（DBノード）
  - DB1/DB2/DB3 の `CSI:9109` に `{"kind":"dbd_query",...}` を送信
  - 結果: すべて `{"status":"spawned"}`
  - 各ノードでローカルACKサーバ受信ファイル生成を確認（spawn後の送信を確認）
- 異常系
  - DB2/DB3 に `kind=noop` → `{"status":"ignored"}`
  - MQ2 に `kind=dbd_query` → `{"status":"rejected"}`

### 3.3 フェーズ3（dbd-query ACKフロー）
DB1/DB2/DB3 それぞれで直接 `dbd-query` 実行テストを実施。

- 正常系（ACK=`OK\n`）
  - 結果: `DBD_QUERY_OK_RC=0`
  - 受信確認: `DBD_QUERY_OK_PAYLOAD_FILE=1`
- 異常系（ACK返却なし、タイムアウト）
  - 結果: `DBD_QUERY_NG_RC=1`
  - ログ: `ops ack timeout`

## 4. 実施時の設定変更
DBノード（3台）の `csi-n-1/2/3` に以下を追加:
- `DBD_QUERY_BIN=/opt/clear/bin/dbd-query`
- `CLEAR_WITNESS_LOG_PATH=/var/lib/clear/witness.log`
- `CLEAR_NTK_KEY_B64=AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=`
- `CLEAR_OPS_ADDR=127.0.0.1:9000`

## 5. 判断
- 正常系: フェーズ1〜3 すべて成立
- 異常系: 期待通りに reject/ignore/fail（fail-closed）

## 6. 次アクション
1. Ops実装側と接続し、`CSI:9109` への実送信を組み込む
2. ACK受信を Ops 側で `OK\n` 固定実装に合わせる
3. CRK/NTK を実鍵に置き換え（現在はテスト鍵）
4. TRON RPC 実装を接続し、E-20最小検証を実運用化

