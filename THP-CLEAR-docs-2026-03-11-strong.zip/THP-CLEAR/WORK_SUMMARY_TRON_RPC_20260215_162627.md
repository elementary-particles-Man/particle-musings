# WORK SUMMARY (TRON RPC Integration)

## Scope
- Project: THP-CLEAR vNext
- Objective: Replace TRON stub facts with live RPC-backed facts and align pending/commit behavior.

## Implemented
1. `core-mq-s` TRON HTTP RPC integration hardening
- File: `rust/clear-vnext/crates/core-mq-s/src/e20.rs`
- Added `fee_sun` extraction from `wallet/gettransactioninfobyid` response (`fee`).
- Added `fee_sun` to `E20VerifiedTransfer` / `TronReceipt`.
- `TxNotFound` and `ReceiptMissing` now return **pending** verified facts instead of hard error.
- Confirmations now computed from live `latest_block_height - block_height`.
- `finality` = `Confirmed` only when confirmations >= configured threshold.

2. Metadata generator output (MQ -> WN)
- File: `rust/clear-vnext/crates/core-mq-s/src/e20.rs`
- `augment_ledger_with_e20_min` now writes:
  - `e20.tx_hash`, `e20.token`, `e20.from`, `e20.to`, `e20.amount`
  - `e20.confirmations`
  - `e20.finality` as boolean (`true`/`false`)
  - `e20.fee` (optional)
  - legacy `transfer_digest` maintained for compatibility.

3. MQ runner log behavior refinement
- File: `rust/clear-vnext/crates/core-mq-s/src/runner.rs`
- `e20_verify_ok` log now emits:
  - `finality=confirmed|pending`
  - live `confirmations`

4. Unit test updates for new pending semantics
- File: `rust/clear-vnext/crates/core-mq-s/tests/e20_logic_unit.rs`
- Updated expectations:
  - TxNotFound => pending result (not error)
  - low confirmations => pending result (not error)
  - ReceiptFailed / amount mismatch remain hard errors.

5. Schema documentation update
- File: `docs/specs/MQ_METADATA_SCHEMA.md`
- Updated `e20.finality` to boolean.
- Added optional `e20.fee` and mapping from `fee_sun`.

6. Live pipeline test script for RPC-003
- File: `scripts/run_tron_live_pipeline_test.sh`
- Host-side one-shot script to:
  - enqueue a real TRON tx hash via MQ
  - poll DB for signed commit state
  - print confirmations/finality/fee from persisted metadata.

## Validation
- Command: `cargo test -p core-mq-s`
- Result: PASS (all tests green)

## Notes
- This update intentionally keeps fail-closed for hard integrity errors (receipt failed / event mismatch).
- Pending state is now explicit and observable for not-yet-finalized on-chain facts.
