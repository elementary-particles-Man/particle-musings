# KEYLESS KMS Verification Report

- Date: 2026-02-15
- Scope: THP-CLEAR vNext Phase 6 (Secret-less WN)
- Cluster: KVM NAT (1 MQ / 3 WN / 2 DB)

## 1. Cluster Status
- MQ: `192.168.122.94`
- WN: `192.168.122.113`, `192.168.122.73`, `192.168.122.133`
- DB: `192.168.122.111` (primary), `192.168.122.87`
- CSI Host: `192.168.122.1:9108` (on host `192.168.234.7`)

## 2. WN Remote Signing Configuration (No SK)
Confirmed on all WN nodes:
- `CLEAR_WN_SIGNING_MODE=remote`
- `CLEAR_CSI_URL=http://192.168.122.1:9108`
- `CLEAR_WN_ED25519_SK` is removed from `thp-wn.service`

Startup evidence (`journalctl -u thp-wn`):
- `INFO core_wn: Signing mode: remote`
- `INFO core_wn: CSI URL: http://192.168.122.1:9108`

## 3. CSI KMS Endpoint Evidence
CSI process environment includes KMS key:
- `CLEAR_CSI_KMS_ED25519_SK` set
- `CSI_HTTP_BIND=0.0.0.0:9108`

### Authorization check
Unauthorized node -> rejected:
- Request: `POST /kms/sign` with `node_id=11111111-1111-1111-1111-111111111111`
- Response: `403 Forbidden`
- Body: `node is not authorized for signing`

Authorized WN node -> signed:
- Request: `POST /kms/sign` with WN node_id `3c52c87f-f042-46e5-b844-1a196f5c3786`
- Response: `200 OK`
- Signature (Base64):
  - `44sCmo2cTsMF1AnOxB1nLo4q+jWcpttW3YD1Pkc3Ff91FMdZ0tmbu390CXV7HZjhVx5hjqCzpkE4aDuIOFo3BA==`

## 4. End-to-End Keyless Pipeline Verification

### BANK flow (MQ -> WN remote -> CSI KMS -> DB)
Injected pair:
- `iso_pacs008` + `iso_camt054`
- Pair ID (`uetr`): `bank-kms-20260215171542`

DB result:
- `tx_id=bank-kms-20260215171542`
- `signed=true`

### TRON/EVM flow (MQ -> WN remote -> CSI KMS -> DB)
Using confirmed TRON tx facts:
- `tx_hash=0x627b642ca4858040c9a3565e493b20de9b52c7b039fa86d1663027d79a4cc5f3`
- MQ log evidence: `event="e20_verify_ok" ... finality="confirmed"`

DB result:
- `tx_id=0x627b642ca4858040c9a3565e493b20de9b52c7b039fa86d1663027d79a4cc5f3`
- `signed=true`
- `currency_code=E20`

## 5. Audit Verification (`audit_verify`)
Executed on DB node (`192.168.122.111`) with CSI master public key (`CLEAR_WN_ED25519_PK`):
- `audit_verify bank-kms-20260215171542` -> `OK`
- `audit_verify 0x627b642ca4858040c9a3565e493b20de9b52c7b039fa86d1663027d79a4cc5f3` -> `OK`

## 6. Conclusion
Keyless architecture is verified in distributed KVM cluster:
- WN commits without local private key in environment
- CSI enforces role-based signing authorization
- Remote-signed entries are persisted and cryptographically valid (`audit_verify=OK`)
