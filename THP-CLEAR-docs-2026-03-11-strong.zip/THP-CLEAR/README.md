# CLEAR vNext (Rust Edition)

This repository has fully migrated to Rust vNext.
The former Go-based CLEAR v2 implementation is archived under the git tag `legacy-clear-v2`.

Active crates:
- core-ledger
- core-witness
- core-dbd
- core-mq-s
- core-mq-c
- core-id-sync-mock

Dev environment:
```bash
docker compose -f rust/clear-vnext/docker-compose.dev.yml up --build
```
