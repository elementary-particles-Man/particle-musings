# TEST RESULTS 2026-02-15 (Bulk 3,000 Cases)

## 1. 実行概要
- 実行環境: KVM分散クラスタ (MQ1 / WN3 / DB2)
- 実行時刻 (JST): `2026-02-15 23:29:02` 〜 `2026-02-15 23:30:12`
- ケース定義: `TestCase-20260215.md`
- 実行スクリプト: `scripts/run_bulk_test_20260215.sh`
- 生データ:
  - `artifacts/bulk_test_20260215/injection_results.csv`
  - `artifacts/bulk_test_20260215/witness_logs/wn-01.log`
  - `artifacts/bulk_test_20260215/witness_logs/wn-02.log`
  - `artifacts/bulk_test_20260215/witness_logs/wn-03.log`

## 2. ケース投入量
- 論理ケース数: 3,000
  - 正常系: 1,000
  - 異常系: 1,000
  - 予測不可能系: 1,000
- HTTP投入リクエスト総数: 4,699
  - ペア型ケース（BANK/CARD）は2リクエストで1ケースのため、総リクエスト数はケース数より多い

## 3. HTTP受理結果（MQ入口）
`injection_results.csv` 集計:
- 正常系
  - `202`: 1,999
- 異常系
  - `202`: 1,400
  - `422`: 300
- 予測不可能系
  - `202`: 651
  - `400`: 349

解釈:
- MQ入口で形式的に受理されるもの (`202`) と、即時拒否 (`400/422`) が分離されている。
- fail-closed設計により、受理後もWN/DB段で commit されるとは限らない。

## 4. DB確定結果（commit）
DB集計（`clear_ledger_vnext`）:
- 正常 BANK commit: `499`
- 正常 CARD commit: `500`
- 正常 EVM commit (実行ウィンドウ内): `0`
- 異常系 commit: `0`
- 予測不可能系 commit: `0`

### 正常系 commit 率
- BANK + CARD: `999 / 999 = 100%`
- EVM: `0 / 1 = 0%`（外部TRON RPC依存のため本バルク実行ウィンドウ内では未成立）

補足:
- 同日別セッションでは実TRON txの `e20_verify_ok` と commit 成立を確認済み（`KEYLESS_KMS_VERIFICATION_REPORT.md` 参照）。

## 5. Witnessログ保存結果
保存先:
- `artifacts/bulk_test_20260215/witness_logs/wn-01.log`
- `artifacts/bulk_test_20260215/witness_logs/wn-02.log`
- `artifacts/bulk_test_20260215/witness_logs/wn-03.log`

観測事項:
- 現在の `thp-wn` journal 出力は systemd 起動停止イベントが中心。
- 1ケース単位の commit/mismatch 詳細ログは限定的であり、詳細判定は DB集計 + MQログで補完した。

## 6. 結論
- BANK/CARDについては大規模投入で正常系 100% commit、異常/予測不可能系 100% non-commit を確認。
- EVMはバルク時点で外部RPC依存により未成立ケースが発生しうることを再確認。
- Witness整合性モデル（TICT）としては、誤commit抑止（異常/未知入力の非commit）に有効に機能。

## 7. 次アクション
1. WNのイベント単位ログ（commit/pending/mismatch）をINFO以上で恒久出力する。
2. EVMバルク試験用に「事前抽出済み confirmed tx セット」を複数用意し、RPC変動影響を低減する。
3. 本結果を `docs/FINAL_TEST_RESULTS_REPORT.md` に追記して最終版へ統合する。
