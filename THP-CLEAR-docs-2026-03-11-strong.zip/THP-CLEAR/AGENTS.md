# AGENTS.md

## 応対言語
- **必ず日本語で応答すること。**（ユーザーは英語を読めません）

## 直近の進捗（要約）
- 仕様書末尾に「既知差分一覧（齟齬・未接続点）」を追記済み。
- TRON/TRC-20 最小検証（fail-closed）を MQ に実装済み（RPC はスタブ）。
- dbd-query（DB検索サブプロセス）を新規実装し、CSI 経由で spawn する経路を追加済み。
- sqlx offline mode を有効化し、`rust/clear-vnext/.sqlx/` と `rust/clear-vnext/sqlx-data.json` を生成済み。
- README 系はルート直下維持（`README.md` / `README_RUST_ONLY.md`）。
- 仮想実稼働テスト環境（NAT）を構築済み:
  - MQ+CSI 3台 / DB+CSI 3台 / Opsはホスト
  - 全ノードで CSI 3重起動を systemd 化
  - DBノード3台に PostgreSQL + migration 適用済み
  - MQ投入→DB保存まで確認済み
- 正常系/異常系の統合テストを実施し、レポート化:
  - `TEST_REPORT_PHASE1_PHASE3.md`（ルート直下）
  - フェーズ1(MQ→DB), フェーズ2(Ops→CSI spawn), フェーズ3(dbd-query ACK) を検証

## 重要な決定/運用前提
- **E-20 検証は MQ 側**（DBD 送信直前）で最小検証。
- **fail-closed** が前提：TRON RPC 未接続時は DBD に送らない。
- **dbd-query は spawn-only / ACK 待ち / 自壊**。
- ACK 仕様は `OK\n` 固定（厳格）。

## 主要ファイル（変更点の目印）
- 仕様書：`docs/CLEAR-vNext最終仕様書.md`（末尾に既知差分一覧）
- TRON 最小検証：`rust/clear-vnext/crates/core-mq-s/src/e20.rs`
- MQ runner への差し込み：`rust/clear-vnext/crates/core-mq-s/src/runner.rs`
- dbd-query：`rust/clear-vnext/crates/core-dbd/src/bin/dbd_query.rs`
- CSI spawn 経路：`csi-n/src/rpc/ops_listener.rs`, `csi-n/src/rpc/mod.rs`, `csi-n/src/main.rs`

## 実運用が難しい理由（現状）
- 実チェーン接続（TRON RPC）が未接続で **常時 fail-closed**。
- Ops → CSI → dbd-query の **実ネットワーク経路**と **鍵運用（NTK/CRK）**が未整備。
- そのため「本番相当の実データ運用」は現時点では実施困難。

## 次にやるべき最低限（実運用に近づけるため）
- TRON RPC の実装（TronRpc を HTTP 実装し、実環境へ接続）。
- Ops → CSI → dbd-query の実ネットワーク接続。
- NTK/CRK の実鍵（TPM/安全マウント）の準備。

## 現在のテストラボ（重要）
- 構成資料: `TEST_LAB_STATUS.md`（ルート直下）
- 開始/停止/ホスト再起動手順: `docs/KVM_TEST_LAB_RUNBOOK.md`
- VMアクセス引継ぎ: `docs/VM_ACCESS_HANDOVER.md`
- VM IP:
  - MQ: `192.168.122.101`, `192.168.122.50`, `192.168.122.86`
  - DB: `192.168.122.185`, `192.168.122.54`, `192.168.122.196`
- ホスト管理IP（固定）: `192.168.234.7/24`
- 主要ポート:
  - CSI: `9109` / `9110` / `9111`
  - MQ: `50051`
  - DBD: `38090`
- テストレポート:
  - `TEST_REPORT_PHASE1_PHASE3.md`

## 次にやること（後続CODEX向け）
1. Ops実装側へ `CSI(9109)` 送信を接続し、テスト用スクリプト運用から本実装運用へ移行。
2. dbd-query の `CLEAR_OPS_ADDR`/鍵注入を運用設定へ固定（現在はテスト値）。
3. TRON RPC 実装を接続し、E-20最小検証を fail-closed から運用可能状態へ移行。
4. WN 分離計画（設計必須）を `core-wn` crate 新設で着手。

## 直近のコミット
- `067f8ea` : 仕様書に既知差分一覧を追記（Push 済み）
- `cc32f5d` : docsへ WN設計必須（未分離）を明記（Push 済み）

## 実行ホスト判定ルール（重要）
- 作業開始時に必ず自ホストIPを確認すること（例: `hostname -I` / `ip -4 addr`）。
- `192.168.234.7` は **PID1 が systemd の実行ホスト**（KVMラボ本体）。
- サーバ実体パスは `/media/flux/THPDOC/Develop/THP-CLEAR`（`thpdoc/Develop/THP-CLEAR/` に対応）。
- ノートPC等の `192.168.234.7` 以外では、PID1 が systemd でない場合があるため、`systemctl` 前提の起動/監視テストは失敗し得る。
- **自ホストIPが `192.168.234.7` 以外の場合**:
  - その作業場所は **NFSマウントされた同一リポジトリ** とみなすこと。
  - ファイル編集はそのまま実施してよい（同一リポジトリに反映される）。
  - `systemd` 依存の検証（`systemctl` / unit restart / watchdog連携）は原則行わず、必要時は `192.168.234.7` 上で実施すること。
  - SMB/GVFS マウント経由では `chmod/chown` が失敗する場合があるため、権限変更は `192.168.234.7` へリモートログイン後、実体パスで実行すること。
  - ただし、KVM起動・停止、複数VMビルド配布などの**メモリ/CPU負荷が高い作業**は行わないこと。
- 高負荷作業（KVM/大規模ビルド/分散配布/ラボ運用）は、必ず `192.168.234.7` にリモートログインして実施すること。
- `192.168.234.7` への接続後に、そこで `virsh` / `systemctl` / 配布スクリプトを実行すること。

## 注意
- `/id` `/pat` `CLEAR-ID` リポジトリは触らないこと。
- README はルート直下に残す必要がある。
- ラボ作業前に `docs/KVM_TEST_LAB_RUNBOOK.md` の開始/停止手順を必ず確認すること。

## Git Push手順（この環境）
- このリポジトリの push は、以下の専用鍵を使う:
  - 秘密鍵: `/home/flux/mnt/thpdoc/Develop/ssh/id_ed25519`
  - known_hosts: `/home/flux/mnt/thpdoc/Develop/ssh/known_hosts`
- 実行コマンド:
```bash
GIT_SSH_COMMAND='ssh -i /home/flux/mnt/thpdoc/Develop/ssh/id_ed25519 -o UserKnownHostsFile=/home/flux/mnt/thpdoc/Develop/ssh/known_hosts -o StrictHostKeyChecking=yes' git push
```
- `Permission denied (publickey)` が出る場合は、`git push` 単体ではなく上記コマンドを使うこと。

## KMS通信のzip-ISE-AESラップ（SEC-001/SEC-002）
- 目的: `/kms/sign` の通信ペイロードを **バイナリ暗号化**し、ISEラップされていない要求はサイレントドロップする。
- 方式: `JSON -> gzip -> ISE -> AES-256-GCM(session) -> binary POST`
- CSI側（`csi-n`）の環境変数:
  - `CLEAR_CSI_SECURE_ENABLE=1`（有効化）
  - `CLEAR_CSI_SECURE_REQUIRE_ALL=1`（`/infra/register` `/infra/heartbeat` `/ops/alert` `/kms/sign` を暗号必須。省略時true）
  - `CLEAR_CSI_SECURE_KMS_REQUIRE=1`（`/kms/sign` は暗号必須。省略時true）
  - `CLEAR_ISE_KEY_B64=...`（**8bytes** をBase64。クラスター全ノードで一致させる）
  - `CLEAR_CSI_OPS_TOKEN=...`（Opsトークン。WN側の `CLEAR_OPS_TOKEN` と一致必須）
  - `CLEAR_CSI_SESSION_TTL_SEC=60`（任意。セッション鍵TTL）
- ノード側（MQ/WN/DBD 共通）の環境変数（CSIへのRegister/Heartbeat/Alert送信）:
  - `CLEAR_CSI_TRANSPORT=zip-ise-aes`（CSI向け通信をzip-ISE-AES化）
  - `CLEAR_ISE_KEY_B64=...`（CSIと一致）
  - `CLEAR_OPS_TOKEN=...`（CSIの `CLEAR_CSI_OPS_TOKEN` と一致）
- WN側（`core-wn`）の環境変数（KMS署名）:
  - `CLEAR_WN_SIGNING_MODE=remote`
  - `CLEAR_WN_SIGNING_TRANSPORT=zip-ise-aes`（これを設定すると `/kms/sign` を暗号化して送る）
  - `CLEAR_CSI_URL=http://CSI-A:9108,http://CSI-B:9108,...`（複数可。フェイルオーバ）

## 内部通信のzip-ISE-AES（SEC-INT-001/002/003）
- 目的: MQ->WN および WN->DBD の内部HTTPを zip-ISE-AES で暗号化し、平文JSONを拒否できるようにする。
- 共通:
  - `CLEAR_ISE_KEY_B64=...`（**8bytes** Base64。全ノードで一致）
- MQ -> WN:
  - MQ側: `CLEAR_MQ_WN_TRANSPORT=zip-ise-aes`
  - WN側: `CLEAR_WN_MQ_TRANSPORT=zip-ise-aes`（これを設定すると WN は平文を拒否）
  - 鍵: `CLEAR_MQ_WN_AES_KEY_B64=...`（**32bytes** Base64。MQ/WNで一致）
- WN -> DBD:
  - WN側: `CLEAR_WN_DBD_TRANSPORT=zip-ise-aes`
  - DBD側: `CLEAR_DBD_WN_TRANSPORT=zip-ise-aes`（これを設定すると DBD は平文を拒否）
  - 鍵: `CLEAR_WN_DBD_AES_KEY_B64=...`（**32bytes** Base64。WN/DBDで一致）
