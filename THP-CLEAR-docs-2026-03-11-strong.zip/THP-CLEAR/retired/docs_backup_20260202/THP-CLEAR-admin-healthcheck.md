# THP-CLEAR Admin Healthcheck Playbook

## 1. Purpose & Scope
- 管理端末から CLEAR-CSI へヘルスチェックを送信し、シリアル＋タイムスタンプで相互整合を検証する運用手順を定義。

## 2. Architecture Snapshot
1. Management Agent (`clear-csi-agent`) が HTTP POST `/api/csi/v1/healthcheck` を送信。
2. CSI がシリアル・リクエスト時刻をエコーし、ステータス＋詳細を応答。
3. Agent はレスポンスの整合／遅延を判定し、ログ／音／DB に記録。

## 3. Prerequisites
- THP-CLEAR CSI 8443/TCP reachable (LGWAN policy compliant)
- rustc/cargo >= 1.91 (agent build)
- SQLite3 runtime (`libsqlite3.so`) available
- Audio出力可能端末（rodio 対応デバイス）

## 4. Installation Steps
1. `cd rust/core && cargo build -p clear-csi-agent --release`
2. Agentバイナリを `/usr/local/bin/clear-csi-agent` へ配置
3. config `/etc/clear/agent.toml` を作成（エンドポイント／シリアル）
4. systemd unit or cron (step 7)

## 5. Configuration
```toml
# /etc/clear/agent.toml
serial = "DG-N-0001"
endpoint = "https://node-a.example.lgwan/api/csi/v1/healthcheck"
interval_secs = 60
latency_warn_ms = 1000
latency_error_ms = 3000
audio = true
sqlite_path = "/var/lib/clear-csi-agent/alerts.db"
```

## 6. Execution Flow
| Step | Agent処理 | CSI処理 |
|------|-----------|---------|
| 1 | request_timestamp生成 (RFC3339) | - |
| 2 | POST送信 | serial/ts検証、details生成 |
| 3 | response_timestamp受信 | - |
| 4 | latency計測、status判定、ログ記録、音／DB記録 | - |

## 7. Scheduling (cron/systemd)
- Cron例：`* * * * * /usr/local/bin/clear-csi-agent >> /var/log/clear-csi-agent.log`
- systemd timer推奨（詳細セクション TBD）

## 8. Metrics & Evidence
- `/metrics`：`clear_csi_healthchecks_total`／`clear_csi_alerts_emitted_total`
- SQLite：`alerts` テーブルに WARN/ERROR を履歴化
- ログ：`/var/log/clear-csi-agent.log`

## 9. Troubleshooting Checklist
1. HTTP 409: serial mismatch → config見直し
2. latency > 3s: ネットワーク遅延 or CSI過負荷
3. TLS error: LGWAN証明書バンドル追加
4. Audio失敗: rodio backend 未対応 → `audio=false`

## 10. Future Enhancements
- CSI側への逆方向レポート（/api/csi/v1/agent-report）
- SSE/WebSocket 常時監視
- Web UI dashboard
