# THP-CLEAR Repository Index

## Overview
This repository contains the full implementation and documentation set for **THP-CLEAR**, the Horizon Protocol core system integrating Witness Network, AI-TAX (CLEAR-TAX), UBI, and Ops-KPI layers.

---
###  Directory Map

| Path | Description |
|------|--------------|
| `core/` | Rust core specifications for Witness / VoidCoin / E-MAD |
| `modules/` | Application module specs (AI-TAX, UBI, Aftermath) |
| `cmd/` | Service binaries (see `cmd/README.md` for endpoints) |
| `docs/AI-TAX` | Design and DR documents for AI-TAX |
| `docs/CLEAR` | Core network and security specs |
| `docs/UBI` | UBI simulation and fiscal reports |
| `docs/THP` | THP charters, lexicon, and appendices |
| `ops/kpi` | Operational metrics and E-MAD scoring models |
| `ops/aftermath` | Recovery and post-incident operations |

---
###  Core Documents
- `docs/AI-TAX/AI-TAX_Implementation_v1.md`
- `docs/AI-TAX/DR/DR-AI-TAX_Risk_Assessment.md`
- `docs/AI-TAX/DR/DR-AI-TAX_Failover_Procedure.md`
- `docs/AI-TAX/DR/DR-AI-TAX_Data_Integrity_Test.md`
- `docs/AI-TAX/DR/DR-AI-TAX_Governance_Impact.md`
- `docs/AI-TAX/DR/DR-AI-TAX_Recovery_Scenario.md`

---
### ⚙️ Ops and Integration
- KPI metrics located under `ops/kpi/`
- Aftermath recovery procedures under `ops/aftermath/`

---
Generated for DR integration testing — phase: `AI-TAX Validation / THP-CLEAR Root Sync`.
