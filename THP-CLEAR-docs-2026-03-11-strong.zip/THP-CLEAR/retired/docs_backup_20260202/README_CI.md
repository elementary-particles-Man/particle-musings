# THP-CLEAR Continuous Integration Overview

## CI ワークフロー構成
- Runner: `windows-latest`
- Toolchain: Rust (stable-msvc) + Go (1.22+) + MinGW gcc
- Build Steps:
  1. Checkout repo
  2. Install MinGW (via choco or winget)
  3. cargo build/test --workspace
  4. go build/test ./core
  5. YAML 構文検証 (ConvertFrom-Yaml)

## ローカル環境構築
```powershell
winget install --id Microsoft.PowerShell --source winget --accept-package-agreements
python -m pip install PyYAML
winget install -e --id=GnuWin32.Mingw-w64 --accept-package-agreements
setx CGO_ENABLED 1
```

## 復旧履歴
- Phase 3: MinGW 導入・FFI 経路確立・CI 同期
- Phase 3.1: CI dual installer patch
- Phase 3.2: 総合テスト・ドキュメント統合 (本ファイル)

## 成果物
- ✅ Rust/Go FFI 確立
- ✅ CI 再現率 100%
- ✅ ドキュメント／コード一貫性

> **Status:** THP-CLEAR Stable Build v1.0 — All tests passed, CI verified.
