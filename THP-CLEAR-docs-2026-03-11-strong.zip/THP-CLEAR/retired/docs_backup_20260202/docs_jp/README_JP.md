# THP-CLEAR

[![CI (unit)](https://github.com/elementary-particles-Man/THP-CLEAR/actions/workflows/ci.yml/badge.svg)](https://github.com/elementary-particles-Man/THP-CLEAR/actions/workflows/ci.yml)
[![Integration](https://github.com/elementary-particles-Man/THP-CLEAR/actions/workflows/itest.yml/badge.svg)](https://github.com/elementary-particles-Man/THP-CLEAR/actions/workflows/itest.yml)

THP-CLEAR は Fiat Maximum の理念に基づき、法定通貨を安全に「用途制限付きデジタル残高」として流通させることを目的にした決済基盤です。レイヤ化したアーキテクチャによって、決済命令の厳格な検証と公開監査可能な Witness ログの生成を両立します。

## プロジェクト全体像

- **Fiat Maximum**: 法定通貨をデジタルで増幅させるのではなく、残高と用途の拘束条件を透明化する思想です。CLEAR では命令の正規化と監査可能性を最優先にし、通貨発行体の裁量を最小化します。
- **レイヤ構造**: Command → Matching → Witness という段階処理で整合性を担保します。各レイヤは独立したコンポーネントで、障害時に段階的なデグレード運転が可能です。
- **MQ / WN / DB の役割**:
  - **MQ (Message Queue)**: API サーバーとバックエンド処理を疎結合にし、暗号化済みの命令エンベロープを配送します。
  - **WN (Worker Node)**: 水平レイヤー（例: EVM 互換チェーン）に接続し、資産移動のファイナリティを検証して Witness ペイロードを生成します。
  - **DB**: 口座・命令の整合性を維持し、Witness ログを永続化します。署名鍵とログの冗長化で真正性を保証します。

```mermaid
graph TD
    subgraph Clients
        A[Operator UI]
        B[Layer0 Integrations]
    end
    A -->|REST/gRPC| C(clear-api)
    B -->|Command API| C
    subgraph Core
        C -->|Encrypted Envelope| D[Message Queue]
        D -->|Dispatch| E[Worker Node]
        E -->|Witness Payload| F[DB Service]
        F -->|Append| G[Witness Log]
    end
    F -->|Query| H[Monitoring]
    G -->|Publish| I[External Auditors]
```

## 実装リポジトリ構成

- `cmd/clear-api`: Go 製 API サーバー（決済命令・Witness 管理）
- `configs/`: 実行設定ファイル (`example.yaml`, `docker.yaml`)
- `internal/`: ドメインロジック、SQLite アダプタ、HTTP ハンドラ等
- `pkg/`: 署名・メトリクスなどの共通ライブラリ
- `docs/`: 設計・運用ドキュメント
- `tests/`: サービスレイヤの基本テスト
- `src/`: レガシー構成（MQ/WN/DB の PoC 実装）。将来的なマイクロサービス分離の検証用に残置。

## Docker での運用

THP-CLEAR は Docker でのデプロイを前提にしています。Ubuntu 24.04 でのセットアップ例は以下の通りです。

### 1. Docker / Compose のインストール

```bash
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
sudo systemctl enable --now docker
sudo usermod -aG docker $USER
```

グループ変更を反映するにはログアウトしてログインし直してください（再ログイン前は `sudo docker ...` のように実行します）。

### 2. 永続データ用ディレクトリの作成

```bash
mkdir -p data witness_logs
```

データベースファイル（`data/clear.db`）、Witness ログ（`witness_logs/transactions.log`）、秘密鍵（`data/private.key`）がホスト側に保存されます。

### 3. コンテナのビルドと起動

```bash
sudo docker compose up --build -d
```

- `configs/docker.yaml` がコンテナ内のデフォルト設定です。ポートやパスを変えたい場合はこのファイルを編集してから再ビルドしてください。
- 稼働確認: `sudo docker compose ps`
- ログ確認: `sudo docker compose logs -f`
- ヘルスチェック: `curl http://localhost:8080/healthz`

API サーバーは `8080/tcp`、メトリクスは `9100/tcp` をリッスンします。

### 4. 停止・再起動

```bash
sudo docker compose stop        # 停止
sudo docker compose start       # 再開
sudo docker compose down        # コンテナを削除
```

### 5. アップデート

```bash
git pull
sudo docker compose build
sudo docker compose up -d
```

新しいバイナリがコンテナに反映されます。

## ビルドと実行

```bash
make run
```

`configs/example.yaml` を環境に合わせて調整してください。初回起動時に以下が自動作成されます。

- SQLite データベース `thp-clear.db`
- Witness ログ `./data/witness.log`
- Ed25519 秘密鍵 `./data/private.key`

## テスト

| コマンド | 内容 |
|----------|------|
| `make test` | メモリストアを用いた高速ユニットテスト（タグ指定不要） |
| `make itest` | SQLite を用いる統合テスト（`integration` タグ） |

直接実行する場合は `go test ./tests -v`（ユニット）や `go test ./tests -tags=integration -v`（統合）を使用してください。`modernc.org/sqlite` を伴う実行は環境によってビルドに時間が掛かります。

## ライセンス

本プロジェクトは [Apache License 2.0](LICENSE) の下で提供されます。
