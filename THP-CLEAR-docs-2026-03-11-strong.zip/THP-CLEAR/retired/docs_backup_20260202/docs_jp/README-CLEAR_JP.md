# THP-CLEAR Node Set
この配下に MQ/WN/DB の3役割ノードを配置します。
