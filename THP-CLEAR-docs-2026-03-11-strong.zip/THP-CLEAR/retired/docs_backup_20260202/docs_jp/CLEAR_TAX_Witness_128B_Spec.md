# CLEAR-TAX Witness 128バイト固定行 仕様

| Offset | Size | 名称 | 説明 |
|---:|---:|---|---|
| 0 | 8 | Version | "WTX1.0\0" |
| 8 | 8 | EpochSecBE | 64bit UNIX時刻（BE） |
| 16 | 16 | CommitIDHash | SHA256(commit_id)先頭16B |
| 32 | 16 | KIDHash | SHA256(kid)先頭16B |
| 48 | 16 | PlainHash16 | SHA256(sha256_plain)先頭16B |
| 64 | 16 | CipherHash16 | SHA256(sha256_cipher)先頭16B |
| 80 | 16 | DBENodeHash16 | SHA256(dbe_node)先頭16B |
| 96 | 16 | Reserved | 将来用 |
| 112 | 16 | HMAC-SHA256-16 | 全体HMAC(16B; CLEAR鍵) |

投函JSON例→128B生成は `src/witness/tax_pointer.go` で実装。
