## DBE-TAX 監視KPI
- tax_effective_parallelism
- tax_batch_size_avg_bytes (target: 4-8 MiB)
- dbe_write_MBps_per_node (target: 80-120)
- gcm_verify_fail_rate (target: 0)
- mq_clear_free_ratio (>=0.4)
- tax_key_age_hours (<=25h)
