# CSI-N on MX-Linux (non-systemd) Deployment Guide v1.0

## 1. 目的

本ドキュメントは、MX-Linux のような **non-systemd 環境** において、CSI-N を永続デーモンとして
動作させるための手順を定義する。

- init スクリプト方式 (`/etc/init.d/csi-n`)
- 自動起動・監視・ログ管理
- 電源断からの復帰手順

## 2. 前提条件

- OS: MX-Linux (SysV init ベース)
- Rust ビルド済み CSI-N バイナリ:
  - `/usr/local/bin/csi-n`
- 設定ファイル:
  - `/etc/clear/csi.conf` (node_id, OPS アドレス, wrap-key など)
  - `/etc/clear/process_list.json`

## 3. init スクリプトの配置

以下のスクリプトを `/etc/init.d/csi-n` として配置し、実行権限を付与する。

```bash
sudo cp deploy/init.d/csi-n /etc/init.d/csi-n
sudo chmod +x /etc/init.d/csi-n
```

## 4. 自動起動の有効化

ランレベルへの登録:

```bash
sudo update-rc.d csi-n defaults
```

これにより、ブート時に自動で csi-n デーモンが起動する。

## 5. 手動操作

```bash
sudo service csi-n start
sudo service csi-n stop
sudo service csi-n restart
sudo service csi-n status
```

`status` は簡易実装 (PID ファイルの存在確認) とし、詳細な状態は OPS UI で確認する。

## 6. ログ管理

- デフォルトのログ出力先:
  - `/var/log/csi-n.log`
- ログローテーションは `/etc/logrotate.d/csi-n` を別途設定する (任意)。

例:

```bash
/var/log/csi-n.log {
  weekly
  rotate 8
  compress
  missingok
  notifempty
  copytruncate
}
```

## 7. 電源断からの復帰

- 電源断後、OS 起動時に init スクリプトにより csi-n が再起動される。
- 再起動後の動作:
  1. `startup_scanner` により process_list.json を再生成
  2. ops-daemon への接続確立
  3. HB0/ACK0/HB1 による TPM ハンドシェイク
  4. CMD_SET_KEY による K_comm 再配布

これにより、電源断前後でノード ID と TPM バインドが担保される。

## 8. 注意事項

- `/usr/local/bin/csi-n` は root 所有・実行権限のみ付与し、書き込み権限を一般ユーザに与えない。
- `/etc/clear/csi.conf` に wrap-key や OPS エンドポイントを置く場合は、権限を 600 に制限する。
- csi-n は CLI から直接実行せず、必ず init スクリプト経由で起動することを推奨する。
