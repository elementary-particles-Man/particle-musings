# THP-CLEAR Node Set
The three role nodes of MQ/WN/DB are placed under this.
