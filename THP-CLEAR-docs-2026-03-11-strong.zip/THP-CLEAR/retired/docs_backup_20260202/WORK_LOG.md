# 作業ログ（概要）

以下は本セッションで行った作業の要約です。タイムスタンプはJSTです。

- 2026-02-02 03:39:23 +0900
  - THP-CLEAR で Git 同期状況を確認し、`feature/clear-tax-e2e` を `main` に merge。
  - README 競合は feature 側を採用。
  - `main` を `origin/main` に push。
- 2026-02-02 03:39:23 +0900
  - `HEAD` 基準でリポジトリ構造を分析。
  - `REPO_STRUCTURE.md` をルートに作成（作業ツリーは変更せずに別 worktree で検証）。
  - `cargo check -p clear-node` を実行し、警告内容を記載。

---

**End of log.**

## 2026-02-02
- Move root-level markdown documents to docs/ (except README.md, README_RUST_ONLY.md kept at root).
- Add TRON/TRC-20 minimal verification gate in core-mq-s (DBD send pre-check, fail-closed).
- Add dbd-query subprocess for read-only witness scan; CSI spawn path; ACK=OK\n enforced.
- Enable sqlx offline mode; generate .sqlx and sqlx-data.json; local Postgres bootstrapped for prepare.
