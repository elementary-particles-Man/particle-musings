# API Specification

The following endpoints are provided for the base URL. In case of an error, `{"error": "message"}` is returned in `application/json` format.

## POST `/command`

- **Purpose**: Issue a payment command with F/M/E tags. The amount is immediately deducted from the balance.
- **Request**

```json
{
  "account_id": "acct-1",
  "amount": 1200,
  "currency": "JPY",
  "purpose": "F",
  "metadata": {
    "supplier": "Example Co"
  },
  "reference": "optional-reference"
}
```

- **Example Response (201)**

```json
{
  "id": "cmd-uuid",
  "account_id": "acct-1",
  "amount": 1200,
  "currency": "JPY",
  "purpose": "F",
  "status": "pending",
  "requested_at": "2025-01-01T00:00:00Z"
}
```

- **Common Errors**: `404 account not found`, `422 invalid input`, `403 account blacklisted`, `423 account frozen`.

## GET `/command/{id}`

- **Purpose**: Check the current status of a command.
- **Response**: Same format as `POST /command` (may include `settled_at`, `quantity`, `unit`, `witness_hash`, etc.).

## POST `/settle`

- **Purpose**: Settle a command with a determined quantity and generate a Witness log.
- **Request**

```json
{
  "command_id": "cmd-uuid",
  "quantity": 42.5,
  "unit": "t",
  "metadata": {
    "origin": "Yokohama",
    "destination": "Manila"
  }
}
```

- **Example Response (200)**

```json
{
  "command": { "id": "cmd-uuid", "status": "settled", "witness_hash": "..." },
  "witness": {
    "id": 15,
    "command_id": "cmd-uuid",
    "hash": "...",
    "previous_hash": "...",
    "recorded_at": "2025-01-01T00:05:00Z",
    "payload": {
      "command_id": "cmd-uuid",
      "quantity": 42.5,
      "unit": "t"
    }
  }
}
```

- **Common Errors**: `404 command not found`, `409 command already settled`, `422 invalid input`.

## GET `/witness?limit=50`

- **Purpose**: Get the latest Witness logs in descending chronological order.
- **Response**: Array of Witness entries (signature is Base64 encoded).

## Admin Endpoints (`/admin`)

### POST `/admin/accounts`

- Register or update an account.
- Request: `{ "id", "display_name", "currency", "balance", "status" }`
- Response: Registered account information.

### POST `/admin/blacklist`

- Register an account in the blacklist DB.
- Request: `{ "account_id", "reason", "expires_at" }` (`expires_at` is RFC3339, optional).
- Response: `{"status":"ok"}`.

### DELETE `/admin/blacklist/{account_id}`

- Remove the specified account from the blacklist.
- Response: `{"status":"ok"}`.

## Health/Monitoring

- `GET /healthz`: Health check for the API server.
- Separate port `/metrics`: Prometheus compatible metrics (`thp_clear_*`).
