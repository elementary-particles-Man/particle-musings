# TRON E-20 Implementation Status (core-mq-s)

## Files changed
- `rust/clear-vnext/crates/core-mq-s/src/e20.rs`
- `rust/clear-vnext/crates/core-mq-s/src/runner.rs`

## Insert point confirmation
- `rust/clear-vnext/crates/core-mq-s/src/runner.rs:run()`
- Inserted immediately after `to_ledger_entry()` and before `dbd_client.send()`.

## What is verified
- tx exists (via `TronRpc::get_tx`)
- receipt exists + success (via `TronRpc::get_receipt`)
- TRC-20 Transfer event match (token/from/to/amount)
- confirmation threshold (default 19; configurable via `CLEAR_MQ_E20_CONFIRMATIONS`)

## What is explicitly out of scope
- balances or account state
- UI / Web UI
- search/indexing
- WN/DB behavior changes
- CLEAR-ID or /id /pat

## Notes on output to DBD
- On successful verification, `metadata_json.e20` is updated with:
  - `chain`
  - `token`
  - `finality` (1 confirmed / 0 otherwise)
  - `transfer_digest` (tx hash hex)
- On verification failure, entry is dropped before DBD send (fail-closed).

## Next step (TODO only)
- Implement real TRON RPC client and wire it into `TronRpc` (HTTP JSON-RPC + TRC-20 log parsing).
