---
機密区分: INTERNAL/WITNESS-ONLY
版数: v1.0
作成日: 2025-11-02
言語: ja-JP
公開可否: 内部版（“本当の顔”を含む）
目的: THP-CLEARおよび派生モジュール群の公開説明と内部抑止機構の全体像整理
注意: ISE鍵素材/TPM詳細/逆経路情報は本書に記載しない（Redline遵守）
---

## ビルド手順（内部配布のみ）

- PDF版はローカルで `pandoc docs/THP-CLEAR_White\&Black_Book_v1.md -o build/THP-CLEAR_White\&Black_Book_v1.pdf` を実行して生成する。レポジトリにはバイナリをコミットしない。
- 公開版は章1（“表の顔”）のみを残したテンポラリMarkdownを作成し、同様に `pandoc` で変換する。生成物はGit管理下に置かない。
- 生成した成果物を配布する際は `/build` ディレクトリ配下に保存し、`.gitignore` で追跡対象から除外する。

# 0. 表紙と注意書き

- 本書は INTERNAL/WITNESS-ONLY 区分であり、Witnessノード群の運用者および監査証人に限定配布する。
- 目的は「透明清算プラットフォームとしての説明資料（表の顔）」と「経済的相互確証抑止を成立させる内部設計（本当の顔）」を切り分け、二系統のビルドが可能な編集母体を提供することにある。
- 非目的：軍事転用・違法な経済封鎖・ISE内部構造の解析支援。公開ビルドでは第1章のみを抽出する。
- 用語凡例：F=Food、M=Medicine、E=Energy用途タグ／E-MAD=Ethical Monitoring & Anomaly Detection／WN=Witness Node／ISE=Indistinguishable Signed Encryption。詳細は付録「用語集」を参照。

# 1. THP-CLEARの“表の顔”

## 1.1 電子インボイス／透明清算／人道回廊の公開説明

THP-CLEARはFiat Maximum思想に基づく決済インフラであり、用途制限付きデジタル残高の安全な配給と公開監査可能なWitnessログ生成を両立する。Command→Matching→Witnessの多層構造が外部決済と人道回廊輸送の照合を行い、MQ/WN/DBの役割分担によって最終記録を公開し得る形で保持する。【F:README.md†L6-L33】

## 1.2 BSJ削減（会計・稟議・証跡の自動化）

REST APIは `/command` `/settle` `/witness` を中心に、発行命令の即時残高反映、数量確定時のWitnessログ生成、最新ログの取得を自動化する。口座登録やブラックリスト登録は `/admin` 配下で行い、全操作がJSONレスポンスとして証跡化されるため、BSJ（Back-office/Sign-off/Journal）工数を削減できる。【F:docs/api.md†L5-L106】

## 1.3 Ops-KPI（運用計測基盤）への接続

Prometheusメトリクスは `thp_clear_*` および `witness_*` 系列で公開され、API要求率やレイテンシ、Witness追記件数、E-MAD違反スコアをダッシュボードから監視できる。Ops-KPIカタログは閾値とSLOを定義し、Grafanaテンプレート `keyhub_witness_ops.json` `e20_emad_overview.json` に接続することで可視化する。【F:ops/kpi/README.md†L1-L71】【F:pkg/monitor/metrics.go†L11-L78】【F:internal/monitoring/exporter.go†L10-L115】

## 1.4 導入コスト／スケーラ／可用性（公開説明範囲）

Docker Composeでの導入手順が整備されており、APIは `8080/tcp`、メトリクスは `9100/tcp` で公開される。WitnessログとSQLite DB、署名鍵はホストボリュームへ保存し、ノード障害時にはWitnessログから再材料化する設計を採用する。単一バイナリ（clear-api）を起点に段階的マイクロサービス分割が可能で、公開説明ではこの柔軟な拡張性と冗長運用方針を示す。【F:README.md†L52-L160】【F:docs/design.md†L5-L69】

# 2. THP-CLEARの“本当の顔”

## 2.1 経済的相互確証抑止（E-MAD×清算）の実装哲学

E-MADは決済命令の倫理的逸脱を0〜1のスコアで表現し、閾値0.25超過が5分継続した場合にアラートを発報する。Rustコアがコンテキストを解析し結果をPrometheusゲージへ反映し、Go層のドメインサービスはSettledごとにWitnessメタデータへスコアを埋め込む。Ops-KPIはスコアの復旧を30分以内に要求し、Aftermath連携のトリガー条件となる。【F:core/emad/README.md†L1-L50】【F:ops/kpi/README.md†L16-L71】【F:internal/domain/service.go†L132-L189】

## 2.2 用途タグ＆ポリシー・ゲート

`internal/domain.Service` はF/M/E以外の用途タグを `ErrInvalidPurpose` として拒否し、ブラックリストに登録された口座は `/command` `/settle` の処理を遮断する。ブラックリスト登録には理由と有効期限を必須とし、解除もWitness付きで履歴を残す。これにより防衛用途など禁止カテゴリの命令は自動的に拒否または監査送りとなる。【F:internal/domain/service.go†L64-L205】【F:docs/security.md†L58-L66】

## 2.3 Witnessログ設計（冗長率／改ざん耐性／証跡一貫性）

WitnessエントリはSHA-256ハッシュチェーンとEd25519署名で保全され、SQLiteトランザクションとJSON Linesファイルへの追記を同時に実行する。**JSON Linesは正本（WORM）として保管し、SQLite `witness_envelopes` はSSD書き込み量を抑えたホットキャッシュ／照会用の仮置き場**として扱う。ファイルは `append+sync` でWORM特性を維持し、`witness_append_total` / `witness_verify_*` メトリクスで追記と検証の成否を監査する。障害時はWitness JSONLから再材料化し、`witness_replay` ツールで復元する運用をRunbook化している。【F:internal/domain/service.go†L132-L205】【F:internal/adapters/witness/file_writer.go†L14-L69】【F:docs/ops.md†L9-L116】

## 2.4 鍵管理（KMSクォーラム／TPMバインド／ノード分散）

内部モードのKeyHubは署名鍵を10分周期でローテーションし、2-of-3クォーラムで署名束を生成する。TLS1.3+mTLSでKMS/ノード間通信を保護し、Rate LimitやSPYアラートにより不審挙動を遮断する。Witness署名鍵はKMS/HSM保管を前提とし、`kms_spy_alert_total` のBlock発生時は即時隔離・鍵差替えがRunbookに定義される。TPMとKMSの連携は複製時にMerkleルート検証を伴う再シール処理で検証する。【F:README.md†L158-L163】【F:docs/ops.md†L23-L183】【F:src/DB/ingest.go†L19-L104】【F:docs/security.md†L46-L71】

## 2.5 Aftermath Protocol自動発動連携

Ops-KPIのしきい値違反やKMS SPY(block)検知時にはAftermathモジュールがWitness差分の抽出と再同期、KMS再署名、外部通報フローを起動する。`ops/ops.md` のRunbookは発見→隔離→再材料化→署名キー差替えまでの時間基準（RPO15分/RTO30分）を定義し、E-MADスコアの戻り値がGate-D解除条件となる。【F:docs/ops.md†L59-L183】【F:modules/README.md†L27-L60】

# 3. CLEAR-TAX（税務特化）

## 3.1 Pupele/e-インボイス国際標準準拠I/O

AI-TAX（CLEAR-TAX）はJP PINT（Peppol準拠）標準に沿った適格請求書を正規化し、Witnessログに固定する。入力時にはT番号のAPI照合、6要件の完全性検証、軽減税率の明示を強制し、電子帳簿保存法の検索要件を満たすインデックスを生成する。【F:docs/AI-TAX/guide/invoice_requirements_jp.md†L1-L104】

## 3.2 組戻し（還付・修正）処理モデル

MQプロトタイプでは税務系パケットを `QueueTAXGOV` に分類し、CLEAR命令より低優先でスケジュールしつつ最大5回のバックプレッシャを適用する。再投入時には`ApplyBackpressure`が遅延を設定し、税務修正要求が人道決済を阻害しない順序制御を実装する。【F:src/MQ/queue.go†L9-L120】【F:src/MQ/dispatcher.go†L19-L120】

## 3.3 仕入税額控除の実装境界

免税事業者からの仕入に対する控除率は経過措置テーブルで管理し、`purchase.is_from_exempt` を基点に期間別80%→50%→0%を自動適用する。法改正が不要な運用として、JP PINTマッピングとWitness固定のみで制度要件を満たし、課税判断は既存法令の範囲で完結する。【F:docs/AI-TAX/guide/invoice_requirements_jp.md†L57-L104】

## 3.4 “課税”ではなく“清算”としてのワークフロー

CLEAR-TAXは `/command` による即時差引と `/settle` による数量確定を利用し、税務処理をWitnessログに埋め込む形で「清算」する。WitnessメタデータにはインボイスIDとE-MADスコアが付与され、会計と稟議を統合したワークフローとなる。【F:docs/api.md†L5-L86】【F:internal/domain/service.go†L132-L205】

## 3.5 監査・追跡・改竄検出（ケースドリル）

AI-TAX DRガイドではJP PINT入力→正規化→計算→Witness固定をケースドリル化し、Witnessログと国税庁APIで二重照合する。ハッシュ差異や署名不一致は `witness_append_fail_total` アラートを契機に`check_witness_integrity`スクリプトで切り出し、Witness→SQLite再材料化で根治させる。【F:docs/AI-TAX/guide/invoice_requirements_jp.md†L74-L104】【F:docs/ops.md†L102-L170】

### アーティファクト: CLEAR-TAX フローシーケンス
```mermaid
sequenceDiagram
    participant Taxpayer as 課税事業者
    participant ClearAPI as CLEAR-API
    participant MQ as MQ (QueueTAXGOV)
    participant WN as Witness Node
    participant DB as DB/Witness
    Taxpayer->>ClearAPI: POST /admin/tax/invoice (JP PINT 添付)
    ClearAPI->>MQ: TAX_GOV Envelope enqueue
    MQ->>WN: Dispatch after backpressure
    WN->>WN: E20 finality + E-MAD score算出
    WN->>DB: Witness payload (invoice hash)
    DB-->>Taxpayer: Witness receipt / E-MADスコア
```

### アーティファクト: 組戻し状態遷移
```mermaid
stateDiagram-v2
    [*] --> Pending
    Pending --> Reviewing: 国税庁戻し通知
    Reviewing --> Adjusting: 追加証跡要求
    Adjusting --> Settled: Witness再固定
    Adjusting --> Rejected: 不備確定
    Rejected --> [*]
    Settled --> [*]
```

# 4. MQ / WN / DB サーバ群（実装/運用）

## 4.1 MQ

MQプロトタイプはリングバッファベースの`CLEARQueue`と遅延再投入可能な`TAXGOVQueue`を持ち、容量と高水準/低水準閾値は `config.yaml.example` で制御する。Dispatcherはイベントフックとメトリクスを持ち、税務パケットのバックプレッシャや平均レイテンシを記録する。【F:src/MQ/queue.go†L9-L120】【F:src/MQ/dispatcher.go†L19-L120】【F:src/MQ/config.yaml.example†L1-L9】

## 4.2 Witness Node (WN)

WNはE20アダプタを通じて外部チェーンのトランザクション確定を確認し、Witnessペイロードを生成する。`e20.Adapter` はトランスファ検索とトークンメタ情報取得を抽象化し、将来的なマイクロサービス移行時も決済検証ロジックを保持する。【F:src/WN/worker.go†L1-L6】【F:src/WN/e20/adapter.go†L1-L7】

## 4.3 DB

DBサービスはWitnessエンベロープをSQLite `witness_envelopes` テーブルへ保存し、バリデーションでNonce長・ハッシュ長・署名必須を確認する。ReplicationハンドラはTPMとKMSを組み合わせ、受信チャンクのMerkleルートを検証してから再シールし、ストアコールバック経由で永続化する。【F:src/DB/db.go†L13-L138】【F:src/DB/ingest.go†L19-L104】

## 4.4 監視

各ロールはPrometheusポート（MQ:9201/DB:9202/WN:9203）で`node_*`メトリクスを公開し、KMS連携の成功率やSPYアラートを追跡する。KeyHub/KMSメトリクスは成功率99.9%/5分のSLOを持ち、`kms_spy_alert_total` Block検知でセキュリティ対応を起動する。【F:docs/ops.md†L23-L116】【F:ops/kpi/README.md†L32-L65】

## 4.5 セキュリティ

ISEパイプラインはActive/Previous/Decoy鍵をKeyRingで管理し、署名検証に成功したペイロードのみをDBに採用する。復号結果が不一致の場合はダミーデータとして破棄され、APIはJSON限定とし中間層で認証を追加予定である。Witnessログは日次ハッシュ公開により改ざん検出を支援する。【F:docs/security.md†L3-L57】

### アーティファクト
```mermaid
graph TD
    subgraph Client Layer
        UI[Operator / API Client]
    end
    subgraph CLEAR Core
        API[clear-api]
        MQD[MQ Dispatcher]
        WND[Witness Node]
        DBD[DB / Witness Store]
    end
    subgraph Observability
        Prom[Prometheus]
        Graf[Grafana]
    end
    UI -->|REST/gRPC| API
    API -->|Envelope| MQD
    MQD -->|Dispatch| WND
    WND -->|Witness Payload| DBD
    DBD -->|Metrics| Prom
    Prom --> Graf
    DBD -->|JSONL| Audit[Witness Log]
```

# 5. ISE（世界唯一の暗号）の扱い

## 5.1 公開可能な概要

ISEはどの鍵で復号してももっともらしい平文が出現し、正当性はEd25519署名のみで確定させる暗号スキームである。THP-CLEARではMQ→DB間のWitnessペイロードに適用し、鍵漏洩時でも真実の特定を不可能にする。【F:docs/security.md†L3-L44】

## 5.2 データタイプ別“偽造可能な構造化テーブル”の概念

WitnessペイロードはコマンドID・数量・用途タグ・メタデータをJSON構造で保持し、ISEはこれらに対し複数のダミー平文を生成する。監査時にはWitness署名とE-MADスコアで真正性を確認し、偽造平文はSignature mismatchで棄却される。【F:internal/domain/service.go†L132-L205】【F:docs/security.md†L21-L44】

## 5.3 危険情報の秘匿ポリシー

本書では鍵長・乱数種・シード管理・Mapping Logの詳細を一切記載しない。TPMバインドやノード間信頼ルートはRedlineとして除外し、公開版にも転記しない。Witnessログの署名鍵IDはローテーション時のみ記録し、復号経路は非公開とする。【F:docs/security.md†L46-L71】

## 5.4 擬似コード（公開域）

公開可能な擬似コードとして、解読→署名検証→ダミー判定のプロセスのみ開示する。整合性不変量（ハッシュ長・署名必須）とテストベクトル形式は公開域に含めるが、鍵素材・乱数源は非公開である。【F:docs/security.md†L21-L44】【F:src/DB/db.go†L21-L131】

## 5.5 法的/輸出管理/倫理準拠

ISEは暗号規制を踏まえた輸出管理ポリシーに従い、公開ビルドでは仕組みの概念図と検証手順のみ提示する。Witnessログと署名による真正性証明は金融規制・人道支援監査の要件を満たし、倫理憲章に沿った利用限定が可能となる。【F:docs/security.md†L3-L71】【F:docs/ops.md†L59-L183】

# 6. Ops-KPI / E-MAD / Aftermath 連携

## 6.1 連鎖概要

KPI測定→E-MADスコア評価→Gate判定→Aftermath自動発動の流れをとり、`emad_violation_score` の閾値超過がGate-Dを閉じる条件になる。Gate復帰にはWitness再同期とKPI基準復帰が必要で、AftermathはWitness差分の封じ込めと再署名を担当する。【F:ops/kpi/README.md†L27-L71】【F:docs/ops.md†L59-L183】

## 6.2 プレイブック

人道回廊輸送や透明清算のプレイブックはWitnessログを一次資料とし、`witness_replay` による再現とKeyHub監査ログの照合作業を標準化している。外部公開ログ（clear-log）はE-MAD正常範囲内のエントリのみ公開し、Witnessログとの差異で異常を検出する。【F:docs/ops.md†L102-L170】

## 6.3 閾値テーブル

| 指標 | Gate条件 | Aftermathアクション |
| --- | --- | --- |
| `emad_violation_score` > 0.25 (5分超) | Gate-D閉鎖 | TAX_GOVキュー停止、Witness差分隔離 |
| `kms_spy_alert_total{level="block"}` 増加 | Gate-K閉鎖 | KMS鍵束隔離、TPMリシール |
| `witness_verify_failed_total` 連続増加 | Gate-W閉鎖 | Witness再同期、監査差異報告 |
| `thp_clear_api_latency_seconds` p95>1s (15分) | Gate-A注意 | API再デプロイ、負荷分散切替 |

### アーティファクト: Gate Pipeline
```mermaid
graph LR
    KPI[Ops KPI Metrics] -->|Push| EMAD[E-MAD Score]
    EMAD -->|Threshold>0.25| GateD[Gate-D Close]
    GateD --> Aftermath[Aftermath Runbook]
    Aftermath -->|Replay/Seal| Witness[Witness Log]
    Witness -->|Hash OK| KPI
```

# 7. リスク登録簿・運用基準・監査

| リスクID | カテゴリ | シナリオ | 影響 | 対応策 | 監査指標 |
| --- | --- | --- | --- | --- | --- |
| R-01 | 技術（暗号） | ISE署名鍵漏洩 | Witness偽造・信用毀損 | KMS 2-of-3クォーラム、即時鍵差替え、旧Witness区間隔離 | `kms_spy_alert_total`, `witness_append_total` 差分【F:docs/ops.md†L102-L170】【F:docs/security.md†L46-L71】 |
| R-02 | 運用（データ） | Witness JSONL破損 | 再材料化不能 | rsync多重保管、`witness_replay` で再生成、日次ハッシュ公開 | `witness_verify_failed_total`, 監査ハッシュ【F:docs/ops.md†L9-L116】【F:internal/adapters/witness/file_writer.go†L14-L69】 |
| R-03 | 倫理（E-MAD） | 人道比率逸脱 | 支援資金の誤配分 | E-MAD閾値0.25警報、Gate-D自動閉鎖、Aftermath差分調査 | `emad_violation_score`, Aftermath報告【F:ops/kpi/README.md†L27-L31】【F:docs/ops.md†L59-L183】 |
| R-04 | サプライチェーン | KMS Rate Limit攻撃 | 正常ノードの鍵取得停止 | `ratelimit.per_node_per_min` 調整、SPYブロック、手動再認証 | `kms_rate_limited_total`, `/control/spy` ログ【F:docs/ops.md†L59-L116】 |
| R-05 | 法的 | JP PINT仕様改定 | インボイス非適格化 | 仕様監視、JP PINTマッピング更新、Witness署名で過去ログ証明 | 税務差分報告、API互換テスト【F:docs/AI-TAX/guide/invoice_requirements_jp.md†L1-L104】 |

付録のCSV版（`docs/risk_register.csv`）ではCVSS互換の重大度と緩和策の責任部署を付記する。

# 付録

- 用語集：`docs/THP-CLEAR_Guidance_JP.md` および `docs/THP-CLEAR_Design_Policy.md` に準拠し、本書脚注で参照した用語はLexiconと整合させる。【F:docs/THP-CLEAR_Guidance_JP.md†L23-L126】【F:docs/THP-CLEAR_Design_Policy.md†L8-L115】
- 設定テンプレート：`configs/example.yaml` に基づく。公開版ではエンドポイントと監視ポートのみ提示する。【F:configs/example.yaml†L1-L25】
- API/Topic/Schema索引：`docs/api_index.json` を参照。
- 出典・コミットハッシュ：`docs/.commit` `docs/.dirty` `docs/.hashes` に記録（ビルド時に生成）。
