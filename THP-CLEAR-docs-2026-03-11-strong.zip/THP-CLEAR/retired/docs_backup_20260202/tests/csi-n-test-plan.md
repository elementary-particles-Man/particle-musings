# CSI-N 総合テスト計画 (v1.0)

## 1. 単体テスト
- cargo test を実行
- 状態遷移/CPU/Queue/Nice/Frame encode-decode を検証

## 2. Docker 単体
- docker run csi-n-dev cargo test
- Linux namespace で SIGSTOP/SIGCONT が正常動作するか

## 3. 連携テスト (docker-compose)
- docker-compose -f docker-compose.test.yml up
- OPS UI で node1/node2 が表示されること
- CPU高負荷: yes > /dev/null &
- Queue backlog 模擬: echo 9999 > /etc/csi/backlog_mock
- ZFS degraded 模擬: echo degraded > /etc/csi/zfs_state

## 4. ノード交換
- node1停止→削除→node3追加（NODE_ID=103）
- OPS UI が node1 消滅・node3 新規を検知

## 5. 障害試験
- プロセス kill: pkill -9 mq-daemon
- ノード freeze: docker pause node1
- 電源断模擬: docker kill -s KILL node2

## 6. 実機 MX-Linux 反映
- systemd 非依存の永続化
- TPM・ZFS 実体での再起動テスト
