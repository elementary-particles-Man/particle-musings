# CSI-N / OPS-daemon CI Pipeline

## 1. 概要
このCIは、以下を自動で証明します:
- CSI-N のビルド
- OPS-daemon のビルド
- CSI-N test image の作成
- docker-compose による 2ノード + OPS の統合実行
- heartbeat / event / ack の疎通確認
- 20秒稼働の結果ログを artifacts に保存

## 2. 実際に検証される内容
- node1,node2 からの 5秒HB
- OPS-daemon への受信
- WSブロードキャスト中にエラーがないこと
- CMD未送信でも ACK 不正発火がないこと

## 3. 成果物
- artifacts/compose.log
    - CSI-N → OPS の全心拍
    - event ハンドラの動作
    - ノード初回HBでの node_id バインド

## 4. 注意
- KEY_PROVIDER は CI ではゼロ鍵（OPS_INSECURE_ZERO_KEY=1）で動かす前提
- KMS 接続は CI で disabled
- ZFS モック状態は /etc/csi/zfs_state を利用
