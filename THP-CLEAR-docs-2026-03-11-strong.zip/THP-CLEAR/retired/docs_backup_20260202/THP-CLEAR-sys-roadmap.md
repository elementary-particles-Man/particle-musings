# THP-CLEAR System & Network Structure Roadmap

## 1. Overview
THP-CLEAR は、法定通貨・自治体コイン・社会給付・課税を統合管理する公共インフラ層であり、
下位の CLEAR システム群と、上位統合層 CLEAR-ID により構成される。

## 2. Hierarchical Architecture
```
統合上位層 : CLEAR-ID
├── CLEAR-GOV   … 公共手続・自治体業務・電子公文書層
├── CLEAR-TAX   … 課税・インボイス・徴収記録層
├── CLEAR-UBI   … 給付・社会福祉・ベーシックインカム層
└── THP-CLEAR 本体 … 通貨・コイン・取引・Witness 層
　　　└── CLEAR-CSI  … 検証・監査・ポート制御・MQ監視
```

## 3. CSI Implementation Summary
- LGWAN ポート強制制御：`ops/lgwan/port-policy.json` を唯一の真実として運用。  
- ノード管理 API：`/nodes/register`・`/nodes/status`・`/nodes/leave`・`/nodes/heartbeat`・`/process/map`。  
- Prometheus 互換 `/metrics` 実装：`clear_csi_heartbeats_total` 等を提供。  
- 閾値ポリシー：`ops/policy/thresholds.json` による企業別・カテゴリ別上限。  
- MQ-CSI 構想：リアルタイム異常検知（非遮断）。  
- ヘルスチェック API：`/api/csi/v1/healthcheck` によるシリアル・時刻整合性保証。  
- CLEAR-ID：上位認証層として計画済（運用カバー可）。  

## 4. Future Integration (CLEAR-ID / MQ-CSI)
- **CLEAR-ID**：個人・法人・権限・閾値を統合管理。CSIは参照のみ。  
- **MQ-CSI**：取引監視と警告発報。処理は通過、異常はリアルタイム通知。  
- 両者の統合により、THP-CLEAR 全体の監査・責任境界が明確化される。  

## 5. Policy Alignment (LGWAN / TAX / GOV / UBI)
- LGWAN：ホワイト/ブラックリストによる固定ポート制御。  
- TAX：インボイス連携、COIN-ID列義務化、徴税対象スコープ共有。  
- GOV：自治体 CSV 構成、手続フォーマット非変更。  
- UBI：支出スコープ管理、閾値監視、社会給付監査ライン接続。  

## 6. CSI Implementation Directives
- LGWAN policy enforcement
- Threshold-based anomaly detection
- MQ-CSI message analyzer
- CSV COIN-ID loader
- Prometheus metrics exposure
- Healthcheck handshake API & management agent

---

**Last Update (JST)：2025-11-07 06:46:31 JST**  
**Responsible：CODEX**
