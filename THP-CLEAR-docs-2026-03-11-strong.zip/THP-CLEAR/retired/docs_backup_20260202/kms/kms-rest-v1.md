KMS REST API — v1.0

クライアント: ops-daemon 専用。CSI-N は KMS に直接アクセスしない。

1. 基本仕様
● Base URL
http://<kms-host>:9200/

● 認証方式

必須：Bearer Token

Authorization: Bearer <token>

LGWAN内閉域の場合は nginx IP 制限で補強してもよい。

2. API 定義
■ GET /kms/key/aes

AES-GCM 256bit キーを取得。

パラメータ
名前	例	説明
id	ops-main	論理キーID（ノード/OPS単位）
リクエスト例
GET /kms/key/aes?id=ops-main
Authorization: Bearer XXXXXX

レスポンス（成功）
{
  "key_id": "ops-main",
  "key": "base64(32bytes)"
}

エラー

401 Unauthorized（トークン無効）

404 KeyNotFound

500 ServerError

■ GET /kms/key/ise

ISE 高速タグ生成鍵（128bit または 256bit）

{
  "key_id": "ops-ise",
  "key": "base64(16bytes)"
}

3. キャッシュ方針

ops-daemon: 60分キャッシュ

CSI-N: KMS 非アクセス。ops-daemon が取得した鍵を CMD/制御フレーム経由で供給。

緊急ローテーション時は /kms/rotated Webhook（後日実装）

⚙️ セキュリティ

すべて AES-GCM の key lifetime は最大 24h

ISE 鍵はハッシュ種別により 12h〜168h

TEST モードでのみ ZERO_KEY を許可（OPS_INSECURE_ZERO_KEY=1）
