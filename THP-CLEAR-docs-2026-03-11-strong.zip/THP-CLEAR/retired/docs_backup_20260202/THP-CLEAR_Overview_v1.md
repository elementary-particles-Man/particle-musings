---
marp: true
theme: default
author: THP CLEAR Team
title: THP-CLEAR Overview v1
lang: ja-JP
paginate: true
---

<!-- _class: lead -->
# THP-CLEAR Overview
INTERNAL/WITNESS-ONLY

---

## 配布形式

- スライドデッキはローカルで `marp docs/THP-CLEAR_Overview_v1.md --pptx build/THP-CLEAR_Overview_v1.pptx` を実行して生成する。リポジトリにはバイナリを追加しない。
- PDF版が必要な場合は `marp docs/THP-CLEAR_Overview_v1.md --pdf build/THP-CLEAR_Overview_v1.pdf` を用いる。
- 生成物は `/build` ディレクトリに配置し、配布後はSecrets/Redline遵守のためアクセス管理を徹底する。

---

## 表の顔
- Fiat Maximumに基づく透明清算。【F:README.md†L6-L33】
- `/command` `/settle` `/witness` による自動証跡。【F:docs/api.md†L5-L86】
- Prometheus/GrafanaでOps-KPIを可視化。【F:ops/kpi/README.md†L1-L65】

---

## 本当の顔
- E-MADスコアでGate-Dを制御。【F:core/emad/README.md†L1-L50】
- ISE + 2-of-3 KMSクォーラムでWitnessを防御。【F:docs/security.md†L3-L71】
- AftermathがWitness差分を隔離・再材料化。【F:docs/ops.md†L59-L170】

---

## CLEAR-TAXハイライト
- JP PINT準拠インボイスとWitness固定。【F:docs/AI-TAX/guide/invoice_requirements_jp.md†L1-L104】
- QueueTAXGOVのバックプレッシャ制御。【F:src/MQ/dispatcher.go†L19-L120】

---

## MQ / WN / DB 構成
```mermaid
graph TD
    API[clear-api] --> MQD[MQ]
    MQD --> WND[Witness Node]
    WND --> DBD[DB/Witness]
    DBD --> Audit[Witness JSONL]
    DBD --> Prom[Prometheus]
```

---

## Ops-KPI → Aftermath
```mermaid
graph LR
    KPI --> EMAD
    EMAD -->|>0.25| GateD
    GateD --> Aftermath
    Aftermath --> Witness
```

---

## リスクと対策
| リスク | 対応 |
| --- | --- |
| ISE鍵漏洩 | KMSクォーラムと即時鍵差替え【F:docs/ops.md†L102-L146】 |
| Witness破損 | JSONL多重保管＋`witness_replay`【F:docs/ops.md†L102-L170】 |
| JP PINT改定 | マッピング差分監視とWitness署名証跡【F:docs/AI-TAX/guide/invoice_requirements_jp.md†L57-L104】 |

---

## 次のアクション
1. 公開版ビルドの分離運用
2. Aftermathシナリオの四半期演習
3. 税制改定時のWitness再検証ライン確立

