# THP-CLEAR Repository Structure (HEAD 기준)

本資料は `HEAD`（コミット済み状態）を基準に、事実のみを記載します。

---

## 1. リポジトリ全体構造（ルート直下）

主要ディレクトリ/ファイル（`HEAD` に存在するもの）:

- `.github/` — GitHub Actions ワークフロー
- `Trush/` — 旧Go実装のアーカイブ領域（ソースとテストが格納）
- `config/` — 設定ファイル（例: `thpclear.json`）
- `dashboards/` — 監視ダッシュボード定義
- `docs/` / `docs_jp/` — 設計/運用/リリース等のドキュメント
- `infra/` / `deploy/` / `docker-compose*.yml` — デプロイ/インフラ関連
- `openapi/` — OpenAPI定義
- `ops/` — 運用関連
- `pkg/` — 旧Goコードのパッケージ群（Trush配下へ移動された構成が混在）
- `report/` / `tests/` / `scripts/` / `tmp/` / `witness_logs/` — レポート/テスト/補助
- `rust/` — Rust実装の主要領域

ルート直下の主要ファイル:

- `README.md`
- `README_RUST_ONLY.md`
- `LICENSE`
- `Dockerfile*`
- `prometheus.yml`
- `build_manifests.json` / `clear_docs_pack.json` / `missing_clear_components_pack.json` / `rust_sources_pack.json`

---

## 2. CLEAR 本体（Rust）の構成

### `rust/` 配下の構造

- `rust/core/` — Rustワークスペース本体
  - `Cargo.toml` — workspace manifest
  - `crates/` — workspace members
    - `clear-csi`
    - `clear-csi-agent`
    - `clear-encryptor`
    - `clear-node`
    - `core-cli`
    - `core-runtime`

### `clear-node`

**目的（事実ベース）**
- `clear-node` は Rustワークスペース内のクレートで、`src/bin/` に複数バイナリを持つ。
- 各バイナリは KMS クライアント・鍵ローテーション・監査ログ・メトリクスを扱うロジックを共有している。

**提供バイナリ**
- `mqd` → `rust/core/crates/clear-node/src/bin/mqd.rs`
- `wnd` → `rust/core/crates/clear-node/src/bin/wnd.rs`
- `dbd` → `rust/core/crates/clear-node/src/bin/dbd.rs`

**共通機能（コード上の事実）**
- KMS接続: `kmsclient` / `kmsproto`
- 監査ログ: `audit::JsonlLogger`
- 署名/鍵管理: `nodeauth::{Manager, ManagerConfig, Store}`
- メトリクス: `PromMetrics` で `/metrics` 提供
- Epoch制御: `util::current_epoch` を用いた定期ローテーション

### `clear-encryptor`

**役割（事実ベース）**
- Rustクレート `clear-encryptor` は Witness 暗号化パイプラインを提供する（`rust/core/README.md` 記載）。

**利用箇所（事実ベース）**
- `clear-node` が `clear-encryptor` を依存として持ち、`clear_encryptor::keys::KeyRing` を利用する（`mqd/wnd/dbd`）。

---

## 3. ノード種別ごとの責務整理（事実ベース）

`mqd / wnd / dbd` は以下の点で共通している:

- `/metrics` を提供する Prometheus メトリクス用 HTTP サーバを起動
- `/control/spy` を受ける制御用 HTTP サーバを起動
- KMS から鍵を取得し、`Manager::ensure_epoch` によるローテーションを定期実行
- 監査ログ (`JsonlLogger`) を出力

**Go版との対応関係**
- 旧Go実装は `Trush/` 配下に保存されている。
- Rust側のノードバイナリ名称（`mqd / wnd / dbd`）は Go版の役割名と一致するが、対応の詳細定義はコード内に明示されていない。

---

## 4. ID・PAT 周辺の位置づけ

- 本リポジトリ `HEAD` には CLEAR-ID サーバ実装（`/id` `/pat` API を含む構成）は存在しない。
- CLEAR-ID は別リポジトリとして切り離され、論理的に独立した取り扱いになっている。

---

## 5. 設定・起動前提

- `clear-node` の各バイナリはデフォルト設定として以下を参照する:
  - `configs/node.mq.yaml`
  - `configs/node.wn.yaml`
  - `configs/node.db.yaml`
- `HEAD` には `configs/` ディレクトリは存在せず、実ファイルは未配置。
- `config/` ディレクトリには `thpclear.json` が存在する。

---

## 6. 現在のビルド状態（HEAD で検証）

- `cargo check -p clear-node` は成功した。
- 警告が2件出る（未使用フィールド）:
  - `crates/clear-node/src/kmsclient.rs`: `quorum` フィールド
  - `crates/clear-node/src/nodeauth.rs`: `node_id` フィールド

---

**End of document.**
