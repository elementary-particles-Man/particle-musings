Thank you. In response to your concern (= SPOF concern around SQLite), I will clarify the **premises and design intent of THP-CLEAR** and present a concrete configuration that does not create a SPOF.

## Conclusion (Key Points Only)

* **THP-CLEAR is an "auditing (monitoring) system," not a "payment execution system."**
  In other words, it **does not "update" a single centralized account ledger**. The outside (chain/payment service provider) is the **primary source of truth**, and CLEAR is in a position to **verify → record (Witness) → visualize** it.
* **SQLite is not used as "shared storage."** It is **locally and independently placed on each node**, and a configuration where **multiple nodes write to a shared file simultaneously** is **prohibited** (to avoid SPOF + for human-centered ease of restoration).

## Correct Overall Picture (Pattern that does not create SPOF)

```
[External Transaction Source] → [WN (Verification)] → [MQ (Ordering/Deduplication)] → [Witness (Immutable Log, Multiple Copies)]
                                        │
                                        └→ [DB Node Group (Each node "materializes" with local SQLite)]
                                              └→ Dashboard/Inquiry
```

### 1) **System of Record = Witness (Immutable/Replicated)**

* **Append-only audit logs** (JSONL/Merkle) are **broadcast to multiple nodes**, and **content hashes** guarantee their identity.
* **Daily/hourly Merkle Roots** are issued, and **root hash consistency** is audited between different nodes (= **consistency is guaranteed by the "log"**).

### 2) **SQLite is a "Materialized View" (Independent for each node)**

* Each DB node **materializes** to its **local SQLite** on its own.

  * Example: `ingest → dedup(tx_hash) → index generation`
* If a node is damaged, it can be **rematerialized from the Witness**, and **neither a shared disk nor a complex distributed RDBMS is required**.
* Therefore, **SQLite itself does not become a SPOF** (**not shared** / **can be regenerated**).

### 3) **Means of Consistency**

* **The unit of consistency is the "immutable log," not the "ledger state"**:

  * **Exactly-Once compliance**: `idempotency_key = tx_hash(+epoch)`
  * The same materialization result is obtained **deterministically** in the order of **WN (Verification) → MQ (Ordering/Deduplication) → Witness (Final Storage)**.
* **Difference detection**: Compare the **daily Roots** of multiple DB nodes, and if there is a discrepancy, proceed to the **rematerialization SOP**.

## Concrete SQLite Operation (Safe Preset)

* `PRAGMA journal_mode=WAL;`
* `PRAGMA synchronous=FULL;`
* `PRAGMA busy_timeout=5000;`
* `VACUUM` with day-of-the-week rotation (outside of audit execution time)
* **Writing is done by each node independently** (shared NFS/SMB prohibited)
* **Backup is for "reference" with rsync** (SPOF countermeasures are realized by Witness resynchronization)

## If a "Single Logical Account" is Strongly Required

* This is **outside the scope of requirements** as it exceeds the role of CLEAR, but if it is unavoidable:

  * **Shard (account_id hash) × Replica set (3) × 1 writer election** (simple Raft/quorum signature)
  * However, this would **"turn the audit system into an execution system,"** and **costs and complexity would skyrocket.**
  * **Not recommended** (CLEAR is a **mirror of external truth**, and it is consistent with the design philosophy for the execution system to remain external).

## Minimum Difference to be Added to the Document

* Clearly state that **"SQLite is not shared. Each node is independent. Rematerialization from Witness is possible = no SPOF."**
* Clearly state with a diagram that **"System of Record is Witness,"** and SQLite is a **"Materialized View."**
* Attach the procedure for **daily Root (Merkle) collation** and the **rematerialization SOP**.
* Specify the **exactly-once (idempotency)** key design in MQ (`tx_hash(+epoch)` + 2-of-3 approval).

---

### Summary

* Gemini's concern is based on the **"assumption of using SQLite as a shared DB,"** but the correct answer for CLEAR is **"independent SQLite for each node + immutable Witness = reproducible materialization."**
* Therefore, following the **elimination of SPOF in KMS**, **there is no SPOF in the DB layer** (avoided by the "do not share" design).
* If necessary, I can also provide a template (CLI) for the **Witness → SQLite rematerialization tool** right away.
