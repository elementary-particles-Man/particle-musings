# 日本標準電子インボイス（JP PINT）仕様概要とAI-TAX実装指針

## 1. 概要
日本政府は、インボイス制度（2023年10月施行）への対応として、**JP PINT (Japan Peppol Invoice Notation Template)** を「標準電子インボイス」として採用しています。開発・管理主体は**デジタル庁および電子インボイス推進協議会（EIPA）**で、国際標準 Peppol BIS Billing 3.0 を日本仕様に適合させたものです。

JP PINT は XML (UBL 2.1) 構造を採用し、**Peppol ネットワーク**経由で企業間請求情報を安全かつ相互運用的に交換することを目的とします。2025年5月28日時点の最新版は **v1.1.1** です。

---

## 2. 構成要素（Peppol UBL準拠）
| 要素 | 内容 | 必須 | AI-TAX対応フィールド |
|-------|------|------|----------------|
| AccountingSupplierParty | 発行者情報（名称・所在地・T番号） | ✔ | issuer.name / issuer.tax_id |
| AccountingCustomerParty | 受領者情報（名称・所在地） | ✔ | receiver.name |
| InvoiceLine | 品目行（品目名・数量・単価・税率区分） | ✔ | items[n] |
| TaxTotal / TaxSubtotal | 税率ごとの小計・合計 | ✔ | tax[rate].amount |
| LegalMonetaryTotal | 総合計額 | ✔ | totals.amount |
| PaymentMeans / PaymentTerms | 支払手段・期日 | 任意 | payment.method / due_date |
| Note / AdditionalDocumentReference | 備考・添付文書 | 任意 | meta.notes |

---

## 3. 技術仕様
- **データ形式:** XML (UBL 2.1)
- **通信方式:** AS4 (Peppol仕様)
- **識別子:** T＋13桁の登録番号、Peppol Participant ID
- **バージョン管理:** schemaVersion="1.1.1"
- **署名方式:** XAdES-BES / Peppolセキュリティポリシー準拠
- **コード体系:** 日本独自コード（JP Code List）＋UN/ECE共通コード体系

---

## 4. 実装指針（AI-TAX/CLEAR-TAX統合）
1. **送受信レイヤー**: Peppol Access Point を介して送受信。AI-TAXは内部でJSONへ正規化して処理。
2. **正規化ルール**: UBL要素を AI-TAX 標準キーにマッピング（上表参照）。
3. **署名・検証**: T番号整合性とXAdES署名検証をWitnessログに記録。
4. **保存**: 電子帳簿保存法対応。XML原文＋正規化JSON＋検証ログを7年間保持。
5. **UI連携**: CLEARノードのメトリクス画面から請求一覧・状態をリアルタイム可視化。
6. **互換性**: JP PINT v1.0系XMLも後方互換モードで受理（schemaVersion判定）。

---

## 5. 管理運営体制
- **仕様策定:** デジタル庁・電子インボイス推進協議会（EIPA）
- **運用基盤:** Peppol Authority Japan（JPA）
- **サンドボックス:** Peppol Japan テストネットワーク (https://test.peppol.jp)
- **参照:** https://www.digital.go.jp/policies/invoice/

---

## 6. AI-TAX内での扱い
- JP PINTデータは `invoice.source = "jp_pint"` として識別。
- AI-TAXでは、JP PINTを**一次データ（法的原本）**として扱い、内部計算値は再構成値としてラベル付け。
- 電子・紙インボイスを問わず、6要件を満たせば適格請求書として扱うが、JP PINT形式は自動適格化（AI-TAX内部判定フラグ `is_certified=true`）。

---

## 7. 実装KPI
| KPI | 内容 | 目標値 |
|------|------|--------|
| jp_pint_integration_rate | JP PINT形式で受領・送信された請求書比率 | ≧80% |
| validation_latency_ms | JP PINT署名・T番号検証平均遅延 | ≤2000ms |
| witness_log_integrity | 検証ログ完全性（改ざんなし） | 100% |
| backward_compatibility | v1.0系XMLの受理率 | ≧95% |

---

_Reference: デジタル庁・電子インボイス推進協議会 (EIPA) 『JP PINT標準仕様書 v1.1.1』（2025年5月28日）、Peppol BIS Billing 3.0、日本国税庁インボイス制度関連資料。_