# CSI-N TPM Handshake Protocol v1.0

## 1. 目的

本ドキュメントは、CSI-N (Nord daemon) と ops-daemon 間で、
**node_id と TPM フィンガープリントをバインドするハンドシェイク** を定義する。

これにより、以下を達成する:

- node_id のなりすまし防止
- TPM 情報に基づくノード真正性確認
- K_comm 配布の前提となる trust anchor の確立

## 2. 登場要素

- CSI-N:
  - config に `node_id` を持つ
  - TPM から取得したフィンガープリント (例: SHA-256 of EK/AIK public key) を `tpm_digest` として扱う

- ops-daemon:
  - 登録済みノードの `{ node_id, tpm_digest }` リストを保持
  - HB0 を受信して `node_id` と `tpm_digest` を検証

## 3. メッセージ概要

ハンドシェイクは 3 ステップで行う:

1. **HB0 (CSI-N → OPS)**: 初回ハートビートで node_id / tpm_digest / nonce_n を送信
2. **ACK0 (OPS → CSI-N)**: 検証結果・nonce 往復・鍵配布開始シグナルを返す
3. **HB1 (CSI-N → OPS)**: nonce_o の返送により、OPS 側が応答真正性を確認

その後は通常の HB/EVENT/CMD/ACK に移行する。

## JSON フォーマット（確定版）

HB0:

{
  "kind": "hb0",
  "node_id": <u32>,
  "tpm_digest": "<64-hex>",
  "nonce_n": "<32-hex>",
  "version": 1
}

ACK0:

{
  "kind": "ack0",
  "node_id": <u32>,
  "nonce_n": "<32-hex>",
  "nonce_o": "<32-hex>",
  "tpm_verified": true | false,
  "can_proceed": true | false
}

HB1:

{
  "kind": "hb1",
  "node_id": <u32>,
  "nonce_o": "<32-hex>"
}

## 4. HB0: 初回ハートビート

### 4.1 送信タイミング

- CSI-N 起動後、最初の ops 接続確立時に 1 回だけ送信する。
- 再起動時も同様に HB0 から開始する。

### 4.2 HB0 ペイロード (平文構造)

```
{
  "kind": "hb0",
  "version": 1,
  "node_id": 1234,
  "tpm_digest": "hex-encoded-32bytes",
  "nonce_n": "base64-encoded-16bytes"
}
```

- `kind`: 常に `"hb0"`
- `version`: プロトコルバージョン
- `node_id`: CSI-N の論理ノード ID
- `tpm_digest`: TPM フィンガープリント (形式は運用で統一: 例 SHA-256)
- `nonce_n`: CSI-N が生成したランダム nonce

HB0 の暗号化は以下のいずれかとする:

- v1.0 では簡易実装として **平文 + TLS/LGWAN 内**を想定
- 将来的には TPM / pre-shared key による ISE ラップも検討可能

## 5. ACK0: 検証応答 + nonce 往復

### 5.1 送信タイミング

- ops-daemon は HB0 を受信後、登録リストと照合し、ACK0 を返す。

### 5.2 登録リストの照合

ops-daemon は内部に以下のリストを持つ:

```
[
  { "node_id": 1234, "tpm_digest": "..." },
  { "node_id": 1235, "tpm_digest": "..." }
]
```

HB0 を受信したら:

- `node_id` が存在するか
- `tpm_digest` が登録値と一致するか

を検証する。

### 5.3 ACK0 ペイロード

```
{
  "kind": "ack0",
  "version": 1,
  "node_id": 1234,
  "nonce_n": "base64-encoded-16bytes",
  "nonce_o": "base64-encoded-16bytes",
  "tpm_verified": true,
  "can_proceed": true
}
```

- `kind`: 常に `"ack0"`
- `node_id`: 対象ノード ID
- `nonce_n`: HB0 で受信した `nonce_n` をそのまま返す
- `nonce_o`: ops-daemon が生成した新規 nonce
- `tpm_verified`: tpm_digest が登録値と一致した場合 true
- `can_proceed`: ハンドシェイク継続可否 (false の場合 CSI-N は接続を落とす)

`can_proceed = true` の場合のみ、以降の K_comm 配布 (CMD_SET_KEY) を行う。

## 6. HB1: 応答真正性確認

### 6.1 送信タイミング

- CSI-N は ACK0 を受信後、以下を確認する:
  - `node_id` が自ノードと一致
  - `nonce_n` が HB0 で送信した値と一致
  - `tpm_verified = true` かつ `can_proceed = true`

- 条件を満たした場合のみ、HB1 を送信する。

### 6.2 HB1 ペイロード

```
{
  "kind": "hb1",
  "version": 1,
  "node_id": 1234,
  "nonce_o": "base64-encoded-16bytes"
}
```

- `kind`: 常に `"hb1"`
- `node_id`: 対象ノード ID
- `nonce_o`: ACK0 で受信した値をそのまま返す

ops-daemon は HB1 を受信し、
node_id 一致 + `nonce_o` 一致を確認した時点で、
**この TCP コネクションが登録済みノードからの正当な接続**であるとみなす。

## ハンドシェイク条件

- CSI-N:
  1. 起動直後に HB0 を送信する。
  2. ACK0 を受信し、以下を満たした場合のみ続行する:
     - node_id が自ノードと一致する
     - nonce_n が HB0 で送った値と一致する
     - tpm_verified == true
     - can_proceed == true
  3. ACK0 の nonce_o を保持し、HB1 を送信する。
  4. HB1 送信後に "Bound" 状態へ遷移し、以降は kind="hb" の通常ハートビートループに入る。

- ops-daemon:
  - HB0 を受信した時点で接続を node_id + tpm_digest に仮バインドする。
  - ACK0 送信後、HB1 を受信した時点でその接続を node_id → connection の本バインドとする。

## 7. K_comm 配布との関係

- HB0/ACK0/HB1 が正常完了した後でのみ、`CMD_SET_KEY` による K_comm 配布を行う。
- これにより:
  - 未登録ノード
  - tpm_digest が不一致なノード
 には鍵が配布されず、以降の暗号通信も成立しない。

## 8. エラーケース

- 登録に存在しない node_id:
  - `tpm_verified = false` / `can_proceed = false` で ACK0 を返すか、接続を即時クローズ

- tpm_digest 不一致:
  - `tpm_verified = false` / `can_proceed = false` を返し、内部ログに記録

- HB1 未達 or `nonce_o` 不一致:
  - ops-daemon は接続を破棄し、ノード交換 or 攻撃の可能性として運用アラート

## 9. 実装メモ

- ops-daemon 側で `node_id → connection_id` マップを持ち、HB1 完了後に接続をバインドする。
- すでに別接続が同じ node_id で存在する場合、最新接続を優先し、旧接続を無効化する。

## エラー・リトライ

- CSI-N 側でのエラー条件:
  - ACK0 未達 (タイムアウト)
  - node_id 不一致
  - nonce_n 不一致
  - tpm_verified == false
  - can_proceed == false

- これらのいずれかの場合:
  - SafeMode を有効化し、ログに理由を出力する。
  - 一定時間 (例: 30 秒) 待機後、HB0 からリトライする。
  - リトライ回数 (例: 3 回) を超えた場合は SafeMode のまま待機し、ops の介入を待つ（将来 CMD_RESET_HANDSHAKE 等で対応）。
