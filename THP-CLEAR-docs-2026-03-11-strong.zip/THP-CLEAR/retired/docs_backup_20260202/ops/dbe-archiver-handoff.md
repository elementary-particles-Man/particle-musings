# THP-CLEAR dbe-archiver Ops & QA Hand-off (with CSI Coordination) — 2025-11-09+coord

## 1. Prerequisites

### Packages
- tpm2-tools (tpm2_unseal, tpm2_pcrread)
- mt-st plus lto-cm or ltfs per environment
- zfsutils-linux
- bash, coreutils, tar, curl

### Kernel Modules & Devices
- Load `zfs`
- TPM 2.0 exposed (`/dev/tpm0`, `/dev/tpmrm0`)
- LTO drive (`/dev/nst0`)

## 2. Filesystem Layout
- Binary: `/usr/local/bin/dbe-archiver`
- Config: `/etc/thp-clear/dbe-archiver.yaml`
- Logs: `/var/log/thp/dbe-archiver/`
- State (stage, replay, coord cache): `/var/lib/thp/dbe-archiver/`

## 3. Systemd Units

### Service
```
[Unit]
Description=THP-CLEAR DBE Archiver
After=network-online.target zfs-mount.service

[Service]
Type=simple
User=root
Group=root
ExecStart=/usr/local/bin/dbe-archiver run -config /etc/thp-clear/dbe-archiver.yaml
Restart=on-failure
RestartSec=5s
AmbientCapabilities=CAP_SYS_RAWIO

[Install]
WantedBy=multi-user.target
```

### Timer
```
[Unit]
Description=THP-CLEAR DBE Archiver (schedule)

[Timer]
OnBootSec=2m
OnUnitActiveSec=15m
AccuracySec=1m
Persistent=true

[Install]
WantedBy=timers.target
```

### Enablement
1. `install -m644 packaging/dbe-archiver.service /etc/systemd/system/`
2. `install -m644 packaging/dbe-archiver.timer /etc/systemd/system/`
3. `systemctl daemon-reload`
4. `systemctl enable --now dbe-archiver.timer`

## 4. Sample Configuration (excerpt)
```
zfs:
  pools: ["tank", "data"]
  thresholds:
    warn_pct: 85
    archive_pct: 90
scan:
  globs: ["/zfs/*/witness/**", "/zfs/*/audit/**"]
  exclude: ["**/.staging/**", "**/.tmp/**"]
stage:
  dir: /var/lib/thp/dbe-archiver/stage
  tar_chunk_mb: 1024
flatten:
  enabled: true
  mode: "tar"
  keep_source: false
tpm:
  required: true
  pcrs: [7]
  unseal_key_handle: 0x81000001
  pcr_policy_file: /etc/thp-clear/pcr-policy.json
lto:
  backend: "ltfs"
  device: /dev/nst0
  mount_point: /mnt/ltfs
  label_prefix: CLEAR
  verify: "sampling"
coord:
  base_url: http://csi.internal:8080
  op_kind: "dbe-archiver"
  pause_reason: "DBE archival maintenance"
  timeout_ms: 5000
  retry:
    max_attempts: 5
    initial_ms: 200
    max_ms: 3000
    jitter: true
  witness:
    enabled: true
    endpoint: http://witness.internal:8080/events
    api_key_file: /etc/thp-clear/witness.key
witness:
  url: http://csi.internal:8080/witness
  api_key_file: /etc/thp-clear/witness.key
  replay_dir: /var/lib/thp/dbe-archiver/replay
telemetry:
  listen: ":9188"
  labels: { node_class: "DBE", site: "tokyo-1" }
dry_run: false
```

## 5. Run Modes / CLI
- Dry-run daemon: `dbe-archiver run -config /etc/thp-clear/dbe-archiver.yaml -dry-run`
- Single shot: `dbe-archiver once -config /etc/thp-clear/dbe-archiver.yaml`
- Threshold simulation: `dbe-archiver simulate -config /etc/thp-clear/dbe-archiver.yaml -pool tank -pct 92`
- LTO status: `dbe-archiver ltostatus -device /dev/nst0`

## 6. Smoke Tests
1. `zpool list && zfs list`
2. `tpm2_pcrread sha256:7`
3. `curl -fsS localhost:9188/metrics | head -n 20`
4. `curl -fsS http://csi.internal:8080/health || true`

## 7. End-to-End Scenarios

### CSI 協調の正道
- Execute: `dbe-archiver simulate ... -pool tank -pct 92`
- Expect:
  - `coord.begin → coord.pause → (archival) → coord.resume → coord.end` all return 2xx.
  - Witness logs Maintenance/Paused/Running in order.
  - Metrics show `dbe_archiver_coord_calls_total{verb}` increments.

### LTO 失敗でも Running へ戻す
- Prep: disconnect or busy the LTO device.
- Execute: `dbe-archiver once ...`
- Expect: cycle fails with `E_LTO_WRITE`, but `coord.resume/end` still run, CSI finishes in Running, payload queued for replay.

### CSI 503 / バックオフ検証
- Prep: force CSI to reply 503.
- Execute: `dbe-archiver once ...`
- Expect: exponential retries (max attempts) then `E_COORD_*` surfaced; `dbe_archiver_errors_total{class="coord"}` increments.

## 8. Metrics
- Endpoint: `http://<node>:9188/metrics`
- Watch:
  - `dbe_archiver_runs_total`
  - `dbe_archiver_errors_total{class}`
  - `dbe_archiver_zfs_usage_pct{pool}`
  - `dbe_archiver_lto_bytes_written_total`
  - `dbe_archiver_replay_queue_depth`
  - `dbe_archiver_tpm_unseal_total`
  - `dbe_archiver_coord_calls_total{verb}`
  - `dbe_archiver_coord_failures_total{verb,code}`

## 9. Guardrails & Risks
- Never touch ZFS payloads unless `coord.begin` and `coord.pause` have succeeded.
- Flatten is plaintext TAR only; encryption, if any, must be handled by LTO hardware.
- LTO encryption keys reside with ops; archiver never stores them.
- Align ZFS snapshot/retention rules before enabling automated cleanup.
- Risks:
  - CSI/Witness misconfiguration → `E_COORD_*`. Validate base_url/endpoints first.
  - Missing TPM/LTO tooling → `E_TPM_UNSEAL` / `E_LTO_WRITE`.
  - Snapshot governance gaps could block cleanup.

## 10. CI / Build Notes
- Lint/test: `go vet ./cmd/dbe-archiver ./internal/...` and `go test ./cmd/dbe-archiver ./internal/... -run Test -v`.
- Container build: `docker build -t thp/dbe-archiver:$(git rev-parse --short HEAD) -f packaging/Dockerfile.dbe-archiver .`
- Sample container run: `docker run --rm --privileged --device /dev/tpm0 --device /dev/nst0 -v /etc/thp-clear:/etc/thp-clear thp/dbe-archiver:TAG run -config /etc/thp-clear/dbe-archiver.yaml -dry-run`
- Build isolation: `go test ./...` fails on other modules (`-lclear_encryptor`). Scope CI to archiver packages or gate encryptor code with `//go:build encryptor`.

## 11. Rollback
1. `systemctl stop dbe-archiver.timer`
2. `systemctl disable dbe-archiver.timer`
3. `systemctl stop dbe-archiver.service || true`
4. `rm -f /etc/systemd/system/dbe-archiver.service`
5. `rm -f /etc/systemd/system/dbe-archiver.timer`
6. `rm -f /usr/local/bin/dbe-archiver`

## 12. Status
- Handoff status: **ready-for-ops**
- Ensure CSI base URL, Witness endpoint, TPM/LTO tooling, and ZFS policies are validated before enabling the timer.
