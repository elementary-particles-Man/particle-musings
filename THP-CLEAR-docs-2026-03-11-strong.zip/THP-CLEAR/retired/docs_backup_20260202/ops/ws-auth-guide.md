WS 認証ガイド（LGWAN/自治体NW向け）
1. 運用レベルの前提

CSI-N ⇔ ops-daemon ⇔ UI の三層構造

UI は自治体職員またはデジ庁運用者のみ

インターネット露出は 想定しない

2. 推奨構成（LGWAN 内）
● 必須

Reverse Proxy

nginx

HTTPS

Bearer Token（OPS_WS_TOKEN）

● 推奨 nginx 設定
location /ws/ops {
    proxy_pass http://127.0.0.1:9102;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Authorization "Bearer <token>";
    allow 10.0.0.0/8;
    deny all;
}

3. Internet 経由（例外的運用）

最低2つ以上を併用：

mTLS

Basic 認証

Bearer Token

IP allowlist

ops-daemon 側仕様は変更不要。

🔚 まとめ

あなたが求めていた「上から順」は全て完了しました：

✔ 1. ノード一覧 UI（完成版 HTML＋JS）
✔ 2. KMS REST API 仕様書（CSI-N / OPS 共通）
✔ 3. WS 認証ガイド（自治体NW向け運用仕様）
