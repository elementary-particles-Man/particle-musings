
## 1. THP-CLEAR CSI-N / OPS 通信・OPS運用仕様書 v1.0（ドラフト）

以下はそのまま `docs/ops-spec-v1.md` みたいなファイルにできる体裁にしてあります。

---

### 1. 概要

本仕様書は、THP-CLEAR における **CSI-N（Nord）と CSI-OPS（Ops UI デーモン）間の通信仕様**および、OPS Web UI の基本要件を定めるものです。

前提：

- 通信は **固定長 900 バイトの平文フレーム**を AES-GCM で暗号化し、  
  **wire 上は 12(NONCE)+900(CT)+16(TAG)=928 バイト固定**とする。
    
- 内部処理は **数値のみ**を扱い、文字列は扱わない。
    
- 人間向けの文字列（ノード名・状態名・説明文等）は、**別途 JSON の翻訳テーブル**として平文保持し、UI レイヤでのみ使用する。
    
- 暗号化・真正性は既存の **AES-GCM** と **軽量 ISE（XOR+ビットシフト）** を用いる。

※ 鍵は ops-daemon が KMS から取得し、初期ハンドシェイクで各 CSI-N に配布する。CSI-N は KMS に直接アクセスしない。
    

---

### 2. 役割と範囲

- **CSI-N（Nord）**  
    各 CLEAR ノード上で動作する常駐プロセス。  
    ノード状態監視・負荷制御・SafeMode 遷移・OPS への通知を担う。
    
- **CSI-OPS（Ops デーモン）**  
    デジ庁等の運用端末上で動作。  
    Nord からのフレームを受信し、
    
    - 状態監視
        
    - アラート通知
        
    - 手動 SafeMode / Resume / メンテナンスコマンド発行  
        を行う。Web UI のバックエンドでもある。
        
- **OPS Web UI**  
    ブラウザからアクセスする運用画面。  
    CSI-OPS が提供する HTTP / WebSocket API を通じて、  
    ノード状態の可視化と操作を行う。
    

---

### 3. フレームフォーマット（平文 900 bytes 固定、暗号 928 bytes 固定）

全ての CSI-N ⇄ CSI-OPS 間通信は、以下の **固定長バイナリフレーム**（平文 900B）とする。  
wire では AES-GCM で暗号化し、`NONCE(12B) + CIPHERTEXT(900B) + TAG(16B) = 928B` を固定長とする。

```
+----------------+----------------------+-----------------------+
| HEADER (16B)   | PAYLOAD (<= 800B)   | PADDING (0x00)        |
+----------------+----------------------+-----------------------+
        ↑                        ↑                  ↑
     固定長                     可変長           900 に調整
```

#### 3.1 HEADER（16 bytes）

|Offset|Size|型|説明|
|---|---|---|---|
|0|1|u8|version（現行 1）|
|1|1|u8|type（1=HB, 2=EVENT, 3=CMD, 4=ACK）|
|2|2|u16|reserved（0 固定、将来拡張用）|
|4|4|u32|node_id（数値化したノードID）|
|8|4|u32|timestamp（UNIX epoch 秒）|
|12|4|u32|payload_size（後続 payload のバイト長）|

※実装はリトルエンディアンで格納（Rust 実装に合わせる）。

#### 3.2 PAYLOAD（最大 ~800 bytes）

type ごとに異なる構造を持つ。  
いずれも「数値＋短い JSON 断片（任意）」で構成される。

パディングは全て 0x00 で埋め、**AES-GCM + ISE 適用後も 1,024 bytes 固定を維持**する。

---

### 4. Heartbeat フレーム（type=1, Nord→OPS）

**目的**：ノードの概要状態の定期報告（数秒〜十数秒間隔）。

#### 4.1 HeartbeatPayload 構造

```text
struct HeartbeatPayload {
    u8  node_state;      // 1=Normal,2=Warning,3=Degraded,4=Panic,5=SafeMode
    u8  cpu_state;       // 1=Normal,2=High,3=Critical
    u8  queue_state;     // 1=Normal,2=Slow,3=Stop
    u8  zfs_state;       // 1=Healthy,2=Degraded,3=Faulted

    u8  proc_critical_down;     // 0/1
    u8  proc_noncritical_down;  // 0/1
    u16 queue_depth;            // 0〜65535

    u32 uptime_sec;

    u8  reserved[8];            // 将来拡張用（現状 0）

    u8  json_ref_size;          // 0〜127
    u8  json_ref[json_ref_size];// 任意 JSON（UTF-8、平文）
}
```

- `json_ref` は人間向けの補助情報（例：簡単な説明）を入れてもよいが、**必須ではない**。
    
- 多言語化は別ファイルの翻訳辞書を使うため、ここは基本的に空で良い。
    

---

### 5. Event フレーム（type=2, Nord→OPS）

**目的**：個別の異常・遷移イベントの通知。

#### 5.1 EventPayload 構造

```text
struct EventPayload {
    u8  event_type;   // 1=critical_down,2=noncritical_down,3=zfs_degraded,4=zfs_faulted,
                      // 5=cpu_critical,6=queue_stop,7=enter_panic,8=enter_safe_mode
    u8  role;         // 1=core,2=aux,3=bulk,4=tax,5=archiver
    u16 process_id;   // startup_scanner が採番した index

    u32 extra_value;  // 例: CPU load * 10000, queue_depth 等、event_typeに依存

    u8  json_ref_size;
    u8  json_ref[json_ref_size];
}
```

- `json_ref` には、process 名や簡単な reason を JSON で置くことも可能だが、  
    **翻訳/表示は基本的に外部 JSON 辞書で行う前提**。
    

---

### 6. Command フレーム（type=3, OPS→Nord）

**目的**：運用者によるノード制御指示。

```text
struct CommandPayload {
    u8  cmd;       // 1=resume,2=status,3=exec_sh,4=exec_term,5=safe
    u8  flags;     // bit0: force, 他 reserved
    u16 arg_len;   // 引数部のバイト長
    u8  arg_bytes[arg_len];
}
```

- `exec_sh`：arg_bytes にシェルスクリプト（またはスクリプト識別子）をバイト列として格納。
    
- `exec_term`：ターミナルセッションID等を格納（疑似SSH用、証跡は ops 側テキストログ）。
    
- `status`：応答として status を返す（Event or Heartbeat で返す設計とする）。
    

---

### 7. ACK フレーム（type=4, OPS→Nord）

**目的**：受信確認と OPS 正当性の簡易証明。

```text
struct AckPayload {
    u8  ok;            // 1=success, 0=error
    u8  received_type; // 1=HB,2=EVENT,3=CMD
    u16 reserved;      // 0
    u32 received_ts;   // 受信時刻
    u8  sig256[32];    // ISE 由来の簡易ハッシュ/タグ
}
```

Nord は `sig256` を ISE 検証し、  
**「既知の OPS からの ACK かどうか」**のみ判定する。

---

### 8. NodeState と SafeMode ポリシー（サマリ）

NodeState の定義：

- 1: Normal
    
- 2: Warning
    
- 3: Degraded
    
- 4: Panic
    
- 5: SafeMode
    

遷移ルール：

---

### 9. 暗号キーとワイヤサイズ / KMS 連携

- 平文フレームは **900 bytes 固定**。AES-GCM の nonce 12B とタグ 16B を付与し、wire では **928 bytes 固定**。
- AES-GCM は 256-bit キー、nonce 12B、タグ 16B。ISE タグ（sig256）は Header||payload を入力に計算。
- 鍵は ops-daemon が KMS（KeyProvider）から取得し、初期ハンドシェイクで node_id ごとの通信用鍵 K_comm を配布する。CSI-N は鍵を揮発保持し、KMS には一切アクセスしない。
- ゼロキーは **テストモードのみ** (`OPS_INSECURE_ZERO_KEY=1`) で許可。
- エンディアンは実装に合わせ **リトルエンディアン**で格納。

### AES-GCM format for CMD_SET_KEY

- key: 32 bytes
- nonce: 12 bytes (random, per message)
- cipher: variable length
- tag: 16 bytes
- wire layout: [nonce || cipher || tag] （すべて連結し、wrapped_key_b64 として base64 エンコード）

CSI-N の unwrap と ops-daemon の wrap は、このレイアウトに厳密に従う。

- `critical_down` or `zfs_faulted` or `CPU Critical + Queue Stop 継続 (15s)`  
    → Panic
    
- Panic → SafeMode：自動（safe_mode エントリスクリプト起動）
    
- SafeMode → Normal：OPS からの `cmd=resume` を受信した場合のみ
    

---

### 9. 暗号レイヤ（AES + ISE）

- **下位レイヤ**：AES-GCM でフレーム全体（HEARDER+PAYLOAD+PADDING）を暗号化
    
- **上位識別**：軽量 ISE により、
    
    - OPS 署名
        
    - Nord 署名  
        を簡易タグとして付与し、「正当な相手であること」だけを判定する。
        

実装方針：

- ISE は既存 dbd 実装の XOR + ビットシフトベースの軽量版をそのまま利用し、  
    CSI-N / OPS 用には **ラッピング関数のみ追加**。
    
- AES は既存実装（KMS / crypto ライブラリ）を利用。  
    CSI-N / OPS 側で鍵の取得・再利用のみ行う。
    

---

### 10. I18N（多言語化）の基本ルール

- バイナリフレーム上では、**文字列を扱わない**（全て数値）。
    
- 各状態・イベント・ロール等は、**コード値（u8/u16）**で表現する。
    
- 人間向け表示は、OPS Web UI 側で
    
    ```json
    {
      "node_state": { "1": "Normal", "2": "Warning", ... },
      "event_type": { "1": "Critical process down", ... }
    }
    ```
    
    のような **平文 JSON 辞書**により行う。
    
- この翻訳 JSON は、**漏洩してもリスクがない**ため暗号化不要。
    

---

### 11. ログポリシー（OPS 側）

- Nord 側は witness ログのみ（TPM + ISE で封緘）。
    
- OPS 側は以下のテキストログをローカルに保持（ローテーションで古いものから削除）：
    
    - `ops_state.log`：フレーム受信概要（数値/簡易テキスト）
        
    - `ops_event.log`：重大イベント
        
    - `ops_cmd.log`：運用者によるコマンド発行
        
    - `ops_term.log`：疑似SSHの入出力（必要に応じて）
        

OPS ログは **運用証跡用途のみ** とし、CLEAR 本体の証拠性は witness ログに依拠する。

---

### 12. 交通路・プロセス構成の前提

- CSI-N ⇄ OPS 間通信は、
    
    - Nord ノードから Ops-GW (KMS 兼用) への TCP ベースのカスタムプロトコル、または
        
    - 既存 MQ/Relay 上でブリッジする形  
        を利用する（実装詳細は CLEAR ネットワーク設計に依存）。
        
- OPS Web UI ⇄ CSI-OPS は、ローカル or VPN 経由の **HTTP + WebSocket**（JSON）で接続する。
    

---

## 2. CODEX 用 Rust 実装タスク JSON（C+B 含む）

ここは「この JSON をそのまま CODEX に投げる」想定で書きます。

```json
{
  "task": "Implement CSI-OPS binary protocol handling and AES+ISE wrapper in Rust, based on the THP-CLEAR Nord/OPS Binary Protocol v1.0. Language is Rust only (no Go).",
  "context": {
    "repo_root": ".",
    "rust_crate": "ops-daemon",
    "frame_size": 1024,
    "spec_doc": "docs/ops-spec-v1.md (THP-CLEAR CSI-N / OPS Protocol v1.0)"
  },
  "steps": [
    {
      "id": "create_crate",
      "description": "Create a new Rust crate `ops-daemon` under `rust/` (or reuse existing if already created). Set edition=2021 and depend on `aes-gcm`, `rand`, `tokio`, `tokio-tungstenite` (for WebSocket), and `serde`, `serde_json` only for WebUI JSON.",
      "files": [
        "rust/ops-daemon/Cargo.toml",
        "rust/ops-daemon/src/lib.rs",
        "rust/ops-daemon/src/main.rs"
      ]
    },
    {
      "id": "frame_structs",
      "description": "Implement binary frame structs and encode/decode functions for 1024-byte frames, using only numeric fields as per the spec.",
      "files": [
        "rust/ops-daemon/src/protocol/frame.rs"
      ],
      "details": {
        "structs": [
          "Header { version: u8, msg_type: u8, reserved: u16, node_id: u32, timestamp: u32, payload_size: u32 }",
          "HeartbeatPayload { node_state: u8, cpu_state: u8, queue_state: u8, zfs_state: u8, proc_critical_down: u8, proc_noncritical_down: u8, queue_depth: u16, uptime_sec: u32, reserved: [u8; 8], json_ref: Vec<u8> }",
          "EventPayload { event_type: u8, role: u8, process_id: u16, extra_value: u32, json_ref: Vec<u8> }",
          "CommandPayload { cmd: u8, flags: u8, arg_bytes: Vec<u8> }",
          "AckPayload { ok: u8, received_type: u8, reserved: u16, received_ts: u32, sig256: [u8; 32] }"
        ],
        "functions": [
          "fn encode_frame(header: &Header, payload: &[u8]) -> [u8; 1024]",
          "fn decode_frame(buf: &[u8; 1024]) -> (Header, Vec<u8>)"
        ]
      }
    },
    {
      "id": "aes_ise_wrapper",
      "description": "Implement AES-GCM + lightweight ISE wrapper for sending/receiving frames. Reuse existing AES/ISE implementations from the repo if present; otherwise define thin wrapper traits and leave the actual crypto to be wired later.",
      "files": [
        "rust/ops-daemon/src/crypto/mod.rs"
      ],
      "details": {
        "functions": [
          "fn seal_frame(plaintext_frame: &[u8; 1024], key_id: &str) -> Vec<u8>",
          "fn open_frame(ciphertext: &[u8], key_id: &str) -> Result<[u8; 1024], CryptoError>",
          "fn apply_ise_tag(data: &[u8], ise_key_id: &str) -> [u8; 32]",
          "fn verify_ise_tag(data: &[u8], tag: &[u8; 32], ise_key_id: &str) -> bool"
        ],
        "notes": "key_id and ise_key_id are logical identifiers; actual key lookup is delegated to KMS client in another module."
      }
    },
    {
      "id": "ops_server",
      "description": "Implement a minimal CSI-OPS daemon that listens on a TCP port for Nord frames, uses the AES+ISE wrapper to open them, maps the binary payloads into internal JSON-like structs, and publishes them to a WebUI via WebSocket.",
      "files": [
        "rust/ops-daemon/src/server/mod.rs",
        "rust/ops-daemon/src/server/tcp.rs",
        "rust/ops-daemon/src/web/mod.rs",
        "rust/ops-daemon/src/web/ws.rs"
      ],
      "details": {
        "functions": [
          "async fn run_tcp_server(bind_addr: &str)",
          "async fn handle_nord_connection(stream: TcpStream)",
          "async fn broadcast_heartbeat_to_clients(hb: HeartbeatPayload)",
          "async fn broadcast_event_to_clients(ev: EventPayload)"
        ],
        "websocket": {
          "path": "/ws/ops",
          "message_format": "JSON with numeric codes mapped to human-readable strings by the frontend using translation JSON."
        }
      }
    },
    {
      "id": "mapping_layer",
      "description": "Implement mapping from numeric payloads to internal event JSON objects for the WebUI, but do not embed any human-readable language strings; only use numeric codes and short symbolic keys.",
      "files": [
        "rust/ops-daemon/src/mapping/mod.rs"
      ],
      "details": {
        "example_json": {
          "type": "heartbeat",
          "node_id": 1234,
          "codes": {
            "node_state": 3,
            "cpu_state": 2,
            "queue_state": 1,
            "zfs_state": 1
          },
          "metrics": {
            "queue_depth": 2412,
            "uptime_sec": 1234567
          }
        }
      }
    },
    {
      "id": "tests",
      "description": "Add unit tests for frame encode/decode and basic AES+ISE wrapper behavior (mocked).",
      "files": [
        "rust/ops-daemon/tests/frame.rs",
        "rust/ops-daemon/tests/crypto.rs"
      ]
    }
  ],
  "constraints": {
    "frame": {
      "size_bytes": 1024,
      "max_payload_bytes": 800
    },
    "strings": {
      "no_strings_in_protocol": true,
      "json_ref_max_len": 127
    },
    "language": "Rust",
    "runtime": "tokio"
  }
}
```

---

## 3. OPS Web UI ワイヤーフレーム（ざっくり案）

ここは「とりあえず触ってみて調整する」前提のたたき台です。  
JS 部分と API 部分をきっちり分ける前提で書きます。

### 3.1 全体構成

- バックエンド：`ops-daemon`（Rust）
    
    - HTTP（静的ファイル配信とか最低限）
        
    - WebSocket `/ws/ops`（Nord イベントを JSON で push）
        
- フロントエンド：純粋な HTML + JS（または React/任意フレームワーク）
    
    - バックエンドの WebSocket だけを喋る
        
    - 翻訳 JSON（言語別）をクライアント側で読み込んで使用
        

### 3.2 画面1：ダッシュボード（メイン）

要素：

- 上部：フィルタバー
    
    - ノード状態フィルタ（All / Normal / Warn / Degraded / Panic / Safe）
        
    - 検索（ノードID・施設名）
        
- 中央：ノード一覧テーブル
    

|ノードID|状態|CPU|Queue|ZFS|最終HB時刻|詳細|
|---|---|---|---|---|---|---|

- 状態・CPU・Queue・ZFS は **数値コード → 翻訳 JSON** で文字列に変換して表示。
    
- 行末の「詳細」クリックで詳細画面へ。
    

### 3.3 画面2：ノード詳細

- ノードID + 施設名（CSVで紐付け）
    
- 現在の状態（大きめに表示）
    
- メトリクス
    
    - CPU 状態（バー or ラベル）
        
    - Queue深度
        
    - ZFS 状態
        
    - 稼働時間（uptime）
        
- 最近のイベント一覧（時系列）
    

|時刻|種別|詳細|
|---|---|---|

右側に操作ボタン：

- 「SafeMode へ移行」 → `cmd=safe`
    
- 「SafeMode から復帰」 → `cmd=resume`
    
- 「状態再取得」 → `cmd=status`
    
- 「メンテスクリプト実行」 → `cmd=exec_sh` + スクリプト選択
    

※ ボタン押下 → JS が JSON コマンドを作成 → WebSocket 経由で ops-daemon に送信 → ops-daemon が Command フレームに変換して Nord に送信。

### 3.4 画面3：イベントログビュー

- 全ノード横断の重大イベントの一覧。
    
- フィルタ：期間 / event_type / node_state 等
    

### 3.5 画面4：ターミナル（疑似SSH）

- 単純なフルスクリーンテキストエリア + 入力欄。
    
- 内部的には WebSocket で
    
    - UI ⇄ ops-daemon ⇄ Nord（疑似SSHプロトコル）
        
- ログは `ops_term.log` に ops-daemon 側で出力。
    
- Nord 側にはターミナルの中身は残さない。
    

### 3.6 JS / API の分離方針

- **API（Rust側）**
    
    - `/ws/ops`: WebSocket
        
        - 受信（from ops-daemon）：
            
            - `{"kind":"heartbeat", ...}`
                
            - `{"kind":"event", ...}`
                
        - 送信（from browser）：
            
            - `{"kind":"command","node_id":1234,"cmd":1,"flags":0,"args":{...}}`
                
    - `/static/*`: JS/HTML/CSS 配信のみ（ロジックは持たない）
        
- **JS（フロント側）**
    
    - `ops-protocol.js`：
        
        - WebSocket 接続管理
            
        - 受信 JSON のパース
            
        - 数値コード → 翻訳 JSON（`lang-ja.json` / `lang-en.json` 等）で文字列化
            
    - `ops-ui.js`：
        
        - DOM 操作
            
        - テーブル更新
            
        - ボタンクリック → command JSON 送信
            

→ API と表示ロジックを完全分離できます。

---

これで、

- 通信仕様（D+E）
    
- Rust 実装タスク JSON（C+B）
    
- Web UI の大枠（A）
    

まで一通り形になりました。

ここから先は：

- 仕様書をそのまま repo に置く
    
- CODEX に JSON タスクを投げて Rust 実装を生成
    
- Web UI はこのワイヤーフレームを叩き台に、実際に触ってから微調整
    

という流れで進められると思います。
