# CSI-N Key Delivery Protocol v1.0

## 1. 目的

本ドキュメントは、THP-CLEAR / ONE-CLEAR における **CSI-N (Nord daemon)** と **ops-daemon** 間の
"制御プレーン鍵" の配布方式を定義する。

- MQ-KMS (CLEAR データパス用 KMS) とは完全分離する。
- KMS クライアントを持つのは **ops-daemon のみ** とする。
- CSI-N は KMS にアクセスしない。鍵のライフサイクルは ops 側で完結させる。

## 2. 鍵の種類

鍵は機能別に以下に分離する。

### 2.1 K_comm(node_id)

- 用途: CSI-N ↔ ops-daemon 間の制御フレーム (HB/EVENT/CMD/ACK) の AES-GCM 通信用鍵
- アルゴリズム: AES-256-GCM
- 単位: node_id 単位
- 扱い:
  - 生成・保管: OPS-KMS
  - 取得クライアント: ops-daemon のみ
  - CSI-N には値を渡すが、永続化してはならない (揮発メモリのみ)

### 2.2 K_ise_ops

- 用途: ops-daemon 内での ISE タグ生成・応答署名など、OPS 側ローカルで完結する用途
- 単位: オペレータ組織単位 (例: デジ庁)
- CSI-N には渡さない。

### 2.3 K_ise_node (任意)

- 用途: node_id 固有情報の ISE タグ生成など、将来拡張用
- 必須ではないが、必要になった場合は ops-daemon 経由で配布する。

## 3. KMS (OPS-KMS) の役割

- MQ 用 KMS とは論理的・物理的に分離された **OPS 専用 KMS** を用意する。
- API は REST ベースとし、クライアントは ops-daemon のみとする。
- 例:

  - `GET /kms/key/aes?id=comm-<node_id>` → K_comm(node_id)
  - `GET /kms/key/aes?id=ise-ops` → K_ise_ops

- すべてのレスポンスは、KMS 自身の ISE 署名 (K_ise_kms) を付与してもよい (将来拡張)。

## 4. CSI-N 側の前提

- CSI-N は **KMS クライアントを持たない**。
- K_comm は以下のいずれかの方法で受け取る:
  1. 初期ハンドシェイク (TPM バインド) において ops-daemon から CMD で渡される
  2. デプロイ時に `/etc/clear/csi.key` などに TPM 由来で ISE ラップされて格納され、起動時に復号する

- 原則として (1) のオンライン配布を推奨し、(2) はオフライン運用向けの例外とする。

## 5. CMD_SET_KEY プロトコル

### 5.1 概要

ops-daemon → CSI-N に対して、制御プレーン通信用の K_comm を配布するためのコマンドフレーム。

- msg_type: `CMD`
- cmd: `SET_KEY (0x10)` を予約
- 暗号: AES-256-GCM (一時的な wrap-key を使用)

### 5.2 wrap-key

- wrap-key は以下のいずれかで構成する:
  - TPM 由来のシークレット (TPM 内部の非エクスポート秘密鍵から導出される共有シークレット)
  - デプロイ時に node 単位で設定された pre-shared key (最小運用構成)

- 本 v1.0 ではシンプルな pre-shared key 方式を採用し、TPM バインドは別ドキュメント
  (csi-n-tpm-handshake-v1.md) で段階的導入とする。

## CMD_SET_KEY ペイロード（確定）

{
  "kind": "cmd_set_key",
  "node_id": <u32>,
  "version": 1,
  "ttl_seconds": <u32>,
  "wrapped_key_b64": "<base64(AES-GCM(wrap_key, K_comm))>"
}

### CSI-N 側の処理フロー

1. 自ノードの node_id と一致するか確認し、一致しなければ無視（ログのみ）。
2. wrapped_key_b64 を base64 デコードする。
3. /etc/clear/csi.conf に格納された wrap_key (32byte) を使い AES-GCM で復号する。
4. 復号結果が 32byte であることを検証し、K_comm として揮発メモリに保持する。
5. ttl_seconds を使って有効期限 (epoch 秒) を計算し、TTL 情報として保持する（TTL 超過時の扱いは後続タスクで実装）。

### ポリシー

- K_comm はディスクに永続化しない。
- TTL を過ぎた場合は K_comm を破棄し、次の CMD_SET_KEY を待つ。
- K_comm の配布・ローテーションは ops 内の KMS で管理し、CSI-N は単純なコンシューマとする。

### Policy when K_comm is missing in Bound phase

- Production:
  - If CSI-N is in `Bound` phase but `K_comm` is `None` (no CMD_SET_KEY received or TTL expired),
    - CSI-N MUST NOT send encrypted heartbeat/events.
    - CSI-N SHOULD enter SafeMode and retry HB0/ACK0/HB1 after a backoff.

- Test (development only):
  - If environment variable `CSI_N_ALLOW_PLAINTEXT=1` is set,
    - CSI-N MAY send plaintext heartbeat/events to ops-daemon even without `K_comm`.
  - This mode MUST NOT be used in production.

### 5.4 CSI-N 側の処理フロー

1. CMD フレーム受信
2. `node_id` が自ノードと一致するか確認
3. wrap-key を使って payload を AES-256-GCM で復号
4. `k_comm` をメモリ上に展開し、以下に利用:
   - HB/EVENT フレームの AES-256-GCM 用鍵
   - ops-daemon からの CMD/ACK フレーム復号
5. `ttl_seconds` をローカルに保持し、期限が近づいたら ops に鍵更新要求 (EVENT または状態フラグ) を送信
6. 旧鍵は TTL 経過後にメモリから破棄

### 5.5 鍵ローテーション

- ローテーションは以下の手順で行う:
  1. ops-daemon が新しい K_comm' を KMS から取得
  2. CMD_SET_KEY で CSI-N に送信
  3. CSI-N が K_comm' を受信・展開（旧鍵 K_comm と並行して保持）
  4. ops-daemon と CSI-N の両者が新鍵使用を開始
  5. 猶予時間経過後、旧鍵 K_comm を破棄

- この手順により、HB や CMD/ACK の途中での鍵切り替えによる通信断を防ぐ。

## 6. エラーハンドリング

- wrap-key での復号に失敗した場合:
  - CSI-N は内部ログに記録し、ops に EVENT (key_error) を送信して鍵再配布を要求
  - `k_comm` は更新しない (旧鍵のまま運用を継続)

- node_id 不一致の場合:
  - 即座に CMD を拒否し、内部ログに記録
  - 任意で ops に EVENT (node_mismatch) を通知

## 7. セキュリティ注意事項

- wrap-key (pre-shared key) はできる限り TPM / HSM に格納し、ファイル平文保存は避ける。
- CSI-N は `k_comm` をディスクに書き込んではならない。
- OPS-KMS の鍵空間と MQ-KMS の鍵空間を混在させてはならない。
