# **THP-CLEAR 実装設計方針書（Go／Rust セグリゲーションモデル）**

## 1. 目的と背景

THP-CLEAR は、国家レベルの会計・証跡基盤として、行政職員が追跡可能なガバナンスと暗号的耐改ざん性の両立を狙うプロジェクトである。本方針書は、現行の **Go モノリシック実装** と、将来的に Rust による安全計算エンジンを分離するロードマップを統合的に管理するための基準文書である。特に以下の点を明確化する。

- 行政・監査系ユーザーに提供する Go 層の責務と公開範囲
- Rust コア（Witness／VoidCoin／E-MAD）の責務、FFI 連携ポリシー、および Go 層との境界
- 運用・DR 監視で必要となる KPI／メトリクスの統一指標

詳細な実装仕様は [`core/`](../core/README.md)、[`modules/`](../modules/README.md)、[`ops/`](../ops/README.md) を参照する。

---

## 2. 言語選定ポリシー

| 層 | 採用言語 | 運用主体 | 選定理由 |
| --- | --- | --- | --- |
| **公開 API・業務ロジック層** | Go | 行政／運用担当 | Go 標準ライブラリのみで HTTP／JSON を実装でき、`internal/` 以下のドメイン層は go doc で検証可能。CI/CD・署名ログ出力が単一言語で完結する。 |
| **安全計算コア層** | Rust (FFI 経由で Go へ提供) | THP 技術チーム | Witness 署名、VoidCoin 検証、E-MAD 倫理指標など、メモリ安全とフォールトアイソレーションが求められる。Rust → C-ABI → Go の cgo バインディングで提供する。|
| **監視・オペレーション層** | Go | SRE／DR 担当 | Prometheus／Grafana との親和性と systemd／Docker 連携を優先。Go ランタイムで `pkg/monitor` や `internal/monitoring` を直接公開する。|

> **現行実装ステータス**: Rust コアは設計段階であり、PoC は `src/` 以下の Go 実装を参照する。Rust 化に合わせて `core/` 以下で仕様と ABI を固定し、Go 層は FFI を介した呼び出しに移行する。

---

## 3. リポジトリ構成の同期

```
THP-CLEAR
├── cmd/                 # 実行バイナリ群。API（clear-api）、MQD、WND、DBD、KMSD
├── internal/            # Go ドメインロジック、HTTP ハンドラ、KeyHub、監視
├── pkg/                 # 共有ライブラリ（署名・モニタリングなど）
├── core/                # Rust コアモジュール仕様（witness / voidcoin / emad）
├── modules/             # AI-TAX・UBI・Aftermath 等の設計ガイド
├── ops/                 # KPI・DR 監視仕様と運用ガイドライン
├── configs/             # 運用設定ファイル
├── docs/                # 全体設計・運用ドキュメント
├── tests/               # Go テストコード（ユニット／統合）
└── src/                 # PoC／レガシー Go 実装（Rust 実装前の参照用）
```

- `cmd/clear-api` から `internal/httpapi` と `internal/domain` を呼び出し、Witness ログを生成する単一バイナリ構成を基本とする。
- `cmd/mqd`・`cmd/wnd`・`cmd/dbd` はマイクロサービス分割時の Go 実装。Rust コアは `core/ffi`（将来追加）経由で各デーモンから参照する。
- `src/` 以下の PoC は Rust 実装移行時のテストベッドとして維持し、差分は `core/` の仕様にマッピングする。

---

## 4. Go／Rust 分離設計の意図

1. **行政アクセスの明確化**
   - Go 層のみで API・業務ロジックの全容を go doc ベースで検証できる。
   - Rust 部分は `core/` で ABI／I/O 契約を固定し、成果物（静的ライブラリ）だけを提供する。

2. **DR（多層臨界リスク）審査の効率化**
   - DR 検証は Go 側 I/O と Rust 側出力の一致確認（Witness ハッシュ／署名）で完結。
   - E-MAD スコアなど倫理監査値は Rust 側で算出し、Go 層から Prometheus へ露出する。

3. **セキュリティと可読性の両立**
   - Rust で AES-GCM／Ed25519 等の暗号計算とハッシュチェーン整合を担保。
   - Go での疎結合構成（chi ルーター／Prometheus エクスポート）を維持し、オペレーションの簡素化を実現。

4. **モジュール境界の固定**
   - Witness／VoidCoin／E-MAD の 3 モジュールについて、I/O スキーマと責務を `core/` 内に明記し、Go 側からはインターフェース経由でのみ利用する。
   - 依存順序は「Go API → FFI ファサード → Rust コア」で一方向。Rust 側から Go ロジックを呼び出さない。

---

## 5. ビルドとデプロイ

### 5.1 Go 中心の CI/CD

- `Makefile` で `test`（`go test ./...`）、`lint`（`golangci-lint`）、`docker-build` を統合。Rust 導入後は `cargo test` を追加し、並列実行する。
- Docker イメージは Go 公式イメージをベースにした単段ビルド。Rust コア導入時はマルチステージ（Rust → Go → Debian）へ移行する。
- `ci.sh` は Go/SQLite 依存のテストを自動実行し、将来的に `cargo` ターゲットを連結する。

### 5.2 FFI ライフサイクル

1. Rust 側で `core/witness` などの静的ライブラリ (`libthp_witness.a`) をビルド。
2. `core/ffi` で C-ABI を定義し、`cmd/*` から cgo でリンク。
3. Go CI では `CGO_ENABLED=1` を明示し、Rust アーティファクトをキャッシュする。
4. DR 用バイナリは Go + Rust 署名を含む Docker イメージとして公開し、Witness ログと鍵マテリアルをホスト側へボリュームマウントする。

---

## 6. 法的・運用上の位置づけ

| 観点 | Go 層 | Rust 層 |
| --- | --- | --- |
| 法的透明性 | API・CLI の公開／監査証跡を提供。`/command` `/witness` エンドポイントで実務を説明可能。 | ソースは非公開でも、Witness ハッシュ／署名および E-MAD スコアで結果を証明。 |
| 改ざん耐性 | Witness ログの二重保存（SQLite + JSONL）と KeyHub 監査。 | 署名鍵管理、VoidCoin 検証、ハッシュチェーン生成を Rust 側で実装。 |
| 保守担当 | デジタル庁・自治体の情報システム部門。 | THP 技術チーム（Rust コア開発）。 |
| DR 対応 | `/healthz`・`/metrics` の監視、KeyHub API 経由の署名検証。 | コアライブラリの再署名・再計算テスト、FFI 契約のリグレッション。 |

---

## 7. 運用・保守ポリシー

1. **Go 層の公開方針**
   - API 仕様は `internal/httpapi` のハンドラと [`cmd/README.md`](../cmd/README.md) に集約し、GoDoc ベースで公開。
   - Witness／メトリクスは Prometheus (`pkg/monitor`) と JSONL ログで DR チームへエクスポート。

2. **Rust 層の変更管理**
   - `core/` 以下の ABI を変更する場合はメジャーリリース扱いとし、Go 層のバインディング更新とセットでリリース。
   - Witness／VoidCoin／E-MAD 以外の Rust モジュール追加は、設計審査と DR テストケース追加を必須とする。

3. **ログ・署名管理**
   - KeyHub (`internal/keyhub`) が署名 API を提供し、Go 層から Witness ペイロードのハッシュを送信。
   - 署名／公開鍵ローテーションは `/internal/kms/*` エンドポイントで管理し、Audit JSONL へ記録する。

---

## 8. 今後の展望

- **Rust コアの段階的導入**: `src/WN` の Go 実装を Rust へ移植し、FFI 経由で `core/witness` と `core/voidcoin` に統合。E-MAD 指標は Rust 側で安全計算し、`ops/kpi` に定義された指標へ出力する。
- **モジュール連携の強化**: `modules/` で整理した AI-TAX／UBI／Aftermath の設計を Go サービスに取り込み、`cmd/` 層での API を増強する。
- **教育・引継ぎ資料**: 自治体職員向けの「Go で読む THP-CLEAR」教材を `docs/` に追加し、FFI 導入後も Go 側からの可観測性を維持する。

---

## 9. 結論

> - **Go は行政と社会が触れる窓口**
> - **Rust は国家会計の「心臓」**
>
> THP-CLEAR は、Go で迅速な業務運用と監査透明性を提供しつつ、Rust で安全計算コアを強化するハイブリッド構成により、**「可読性・法的透明性・改ざん耐性」** を同時に満たす実装基盤となる。
