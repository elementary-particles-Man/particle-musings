---
機密区分: INTERNAL/WITNESS-ONLY
ページ長: 1
目的: 経営層向けサマリ
---

# THP-CLEAR エグゼクティブサマリ

## 表の顔（公開説明ハイライト）
- **透明清算基盤**: Fiat Maximum思想の下、Command→Matching→Witnessの段階処理で人道回廊・電子インボイスを可視化。【F:README.md†L6-L33】
- **APIと自動証跡**: `/command` `/settle` `/witness` が残高更新とWitnessログを自動化し、BSJ工数を削減。【F:docs/api.md†L5-L86】
- **Ops-KPI接続**: `thp_clear_*`・`witness_*` メトリクスをPrometheusで提供し、Grafanaテンプレートと直結。【F:ops/kpi/README.md†L1-L65】

## 本当の顔（内部実装ハイライト）
- **E-MAD抑止ループ**: スコア0.25超でGate-Dを閉鎖し、AftermathがWitness差分を隔離。30分以内に倫理スコアを平常化。【F:core/emad/README.md†L1-L50】【F:ops/kpi/README.md†L27-L31】【F:docs/ops.md†L59-L170】
- **ISE + KMSクォーラム**: Active/Previous/Decoy鍵と2-of-3署名束でWitness真正性を維持し、SPY(block)検知で即時鍵差替え。【F:docs/security.md†L3-L71】【F:docs/ops.md†L59-L146】
- **CLEAR-TAX統合**: JP PINT適格請求書をWitnessへ固定し、税務組戻しはMQバックプレッシャでCLEAR決済を優先。【F:docs/AI-TAX/guide/invoice_requirements_jp.md†L1-L104】【F:src/MQ/dispatcher.go†L19-L120】

## 即応アクション
1. **公開ビルド切替**: 第1章のみ抽出して外部開示。内部版はWitness鍵情報を含まず保管区を限定。
2. **Aftermath演習**: E-MAD閾値越えとSPY(block)検知の卓上演習を四半期毎に実施（RTO30分/RPO15分維持）。【F:docs/ops.md†L59-L183】
3. **JP PINT改定監視**: 国税庁更新時にマッピング差分とWitness署名証跡を照合し、API互換テストを実行。【F:docs/AI-TAX/guide/invoice_requirements_jp.md†L57-L104】

## 指標ダッシュボード（経営層ビュー）
| KPI | 目標 | トリガ | フォローアップ |
| --- | --- | --- | --- |
| `emad_violation_score` | ≤0.15 平常時 | >0.25（5分） | Aftermath即時招集 |
| `witness_append_total` | 日次更新継続 | 停止 | Witness再同期報告 |
| `kms_spy_alert_total{level="block"}` | 0/月 | 増加 | 鍵束隔離+法務報告 |
| `thp_clear_api_latency_seconds` p95 | <1s | >1s (15分) | スケールアウト決裁 |

*本サマリは内部限定。外部配布時は公開章のみ別冊化すること。*
