# CLEAR vNext — Integrated Data Schema (Freeze 2025-12)

**Status: FROZEN**  
このスキーマは CLEAR vNext Rust 実装の型定義に完全準拠し、Ledger / Witness / MQ / ID-Sync の全境界を統合的に規定する。以後の変更はマイグレーション必須。

---

## 0. 用語と原則

### 0.1 Ledger と Witness の原則
- **Ledger**: 決済の事実記録（状態遷移ログ）
- **Witness**: Ledger の不変ハッシュ（証跡ログ）

### 0.2 Stable / Void の扱い
- Stable（法定通貨相当）: **i64 (INT8)**
- Void（暗号資産相当）: **U256 ([u8; 32])**
- Stable と Void は混在しない。LedgerEntry ではどちらか一方のみが非ゼロ。

### 0.3 CLEAR-ID との結合
CLEAR vNext 本体は ID を保持しない。Ledger 書き込み直前に **ID-Sync** が以下を返す:
```json
{
  "owner_id": <i64>,
  "status": "ok"
}
```
この `owner_id` を Ledger / Witness に付加する。

---

## 1. LedgerEntry Schema (Write Path)
Rust 構造体（core-ledger/model.rs）準拠:
```rust
pub struct LedgerEntry {
    pub tx_id: String,            // 決済トランザクション一意識別子 (text)
    pub from_account: String,     // 口座ID (text)
    pub to_account: String,       // 口座ID (text)
    pub from_id: Option<i64>,     // ID-Sync結果（NULL許容）
    pub to_id: Option<i64>,

    pub stable_amount: i64,             // stable処理時のみ使用、voidの場合は0
    pub void_amount: Option<[u8; 32]>,  // void処理時のみ使用、stableの場合はNone

    pub currency_code: String,    // 3文字固定 (CHAR(3)) “JPY”, “USD”, “JPYC”, “USDT”, “VC0”, “VOID” 等
    pub nonce: i64,               // ledger内の一意性維持用nonce (BIGINT)
    pub sig: Vec<u8>,             // MQ → LedgerEntry変換時の署名
    pub metadata_json: serde_json::Value, // JSONメタ。必要に応じて空オブジェクト
}
```

### 1.1 Postgres Schema (clear_ledger_vnext)
```sql
CREATE TABLE clear_ledger_vnext (
    tx_id TEXT PRIMARY KEY,
    from_account TEXT NOT NULL,
    to_account TEXT NOT NULL,

    from_id BIGINT,
    to_id BIGINT,

    stable_amount BIGINT NOT NULL DEFAULT 0,
    void_amount  BYTEA  NOT NULL DEFAULT E'\\x00'::bytea,    -- 32 bytes

    currency_code CHAR(3) NOT NULL,
    nonce BIGINT NOT NULL,

    sig BYTEA NOT NULL,
    metadata_json JSONB NOT NULL DEFAULT '{}'::jsonb,

    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_ledger_from_account ON clear_ledger_vnext(from_account);
CREATE INDEX idx_ledger_to_account   ON clear_ledger_vnext(to_account);
CREATE INDEX idx_ledger_from_id      ON clear_ledger_vnext(from_id);
CREATE INDEX idx_ledger_to_id        ON clear_ledger_vnext(to_id);
CREATE INDEX idx_ledger_currency     ON clear_ledger_vnext(currency_code);
CREATE INDEX idx_ledger_created_at   ON clear_ledger_vnext(created_at);
```

### 1.2 不変条件（Invariant）
1. `stable_amount != 0` のとき `void_amount == 0`
2. `void_amount != 0` のとき `stable_amount == 0`
3. `from_id` / `to_id` は ID-Sync 結果による（NULL 許容）
4. `currency_code` は stable/void によって動作が分岐

---

## 2. Witness128 Schema
Rust 実装（core-witness/builder.rs）準拠:
```
struct Witness128 {
  h: [u8; 32],           // H = blake3(tx_hash || account_hash || amount_id_hash)
  tx_hash: [u8; 32],     // blake3(tx_id)
  account_hash: [u8; 32],// blake3(from_account || to_account)
  amount_id_hash: [u8; 32], // blake3(stable_amount||void_amount||currency_code||from_id||to_id)
}
```
- 全体サイズは 128 バイト。`payload` として `tx_hash || account_hash || amount_id_hash` を連結した 96 バイトを格納し、`h` は先頭32バイトに保持。tx_id の影響は tx_hash と h に吸収し、5本目のハッシュは持たない。

### 2.1 Postgres Schema (clear_witness_vnext)
```sql
CREATE TABLE clear_witness_vnext (
    h BYTEA PRIMARY KEY,               -- 32 bytes
    tx_id TEXT NOT NULL REFERENCES clear_ledger_vnext(tx_id),
    payload BYTEA NOT NULL,            -- 96 bytes: tx_hash || account_hash || amount_id_hash
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

### 2.2 不変条件
- Witness は LedgerEntry の内容に対する単方向ハッシュ
- LedgerEntry の変更は禁止（append-only）

---

## 3. MQ → LedgerEntry Mapping Schema
Stable / Void で分岐。MQ-S / MQ-C のエンドポイントは Rust vNext に実装済み。

### 3.1 Stable MQ Payload Schema
```json
{
  "tx_id": "string",
  "from_account": "string",
  "to_account": "string",
  "stable_amount": 1234,
  "currency_code": "JPY",
  "nonce": 98765,
  "sig": "base64url",
  "metadata_json": {}
}
```
変換規則: `stable_amount` をそのままセット、`void_amount = None`（DB では 0x00..00 を保存）

### 3.2 Void MQ Payload Schema
```json
{
  "tx_id": "string",
  "from_account": "string",
  "to_account": "string",
  "void_amount_hex": "64-hex-chars",   // 64 hex chars → U256
  "currency_code": "VOID",
  "nonce": 98765,
  "sig": "base64url",
  "metadata_json": {}
}
```
変換規則: `stable_amount = 0`, `void_amount = U256(void_amount_hex)`

---

## 4. ID-Sync Schema
CLEAR本体にはユーザIDデータを保持しない。ID-Sync が 口座 → CLEAR-ID を返す。

### 4.1 Request
```json
POST /sync/id
{
  "account": "JPYC:abc-123"
}
```
### 4.2 Response (mock & future)
```json
{
  "owner_id": 1234567890123,
  "status": "ok"
}
```
NULL 許容の理由: 全世界の口座を処理対象とするため、未登録口座を拒否しない。

---

## 5. End-to-End Data Flow
```
[MQ-S/MQ-C]
    → (HTTP)
        → [DBD Worker]
            → ID-Sync
            → LedgerEntry enrich (from_id/to_id)
            → Witness128 生成
            → LedgerStore.persist
            → LedgerStore.persist_witness
                → Postgres
```
このフローが vNext 正式仕様。

---

## 6. スキーマ変更ルール（不可逆）
1. LedgerEntry に互換性を壊す変更は禁止（追加は可、nullable/default 必須）
2. witness_hash のアルゴリズム変更は禁止（H, payload の構造を変えない）
3. ID-Sync の戻り値は安定的で、CLEAR-ID を後から変えない

---

## 7. Freeze バージョン
```
Schema Version: CLEAR-vNext-Freeze-2025-12
Applicable Systems:
  - core-ledger
  - core-witness
  - core-mq-s
  - core-mq-c
  - core-dbd
  - core-id-sync-mock (temporary)
```
