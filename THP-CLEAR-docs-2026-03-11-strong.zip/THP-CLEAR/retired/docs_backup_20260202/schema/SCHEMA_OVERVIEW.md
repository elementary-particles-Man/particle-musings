# 総合データスキーマ説明書（現行実装ベース）

本書は現時点の実装（Go/Rust）に存在する実データ構造をまとめたものです。ドキュメントに残っている JSON Schema（`docs/schema/*.json`）と異なる点があるため、CLEAR-ID 連携時は本書の「実装スキーマ」を優先してください。

## 1. HTTP API ペイロード（`internal/httpapi/handler.go`）

- `POST /command` リクエスト: `account_id`(string), `amount`(int64), `currency`(string), `purpose`(F/M/E), `metadata`(object, 任意), `reference`(string, 任意)  
  レスポンス: `id, account_id, amount, currency, purpose, status, requested_at` ＋任意で `metadata, settled_at, quantity, unit, witness_hash`
- `GET /command/{id}`: 上記レスポンスと同形。
- `POST /settle` リクエスト: `command_id`(string), `quantity`(float64), `unit`(string), `metadata`(object, 任意)  
  レスポンス: `command`(上記と同形) と `witness`（後述 WitnessEntry）。
- `GET /witness?limit=`: WitnessEntry 配列。
- `POST /admin/accounts`: `id, display_name, currency, balance(int64), status(active/frozen)`  
  レスポンス: 上記＋ `created_at, updated_at`
- `POST /admin/blacklist`: `account_id, reason, expires_at(RFC3339 or empty)`  
- `DELETE /admin/blacklist/{account_id}`: 成功時 `{status:"ok"}`

### ドメインモデル（`internal/domain/types.go`）
- `Account`: `id, display_name, currency, balance(int64最小単位), status, created_at, updated_at`
- `Command`: `id, account_id, amount(int64), currency, purpose(F/M/E), status(pending/settled/rejected), metadata(map), requested_at, settled_at?, quantity?, unit?, witness_hash?`
- `BlacklistEntry`: `id(int64), account_id, reason, expires_at?, created_at, active`
- `WitnessEntry`: `id(int64), command_id, payload([]byte), hash(string), previous_hash(string), signature([]byte), recorded_at`

## 2. MQ エンベロープ（`src/MQ/queue.go`）
- `QueueType`: `CLEAR` または `TAX_GOV`
- `TxPacket`: `ID`(string 任意), `Payload`([]byte; 下記 PacketCipher 352B), `Queue`(QueueType), `EnqueuedAt`, `ReadyAt`, `LastAttempt`, `Attempts`, `ReadyAt`

## 3. 決済パケット（THP v2.2, `src/model/packet_v2_2.go`）
- ワイヤ形式 `PacketCipher` 352B = `IV`(12) + `Tag`(16) + `HdrCRC`(4, Castagnoli) + `Ciphertext`(320)
- 平文 `PacketBody` 320B
  - `Header`: `TxID(u64)`, `TimestampISE(ms,u64)`, `FromID(u64)`, `ToID(u64)`, `AssetCode(u32)`, `CurrencyNum(u16)`, `Flags`(DualSign/StrictOrder), `Flags2`(bit0=Exchange), `AmountMinor(i64)`, `FeeMinor(i32)`
  - `KeyBlock`: `MgmtKeyISE[32]`, `PayKeyISE[32]`
  - `SignatureBlock`: `SigMgmt[64]`, `SigPay[64]`
  - `Control`: `H[32]` (=SHA3-256(TxID||Timestamp)), `TPMHandle[16]`, `RsvPad[16]`
- AAD: `TxID||TimestampISE||version(1B)`; 暗号は AES-256-GCM。`PacketCipher.UpdateCRC()` で CRC を付与。
- 生成器: `src/MQ/builder_v2.go` の `BuildRequest` でヘッダ値＋署名＋キー素材を入力し `Build()` が `PacketCipher` と平文 `PacketBody` を返す。

## 4. WN 側処理（`src/WN/processor_v2.go`）
- 入力: `ProcessRequest{PacketBytes(352B), AESKey[32], MgmtPublicKey?, PayPublicKey?, SeqNo, VoidRules}`
- 処理: CRC検証 → CTR preview で AAD 抽出 → GCM Open → 署名検証（任意）→ VoidCoin ルール検証 → `WitnessRecord128` 生成。

## 5. Witness 関連
- API 出力用: `internal/domain.WitnessEntry` を JSON 化したもの（`id, command_id, hash, previous_hash, recorded_at, signature, payload`）。
- JSON Schema との差異: `docs/schema/witness_log.json` は `entry_id/invoice_id/vendor_id/...` など別フォーマットで、現行実装とは非整合。
- 他の witness 定義: `src/common/witness.go` / `pkg/clear/witness_api.go` は更に別の用途（外部連携向け）でフィールドが異なる。

## 6. 既存 JSON Schema ファイル（参考・未同期）
- `docs/schema/clear_invoice.json`, `docs/schema/tax_ledger.json`, `docs/schema/witness_log.json`  
  現行コードから直接参照されておらず、実装構造とフィールドが異なる点に注意。

## 7. CLEAR-ID 連携の注意
- CLEAR-ID で参照・生成するデータは上記「実装スキーマ」を基準とし、`docs/schema/*.json` や OpenAPI (`openapi/clear-api.yaml`) にズレがある場合は実装側に合わせる。必要なら JSON Schema を実装構造へ寄せて更新する。***
