# THP-CLEAR デザイン概要

## アーキテクチャポリシー

- **単一バイナリを起点とする漸進的分割**: 現在は `cmd/clear-api` が API、キュー連携、Witness 生成を1プロセスで担います。将来的にレイテンシ要件や組織構成が変わった場合は、`cmd/mqd` `cmd/wnd` `cmd/dbd` を個別デプロイし、gRPC + NATS で連携するマイクロサービス構成へ移行できるようコードを `internal/` 配下のユースケース単位にモジュール化しています。
- **レイヤ分離**: Layer0（口座）/Layer1（Command）/Layer2（Matching）/Layer3（Witness）を明示し、各レイヤが他レイヤに直接アクセスしないようポート/アダプタパターンを採用しています。
- **公開監査可能性**: Witness ログは SQLite と JSON Lines の二重化を基本とし、署名鍵ローテーション時も `kid` をログに残して連続性を保証します。

マイクロサービス化を選択する場合は次の責務を想定しています。

| サービス | 責務 | 通信 | ディスカバリ |
|----------|------|------|---------------|
| `mqd` | API からの暗号化命令を受け取り、NATS サブジェクトに中継する。KeyRing とレート制御を保持。 | REST → NATS | 静的設定 (`configs/mq.yaml`) + Consul/etcd を将来導入 |
| `wnd` | 水平レイヤーとブロックチェーン RPC を監視し、確定トランザクションから Witness ペイロードを構築。 | NATS → gRPC | NATS チャンネルでのハートビート |
| `dbd` | Witness ペイロードの署名検証、ISE 復号、SQLite/外部DB 書き込み。 | gRPC → SQL | Kubernetes Service / Static IP |

単一バイナリ (`clear-api`) を維持する場合でも、上表の責務をパッケージとして切り出しているため、不要になった `cmd/mqd` などのプレースホルダーは移行フェーズで削除可能です。`src/` 配下の PoC は、分割移行時に参照すべき暗号ワークフローとストレージのテンプレートです。

## レイヤ構成

THP-CLEAR は以下の4レイヤで構成します。

1. **Layer0（通貨I/O）**: 円ベースの口座を主軸に、他通貨は水平ミラーとして接続。
2. **Layer1（Command）**: F/M/E（Food/Medicine/Energy）用途タグ付きの決済命令。
3. **Layer2（Matching）**: 買い手・売り手の選択を吸収しつつ、命令を正規化して約定。
4. **Layer3（Witness）**: ハッシュ鎖と署名で保全された数量ログを Append-only で公開。

各レイヤは Go サービス内で次の役割に対応します。

| レイヤ | 実装コンポーネント |
|--------|--------------------|
| Layer0 | `internal/adapters/sqlite` の口座テーブル（残高管理） |
| Layer1 | `internal/domain.Service` の Command 発行・精算ロジック |
| Layer2 | `internal/httpapi` が提供する `/command` `/settle` API |
| Layer3 | Witness ログ（SQLite + `internal/adapters/witness` ファイル出力） |

## 決済命令のデータフロー

```mermaid
sequenceDiagram
    participant C as Client (Operator UI)
    participant API as clear-api
    participant MQ as Message Queue
    participant WN as Worker Node
    participant DB as DB Adapter
    participant WL as Witness Log

    C->>API: POST /command
    API->>API: ドメイン検証<br/>残高/用途タグチェック
    API->>MQ: 暗号化 Envelope を Publish
    MQ-->>API: Ack + トレースID
    MQ->>WN: Envelope Dispatch (NATS)
    WN->>WN: ISE 復号 / EVM ファイナリティ確認
    WN->>DB: Witness Payload (gRPC)
    DB->>DB: 署名検証 / トランザクション更新
    DB->>WL: JSON Lines Append + SQLite insert
    DB-->>API: 成功レスポンス
    API-->>C: 202 Accepted
```

- **非同期処理**: API は Envelope をキューイングした段階で 202 を返却します。トレースIDで進捗を `/command/{id}` から照会します。
- **一貫性モデル**: Command テーブルと Witness ログは同一トランザクションで更新します。DB 書き込みに失敗した場合は MQ にリトライ要求を返し、Envelope を再配送します。
- **リトライ戦略**: MQ は最大 5 回まで指数バックオフで再送。WN は EVM ファイナリティが未確定の場合、`Retry-After` を添えて NATS に Nack を返す実装です。
- **ロールバック**: DB 書き込みが失敗した場合は SQLite トランザクションをロールバックし、Witness ファイルには追記しません。ファイル追記に失敗した場合は補償処理として再度 Append を試行し、最終的に失敗した場合はアラートを送出して手動復旧に切り替えます。

## 永続化・データモデル

- **accounts**: 口座ID / 表示名 / 通貨 / 残高 / 状態
- **commands**: 命令ID / 口座ID / 金額 / 用途タグ / ステータス / Witness ハッシュ
- **blacklist**: 口座ID / 理由 / 期限 / active フラグ
- **witness_entries**: Hash 鎖・署名付きの数量ログ

データベースはモジュール `modernc.org/sqlite` を利用した SQLite。単一バイナリで配布可能なため、緊急展開に向きます。

## 水平レイヤー（Horizontal Layers）

`src/WN/e20` は、EVM 互換チェーン上で発生したトークン移転を Layer0 の残高に取り込むための PoC 実装です。

- **Worker Node の役割**: `e20.Adapter` を通じて RPC エンドポイントに接続し、トランザクションハッシュの確定確認（`Confirmed`）と `Transfer` イベントの取得を行います。
- **接続方法**: HTTPS RPC または WebSocket RPC を `configs/wn.yaml` で指定します。Adapter はチェーンIDとブロック深度を持ち、ファイナリティ確認を可変にできます。
- **ファイナリティ確認**: Depth（例: 12 ブロック）を超えるまで待機し、Reorg が検出された場合は再度 `Confirmed` を照会して中断します。
- **残高反映**: 確定後に Witness ペイロードへ `source_tx`, `token_address`, `amount`, `recipient_account` を格納し、DB にポストします。

今後、水平レイヤーを追加する場合は Adapter インターフェイスを実装することで拡張できます。

## ドメインサービス

`internal/domain.Service` が決済命令・Witness 処理を一元管理します。

- 残高チェック、口座ステータス、ブラックリスト照会を行った上で命令発行。
- 精算時に Witness ペイロードを JSON 化 → SHA-256 でハッシュ化 → Ed25519 署名。
- DB トランザクションで Command 更新 + Witness 追加を原子的に実行。
- ファイルライターは WORM 的に JSON Lines で追記。

## 監視と運用

- `pkg/monitor` が Prometheus メトリクス（リクエスト件数・レイテンシ・命令数）を提供。
- API `/healthz` と別ポート `/metrics` を expose。systemd などで再起動監視が可能。
- Witness ログと署名鍵は `./data/` 以下に保存（パスは設定で変更可）。
