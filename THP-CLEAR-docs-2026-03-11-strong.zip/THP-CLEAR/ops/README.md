# THP-CLEAR Operations Overview

This directory gathers operational policies that complement the main design policy. Detailed procedures continue to live in `docs/ops*.md`; the files here normalise the KPI definitions and aftermath processes for engineering teams.

- [`kpi/README.md`](kpi/README.md): Metric catalogue for the Ops-KPI dashboard, mapped to Prometheus names exposed by Go services.
- [`aftermath/README.md`](aftermath/README.md): Recovery and replay guidance aligned with DR specifications.

Refer to `docs/ops.md` and `docs/ops_JP.md` for full runbooks. The documents under `ops/` provide concise extracts that keep the repository structure synchronised with the latest metrics and recovery strategy.

## Daily Audit

以下の手順で日次監査を実施します。

- 監査対象期間を決める（例: 前日 00:00〜23:59 UTC）。
- 監査コマンドを実行する。
- 出力JSONの `tampered` が 0 であることを確認する。

コマンド例:

```
export CLEAR_WN_ED25519_PK=<base64 public key>
export CLEAR_DB_URL=postgres://clear:clear@localhost/clear
cargo run -p core-dbd --bin audit_verify -- --start-time 2026-02-05T00:00:00Z --end-time 2026-02-05T23:59:59Z
```

`tampered` が 1 以上の場合は改ざん疑いとして扱う。

- 直ちに対象 `tx_id` を隔離（読み取り専用化）し、DBの書き込みを停止する。
- `tampered_ids` に列挙されたIDを使い、該当行を別環境へ複製して調査を開始する。
- セキュリティ担当と監査担当へエスカレーションし、再署名/復旧の可否を判断する。
