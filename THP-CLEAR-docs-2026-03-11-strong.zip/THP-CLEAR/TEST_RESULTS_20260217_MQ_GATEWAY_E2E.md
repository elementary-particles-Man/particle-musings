# TEST RESULTS 2026-02-17 MQ Gateway E2E

## 1. Scope
- Participant -> MQ `/api/v1/ingest` -> MQ zip-ISE-AES wrap -> WN -> DBD commit
- Bulk load: `scripts/run_bulk_test_20260215.sh` (4699 requests = normal 1999 + abnormal 1700 + unpredictable 1000)
- Run ID: `20260217_230452`
- Time (UTC): `2026-02-17 14:04:52` to `2026-02-17 14:06:07`

## 2. Environment applied
- MQ (`192.168.122.94`)
  - `CLEAR_PARTICIPANT_TOKEN=thp_ops_20260217_vnext`
  - `CLEAR_WN_URLS=http://192.168.122.113:39090,http://192.168.122.73:39090,http://192.168.122.133:39090`
  - `CLEAR_MQ_WN_TRANSPORT=zip-ise-aes`
  - `CLEAR_ISE_KEY_B64=dGhwaXNlMDE=`
  - `CLEAR_MQ_WN_AES_KEY_B64=MDEyMzQ1Njc4OWFiY2RlZjAxMjM0NTY3ODlhYmNkZWY=`
- WN (`192.168.122.113/73/133`)
  - `CLEAR_WN_MQ_TRANSPORT=zip-ise-aes`
  - `CLEAR_ISE_KEY_B64=dGhwaXNlMDE=`
  - `CLEAR_MQ_WN_AES_KEY_B64=MDEyMzQ1Njc4OWFiY2RlZjAxMjM0NTY3ODlhYmNkZWY=`
  - `CLEAR_WN_SIGNING_MODE=local`
- DB (`192.168.122.111`)
  - `CLEAR_WN_ED25519_PK=PM0kHP/Js2GARLl9A22GFFk9iwF8NA8d7odzOFUXZUs=`

## 3. Bulk request result
- CSV: `artifacts/bulk_test_20260215/injection_results.csv`
- HTTP code distribution:
  - `normal,202 = 1999`
  - `abnormal,202 = 1400`
  - `abnormal,422 = 300`
  - `unpredictable,202 = 651`
  - `unpredictable,400 = 349`

## 4. Ledger result
- `count_normal_bank.txt = 499`
- `count_normal_card.txt = 500`
- `count_abnormal_committed.txt = 0`
- `count_unpredictable_committed.txt = 0`
- `count_normal_evm.txt = 0`

Interpretation:
- Normal BANK/CARD commit expected counts were achieved.
- Abnormal set false commits: `0`.

## 5. Audit verify
- Command: `/usr/local/bin/audit_verify --limit 1200`
- Result: `ok=999`, `tampered=0`, `total_scanned=999`

## 6. Forensic behavior checks
- MQ log confirms encrypted forwarding:
  - `Forwarding encrypted payload to WN-xx`
- Targeted checks:
  - BANK fee > 5% case (`t-bank-fee2`): no commit observed
  - CARD clearing 116% case (`t-card-116-2`): no commit observed

## 7. Known limitation in this run
- CSI endpoint (`192.168.122.1:9108`) was unavailable after host reboot.
- Therefore `CSI Heartbeat OK` could not be re-established during this run.
- WN/DBD were run in fail-open-for-alert mode for E2E continuity; commit path and audit signature verification were validated.
