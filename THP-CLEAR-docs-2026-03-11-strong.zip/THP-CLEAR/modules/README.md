# THP-CLEAR Application Modules

This document aligns the AI-TAX, UBI, and Aftermath modules with the updated implementation policy. Each module is described in terms of its responsibility, interfaces, and dependency on the Go/Rust split defined in `docs/THP-CLEAR_Design_Policy.md`.

## Directory Map

| Module | Planned Location | Current Assets | Notes |
| --- | --- | --- | --- |
| AI-TAX | `modules/ai-tax/` (spec) + `src/tax/` (Go PoC) | `docs/AI-TAX/DR/*` (DR runbooks), `src/tax` (placeholder) | Automates tax reconciliation and fiscal reporting. |
| UBI | `modules/ubi/` (spec) + `src/ubi/` (Go PoC) | `src/ubi` (placeholder) | Distributes universal basic income envelopes and integrates with Witness logs. |
| Aftermath | `modules/aftermath/` (spec) + `ops/aftermath` (runbooks) | `ops/aftermath` | Handles post-incident replay, manual adjustments, and DR reconciliation. |

*(Subdirectories will be created as the specs are expanded; this README provides the consolidated view.)*

## AI-TAX (CLEAR-TAX)

- **Goal**: Normalize tax declarations and reconcile them against Witness-backed disbursements. Ensures every `command` settled by the core has a corresponding fiscal ledger entry.
- **Inbound interfaces**:
  - REST API extensions on `clear-api` under `/admin/tax/*` (to be implemented; will reuse `internal/httpapi` router).
  - Batch ingestion via signed CSV/JSON uploads validated against Witness hashes.
- **Outbound dependencies**:
  - Reads witness entries via `internal/domain.Service.ListWitnessEntries` to cross-reference hashed payloads.
  - Emits compliance metrics (`tax_reconciliation_gap_total`) to the Prometheus registry defined in `pkg/monitor`.
- **Rust boundary**: Calls into `core/witness` for hash verification when running in Rust mode; tax reconciliation logic remains in Go for auditor readability.
- **Artifacts**: DR playbooks stored under `docs/AI-TAX/DR/` remain the source for recovery sequences.

## UBI Module

- **Goal**: Calculate and distribute universal basic income while respecting purpose tags (F/M/E) defined in `internal/domain`.
- **Inbound interfaces**:
  - Scheduled issuance pipeline that pushes commands via the `/command` endpoint.
  - Operator console actions exposed through future `/admin/ubi/*` endpoints.
- **Outbound dependencies**:
  - Leverages the same Witness hash chain to ensure payments are immutable.
  - Consumes E-MAD scores from `core/emad` to flag anomalous distributions and throttles issuance when violations occur.
- **Data stores**: Reuses `internal/adapters/sqlite` schema; additional tables (`ubi_entitlements`, `ubi_cycles`) will be introduced under `modules/ubi/schema.sql`.

## Aftermath Module

- **Goal**: Provide tooling for incident response, backfill operations, and manual adjustments after DR events.
- **Scope**:
  - Replay Witness JSONL into SQLite using deterministic scripts (`ops/aftermath/replay.md`, to be added).
  - Coordinate with KMS audit logs to ensure signature bundles remain valid post-incident.
  - Track recovery KPIs defined in `ops/kpi/README.md` (e.g., recovery RTO, replay lag).
- **Integration**:
  - Hooks into `cmd/dbd` control endpoint (`/control/spy`) to accept incident alerts from KMS.
  - Accesses KeyHub HTTP server (`/internal/kms/*`) for key re-issuance when running manual patch jobs.

## Implementation Notes

- Each module spec will declare the APIs it introduces; these APIs must be added to `cmd/README.md` and enforced via GoDoc comments in the relevant handlers.
- Module development follows the Go-first approach for operator clarity; security-sensitive computations (hash verification, scoring) delegate to Rust modules once available.
- Dependencies between modules are acyclic: AI-TAX and UBI both depend on Witness/E-MAD, but they do not call each other.

By keeping the module responsibilities explicit here, engineering teams can evolve the Go services and future Rust components without drifting from the system-wide design policy.
